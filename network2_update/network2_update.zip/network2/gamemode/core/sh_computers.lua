NW.computers = NW.computers or {}

local CP = NW.computers

CP.kinds = {
	admin = {name = "Администрация города", short = "C24 ADMIN", color = Color(92, 168, 230),
		apps = {"docs", "mail", "citizens", "requests", "treasury", "announce", "settings"}},
	council = {name = "Совет Лоялистов", short = "C24 COUNCIL", color = Color(222, 186, 104),
		apps = {"docs", "mail", "citizens", "settings"}}
}

CP.apps = {
	docs = {name = "Документы", icon = "edit"},
	mail = {name = "Почта", icon = "talk"},
	citizens = {name = "База граждан", icon = "cid"},
	requests = {name = "Заявки", icon = "status"},
	treasury = {name = "Казна", icon = "tokens"},
	announce = {name = "Объявления", icon = "talk"},
	settings = {name = "Настройки", icon = "settings"}
}

function CP.Allowed(client, entity)
	if (!IsValid(client) or client:GetCharacterID() == 0) then
		return false
	end

	if (client:IsAdmin()) then
		return true
	end

	if (entity.ComputerKind == "admin") then
		return client:GetNW2Bool("nwCityAdmin", false) or NW.zones.UsesAlliance(client)
	end

	return client:GetNW2Bool("nwCouncil", false)
end

function CP.All()
	local out = ents.FindByClass("nw_admin_computer")

	table.Add(out, ents.FindByClass("nw_council_computer"))

	return out
end

if (SERVER) then
	util.AddNetworkString("nwComputer")

	local MAIL = "network2/computer_mail.json"

	CP.mail = util.JSONToTable(file.Read(MAIL, "DATA") or "") or {}

	local function SaveMail()
		file.CreateDir("network2")
		file.Write(MAIL, util.TableToJSON(CP.mail, true))
	end

	local function Hash(entity, password)
		return util.SHA256((entity.nwUID or "") .. ":" .. tostring(password))
	end

	local function Send(client, entity, action, data)
		net.Start("nwComputer")
			net.WriteEntity(entity)
			net.WriteString(action)
			net.WriteString(util.TableToJSON(data or {}))
		net.Send(client)
	end

	local function Notify(client, text)
		NW.Notify(client, text)
	end

	local function State(client, entity)
		local kind = entity.ComputerKind
		local mail = {}

		for index = #CP.mail, 1, -1 do
			local letter = CP.mail[index]

			if (letter.to == kind or letter.fromKind == kind) then
				mail[#mail + 1] = letter
			end

			if (#mail >= 40) then
				break
			end
		end

		local out = {name = entity.nwName, kind = kind, docs = entity.nwDocs or {}, mail = mail,
			user = client:Nick()}

		if (kind == "admin") then
			local requests = {}

			for index = #NW.requests.list, 1, -1 do
				local entry = NW.requests.list[index]

				requests[#requests + 1] = {id = entry.id, kind = entry.kind, name = entry.name, status = entry.status,
					fields = entry.fields, time = os.date("%d.%m %H:%M", entry.time or 0),
					kindName = NW.requests.kinds[entry.kind] and NW.requests.kinds[entry.kind].name or entry.kind}

				if (#requests >= 30) then
					break
				end
			end

			out.requests = requests

			local state = NW.exports and NW.exports.state

			out.treasury = state and state.treasury or 0
			out.treasuryLog = state and state.log or {}
		end

		return out
	end

	function CP.Open(client, entity)
		if (!CP.Allowed(client, entity)) then
			entity:EmitSound("buttons/button10.wav", 60)

			return Notify(client, "Доступ закрыт: компьютер — «" .. CP.kinds[entity.ComputerKind].name .. "»")
		end

		entity:EmitSound("buttons/blip1.wav", 60)

		if ((entity.nwSessions or {})[client] or (client:IsAdmin() and !entity.nwPass)) then
			entity.nwSessions = entity.nwSessions or {}
			entity.nwSessions[client] = true

			return Send(client, entity, "desktop", State(client, entity))
		end

		Send(client, entity, "login", {name = entity.nwName, kind = entity.ComputerKind, first = entity.nwPass == nil,
			admin = client:IsAdmin()})
	end

	local ACTIONS = {}

	function ACTIONS.login(client, entity, data)
		local password = tostring(data.password or "")

		if (!entity.nwPass) then
			if ((utf8.len(password) or 0) < 3) then
				return Send(client, entity, "error", {message = "Пароль — не короче 3 символов"})
			end

			entity.nwPass = Hash(entity, password)
			NW.persist.Save(entity:GetClass())
			Notify(client, "Пароль компьютера задан")
		elseif (Hash(entity, password) != entity.nwPass and !(data.admin and client:IsAdmin())) then
			entity:EmitSound("buttons/button10.wav", 60)

			return Send(client, entity, "error", {message = "Неверный пароль"})
		end

		entity.nwSessions = entity.nwSessions or {}
		entity.nwSessions[client] = true
		Send(client, entity, "desktop", State(client, entity))
	end

	function ACTIONS.refresh(client, entity)
		Send(client, entity, "desktop", State(client, entity))
	end

	function ACTIONS.doc_save(client, entity, data)
		local docs = entity.nwDocs or {}
		local title = NW.Cut(string.Trim(string.gsub(tostring(data.title or ""), "[%c]", " ")), 80)
		local body = NW.Cut(tostring(data.body or ""), 6000)

		if (title == "") then
			title = "Без названия"
		end

		local doc

		for _, entry in ipairs(docs) do
			if (entry.id == data.id) then
				doc = entry
			end
		end

		if (!doc) then
			if (#docs >= 40) then
				return Send(client, entity, "error", {message = "Не больше 40 документов"})
			end

			doc = {id = string.format("%x%x", os.time(), math.random(0, 0xffff))}
			docs[#docs + 1] = doc
		end

		doc.title, doc.body, doc.by, doc.time = title, body, client:Nick(), os.date("%d.%m.%Y %H:%M")
		entity.nwDocs = docs
		NW.persist.Save(entity:GetClass())
		Send(client, entity, "desktop", State(client, entity))
	end

	function ACTIONS.doc_print(client, entity, data)
		local doc

		for _, entry in ipairs(entity.nwDocs or {}) do
			if (entry.id == data.id) then doc = entry end
		end

		if (!doc or !NW.press) then return end

		local printer = NW.press.Nearest(entity:GetPos())

		if (IsValid(printer) and !NW.press.CanUsePrinter(client, printer)) then
			return Send(client, entity, "error", {message = "Ближайший принтер чужой: печатать на нём нельзя"})
		end

		if (!IsValid(printer)) then
			return Send(client, entity, "error", {message = "Принтер не подключён: поставьте принтер рядом с компьютером"})
		end

		local ok, why = NW.press.Print(printer, {title = doc.title, text = NW.Cut(doc.body or "", 2000), author = entity.nwName or doc.by,
			time = os.date("%d.%m %H:%M")}, data.copies)

		if (!ok) then
			return Send(client, entity, "error", {message = why})
		end

		NW.Notify(client, "Документ отправлен на печать: " .. math.Clamp(math.floor(tonumber(data.copies) or 1), 1, NW.press.maxCopies) .. " экз.")
	end

	function ACTIONS.doc_delete(client, entity, data)
		for index, entry in ipairs(entity.nwDocs or {}) do
			if (entry.id == data.id) then
				table.remove(entity.nwDocs, index)
				NW.persist.Save(entity:GetClass())

				break
			end
		end

		Send(client, entity, "desktop", State(client, entity))
	end

	function ACTIONS.mail_send(client, entity, data)
		local to = CP.kinds[data.to or ""] and data.to
		local subject = NW.Cut(string.Trim(string.gsub(tostring(data.subject or ""), "[%c]", " ")), 80)
		local body = NW.Cut(tostring(data.body or ""), 3000)

		if (!to or subject == "" or string.Trim(body) == "") then
			return Send(client, entity, "error", {message = "Укажите получателя, тему и текст"})
		end

		CP.mail[#CP.mail + 1] = {id = string.format("%x%x", os.time(), math.random(0, 0xffff)), to = to,
			fromKind = entity.ComputerKind, from = entity.nwName, by = client:Nick(), subject = subject, body = body,
			time = os.date("%d.%m %H:%M")}

		while (#CP.mail > 200) do
			table.remove(CP.mail, 1)
		end

		SaveMail()

		for _, other in ipairs(CP.All()) do
			if (other.ComputerKind == to) then
				other:EmitSound("buttons/button3.wav", 60)

				for user in pairs(other.nwSessions or {}) do
					if (IsValid(user)) then
						Send(user, other, "desktop", State(user, other))
					end
				end
			end
		end

		Send(client, entity, "desktop", State(client, entity))
	end

	function ACTIONS.mail_delete(client, entity, data)
		for index, letter in ipairs(CP.mail) do
			if (letter.id == data.id and (letter.to == entity.ComputerKind or letter.fromKind == entity.ComputerKind)) then
				table.remove(CP.mail, index)
				SaveMail()

				break
			end
		end

		Send(client, entity, "desktop", State(client, entity))
	end

	function ACTIONS.cid(client, entity, data)
		local found = NW.citizens.Find and NW.citizens.Find(data.cid)

		if (!found) then
			return Send(client, entity, "cid", {missing = true, cid = data.cid})
		end

		local file = NW.citizens.File(found)

		if (entity.ComputerKind == "council") then
			file.violations, file.log, file.wanted, file.zone = nil, nil, nil, nil
		end

		Send(client, entity, "cid", file)
	end

	function ACTIONS.req_decide(client, entity, data)
		local entry = entity.ComputerKind == "admin" and NW.requests.Get(tonumber(data.id) or 0)

		if (!entry or entry.kind != "license") then
			return Send(client, entity, "error", {message = "Здесь решаются только лицензии на торговлю"})
		end

		NW.requests.Decide(entry, data.approve == true, NW.Cut(tostring(data.reason or ""), 160),
			client:Nick() .. " (администрация)")
		Send(client, entity, "desktop", State(client, entity))
	end

	function ACTIONS.announce(client, entity)
		if (entity.ComputerKind == "admin" and NW.terminal.CanAnnounce(client)) then
			NW.terminal.Send(client, "announce_list", NULL, {list = NW.terminal.announcements})
		end
	end

	function ACTIONS.settings(client, entity, data)
		local name = NW.Cut(string.Trim(string.gsub(tostring(data.name or ""), "[%c]", " ")), 40)

		if (name != "") then
			entity.nwName = name
			entity:SetNW2String("nwComputerName", name)
		end

		if (data.newPassword and data.newPassword != "") then
			if ((utf8.len(data.newPassword) or 0) < 3) then
				return Send(client, entity, "error", {message = "Пароль — не короче 3 символов"})
			end

			if (entity.nwPass and Hash(entity, data.oldPassword or "") != entity.nwPass and !client:IsAdmin()) then
				return Send(client, entity, "error", {message = "Старый пароль неверен"})
			end

			entity.nwPass = Hash(entity, data.newPassword)

			entity.nwSessions = {[client] = true}
		end

		NW.persist.Save(entity:GetClass())
		Notify(client, "Настройки компьютера сохранены")
		Send(client, entity, "desktop", State(client, entity))
	end

	function ACTIONS.logout(client, entity)
		if (entity.nwSessions) then
			entity.nwSessions[client] = nil
		end
	end

	net.Receive("nwComputer", function(_, client)
		local entity = net.ReadEntity()
		local action = net.ReadString()
		local data = util.JSONToTable(net.ReadString() or "") or {}

		if ((client.nwComputerNext or 0) > CurTime() or !IsValid(entity) or !entity.ComputerKind or !ACTIONS[action] or
			client:GetPos():DistToSqr(entity:GetPos()) > 160 * 160 or !CP.Allowed(client, entity)) then
			return
		end

		client.nwComputerNext = CurTime() + 0.25

		if (action != "login" and !(entity.nwSessions or {})[client]) then
			return
		end

		ACTIONS[action](client, entity, data)
	end)

	timer.Create("nwComputerSessions", 2, 0, function()
		for _, entity in ipairs(CP.All()) do
			for user in pairs(entity.nwSessions or {}) do
				if (!IsValid(user) or user:GetPos():DistToSqr(entity:GetPos()) > 220 * 220) then
					entity.nwSessions[user] = nil
				end
			end
		end
	end)

	function CP.RegisterPersist(class)
		timer.Simple(0, function()
			NW.persist.Register(class, {
				Save = function(entity)
					return {uid = entity.nwUID, name = entity.nwName, pass = entity.nwPass, docs = entity.nwDocs}
				end,
				Load = function(entity, data)
					entity.nwUID = isstring(data.uid) and data.uid or entity.nwUID
					entity.nwName = isstring(data.name) and data.name or entity.nwName
					entity.nwPass = isstring(data.pass) and data.pass or nil
					entity.nwDocs = istable(data.docs) and data.docs or {}
					entity:SetNW2String("nwComputerName", entity.nwName)
				end
			})
		end)
	end

	CP.RegisterPersist("nw_admin_computer")
	CP.RegisterPersist("nw_council_computer")

	NW.AddChatCommand("council", {admin = true, run = function(client, rest)
		local target = NW.FindPlayer(rest or "")

		if (!IsValid(target) or !target.nwCharacter) then
			return Notify(client, "/council <имя> — принять в Совет Лоялистов или исключить")
		end

		local data = target.nwCharacter.data or {}

		target.nwCharacter.data = data
		data.council = !data.council or nil
		NW.char.SaveData(target)
		target:SetNW2Bool("nwCouncil", data.council == true)
		Notify(client, target:Nick() .. ": " .. (data.council and "член Совета Лоялистов" or "исключён из Совета"))
		Notify(target, data.council and "Вы приняты в Совет Лоялистов" or "Вы больше не член Совета Лоялистов")
	end})

	hook.Add("NWCharacterLoaded", "nwCouncil", function(client, character)
		client:SetNW2Bool("nwCouncil", character.data and character.data.council == true)
	end)

	return
end

local U = NW.ui

local function Fonts()
	local h = ScrH()
	local function F(name, font, size, weight)
		surface.CreateFont(name, {font = font, size = math.max(10, math.Round(h * size)), weight = weight,
			extended = true, antialias = true})
	end

	F("nwPcBig", "Oswald Medium", 0.042, 500)
	F("nwPcHead", "Montserrat SemiBold", 0.019, 600)
	F("nwPcText", "Exo 2", 0.0165, 500)
	F("nwPcMono", "JetBrains Mono Medium", 0.0135, 500)
	F("nwPcSmall", "JetBrains Mono Medium", 0.0115, 500)
end

Fonts()
hook.Add("OnScreenSizeChanged", "nwPcFonts", Fonts)

local TEXT = Color(226, 232, 238)
local MUTED = Color(130, 140, 150)
local WINDOW = Color(18, 22, 28, 248)
local BAR = Color(26, 31, 38, 255)

local function Key()
	surface.PlaySound("network2/computer/key" .. math.random(1, 8) .. ".wav")
end

local function Field(parent, value, multiline, accent)
	local entry = parent:Add("DTextEntry")

	entry:SetFont(multiline and "nwPcText" or "nwPcMono")
	entry:SetValue(value or "")
	entry:SetMultiline(multiline == true)
	entry:SetDrawLanguageID(false)
	entry.Paint = function(self, w, h)
		draw.RoundedBox(4, 0, 0, w, h, Color(10, 13, 17, 255))
		surface.SetDrawColor(accent.r, accent.g, accent.b, self:HasFocus() and 220 or 70)
		surface.DrawOutlinedRect(0, 0, w, h, 1)
		self:DrawTextEntryText(TEXT, accent, TEXT)
	end
	entry.OnKeyCodeTyped = function(self, code)
		Key()

		if (code == KEY_ENTER and !multiline and self.OnEnter) then
			self:OnEnter()
		end
	end

	return entry
end

local function Button(parent, text, onClick, color, bFilled)
	local button = parent:Add("DButton")

	button:SetText("")
	button.Paint = function(self, w, h)
		local hover = self:IsHovered() and self:IsEnabled()

		draw.RoundedBox(4, 0, 0, w, h, ColorAlpha(color, (bFilled and 170 or 30) + (hover and 60 or 0)))
		draw.SimpleText(text, "nwPcHead", w / 2, h / 2, bFilled and Color(12, 14, 18) or TEXT, TEXT_ALIGN_CENTER,
			TEXT_ALIGN_CENTER)
	end
	button.DoClick = function()
		surface.PlaySound("network2/computer/key" .. math.random(1, 8) .. ".wav")
		onClick()
	end

	return button
end

local OS = {}

local function Send(action, data)
	if (!IsValid(OS.entity)) then
		return
	end

	net.Start("nwComputer")
		net.WriteEntity(OS.entity)
		net.WriteString(action)
		net.WriteString(util.TableToJSON(data or {}))
	net.SendToServer()
end

function OS.Close()
	if (IsValid(OS.frame)) then
		OS.frame:Remove()
	end
end

local function Monitor(entity)
	OS.Close()

	local sw, sh = ScrW(), ScrH()
	local frame = vgui.Create("EditablePanel")
	local kind = CP.kinds[entity.ComputerKind] or CP.kinds.admin
	local accent = kind.color
	local bw, bh = math.Round(math.min(sw * 0.86, sh * 1.55)), math.Round(sh * 0.86)
	local bx, by = math.Round((sw - bw) / 2), math.Round((sh - bh) / 2)
	local bezel = math.Round(sh * 0.035)

	frame:SetSize(sw, sh)
	frame:MakePopup()
	frame.born = RealTime()
	frame.Paint = function(self, w, h)
		local a = math.Clamp((RealTime() - self.born) / 0.25, 0, 1)

		U.Blur(0, 0, w, h, 4, 255 * a, self, 10)
		surface.SetDrawColor(0, 0, 0, 200 * a)
		surface.DrawRect(0, 0, w, h)
		draw.RoundedBox(18, bx, by, bw, bh, Color(196, 190, 172, 255 * a))
		draw.RoundedBox(16, bx + 4, by + 4, bw - 8, bh - 8, Color(178, 172, 154, 255 * a))
		draw.RoundedBox(10, bx + bezel - 4, by + bezel - 4, bw - bezel * 2 + 8, bh - bezel * 2 + 8, Color(40, 40, 38, 255 * a))

		draw.RoundedBox(3, bx + bw - bezel * 1.4, by + bh - bezel * 0.6, 8, 6, Color(110, 230, 120, 220 * a))
		draw.SimpleText(kind.short, "nwPcSmall", bx + bezel, by + bh - bezel * 0.5, Color(90, 86, 76, 255 * a),
			TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	local screen = frame:Add("EditablePanel")

	screen:SetPos(bx + bezel, by + bezel)
	screen:SetSize(bw - bezel * 2, bh - bezel * 2)
	screen.PaintOver = function(_, w, h)
		for y = 0, h, 3 do
			surface.SetDrawColor(0, 0, 0, 22)
			surface.DrawRect(0, y, w, 1)
		end

		local edge = math.Round(h * 0.06)

		for i = 0, edge do
			local alpha = (1 - i / edge) ^ 2 * 90

			surface.SetDrawColor(0, 0, 0, alpha)
			surface.DrawOutlinedRect(i, i, w - i * 2, h - i * 2, 1)
		end
	end

	OS.frame, OS.screen, OS.entity, OS.kind, OS.accent = frame, screen, entity, kind, accent
	OS.windows = {}

	return frame, screen
end

function OS.Login(entity, data)
	local _, screen = Monitor(entity)
	local accent = OS.accent
	local w, h = screen:GetSize()
	local sh = ScrH()

	screen.Paint = function(_, pw, ph)
		draw.RoundedBox(6, 0, 0, pw, ph, Color(8, 11, 15))

		for i = 0, 6 do
			surface.SetDrawColor(accent.r, accent.g, accent.b, 6)
			surface.DrawRect(0, ph * (i / 6), pw, 1)
		end

		draw.SimpleText("C24-OS", "nwPcBig", pw / 2, ph * 0.3, accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(U.Upper(OS.kind.name) .. "  ·  " .. tostring(data.name or ""), "nwPcMono", pw / 2, ph * 0.37,
			MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(data.first and "Задайте пароль этого компьютера" or "Введите пароль", "nwPcText", pw / 2, ph * 0.45,
			TEXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

		if (OS.error and RealTime() - OS.errorAt < 3) then
			draw.SimpleText(OS.error, "nwPcText", pw / 2, ph * 0.62, Color(236, 100, 84), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	local field = Field(screen, "", false, accent)

	field:SetPos(w / 2 - sh * 0.16, h * 0.49)
	field:SetSize(sh * 0.32, sh * 0.04)
	field:RequestFocus()

	local function Enter(bAdmin)
		Send("login", {password = field:GetValue(), admin = bAdmin})
	end

	field.OnEnter = function()
		Enter(false)
	end

	local go = Button(screen, data.first and "Задать" or "Войти", function()
		Enter(false)
	end, accent, true)

	go:SetPos(w / 2 - sh * 0.16, h * 0.49 + sh * 0.05)
	go:SetSize(sh * 0.32, sh * 0.04)

	if (data.admin and !data.first) then
		local staff = Button(screen, "Войти как администратор сервера", function()
			Enter(true)
		end, MUTED)

		staff:SetPos(w / 2 - sh * 0.16, h * 0.49 + sh * 0.1)
		staff:SetSize(sh * 0.32, sh * 0.034)
	end

	local off = Button(screen, "Выключить", function()
		OS.Close()
	end, Color(236, 100, 84))

	off:SetPos(w - sh * 0.17, h - sh * 0.055)
	off:SetSize(sh * 0.15, sh * 0.036)
end

function OS.Window(id, title, ww, wh, Build)
	local screen = OS.screen
	local accent = OS.accent
	local sh = ScrH()
	local barH = math.Round(sh * 0.032)

	if (IsValid(OS.windows[id])) then
		OS.windows[id]:Remove()
	end

	local window = screen:Add("EditablePanel")
	local count = table.Count(OS.windows)

	window:SetSize(ww, wh)
	window:SetPos(math.Clamp(screen:GetWide() * 0.18 + count * sh * 0.03, 0, screen:GetWide() - ww),
		math.Clamp(sh * 0.04 + count * sh * 0.03, 0, screen:GetTall() - wh - sh * 0.05))
	window.Paint = function(self, w, h)
		draw.RoundedBox(6, 0, 0, w, h, WINDOW)
		draw.RoundedBoxEx(6, 0, 0, w, barH, OS.top == self and ColorAlpha(accent, 200) or BAR, true, true, false, false)
		draw.SimpleText(title, "nwPcHead", sh * 0.012, barH / 2, OS.top == self and Color(10, 12, 16) or TEXT,
			TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	window.OnMousePressed = function(self)
		local x, y = self:CursorPos()

		self:MoveToFront()
		OS.top = self

		if (y < barH) then
			self.drag = {x, y}
		end
	end
	window.OnMouseReleased = function(self)
		self.drag = nil
	end
	window.Think = function(self)
		if (self.drag and input.IsMouseDown(MOUSE_LEFT)) then
			local mx, my = screen:CursorPos()

			self:SetPos(math.Clamp(mx - self.drag[1], 0, screen:GetWide() - self:GetWide()),
				math.Clamp(my - self.drag[2], 0, screen:GetTall() - self:GetTall() - sh * 0.04))
		elseif (self.drag) then
			self.drag = nil
		end
	end

	local close = window:Add("DButton")

	close:SetText("")
	close:SetSize(barH, barH)
	close:SetPos(ww - barH, 0)
	close.Paint = function(self, w, h)
		draw.SimpleText("✕", "nwPcHead", w / 2, h / 2, self:IsHovered() and Color(236, 100, 84) or
			(OS.top == window and Color(10, 12, 16) or MUTED), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	close.DoClick = function()
		window:Remove()
		OS.windows[id] = nil
	end

	local body = window:Add("EditablePanel")

	body:SetPos(sh * 0.012, barH + sh * 0.012)
	body:SetSize(ww - sh * 0.024, wh - barH - sh * 0.024)
	Build(body, body:GetWide(), body:GetTall())

	OS.windows[id] = window
	OS.top = window
	window:MoveToFront()

	return window
end

local function Label(parent, text, x, y, font, color)
	local label = parent:Add("DLabel")

	label:SetPos(x, y)
	label:SetFont(font or "nwPcSmall")
	label:SetTextColor(color or MUTED)
	label:SetText(text)
	label:SizeToContents()

	return label
end

local function List(parent, x, y, w, h)
	local scroll = parent:Add("DScrollPanel")

	scroll:SetPos(x, y)
	scroll:SetSize(w, h)
	scroll:GetVBar():SetWide(4)
	scroll:GetVBar().Paint = function() end
	scroll:GetVBar().btnGrip.Paint = function(_, gw, gh)
		draw.RoundedBox(2, 0, 0, gw, gh, ColorAlpha(OS.accent, 140))
	end
	scroll:GetVBar():SetHideButtons(true)

	return scroll
end

local function Row(scroll, height, Paint, DoClick)
	local row = scroll:Add("DButton")

	row:Dock(TOP)
	row:DockMargin(0, 0, 6, 4)
	row:SetTall(height)
	row:SetText("")
	row.Paint = Paint
	row.DoClick = DoClick or function() end

	return row
end

local APPS = {}

APPS.docs = function()
	local sh = ScrH()

	OS.Window("docs", "Документы", sh * 1.0, sh * 0.58, function(body, w, h)
		local list = List(body, 0, 0, w * 0.32, h - sh * 0.05)
		local current = OS.doc and OS.doc or {}
		local title = Field(body, current.title or "", false, OS.accent)
		local text = Field(body, current.body or "", true, OS.accent)

		title:SetPos(w * 0.34, 0)
		title:SetSize(w * 0.66, sh * 0.036)
		text:SetPos(w * 0.34, sh * 0.044)
		text:SetSize(w * 0.66, h - sh * 0.1)

		for _, doc in ipairs(OS.state.docs or {}) do
			Row(list, sh * 0.05, function(self, rw, rh)
				local on = OS.doc and OS.doc.id == doc.id

				draw.RoundedBox(4, 0, 0, rw, rh, on and ColorAlpha(OS.accent, 60) or Color(255, 255, 255, self:IsHovered() and 14 or 6))
				draw.SimpleText(doc.title, "nwPcHead", rh * 0.25, rh * 0.34, TEXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText(doc.by .. " · " .. doc.time, "nwPcSmall", rh * 0.25, rh * 0.72, MUTED, TEXT_ALIGN_LEFT,
					TEXT_ALIGN_CENTER)
			end, function()
				OS.doc = doc
				APPS.docs()
			end)
		end

		local new = Button(body, "+ Новый", function()
			OS.doc = nil
			APPS.docs()
		end, OS.accent)

		new:SetPos(0, h - sh * 0.04)
		new:SetSize(w * 0.32, sh * 0.036)

		local save = Button(body, "Сохранить", function()
			Send("doc_save", {id = OS.doc and OS.doc.id, title = title:GetValue(), body = text:GetValue()})
		end, OS.accent, true)

		save:SetPos(w - w * 0.2, h - sh * 0.046)
		save:SetSize(w * 0.2, sh * 0.04)

		if (OS.doc) then
			local delete = Button(body, "Удалить", function()
				Send("doc_delete", {id = OS.doc.id})
				OS.doc = nil
			end, Color(236, 100, 84))

			delete:SetPos(w * 0.34, h - sh * 0.046)
			delete:SetSize(w * 0.16, sh * 0.04)

			local doc = OS.doc
			local printButton = Button(body, "Печать", function()
				Derma_StringRequest("Печать документа", "Сколько экземпляров (1-" .. NW.press.maxCopies .. ")? Печатает ближайший принтер.", "1",
					function(value)
						Send("doc_print", {id = doc.id, copies = tonumber(value) or 1})
					end)
			end, OS.accent)

			printButton:SetPos(w * 0.52, h - sh * 0.046)
			printButton:SetSize(w * 0.16, sh * 0.04)
		end
	end)
end

APPS.mail = function()
	local sh = ScrH()

	OS.Window("mail", "Почта", sh * 1.05, sh * 0.6, function(body, w, h)
		local list = List(body, 0, 0, w * 0.4, h)
		local letter = OS.letter

		for _, entry in ipairs(OS.state.mail or {}) do
			local incoming = entry.to == OS.state.kind

			Row(list, sh * 0.055, function(self, rw, rh)
				local on = letter and letter.id == entry.id

				draw.RoundedBox(4, 0, 0, rw, rh, on and ColorAlpha(OS.accent, 60) or Color(255, 255, 255, self:IsHovered() and 14 or 6))
				draw.SimpleText((incoming and "◀ " or "▶ ") .. entry.subject, "nwPcHead", rh * 0.2, rh * 0.34, TEXT,
					TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText((incoming and ("от: " .. entry.from) or ("кому: " .. CP.kinds[entry.to].name)) .. " · " ..
					entry.time, "nwPcSmall", rh * 0.2, rh * 0.72, MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end, function()
				OS.letter = entry
				OS.compose = nil
				APPS.mail()
			end)
		end

		local right = body:Add("EditablePanel")

		right:SetPos(w * 0.42, 0)
		right:SetSize(w * 0.58, h)

		local rw, rh = right:GetSize()

		if (OS.compose) then
			local to = OS.state.kind == "admin" and "council" or "admin"

			Label(right, "Кому: " .. CP.kinds[to].name, 0, 0, "nwPcHead", TEXT)

			local subject = Field(right, "", false, OS.accent)

			subject:SetPos(0, sh * 0.03)
			subject:SetSize(rw, sh * 0.036)

			local text = Field(right, "", true, OS.accent)

			text:SetPos(0, sh * 0.075)
			text:SetSize(rw, rh - sh * 0.13)

			local send = Button(right, "Отправить", function()
				Send("mail_send", {to = to, subject = subject:GetValue(), body = text:GetValue()})
				OS.compose = nil
			end, OS.accent, true)

			send:SetPos(rw - rw * 0.3, rh - sh * 0.046)
			send:SetSize(rw * 0.3, sh * 0.04)
		elseif (letter) then
			right.Paint = function(_, pw, ph)
				draw.SimpleText(letter.subject, "nwPcHead", 0, 0, TEXT)
				draw.SimpleText(letter.from .. " (" .. letter.by .. ") · " .. letter.time, "nwPcSmall", 0, sh * 0.026, MUTED)

				for index, line in ipairs(NW.inventory.WrapText(letter.body, "nwPcText", pw)) do
					draw.SimpleText(line, "nwPcText", 0, sh * 0.06 + (index - 1) * sh * 0.022, TEXT)
				end
			end

			local delete = Button(right, "Удалить", function()
				Send("mail_delete", {id = letter.id})
				OS.letter = nil
			end, Color(236, 100, 84))

			delete:SetPos(0, rh - sh * 0.046)
			delete:SetSize(rw * 0.25, sh * 0.04)
		end

		local new = Button(right, "Написать", function()
			OS.compose = true
			OS.letter = nil
			APPS.mail()
		end, OS.accent)

		new:SetPos(OS.compose and 0 or rw - rw * 0.3, rh - sh * 0.046)
		new:SetSize(rw * 0.3, sh * 0.04)
		new:SetVisible(!OS.compose)
	end)
end

APPS.citizens = function()
	local sh = ScrH()

	OS.Window("citizens", "База граждан", sh * 0.78, sh * 0.5, function(body, w, h)
		local field = Field(body, OS.cid and tostring(OS.cid.cid or "") or "", false, OS.accent)

		field:SetPos(0, 0)
		field:SetSize(w * 0.6, sh * 0.038)
		field:SetNumeric(true)

		local function Find()
			Send("cid", {cid = field:GetValue()})
		end

		field.OnEnter = Find

		local go = Button(body, "Найти", Find, OS.accent, true)

		go:SetPos(w * 0.62, 0)
		go:SetSize(w * 0.38, sh * 0.038)

		local card = body:Add("DPanel")

		card:SetPos(0, sh * 0.05)
		card:SetSize(w, h - sh * 0.05)
		card.Paint = function(_, cw, ch)
			local info = OS.cid

			draw.RoundedBox(6, 0, 0, cw, ch, Color(255, 255, 255, 5))

			if (!info) then
				draw.SimpleText("Введите номер CID", "nwPcText", cw / 2, ch / 2, MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

				return
			end

			if (info.missing) then
				draw.SimpleText("Номер #" .. tostring(info.cid or "?") .. " в базе не найден", "nwPcText", cw / 2, ch / 2,
					Color(236, 100, 84), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

				return
			end

			local p = sh * 0.02

			draw.SimpleText(info.name .. "  ·  #" .. tostring(info.cid), "nwPcBig", p, p, TEXT)

			local rows = {{"Статус", info.status}, {"В сети", info.online and "да" or "нет"},
				{"Очки лояльности", tostring(info.loyalty or 0)}}

			if (info.violations) then
				rows[#rows + 1] = {"Очки нарушений", tostring(info.violations)}
			end

			if (info.prison) then
				rows[#rows + 1] = {"Заключение", "осталось " .. info.prison .. " мин"}
			end

			for index, row in ipairs(rows) do
				local y = p + sh * 0.065 + (index - 1) * sh * 0.032

				draw.SimpleText(row[1], "nwPcSmall", p, y, MUTED)
				draw.SimpleText(row[2], "nwPcHead", cw * 0.42, y - 2, TEXT)
			end
		end
	end)
end

APPS.requests = function()
	local sh = ScrH()

	OS.Window("requests", "Заявки граждан", sh * 0.95, sh * 0.55, function(body, w, h)
		local list = List(body, 0, 0, w, h)

		for _, entry in ipairs(OS.state.requests or {}) do
			local row = Row(list, sh * 0.06, function(self, rw, rh)
				local color = entry.status == "pending" and Color(244, 186, 92) or (entry.status == "approved" and
					Color(110, 232, 132) or MUTED)

				draw.RoundedBox(4, 0, 0, rw, rh, Color(255, 255, 255, 6))
				surface.SetDrawColor(color)
				surface.DrawRect(0, 0, 3, rh)
				draw.SimpleText(entry.kindName .. " · " .. entry.name, "nwPcHead", rh * 0.25, rh * 0.32, TEXT, TEXT_ALIGN_LEFT,
					TEXT_ALIGN_CENTER)
				draw.SimpleText(entry.time .. " · " .. (NW.requests.statuses[entry.status] or entry.status) ..
					(entry.fields and entry.fields.title and ("  ·  «" .. entry.fields.title .. "»") or ""), "nwPcSmall",
					rh * 0.25, rh * 0.72, MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end)

			if (entry.kind == "license" and entry.status == "pending") then
				local yes = Button(row, "Одобрить", function()
					Send("req_decide", {id = entry.id, approve = true, reason = "решение администрации"})
				end, Color(110, 232, 132))
				local no = Button(row, "Отказать", function()
					Derma_StringRequest("Отказ", "Причина отказа", "", function(reason)
						Send("req_decide", {id = entry.id, approve = false, reason = reason})
					end)
				end, Color(236, 100, 84))

				row.PerformLayout = function(_, rw, rh)
					yes:SetPos(rw - rw * 0.34, rh * 0.18)
					yes:SetSize(rw * 0.16, rh * 0.64)
					no:SetPos(rw - rw * 0.17, rh * 0.18)
					no:SetSize(rw * 0.16, rh * 0.64)
				end
			end
		end
	end)
end

APPS.treasury = function()
	local sh = ScrH()

	OS.Window("treasury", "Казна города", sh * 0.7, sh * 0.5, function(body, w, h)
		local top = body:Add("DPanel")

		top:SetSize(w, sh * 0.09)
		top.Paint = function(_, pw, ph)
			draw.RoundedBox(6, 0, 0, pw, ph, ColorAlpha(OS.accent, 30))
			draw.SimpleText("В КАЗНЕ", "nwPcSmall", sh * 0.02, ph * 0.3, MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(tostring(OS.state.treasury or 0) .. " ток.", "nwPcBig", sh * 0.02, ph * 0.65, TEXT, TEXT_ALIGN_LEFT,
				TEXT_ALIGN_CENTER)
		end

		local list = List(body, 0, sh * 0.1, w, h - sh * 0.1)

		for _, line in ipairs(OS.state.treasuryLog or {}) do
			Row(list, sh * 0.034, function(_, rw, rh)
				draw.SimpleText(istable(line) and (tostring(line.time or "") .. "  " .. tostring(line.text or "")) or tostring(line),
					"nwPcMono", 4, rh / 2, TEXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end)
		end
	end)
end

APPS.announce = function()
	Send("announce")
end

APPS.settings = function()
	local sh = ScrH()

	OS.Window("settings", "Настройки", sh * 0.6, sh * 0.4, function(body, w, h)
		Label(body, "Имя компьютера", 0, 0)

		local name = Field(body, OS.state.name or "", false, OS.accent)

		name:SetPos(0, sh * 0.02)
		name:SetSize(w, sh * 0.036)

		Label(body, "Старый пароль", 0, sh * 0.07)

		local old = Field(body, "", false, OS.accent)

		old:SetPos(0, sh * 0.09)
		old:SetSize(w * 0.48, sh * 0.036)

		Label(body, "Новый пароль (пусто — не менять)", w * 0.52, sh * 0.07)

		local new = Field(body, "", false, OS.accent)

		new:SetPos(w * 0.52, sh * 0.09)
		new:SetSize(w * 0.48, sh * 0.036)

		local save = Button(body, "Сохранить", function()
			Send("settings", {name = name:GetValue(), oldPassword = old:GetValue(), newPassword = new:GetValue()})
		end, OS.accent, true)

		save:SetPos(w - w * 0.3, h - sh * 0.046)
		save:SetSize(w * 0.3, sh * 0.04)
	end)
end

function OS.Desktop(entity, state)
	local reopen = {}

	if (IsValid(OS.frame) and OS.entity == entity and OS.state) then
		for id, window in pairs(OS.windows or {}) do
			if (IsValid(window)) then
				reopen[#reopen + 1] = id
			end
		end
	end

	OS.state = state

	if (#reopen > 0) then
		for _, id in ipairs(reopen) do
			if (APPS[id] and id != "announce") then
				APPS[id]()
			end
		end

		return
	end

	local _, screen = Monitor(entity)
	local accent = OS.accent
	local sh = ScrH()
	local w, h = screen:GetSize()
	local taskH = math.Round(sh * 0.042)

	screen.Paint = function(_, pw, ph)
		for i = 0, 15 do
			local t = i / 15

			surface.SetDrawColor(10 + accent.r * 0.08 * t, 14 + accent.g * 0.08 * t, 20 + accent.b * 0.1 * t, 255)
			surface.DrawRect(0, ph * t, pw, ph / 15 + 1)
		end

		draw.SimpleText("C24-OS", "nwPcBig", pw - sh * 0.03, ph - taskH - sh * 0.05, ColorAlpha(accent, 40), TEXT_ALIGN_RIGHT,
			TEXT_ALIGN_CENTER)
		draw.SimpleText(U.Upper(OS.kind.name), "nwPcMono", pw - sh * 0.03, ph - taskH - sh * 0.02, ColorAlpha(accent, 60),
			TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)

		surface.SetDrawColor(BAR)
		surface.DrawRect(0, ph - taskH, pw, taskH)
		surface.SetDrawColor(accent.r, accent.g, accent.b, 160)
		surface.DrawRect(0, ph - taskH, pw, 1)
		draw.SimpleText(os.date("%H:%M") .. "   " .. os.date("%d.%m.%Y"), "nwPcMono", pw - sh * 0.02, ph - taskH / 2, TEXT,
			TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		draw.SimpleText((OS.state.user or "") .. "  ·  " .. (OS.state.name or ""), "nwPcSmall", pw / 2, ph - taskH / 2, MUTED,
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	local start = Button(screen, "C24-OS  ⏻", function()
		Send("logout")
		OS.Close()
	end, accent, true)

	start:SetPos(sh * 0.008, h - taskH + sh * 0.006)
	start:SetSize(sh * 0.15, taskH - sh * 0.012)

	for index, id in ipairs(OS.kind.apps) do
		local app = CP.apps[id]
		local icon = screen:Add("DButton")
		local size = math.Round(sh * 0.1)

		icon:SetText("")
		icon:SetPos(sh * 0.025, sh * 0.025 + (index - 1) * (size + sh * 0.008))
		icon:SetSize(size, size)
		icon.Paint = function(self, iw, ih)
			if (self:IsHovered()) then
				draw.RoundedBox(6, 0, 0, iw, ih, ColorAlpha(accent, 40))
			end

			local unread = id == "mail" and #(OS.state.mail or {}) > 0

			U.DrawIcon(app.icon, iw * 0.3, ih * 0.12, iw * 0.4, TEXT)

			if (unread) then
				draw.RoundedBox(4, iw * 0.66, ih * 0.1, 8, 8, accent)
			end

			draw.SimpleText(app.name, "nwPcSmall", iw / 2, ih * 0.75, TEXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		icon.DoClick = function()
			Key()
			APPS[id]()
		end
	end
end

net.Receive("nwComputer", function()
	local entity = net.ReadEntity()
	local action = net.ReadString()
	local data = util.JSONToTable(net.ReadString() or "") or {}

	if (!IsValid(entity)) then
		return
	end

	if (action == "login") then
		OS.error = nil
		OS.Login(entity, data)
	elseif (action == "desktop") then
		surface.PlaySound("buttons/button3.wav")
		OS.Desktop(entity, data)
	elseif (action == "error") then
		OS.error, OS.errorAt = data.message, RealTime()
		surface.PlaySound("buttons/button10.wav")
		NW.notify.Add(data.message or "Ошибка")
	elseif (action == "cid") then
		OS.cid = data

		if (IsValid(OS.frame)) then
			APPS.citizens()
		end
	end
end)

hook.Add("NWEscape", "nwComputer", function()
	if (IsValid(OS.frame)) then
		OS.Close()

		return true
	end
end)

hook.Add("Think", "nwComputerAway", function()
	if (IsValid(OS.frame) and (!IsValid(OS.entity) or LocalPlayer():GetPos():DistToSqr(OS.entity:GetPos()) > 200 * 200)) then
		OS.Close()
	end
end)

CP.OS = OS
