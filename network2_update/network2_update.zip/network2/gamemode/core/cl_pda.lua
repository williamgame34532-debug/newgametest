NW.pda = NW.pda or {}

local PD = NW.pda
local CI = NW.cid
local U = NW.ui

local CYAN = Color(110, 214, 245)
local DIM = Color(86, 150, 176)
local TEXT = Color(218, 244, 252)
local RED = Color(236, 100, 84)
local GREEN = Color(110, 232, 132)
local AMBER = Color(244, 186, 92)

local VERDICTS = {
	valid = {"В БАЗЕ ДАННЫХ", GREEN, "Карта настоящая и принадлежит предъявителю."},
	forged = {"НЕТ В БАЗЕ — ПОДДЕЛКА", RED, "Номера нет в базе города. Задержать. Диспетчер оповестил подразделения."},
	foreign = {"ЧУЖАЯ КАРТА", AMBER, "Карта настоящая, но выдана другому человеку."},
	none = {"CID-КАРТЫ НЕТ", AMBER, "При себе нет удостоверения гражданина."}
}

PD.history = PD.history or {}

local function Fonts()
	local h = ScrH()
	local function F(name, font, size, weight)
		surface.CreateFont(name, {font = font, size = math.max(10, math.Round(h * size)), weight = weight,
			extended = true, antialias = true})
	end

	F("nwPdaBig", "Oswald Medium", 0.04, 500)
	F("nwPdaHead", "Oswald Medium", 0.024, 500)
	F("nwPdaName", "Exo 2", 0.019, 700)
	F("nwPdaText", "Exo 2", 0.016, 500)
	F("nwPdaMono", "JetBrains Mono ExtraBold", 0.013, 800)
	F("nwPdaTiny", "JetBrains Mono Medium", 0.011, 500)
end

Fonts()
hook.Add("OnScreenSizeChanged", "nwPdaFonts", Fonts)

local function Up(text)
	return NW.terminal.Upper(tostring(text or ""))
end

local function Click()
	surface.PlaySound("network2/cmbterminal/combine_tech_click_0" .. math.random(1, 5) .. ".wav")
end

local function Button(parent, text, onClick, color)
	local button = parent:Add("DButton")

	color = color or CYAN
	button:SetText("")
	button.Paint = function(self, w, h)
		local on = self:IsEnabled()
		local hover = self:IsHovered() and on

		surface.SetDrawColor(color.r, color.g, color.b, on and (hover and 80 or 28) or 8)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(color.r, color.g, color.b, on and (hover and 255 or 160) or 40)
		surface.DrawOutlinedRect(0, 0, w, h, 1)
		draw.SimpleText(Up(text), "nwPdaMono", w / 2, h / 2, on and TEXT or DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	button.DoClick = function()
		Click()
		onClick()
	end

	return button
end

local function Field(parent, value, multiline)
	local entry = parent:Add("DTextEntry")

	entry:SetFont("nwPdaText")
	entry:SetValue(value or "")
	entry:SetMultiline(multiline == true)
	entry:SetDrawLanguageID(false)
	entry.Paint = function(self, w, h)
		surface.SetDrawColor(6, 22, 32, 230)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(CYAN.r, CYAN.g, CYAN.b, self:HasFocus() and 255 or 110)
		surface.DrawOutlinedRect(0, 0, w, h, 1)
		self:DrawTextEntryText(TEXT, CYAN, TEXT)
	end

	return entry
end

local function Near(first)
	local out = {}
	local me = LocalPlayer()

	if (IsValid(first) and first != me) then
		out[1] = first
	end

	for _, other in ipairs(player.GetAll()) do
		if (other != me and other != first and other:GetCharacterID() != 0 and other:Alive() and
			other:GetPos():DistToSqr(me:GetPos()) < 220 * 220) then
			out[#out + 1] = other
		end
	end

	return out
end

local PAGES = {}

PAGES.check = function(area, w, h)
	local sh = ScrH()
	local result = CI.last

	local go = Button(area, "Проверить человека", function()
		PD.Aim()
	end)

	go:SetPos(0, 0)
	go:SetSize(w * 0.42, sh * 0.05)

	local info = area:Add("DPanel")

	info:SetPos(w * 0.45, 0)
	info:SetSize(w * 0.55, sh * 0.05)
	info.Paint = function(_, iw, ih)
		draw.SimpleText("Планшет опустится. Наведитесь на человека и нажмите ЛКМ.", "nwPdaText", 0, ih / 2, DIM,
			TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	local card = area:Add("DPanel")

	card:SetPos(0, sh * 0.075)
	card:SetSize(w, h - sh * 0.075)
	card.Paint = function(_, cw, ch)
		surface.SetDrawColor(6, 22, 32, 200)
		surface.DrawRect(0, 0, cw, ch)
		surface.SetDrawColor(CYAN.r, CYAN.g, CYAN.b, 60)
		surface.DrawOutlinedRect(0, 0, cw, ch, 1)

		if (!result) then
			draw.SimpleText("ПРОВЕРОК ЕЩЁ НЕ БЫЛО", "nwPdaMono", cw / 2, ch / 2, DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

			return
		end

		local verdict = VERDICTS[result.verdict] or VERDICTS.none
		local p = sh * 0.025

		surface.SetDrawColor(verdict[2].r, verdict[2].g, verdict[2].b, 255)
		surface.DrawRect(0, 0, 4, ch)
		draw.SimpleText("ПОСЛЕДНЯЯ ПРОВЕРКА  ·  " .. tostring(result.time or ""), "nwPdaTiny", p, p, DIM)
		draw.SimpleText(verdict[1], "nwPdaBig", p, p + sh * 0.02, verdict[2])
		draw.SimpleText(verdict[3], "nwPdaText", p, p + sh * 0.075, TEXT)

		if (result.verdict != "none") then
			local rows = {
				{"ИМЯ НА КАРТЕ", result.name},
				{"НОМЕР CID", "#" .. tostring(result.number)},
				{"СТАТУС ПО КАРТЕ", result.faction != "" and result.faction or "—"},
				{"ВЫДАНА", result.issued}
			}

			for index, row in ipairs(rows) do
				local column = (index - 1) % 2
				local line = math.floor((index - 1) / 2)
				local x, y = p + column * cw * 0.48, p + sh * 0.13 + line * sh * 0.065

				draw.SimpleText(row[1], "nwPdaTiny", x, y, DIM)
				draw.SimpleText(Up(row[2]), "nwPdaName", x, y + sh * 0.02, TEXT)
			end
		end
	end
end

PAGES.issue = function(area, w, h)
	local sh = ScrH()
	local people = Near(PD.target)
	local fh = math.Round(sh * 0.04)

	if (#people == 0) then
		local empty = area:Add("DPanel")

		empty:SetSize(w, h)
		empty.Paint = function(_, ew, eh)
			draw.SimpleText("РЯДОМ НИКОГО НЕТ", "nwPdaMono", ew / 2, eh * 0.4, DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText("Подойдите к гражданину и откройте планшет снова (ПКМ по нему)", "nwPdaText", ew / 2, eh * 0.4 +
				sh * 0.03, DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end

		return
	end

	PD.target = IsValid(PD.target) and table.HasValue(people, PD.target) and PD.target or people[1]

	local target = PD.target

	local who = area:Add("DPanel")

	who:SetPos(0, 0)
	who:SetSize(w, sh * 0.03)
	who.Paint = function()
		draw.SimpleText("КОМУ", "nwPdaTiny", 0, 0, DIM)
	end

	for index, other in ipairs(people) do
		if (index > 4) then
			break
		end

		local pick = Button(area, other:Nick(), function()
			PD.target = other
			PD.Show("issue")
		end, other == target and GREEN or CYAN)

		pick:SetPos((index - 1) * (w * 0.25), sh * 0.022)
		pick:SetSize(w * 0.24, fh)
	end

	local y = sh * 0.022 + fh + sh * 0.025

	local function Label(text, x, ly)
		local label = area:Add("DLabel")

		label:SetPos(x, ly)
		label:SetFont("nwPdaTiny")
		label:SetTextColor(DIM)
		label:SetText(text)
		label:SizeToContents()
	end

	Label("ИМЯ НА КАРТЕ", 0, y)

	local name = Field(area, target:RealName())

	name:SetPos(0, y + sh * 0.02)
	name:SetSize(w * 0.62, fh)

	Label("ПОЛ", w * 0.65, y)

	local gender = target:GetNW2String("nwCharGender", "male")
	local male, female

	male = Button(area, "Мужской", function()
		gender = "male"
	end)
	female = Button(area, "Женский", function()
		gender = "female"
	end)

	male:SetPos(w * 0.65, y + sh * 0.02)
	male:SetSize(w * 0.17, fh)
	female:SetPos(w * 0.83, y + sh * 0.02)
	female:SetSize(w * 0.17, fh)

	local paintMale, paintFemale = male.Paint, female.Paint

	male.Paint = function(self, bw, bh)
		paintMale(self, bw, bh)

		if (gender == "male") then
			surface.SetDrawColor(GREEN)
			surface.DrawRect(0, bh - 2, bw, 2)
		end
	end
	female.Paint = function(self, bw, bh)
		paintFemale(self, bw, bh)

		if (gender == "female") then
			surface.SetDrawColor(GREEN)
			surface.DrawRect(0, bh - 2, bw, 2)
		end
	end

	y = y + sh * 0.02 + fh + sh * 0.02
	Label("ПРИМЕТЫ", 0, y)

	local signs = Field(area, target:GetCharacterDescription(), true)

	signs:SetPos(0, y + sh * 0.02)
	signs:SetSize(w, h - (y + sh * 0.02) - fh - sh * 0.03)

	local issue = Button(area, "Оформить CID-карту", function()
		net.Start("nwPdaIssue")
			net.WriteEntity(target)
			net.WriteString(util.TableToJSON({name = name:GetValue(), gender = gender, description = signs:GetValue()}))
		net.SendToServer()
		surface.PlaySound("buttons/combine_button7.wav")
	end, GREEN)

	issue:SetPos(w * 0.6, h - fh)
	issue:SetSize(w * 0.4, fh)

	local note = area:Add("DPanel")

	note:SetPos(0, h - fh)
	note:SetSize(w * 0.58, fh)
	note.Paint = function(_, nw, nh)
		draw.SimpleText("Номер CID остаётся прежним. Карта ляжет гражданину в инвентарь.", "nwPdaTiny", 0, nh / 2, DIM,
			TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
end

PAGES.database = function(area, w, h)
	local sh = ScrH()
	local fh = math.Round(sh * 0.045)
	local entry = Field(area, "")

	entry:SetPos(0, 0)
	entry:SetSize(w * 0.5, fh)
	entry:SetNumeric(true)
	entry:SetPlaceholderText("Номер CID")

	local function Search()
		local value = string.Trim(entry:GetValue() or "")

		if (value != "") then
			net.Start("nwPdaCitizen")
				net.WriteString(value)
			net.SendToServer()
		end
	end

	entry.OnEnter = Search

	local find = Button(area, "Найти", Search, GREEN)

	find:SetPos(w * 0.52, 0)
	find:SetSize(w * 0.2, fh)

	local info = NW.citizens and NW.citizens.file
	local card = area:Add("DPanel")

	card:SetPos(0, fh + sh * 0.02)
	card:SetSize(w, h - fh - sh * 0.02)

	if (info and !info.missing) then
		entry:SetValue(tostring(info.cid or ""))
	end

	card.Paint = function(_, cw, ch)
		surface.SetDrawColor(6, 22, 32, 200)
		surface.DrawRect(0, 0, cw, ch)
		surface.SetDrawColor(CYAN.r, CYAN.g, CYAN.b, 60)
		surface.DrawOutlinedRect(0, 0, cw, ch, 1)

		local p = sh * 0.025

		if (!info) then
			draw.SimpleText("ВВЕДИТЕ НОМЕР CID ГРАЖДАНИНА", "nwPdaMono", cw / 2, ch / 2, DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			return
		end

		if (info.missing) then
			draw.SimpleText("НОМЕР #" .. tostring(info.cid or "?") .. " НЕ НАЙДЕН В БАЗЕ", "nwPdaMono", cw / 2, ch / 2, RED,
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			return
		end

		surface.SetDrawColor(info.wanted and RED or CYAN)
		surface.DrawRect(0, 0, 4, ch)
		draw.SimpleText(Up(info.name) .. "  ·  #" .. tostring(info.cid), "nwPdaBig", p, p, TEXT)
		draw.SimpleText(info.online and "В СЕТИ" or "НЕ В СЕТИ", "nwPdaMono", cw - p, p, info.online and GREEN or DIM, TEXT_ALIGN_RIGHT)

		local rows = {
			{"СТАТУС", Up(info.status)},
			{"МЕСТОНАХОЖДЕНИЕ", info.online and (info.zone != "" and Up(info.zone) or "НЕИЗВЕСТНО") or "—"},
			{"ЗАКЛЮЧЕНИЕ", info.prison and ("ОТБЫВАЕТ, ОСТАЛОСЬ " .. info.prison .. " МИН") or "НЕТ"},
			{"РОЗЫСК", info.wanted and "НАПАДЕНИЕ НА АЛЬЯНС" or "НЕТ"},
			{"ОЧКИ ЛОЯЛЬНОСТИ", tostring(info.loyalty or 0)},
			{"ОЧКИ НАРУШЕНИЙ", tostring(info.violations or 0)}
		}

		for index, row in ipairs(rows) do
			local column = (index - 1) % 2
			local line = math.floor((index - 1) / 2)
			local x, y = p + column * cw * 0.48, p + sh * 0.06 + line * sh * 0.06

			draw.SimpleText(row[1], "nwPdaTiny", x, y, DIM)
			draw.SimpleText(row[2], "nwPdaName", x, y + sh * 0.02, ((index == 3 or index == 4) and row[2] != "НЕТ" or index == 6) and RED or
				(index == 5 and GREEN or TEXT))
		end

		local ly = p + sh * 0.25

		draw.SimpleText("ПОСЛЕДНИЕ ЗАПИСИ", "nwPdaTiny", p, ly, DIM)

		for index, record in ipairs(info.log or {}) do
			if (index > 5) then break end

			local good = record.kind == "loyalty"

			draw.SimpleText((good and "ОЛ +" or "ОН +") .. tostring(record.amount) .. "  " .. Up(record.reason), "nwPdaText", p,
				ly + sh * 0.022 * index, good and GREEN or RED)
			draw.SimpleText(Up(record.by) .. " · " .. tostring(record.time), "nwPdaTiny", cw - p, ly + sh * 0.022 * index + 2, DIM,
				TEXT_ALIGN_RIGHT)
		end
	end

	if (!info or info.missing) then return end

	local function Points(kind)
		Derma_StringRequest(kind == "loyalty" and "Очки лояльности" or "Очки нарушений", "Сколько (1-100)", "1", function(amount)
			Derma_StringRequest("Причина", kind == "loyalty" and "За что начисляются ОЛ" or "Какое нарушение", "", function(reason)
				net.Start("nwPdaCitizenPoints")
					net.WriteString(util.TableToJSON({cid = info.cid, kind = kind, amount = tonumber(amount) or 1, reason = reason}))
				net.SendToServer()
			end)
		end)
	end

	local plus = Button(card, "+ ОЛ", function() Points("loyalty") end, GREEN)

	plus:SetPos(card:GetWide() * 0.52, card:GetTall() - sh * 0.065)
	plus:SetSize(card:GetWide() * 0.22, sh * 0.045)

	local minus = Button(card, "+ ОН", function() Points("violations") end, RED)

	minus:SetPos(card:GetWide() * 0.76, card:GetTall() - sh * 0.065)
	minus:SetSize(card:GetWide() * 0.22, sh * 0.045)
end

PAGES.journal = function(area, w, h)
	local sh = ScrH()
	local scroll = area:Add("DScrollPanel")

	scroll:SetSize(w, h)

	if (#PD.history == 0) then
		local empty = scroll:Add("DPanel")

		empty:Dock(TOP)
		empty:SetTall(sh * 0.05)
		empty.Paint = function(_, ew, eh)
			draw.SimpleText("ЖУРНАЛ ПУСТ", "nwPdaMono", 0, eh / 2, DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
	end

	for _, entry in ipairs(PD.history) do
		local row = scroll:Add("DPanel")
		local verdict = VERDICTS[entry.verdict] or VERDICTS.none

		row:Dock(TOP)
		row:DockMargin(0, 0, 6, 5)
		row:SetTall(sh * 0.055)
		row.Paint = function(_, rw, rh)
			surface.SetDrawColor(6, 22, 32, 200)
			surface.DrawRect(0, 0, rw, rh)
			surface.SetDrawColor(verdict[2])
			surface.DrawRect(0, 0, 3, rh)
			draw.SimpleText(tostring(entry.time or ""), "nwPdaMono", rh * 0.3, rh / 2, DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(Up(entry.name != "" and entry.name or "без карты") .. (entry.number != "" and ("  #" .. entry.number) or ""),
				"nwPdaName", rw * 0.12, rh / 2, TEXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(verdict[1], "nwPdaMono", rw - rh * 0.3, rh / 2, verdict[2], TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
	end
end

local NAV = {
	{"check", "Проверка", "examine"},
	{"issue", "Оформление CID", "cid"},
	{"database", "База граждан", "user"},
	{"journal", "Журнал", "status"}
}

function PD.Close()
	if (IsValid(PD.frame)) then
		PD.frame:Remove()
	end
end

function PD.Show(page)
	page = PAGES[page or ""] and page or (PD.page or "check")
	PD.page = page

	if (!IsValid(PD.frame)) then
		return PD.Open(page)
	end

	PD.area:Clear()
	PAGES[page](PD.area, PD.area:GetWide(), PD.area:GetTall())
end

function PD.Open(page)
	PD.Close()
	PD.aiming = false

	local sw, sh = ScrW(), ScrH()
	local frame = vgui.Create("EditablePanel")
	local tw, th = math.Round(math.min(sw * 0.7, sh * 1.25)), math.Round(sh * 0.78)
	local tx, ty = math.Round((sw - tw) / 2), math.Round((sh - th) / 2)
	local bezel = math.Round(sh * 0.028)
	local sx, sy, sw2, sh2 = tx + bezel, ty + bezel, tw - bezel * 2, th - bezel * 2
	local top = math.Round(sh * 0.045)
	local navW = math.Round(sw2 * 0.22)
	local pad = math.Round(sh * 0.022)

	frame:SetSize(sw, sh)
	frame:MakePopup()
	frame.born = RealTime()
	PD.frame = frame

	surface.PlaySound("buttons/combine_button5.wav")

	frame.Paint = function(self, w, h)
		local a = math.Clamp((RealTime() - self.born) / 0.3, 0, 1)
		local lift = (1 - math.ease.OutCubic(a)) * h * 0.4

		surface.SetDrawColor(0, 0, 0, 150 * a)
		surface.DrawRect(0, 0, w, h)

		local y = ty + lift

		draw.RoundedBox(22, tx, y, tw, th, Color(26, 28, 31, 255))
		draw.RoundedBox(20, tx + 3, y + 3, tw - 6, th - 6, Color(40, 43, 47, 255))
		draw.RoundedBox(8, sx, y + bezel, sw2, sh2, Color(6, 20, 28, 255))

		for lx = sx + 6, sx + sw2 - 6, 9 do
			surface.SetDrawColor(CYAN.r, CYAN.g, CYAN.b, 6)
			surface.DrawRect(lx, y + bezel + 2, 1, sh2 - 4)
		end

		draw.RoundedBox(4, tx + tw / 2 - 4, y + bezel / 2 - 4, 8, 8, Color(12, 14, 16))
		draw.RoundedBox(2, tx + tw - bezel * 2, y + bezel / 2 - 2, 4, 4, Color(110, 214, 245, 150 + 100 * math.sin(RealTime() * 3)))

		local by = y + bezel

		surface.SetDrawColor(CYAN.r, CYAN.g, CYAN.b, 30)
		surface.DrawRect(sx, by, sw2, top)
		surface.SetDrawColor(CYAN.r, CYAN.g, CYAN.b, 140)
		surface.DrawRect(sx, by + top - 1, sw2, 1)
		draw.SimpleText("ГРАЖДАНСКАЯ ОБОРОНА  ·  ПДА", "nwPdaMono", sx + pad, by + top / 2, TEXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(Up(LocalPlayer():Nick()) .. "   " .. os.date("%H:%M"), "nwPdaMono", sx + sw2 - pad - sh * 0.06,
			by + top / 2, DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)

		local ix = sx + sw2 - pad - sh * 0.05

		for i = 1, 4 do
			surface.SetDrawColor(CYAN.r, CYAN.g, CYAN.b, i <= 3 and 230 or 70)
			surface.DrawRect(ix + (i - 1) * 5, by + top * 0.65 - i * 3, 3, i * 3)
		end

		surface.SetDrawColor(CYAN.r, CYAN.g, CYAN.b, 200)
		surface.DrawOutlinedRect(ix + 26, by + top * 0.35, 20, top * 0.3, 1)
		surface.DrawRect(ix + 28, by + top * 0.35 + 2, 13, top * 0.3 - 4)

		surface.SetDrawColor(CYAN.r, CYAN.g, CYAN.b, 50)
		surface.DrawRect(sx + navW, by + top, 1, sh2 - top)

		self.lift = lift
	end

	for index, entry in ipairs(NAV) do
		local button = frame:Add("DButton")

		button:SetText("")
		button:SetPos(sx + pad * 0.5, sy + top + pad + (index - 1) * sh * 0.06)
		button:SetSize(navW - pad, sh * 0.052)
		button.Paint = function(self, w, h)
			local active = PD.page == entry[1]

			surface.SetDrawColor(CYAN.r, CYAN.g, CYAN.b, active and 50 or (self:IsHovered() and 22 or 0))
			surface.DrawRect(0, 0, w, h)

			if (active) then
				surface.SetDrawColor(CYAN)
				surface.DrawRect(0, 0, 3, h)
			end

			U.DrawIcon(entry[3], h * 0.3, h * 0.25, h * 0.5, active and TEXT or DIM)
			draw.SimpleText(Up(entry[2]), "nwPdaMono", h * 1.05, h / 2, active and TEXT or DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		button.DoClick = function()
			Click()
			PD.Show(entry[1])
		end
	end

	local closeButton = Button(frame, "Убрать ПДА", function()
		PD.Close()
	end, RED)

	closeButton:SetPos(sx + pad * 0.5, sy + sh2 - pad - sh * 0.045)
	closeButton:SetSize(navW - pad, sh * 0.045)

	local area = frame:Add("EditablePanel")

	area:SetPos(sx + navW + pad, sy + top + pad)
	area:SetSize(sw2 - navW - pad * 2, sh2 - top - pad * 2)
	PD.area = area

	frame.Think = function(self)
		local lift = self.lift or 0

		for _, child in ipairs(self:GetChildren()) do
			child.baseY = child.baseY or select(2, child:GetPos())
			child:SetPos(select(1, child:GetPos()), child.baseY + lift)
		end

		local weapon = LocalPlayer():GetActiveWeapon()

		if (!LocalPlayer():Alive() or !IsValid(weapon) or weapon:GetClass() != "nw_cid_pda") then
			self:Remove()
		end
	end

	PD.Show(page)
end

function PD.Aim()
	PD.Close()
	PD.aiming = true
	surface.PlaySound("buttons/combine_button2.wav")
end

net.Receive("nwPdaOpen", function()
	local page = net.ReadString()
	local target = net.ReadEntity()

	if (IsValid(target)) then
		PD.target = target
	end

	PD.Open(page != "" and page or PD.page or "check")
end)

hook.Add("NWCidResult", "nwPda", function(result)
	table.insert(PD.history, 1, result)

	while (#PD.history > 40) do
		table.remove(PD.history)
	end

	if (PD.aiming) then
		PD.aiming = false

		timer.Simple(0.4, function()
			PD.Open("check")
		end)
	elseif (IsValid(PD.frame) and PD.page == "check") then
		PD.Show("check")
	end
end)

hook.Add("HUDPaint", "nwPdaAim", function()
	local weapon = LocalPlayer():GetActiveWeapon()

	if (!PD.aiming) then
		return
	end

	if (!IsValid(weapon) or weapon:GetClass() != "nw_cid_pda") then
		PD.aiming = false

		return
	end

	local sw, sh = ScrW(), ScrH()

	draw.RoundedBox(6, sw / 2 - sh * 0.22, sh * 0.82, sh * 0.44, sh * 0.06, Color(6, 20, 28, 220))
	surface.SetDrawColor(CYAN)
	surface.DrawRect(sw / 2 - sh * 0.22, sh * 0.82, sh * 0.44, 2)
	draw.SimpleText("ПДА: РЕЖИМ ПРОВЕРКИ", "nwPdaMono", sw / 2, sh * 0.836, TEXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	draw.SimpleText("ЛКМ по человеку — проверить  ·  R — вернуться к планшету", "nwPdaTiny", sw / 2, sh * 0.862, DIM,
		TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end)

hook.Add("NWEscape", "nwPda", function()
	if (IsValid(PD.frame)) then
		PD.Close()

		return true
	end
end)
