NW.dispatchTasks=NW.dispatchTasks or {}
local T=NW.dispatchTasks
local DP=NW.dispatcher
local K=NW.chatKinds
T.reportHint="/t Диспетчер, задача выполнена. Статус проверки: <результат обыска>"
function T.Parse(text)
	local key=NW.voices.Key(text)
	if (key=="10-7" or key=="10-7 вне службы") then return "offduty" end
	if (key=="10-8" or key=="10-8 на службе" or key=="10-8 на связи") then return "duty" end
	if (string.StartWith(key,"диспетчер задача выполнена статус проверки")) then
		local body=string.match(text,":%s*(.+)$")
		return "complete",body and NW.Cut(string.Trim(body),360) or ""
	end
	if (string.StartWith(key,"диспетчер разыскивается")) then
		local body=string.match(text,":%s*(.+)$")
		return "wanted",body and NW.Cut(string.Trim(body),360) or ""
	end
end
if (SERVER) then
	util.AddNetworkString("nwDispatchTask")
	local path="network2/dispatch_blocks_"..game.GetMap()..".json"
	T.blocks=util.JSONToTable(file.Read(path,"DATA") or "") or {}
	T.active={}
	T.used={}
	local function SaveBlocks() file.CreateDir("network2") file.Write(path,util.TableToJSON(T.blocks,true)) end
	local function Members(squad) return NW.squads.Members(squad) end
	local function SendTask(squad,task)
		local zone=task and NW.zones.list[task.zone]
		local out={}
		if (zone) then
			local lo,hi=NW.zones.Bounds(zone)
			local pos=(lo+hi)*.5
			out={name=zone.name,pos={pos.x,pos.y,pos.z},expires=task.expires,visited=task.visited==true,hint=T.reportHint}
		end
		net.Start("nwDispatchTask") net.WriteString(util.TableToJSON(out)) net.Send(Members(squad))
	end
	local function Eligible(squad)
		local c=squad and squad.leader
		return IsValid(c) and c:Alive() and c:GetCharacterID()!=0 and NW.zones.IsAlliance(c) and !c:GetNW2Bool("nwOffDuty",false)
	end
	function T.Score(zone)
		local score=0
		for _,c in ipairs(player.GetAll()) do
			if (c:Alive() and c:GetCharacterID()!=0 and !NW.zones.IsAlliance(c) and NW.zones.Contains(zone,c:GetPos())) then score=score+3 end
		end
		local seen={}
		for _,door in ipairs(ents.GetAll()) do
			if (!seen[door] and NW.doors.IsDoor(door) and door:GetNW2String("nwDoorKind","")=="apartment" and
				(door:GetNW2Int("nwDoorOwner",0)!=0 or door:GetNW2String("nwDoorTenants","")!="") and NW.zones.Contains(zone,door:GetPos())) then
				score=score+1
				for _,member in ipairs(NW.doors.Group(door)) do seen[member]=true end
			end
		end
		return score
	end
	function T.Ranked()
		local out={}
		for id in pairs(T.blocks) do
			local zone=NW.zones.list[tonumber(id)]
			if (zone) then
				local score=T.Score(zone)
				if (score>0) then out[#out+1]={zone=zone,score=score} end
			end
		end
		table.sort(out,function(a,b) if (a.score==b.score) then return a.zone.id<b.zone.id end return a.score>b.score end)
		return out
	end
	function T.Assign(squad,zone)
		if (!Eligible(squad) or !zone or T.active[squad.id]) then return false end
		local task={zone=zone.id,expires=CurTime()+600,leader=squad.leader,visited=false,dwell=0}
		local accepted=DP.Queue(function()
			if (T.active[squad.id]!=task or !Eligible(squad) or NW.schedule.Current().id!="curfew") then return end
			local name,call=DP.Callsign(squad.leader)
			local words=table.Copy(call) table.Add(words,DP.Words({"search","residentialblock","investigateandreport"}))
			DP.Say(name..", отряд «"..squad.name.."»: обыскать жилой блок «"..zone.name.."». После проверки доложить статус.",words)
			for _,c in ipairs(Members(squad)) do NW.Notify(c,T.reportHint) end
		end,"task:"..squad.id,10,0,true)
		if (!accepted) then return false end
		T.active[squad.id]=task T.used[zone.id]=true SendTask(squad,task)
		return true
	end
	NW.AddChatCommand("dispatchblock",{admin=true,run=function(client,rest)
		local action=string.Trim(rest or "")
		if (action=="list") then
			for id in pairs(T.blocks) do local z=NW.zones.list[tonumber(id)] if (z) then NW.Notify(client,z.id..": "..z.name) end end
			return
		end
		local zone=NW.zones.At(client:GetPos())
		if (!zone or (action!="add" and action!="remove")) then return NW.Notify(client,"Выделите блок через /areaedit, войдите в него: /dispatchblock add или remove. Список: /dispatchblock list") end
		T.blocks[tostring(zone.id)]=action=="add" and true or nil
		SaveBlocks() NW.Notify(client,(action=="add" and "Блок включён в обыски: " or "Блок исключён: ")..zone.name)
	end})
	NW.AddChatCommand("dispatchhelp",{run=function(client)
		NW.Notify(client,T.reportHint)
		NW.Notify(client,"/t 10-7, вне службы. · /t 10-8, на службе.")
		NW.Notify(client,"/t Диспетчер, разыскивается: <имя или неизвестный; внешность; последнее место>")
	end})
	local function QueueReply(client,key,fn)
		local character=client:GetCharacterID()
		return DP.Queue(function() if (IsValid(client) and client:GetCharacterID()==character) then fn() end end,key,3,math.max(1.8,(client.nwVoiceUntil or 0)-CurTime()+.25),true)
	end
	hook.Add("NWRadioText","nwDispatchTasks",function(client,text,kind)
		if ((kind!=K.RADIO and kind!=K.RADIO_ALL) or !NW.zones.IsAlliance(client)) then return end
		local action,body=T.Parse(text)
		if (!action) then return end
		if ((client.nwDispatchTextNext or 0)>CurTime()) then return true end
		client.nwDispatchTextNext=CurTime()+3
		local name,call=DP.Callsign(client)
		if (action=="duty" or action=="offduty") then
			client:SetNW2Bool("nwOffDuty",action=="offduty")
			QueueReply(client,"duty:"..client:EntIndex(),function()
				local words=table.Copy(call) table.Add(words,DP.Words(action=="offduty" and {"suspend"} or {"isnow","eight"}))
				DP.Say(name..(action=="offduty" and ", 10-7 подтверждено. Вне службы, назначения приостановлены." or ", 10-8 подтверждено. На службе, ожидайте распоряжений."),words)
			end)
		elseif (action=="wanted") then
			if ((utf8.len(body) or 0)<8) then NW.Notify(client,"/t Диспетчер, разыскивается: <имя; внешность; место>") return true end
			if ((client.nwWantedReportNext or 0)>CurTime()) then NW.Notify(client,"Ориентировка уже передана. Следующая через минуту") return true end
			local accepted=QueueReply(client,"wanted:"..client:EntIndex(),function()
				DP.Say("Поступила ориентировка от "..name..": "..body.." Всем юнитам: установить местонахождение и доложить.",DP.Words({"attention","allunitsbolfor243suspect","reportplease"}))
			end)
			if (accepted) then client.nwWantedReportNext=CurTime()+60 else NW.Notify(client,"Канал занят. Повторите ориентировку через несколько секунд") end
		else
			local squad=NW.squads.Of(client)
			local task=squad and T.active[squad.id]
			if (!task or squad.leader!=client) then NW.Notify(client,"Отчёт подаёт лидер отряда с активным заданием") return true end
			if (!task.visited) then NW.Notify(client,"Отряд должен посетить назначенный блок и провести проверку") return true end
			if ((utf8.len(body) or 0)<3) then NW.Notify(client,T.reportHint) return true end
			if (task.reporting) then return true end
			local accepted=QueueReply(client,"report:"..squad.id,function()
				if (T.active[squad.id]!=task) then return end
				if (squad.leader!=client) then task.reporting=false return end
				DP.Say("Принято, "..name..". Проверка завершена. Статус: "..body.." Работа отряда подтверждена.",DP.Words({"sociostabilizationrestored"}))
				T.active[squad.id]=nil SendTask(squad)
				MsgN("[DISPATCH REPORT] "..client:SteamID().." block "..task.zone..": "..body)
			end)
			if (accepted) then task.reporting=true else NW.Notify(client,"Канал занят. Повторите отчёт через несколько секунд") end
		end
		return true
	end)
	hook.Add("NWCharacterLoaded","nwDispatchDutyState",function(c) c:SetNW2Bool("nwOffDuty",false) end)
	hook.Add("NWCharacterUnloaded","nwDispatchTaskClear",function(c)
		net.Start("nwDispatchTask") net.WriteString("{}") net.Send(c)
	end)
	hook.Add("NWScheduleChanged","nwDispatchTasks",function(phase)
		T.used={}
		for id in pairs(T.active) do local squad=NW.squads.list[id] if (squad) then SendTask(squad) end end
		T.active={}
	end)
	timer.Create("nwDispatchTasks",2,0,function()
		for id,task in pairs(T.active) do
			local squad=NW.squads.list[id]
			local zone=NW.zones.list[task.zone]
			if (!Eligible(squad) or !zone or CurTime()>task.expires or NW.schedule.Current().id!="curfew") then
				T.active[id]=nil T.used[task.zone]=nil if (squad) then SendTask(squad) end
			else
				if (task.leader!=squad.leader) then task.leader=squad.leader task.reporting=false end
				local inside=false
				for _,c in ipairs(Members(squad)) do if (c:Alive() and NW.zones.Contains(zone,c:GetPos())) then inside=true break end end
				if (inside and !task.visited) then task.dwell=task.dwell+2 if (task.dwell>=10) then task.visited=true SendTask(squad,task) end end
			end
		end
		if (NW.schedule.Current().id!="curfew" or (T.assignNext or 0)>CurTime()) then return end
		T.assignNext=CurTime()+15
		local ranked=T.Ranked()
		for _,squad in SortedPairs(NW.squads.list) do
			if (Eligible(squad) and !T.active[squad.id]) then
				for _,entry in ipairs(ranked) do
					if (!T.used[entry.zone.id] and T.Assign(squad,entry.zone)) then break end
				end
			end
		end
	end)
	hook.Add("NWSquadChanged","nwDispatchTaskSync",function()
		for _,c in ipairs(player.GetAll()) do
			local squad=NW.squads.Of(c)
			if (!squad) then net.Start("nwDispatchTask") net.WriteString("{}") net.Send(c) end
		end
		for id,task in pairs(T.active) do local squad=NW.squads.list[id] if (squad) then SendTask(squad,task) end end
	end)
	return
end
T.current={}
net.Receive("nwDispatchTask",function() T.current=util.JSONToTable(net.ReadString() or "") or {} end)
local glow=Material("sprites/light_glow02_add")
local beam=Material("trails/laser")
local function Position()
	local task=T.current
	if (!task.pos or !task.expires or task.expires<CurTime() or !NW.squads.Of(LocalPlayer())) then return end
	return Vector(task.pos[1],task.pos[2],task.pos[3])
end
hook.Add("HUDPaint","nwDispatchTask",function()
	local pos=Position() if (!pos) then return end
	local task=T.current
	local point=pos:ToScreen()
	local x,y=math.Clamp(point.x,210,ScrW()-210),math.Clamp(point.y,95,ScrH()-130)
	local distance=math.floor(LocalPlayer():GetPos():Distance(pos)*.01905)
	draw.RoundedBox(7,x-195,y-28,390,78,Color(9,21,29,225))
	surface.SetDrawColor(100,217,247) surface.DrawOutlinedRect(x-195,y-28,390,78,1)
	draw.SimpleText("ОБЫСК · "..NW.Cut(task.name or "Блок",48),"DermaDefaultBold",x,y-16,Color(139,229,250),TEXT_ALIGN_CENTER)
	draw.SimpleText(distance.." м  ·  "..(task.visited and "Проверка — доложить статус" or "Войдите в отмеченный блок"),"DermaDefault",x,y+4,color_white,TEXT_ALIGN_CENTER)
	draw.SimpleText("Отчёт: /dispatchhelp", "DermaDefault",x,y+25,Color(160,183,195),TEXT_ALIGN_CENTER)
	if (task.visited) then
		draw.SimpleText(T.reportHint,"DermaDefaultBold",ScrW()/2,ScrH()*.82,Color(139,229,250),TEXT_ALIGN_CENTER)
	end
end)
hook.Add("PostDrawTranslucentRenderables","nwDispatchTask",function(depth,sky)
	if (depth or sky) then return end
	local pos=Position() if (!pos) then return end
	render.SetMaterial(beam)
	local color=Color(91,209,240,150)
	render.DrawBeam(pos,pos+Vector(0,0,90),2,0,1,color)
	local prev
	for i=0,48 do
		local a=i/48*math.pi*2
		local p=pos+Vector(math.cos(a)*28,math.sin(a)*28,0)
		if (prev) then render.DrawBeam(prev,p,1,0,1,color) end
		prev=p
	end
	render.SetMaterial(glow) render.DrawSprite(pos+Vector(0,0,30),14,14,color)
end)
