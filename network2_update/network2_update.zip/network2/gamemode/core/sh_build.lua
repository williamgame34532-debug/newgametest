NW.build = NW.build or {}

local BD = NW.build

BD.catalog = {
	{id = "bed", name = "Кровать", model = "models/props_c17/FurnitureBed001a.mdl", price = 25},
	{id = "mattress", name = "Матрас", model = "models/props_c17/FurnitureMattress001a.mdl", price = 10},
	{id = "couch", name = "Диван", model = "models/props_c17/FurnitureCouch001a.mdl", price = 30},
	{id = "couch2", name = "Старый диван", model = "models/props_c17/FurnitureCouch002a.mdl", price = 22},
	{id = "armchair", name = "Кресло", model = "models/props_c17/FurnitureChair001a.mdl", price = 14},
	{id = "chair", name = "Стул", model = "models/props_c17/chair02a.mdl", price = 6},
	{id = "chair_wood", name = "Деревянный стул", model = "models/props_interiors/Furniture_chair01a.mdl", price = 8},
	{id = "table", name = "Стол", model = "models/props_c17/FurnitureTable001a.mdl", price = 15},
	{id = "table_small", name = "Столик", model = "models/props_c17/FurnitureTable002a.mdl", price = 10},
	{id = "desk", name = "Письменный стол", model = "models/props_interiors/Furniture_Desk01a.mdl", price = 20},
	{id = "drawer", name = "Комод", model = "models/props_c17/FurnitureDrawer001a.mdl", price = 18},
	{id = "dresser", name = "Шкаф", model = "models/props_c17/FurnitureDresser001a.mdl", price = 24},
	{id = "shelf", name = "Стеллаж", model = "models/props_c17/FurnitureShelf001a.mdl", price = 16},
	{id = "cupboard", name = "Шкафчик", model = "models/props_c17/FurnitureCupboard001a.mdl", price = 12},
	{id = "fridge", name = "Холодильник", model = "models/props_c17/FurnitureFridge001a.mdl", price = 30},
	{id = "stove", name = "Плита", model = "models/props_c17/furnitureStove001a.mdl", price = 28},
	{id = "sink", name = "Раковина", model = "models/props_interiors/SinkKitchen01a.mdl", price = 14},
	{id = "radiator", name = "Батарея", model = "models/props_c17/furnitureradiator001a.mdl", price = 8},
	{id = "lamp", name = "Лампа", model = "models/props_interiors/Furniture_Lamp01a.mdl", price = 9},
	{id = "tv", name = "Телевизор", model = "models/props_c17/tv_monitor01.mdl", price = 20},
	{id = "crate", name = "Ящик", model = "models/props_junk/wood_crate001a.mdl", price = 6},
	{id = "barrel", name = "Бочка", model = "models/props_c17/oildrum001.mdl", price = 6},
	{id = "counter", name = "Прилавок", model = "models/props_c17/FurnitureCounter001a.mdl", price = 22},
	{id = "board", name = "Доска (стена)", model = "models/props_debris/wood_board06a.mdl", price = 4},
	{id = "fence", name = "Решётка", model = "models/props_c17/fence01a.mdl", price = 12},
	{id = "plant", name = "Растение в горшке", model = "models/props_lab/cactus.mdl", price = 5}
}

BD.byID = {}

for _, entry in ipairs(BD.catalog) do
	BD.byID[entry.id] = entry
end

BD.limit = CreateConVar("nw_build_limit", "30", {FCVAR_ARCHIVE, FCVAR_REPLICATED}, "Сколько предметов можно построить в одном помещении")
BD.refund = CreateConVar("nw_build_refund", "50", {FCVAR_ARCHIVE, FCVAR_REPLICATED}, "Сколько процентов цены возвращается, если убрать предмет")

if (SERVER) then
	util.AddNetworkString("nwBuildOpen")
	util.AddNetworkString("nwBuildPlace")
	util.AddNetworkString("nwBuildRemove")

	local D = NW.doors
	local Z = NW.zones
	local SO = NW.social
	local DIR = "network2/builds"

	local function Path() return DIR .. "/" .. game.GetMap() .. ".json" end

	BD.state = BD.state or {links = {}, props = {}}

	local loading = false

	local function DoorKey(door)
		local id = door:MapCreationID()
		return id and id > 0 and tostring(id) or nil
	end

	local function DoorByKey(key)
		local entity = ents.GetMapCreatedEntity(tonumber(key) or -1)
		return IsValid(entity) and entity or nil
	end

	function BD.Save()
		if (loading) then return end

		local props = {}

		for _, prop in ipairs(ents.FindByClass("prop_physics")) do
			if (prop.nwBuild) then
				local pos, ang = prop:GetPos(), prop:GetAngles()
				props[#props + 1] = {door = prop.nwBuild.door, owner = prop.nwBuild.owner, id = prop.nwBuild.id, price = prop.nwBuild.price,
					pos = {math.Round(pos.x, 2), math.Round(pos.y, 2), math.Round(pos.z, 2)}, ang = {math.Round(ang.p, 2), math.Round(ang.y, 2), math.Round(ang.r, 2)}}
			end
		end

		BD.state.props = props
		file.CreateDir(DIR)
		file.Write(Path(), util.TableToJSON(BD.state, true))
	end

	local function Spawn(entry, data)
		local prop = ents.Create("prop_physics")
		if (!IsValid(prop)) then return end
		prop:SetModel(entry.model)
		prop:SetPos(Vector(data.pos[1], data.pos[2], data.pos[3]))
		prop:SetAngles(Angle(data.ang[1], data.ang[2], data.ang[3]))
		prop:Spawn()
		prop:Activate()
		local physics = prop:GetPhysicsObject()
		if (IsValid(physics)) then physics:EnableMotion(false) end
		prop.nwBuild = {door = data.door, owner = data.owner, id = data.id, price = data.price}
		prop:SetNW2Int("nwBuildOwner", data.owner)
		prop:SetNW2String("nwBuildName", entry.name)
		return prop
	end

	function BD.Load()
		loading = true
		BD.state = util.JSONToTable(file.Read(Path(), "DATA") or "") or {}
		BD.state.links = BD.state.links or {}
		BD.state.props = BD.state.props or {}

		for _, prop in ipairs(ents.FindByClass("prop_physics")) do
			if (prop.nwBuild) then prop:Remove() end
		end

		for _, data in ipairs(BD.state.props) do
			local entry = BD.byID[data.id or ""]
			if (entry and istable(data.pos) and istable(data.ang)) then Spawn(entry, data) end
		end

		loading = false
	end

	hook.Add("InitPostEntity", "nwBuild", function()
		timer.Simple(3, BD.Load)
	end)

	hook.Add("PostCleanupMap", "nwBuild", function()
		timer.Simple(1, BD.Load)
	end)

	function BD.Areas(client)
		local out = {}

		for key, zoneID in pairs(BD.state.links) do
			local door = DoorByKey(key)
			local zone = Z.list[zoneID]

			if (door and zone and D.IsOwner(client, door)) then
				out[#out + 1] = {door = door, key = key, zone = zone}
			end
		end

		return out
	end

	function BD.AreaAt(client, pos)
		for _, area in ipairs(BD.Areas(client)) do
			if (Z.Contains(area.zone, pos)) then return area end
		end
	end

	local function CountIn(key)
		local count = 0

		for _, prop in ipairs(ents.FindByClass("prop_physics")) do
			if (prop.nwBuild and prop.nwBuild.door == key) then count = count + 1 end
		end

		return count
	end

	function BD.Open(client)
		local areas = BD.Areas(client)

		if (#areas == 0) then
			return NW.Notify(client, "Строить можно только в своей квартире или помещении, отмеченном администрацией")
		end

		local here = BD.AreaAt(client, client:GetPos())
		local info = {}

		for _, area in ipairs(areas) do
			info[#info + 1] = {name = area.door:GetNW2String("nwDoorName", "помещение"), used = CountIn(area.key)}
		end

		net.Start("nwBuildOpen")
			net.WriteString(util.TableToJSON({areas = info, inside = here != nil, limit = BD.limit:GetInt()}))
		net.Send(client)
	end

	NW.AddChatCommand("build", {run = function(client)
		BD.Open(client)
	end})

	net.Receive("nwBuildPlace", function(_, client)
		local id = net.ReadString()
		local pos = net.ReadVector()
		local ang = net.ReadAngle()
		local entry = BD.byID[id]

		if (!entry or !client:Alive() or client:GetCharacterID() == 0 or (client.nwBuildNext or 0) > CurTime()) then return end
		client.nwBuildNext = CurTime() + 0.5

		if (client:EyePos():DistToSqr(pos) > 220 * 220) then return NW.Notify(client, "Слишком далеко") end

		local area = BD.AreaAt(client, pos)

		if (!area) then return NW.Notify(client, "Это место вне вашего помещения") end
		if (CountIn(area.key) >= BD.limit:GetInt()) then return NW.Notify(client, "В помещении уже " .. BD.limit:GetInt() .. " построек") end

		local tokens = SO.GetTokens(client)

		if (tokens < entry.price) then return NW.Notify(client, "Нужно " .. entry.price .. " ток.") end

		local prop = Spawn(entry, {door = area.key, owner = client:GetCharacterID(), id = entry.id, price = entry.price,
			pos = {pos.x, pos.y, pos.z}, ang = {0, ang.y, 0}})

		if (!IsValid(prop)) then return end

		local mins = prop:OBBMins()
		prop:SetPos(pos - Vector(0, 0, mins.z))

		SO.SetTokens(client, tokens - entry.price)
		prop:EmitSound("physics/wood/wood_box_impact_hard" .. math.random(1, 3) .. ".wav", 60)
		NW.Notify(client, "Поставлено: " .. entry.name .. " (−" .. entry.price .. " ток.)")
		BD.Save()
	end)

	function BD.Remove(client, prop)
		if (!IsValid(prop) or !prop.nwBuild) then return false end

		local door = DoorByKey(prop.nwBuild.door)
		local mine = prop.nwBuild.owner == client:GetCharacterID() or (door and D.IsOwner(client, door))

		if (!mine and !client:IsAdmin()) then return false end

		local refund = math.floor((prop.nwBuild.price or 0) * math.Clamp(BD.refund:GetFloat(), 0, 100) / 100)

		local paid = prop.nwBuild.owner == client:GetCharacterID()

		if (paid and refund > 0) then SO.SetTokens(client, SO.GetTokens(client) + refund) end

		prop:Remove()
		NW.Notify(client, "Убрано" .. (paid and refund > 0 and (": +" .. refund .. " ток.") or ""))
		timer.Simple(0, BD.Save)

		return true
	end

	net.Receive("nwBuildRemove", function(_, client)
		local prop = net.ReadEntity()
		if ((client.nwBuildNext or 0) > CurTime() or !IsValid(prop) or client:EyePos():DistToSqr(prop:GetPos()) > 220 * 220) then return end
		client.nwBuildNext = CurTime() + 0.5
		BD.Remove(client, prop)
	end)

	NW.AddChatCommand("buildzone", {admin = true, run = function(client, rest)
		local door = D.Aimed(client, 200)

		if (!IsValid(door)) then return NW.Notify(client, "Посмотрите на дверь квартиры или помещения") end

		local key = DoorKey(door)

		if (!key) then return NW.Notify(client, "Эта дверь не с карты: привязать нельзя") end

		if (string.Trim(rest or "") == "remove") then
			BD.state.links[key] = nil
			BD.Save()
			return NW.Notify(client, "Зона стройки отвязана от двери")
		end

		local zone = Z.At(client:GetPos())

		if (!zone) then return NW.Notify(client, "Встаньте внутри зоны помещения (её создают через /areaedit)") end

		for _, member in ipairs(D.Group(door)) do
			local memberKey = DoorKey(member)
			if (memberKey) then BD.state.links[memberKey] = zone.id end
		end

		BD.Save()
		NW.Notify(client, "Стройка разрешена жильцам двери «" .. door:GetNW2String("nwDoorName", "?") .. "» в зоне «" .. zone.name .. "»")
	end})

	timer.Create("nwBuildOwners", 60, 0, function()
		local removed = false

		for _, prop in ipairs(ents.FindByClass("prop_physics")) do
			if (prop.nwBuild) then
				local door = DoorByKey(prop.nwBuild.door)
				local tenant = false

				if (door) then
					for _, id in ipairs(D.Tenants(door)) do
						if (id == prop.nwBuild.owner) then tenant = true break end
					end
				end

				if (!tenant) then
					prop:Remove()
					removed = true
				end
			end
		end

		if (removed) then timer.Simple(0, BD.Save) end
	end)

	hook.Add("EntityTakeDamage", "nwBuild", function(prop)
		if (IsValid(prop) and prop.nwBuild) then return true end
	end)

	hook.Add("PhysgunDrop", "nwBuild", function(_, prop)
		if (IsValid(prop) and prop.nwBuild) then
			local physics = prop:GetPhysicsObject()
			if (IsValid(physics)) then physics:EnableMotion(false) end
			timer.Simple(0, BD.Save)
		end
	end)

	return
end

local W = NW.widgets
local U = NW.ui

BD.placing = nil

net.Receive("nwBuildOpen", function()
	local data = util.JSONToTable(net.ReadString() or "") or {}
	local sh = ScrH()
	local frame, box = W.Window("Обустройство помещения", math.Round(sh * 0.9), math.Round(sh * 0.7))
	local pad = math.Round(sh * 0.02)
	local bw, bh = box:GetWide(), box:GetTall()
	local top = box.top
	local info = box:Add("DPanel")

	info:SetPos(pad, top)
	info:SetSize(bw - pad * 2, sh * 0.06)
	info.Paint = function(_, w, h)
		local lines = {}
		for _, area in ipairs(data.areas or {}) do lines[#lines + 1] = area.name .. ": " .. area.used .. "/" .. data.limit end
		draw.SimpleText(table.concat(lines, "   ·   "), "nwWidgetBold", 0, h * 0.3, U.color.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(data.inside and "Выберите предмет: ЛКМ — поставить, колесо — повернуть, ПКМ — отмена" or
			"Вы сейчас вне своего помещения: зайдите внутрь, чтобы ставить предметы",
			"nwWidget", 0, h * 0.78, W.MUTED, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	local remove = W.Button(box, "Убрать то, на что смотрю", function()
		local trace = LocalPlayer():GetEyeTrace()
		if (IsValid(trace.Entity)) then
			net.Start("nwBuildRemove")
				net.WriteEntity(trace.Entity)
			net.SendToServer()
		end
		frame:Remove()
	end)

	remove:SetPos(bw - pad - sh * 0.3, bh - pad - sh * 0.045)
	remove:SetSize(sh * 0.3, sh * 0.045)

	local scroll = W.Scroll(box)

	scroll:SetPos(pad, top + sh * 0.07)
	scroll:SetSize(bw - pad * 2, bh - top - sh * 0.07 - pad * 2 - sh * 0.045)

	local grid = scroll:Add("DIconLayout")

	grid:Dock(FILL)
	grid:SetSpaceX(6)
	grid:SetSpaceY(6)

	for _, entry in ipairs(BD.catalog) do
		if (!util.IsValidModel(entry.model)) then continue end

		local cell = grid:Add("DButton")
		local size = math.Round(sh * 0.15)

		cell:SetSize(size, size)
		cell:SetText("")
		cell.Paint = function(self, w, h)
			draw.RoundedBox(6, 0, 0, w, h, self:IsHovered() and Color(44, 48, 54, 250) or Color(24, 27, 31, 240))
			draw.SimpleText(entry.name, "nwWidget", w / 2, h - h * 0.2, U.color.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText(entry.price .. " ток.", "nwWidgetBold", w / 2, h - h * 0.08, W.ACCENT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end

		local icon = cell:Add("SpawnIcon")

		icon:SetModel(entry.model)
		icon:SetSize(size * 0.62, size * 0.62)
		icon:SetPos(size * 0.19, size * 0.04)
		icon:SetMouseInputEnabled(false)

		cell.DoClick = function()
			surface.PlaySound("network2/ui/click.wav")
			BD.placing = {entry = entry, yaw = 0}
			frame:Remove()
		end
	end
end)

local ghost

local function Ghost()
	local placing = BD.placing
	if (!placing) then
		if (IsValid(ghost)) then ghost:Remove() end
		return
	end
	if (!IsValid(ghost) or ghost:GetModel() != placing.entry.model) then
		if (IsValid(ghost)) then ghost:Remove() end
		ghost = ClientsideModel(placing.entry.model, RENDERGROUP_TRANSLUCENT)
		if (IsValid(ghost)) then ghost:SetNoDraw(true) end
	end
	return ghost
end

local function Target()
	local client = LocalPlayer()
	local trace = util.TraceLine({start = client:EyePos(), endpos = client:EyePos() + client:GetAimVector() * 200, filter = client})
	return trace.Hit and trace.HitPos or nil, trace.HitNormal
end

hook.Add("PostDrawTranslucentRenderables", "nwBuildGhost", function(depth, sky)
	if (sky or !BD.placing) then return end
	local model = Ghost()
	if (!IsValid(model)) then return end
	local pos = Target()
	if (!pos) then return end
	local ang = Angle(0, BD.placing.yaw, 0)
	model:SetAngles(ang)
	model:SetPos(pos - Vector(0, 0, model:OBBMins().z))
	model:SetupBones()
	render.SetBlend(0.55)
	render.SetColorModulation(0.6, 1, 0.7)
	model:DrawModel()
	render.SetColorModulation(1, 1, 1)
	render.SetBlend(1)
end)

hook.Add("PlayerBindPress", "nwBuildPlace", function(client, bind, pressed)
	if (!BD.placing or !pressed) then return end

	if (string.find(bind, "invnext", 1, true)) then
		BD.placing.yaw = (BD.placing.yaw + 15) % 360
		return true
	elseif (string.find(bind, "invprev", 1, true)) then
		BD.placing.yaw = (BD.placing.yaw - 15) % 360
		return true
	elseif (string.find(bind, "+attack2", 1, true)) then
		BD.placing = nil
		Ghost()
		return true
	elseif (string.find(bind, "+attack", 1, true)) then
		local pos = Target()
		if (pos) then
			net.Start("nwBuildPlace")
				net.WriteString(BD.placing.entry.id)
				net.WriteVector(pos)
				net.WriteAngle(Angle(0, BD.placing.yaw, 0))
			net.SendToServer()
		end
		if (!input.IsKeyDown(KEY_LSHIFT)) then
			BD.placing = nil
			Ghost()
		end
		return true
	end
end)

hook.Add("HUDPaint", "nwBuildHint", function()
	if (!BD.placing) then return end
	local sw, sh = ScrW(), ScrH()
	draw.SimpleTextOutlined(BD.placing.entry.name .. " · " .. BD.placing.entry.price .. " ток.   ЛКМ — поставить (Shift — ещё)   колесо — повернуть   ПКМ — отмена",
		"nwWidgetBold", sw / 2, sh * 0.62, Color(232, 196, 72), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, 160))
end)
