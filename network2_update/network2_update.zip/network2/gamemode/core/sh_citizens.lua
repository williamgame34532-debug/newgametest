NW.citizens = NW.citizens or {}

local CZ = NW.citizens

CZ.maxPoints = 100
function CZ.CanAward(client)
	return IsValid(client) and client:GetCharacterID()!=0 and (client:IsAdmin() or client:GetFaction()=="cp" or client:GetNW2Bool("nwCityAdmin",false))
end

if (SERVER) then
	util.AddNetworkString("nwCitizenFile")

	local function Q(value)
		return sql.SQLStr(value)
	end

	local function Online(charID)
		for _, client in ipairs(player.GetAll()) do
			if (client:GetCharacterID() == charID) then
				return client
			end
		end
	end

	local function Find(cid)
		cid = string.match(tostring(cid or ""), "^%s*#?(%d+)%s*$")

		if (!cid) then
			return
		end

		for _, client in ipairs(player.GetAll()) do
			local character = client.nwCharacter

			if (character and character.data and tostring(character.data.cid or "") == cid and client:GetCharacterID() != 0) then
				return {id = client:GetCharacterID(), name = client:RealName(), faction = character.faction,
					data = character.data, client = client, model = client:GetModel()}
			end
		end

		local rows = sql.Query("SELECT id, name, faction, model, data FROM nw_characters WHERE data LIKE " ..
			Q('%"cid":"' .. cid .. '"%') .. " LIMIT 1")
		local row = rows and rows[1]

		if (row) then
			return {id = tonumber(row.id), name = row.name, faction = row.faction, model = row.model,
				data = util.JSONToTable(row.data or "") or {}}
		end
	end

	local function Modify(found, change)
		change(found.data)

		if (IsValid(found.client)) then
			NW.char.SaveData(found.client)
		else
			sql.Query("UPDATE nw_characters SET data = " .. Q(util.TableToJSON(found.data)) .. " WHERE id = " .. found.id)
		end
	end

	local function File(found)
		local data = found.data
		local faction = NW.char.factions[found.faction or ""]
		local shown = faction and faction.disguise and NW.char.factions[faction.disguise] or faction
		local points = data.points or {}
		local zone = IsValid(found.client) and NW.zones.At(found.client:GetPos())

		return {
			char = found.id, name = data.civName or found.name, cid = data.cid or "?", model = found.model or "",
			status = shown and shown.name or "Не определено", online = IsValid(found.client),
			zone = zone and zone.name or "", loyalty = points.loyalty or 0, violations = points.violations or 0,
			prison = data.prison and math.ceil((data.prison.left or 0) / 60) or nil,
			wanted = IsValid(found.client) and NW.npcRelations and NW.npcRelations.Wanted(found.client) or false,
			log = points.log or {}
		}
	end

	local function Send(client, info)
		net.Start("nwCitizenFile")
			net.WriteString(util.TableToJSON(info or {missing = true}))
		net.Send(client)
	end

	CZ.Find, CZ.File = Find, File

	local ACTIONS = NW.cmbTerminalActions

	function ACTIONS.citizen_find(client, terminal, arg)
		if (terminal:GetClass() != "nw_cmb_terminal" or !NW.zones.UsesAlliance(client)) then
			return
		end

		local found = Find(arg)

		Send(client, found and File(found) or {missing = true, cid = arg})
	end

	util.AddNetworkString("nwPdaCitizen")
	util.AddNetworkString("nwPdaCitizenPoints")

	local function HoldsPda(client)
		local weapon = client:GetActiveWeapon()
		return client:Alive() and IsValid(weapon) and weapon:GetClass() == "nw_cid_pda" and NW.zones.UsesAlliance(client)
	end

	net.Receive("nwPdaCitizen", function(_, client)
		local cid = net.ReadString()
		if (!HoldsPda(client) or (client.nwPdaFindNext or 0) > CurTime()) then return end
		client.nwPdaFindNext = CurTime() + 0.5
		local found = Find(cid)
		Send(client, found and File(found) or {missing = true, cid = cid})
	end)

	net.Receive("nwPdaCitizenPoints", function(_, client)
		local request = util.JSONToTable(net.ReadString() or "") or {}
		if (!HoldsPda(client)) then return end
		local ok, why = CZ.Award(client, request.cid, request.kind, request.amount, request.reason)
		if (!ok) then NW.Notify(client, why) end
	end)

	function CZ.Award(client,cid,kind,amount,reason)
		if (!CZ.CanAward(client) or (kind!="loyalty" and kind!="violations")) then return false,"Нет полномочий" end
		amount=tonumber(amount)
		if (!amount or amount!=amount or amount<1 or amount>CZ.maxPoints or amount!=math.floor(amount)) then return false,"Количество: целое число 1–100" end
		reason=NW.Cut(string.Trim(string.gsub(tostring(reason or ""),"[%c]"," ")),140)
		if ((utf8.len(reason) or 0)<3) then return false,"Укажите причину" end
		if ((client.nwPointsNext or 0)>CurTime()) then return false,"Подождите перед следующим начислением" end
		local found=Find(cid)
		if (!found) then return false,"CID не найден" end
		client.nwPointsNext=CurTime()+2
		Modify(found,function(data)
			data.points=data.points or {}
			data.points[kind]=math.min(1000000,(tonumber(data.points[kind]) or 0)+amount)
			data.points.log=data.points.log or {}
			table.insert(data.points.log,1,{time=os.date("%d.%m %H:%M"),by=client:Nick(),kind=kind,amount=amount,reason=reason})
			while (#data.points.log>25) do table.remove(data.points.log) end
		end)
		if (IsValid(found.client)) then NW.Notify(found.client,(kind=="loyalty" and "ОЛ +" or "ОН +")..amount.." — "..reason) end
		NW.Notify(client,"Записано: "..found.name.." · +"..amount)
		MsgN(string.format("[CITIZENS] %s (%s): %s +%d CID %s — %s",client:Nick(),client:SteamID(),kind,amount,tostring(cid),reason))
		Send(client,File(found))
		return true
	end
	function ACTIONS.citizen_points(client,terminal,arg)
		if (terminal:GetClass()!="nw_cmb_terminal") then return end
		local request=util.JSONToTable(arg or "") or {}
		local ok,why=CZ.Award(client,request.cid,request.kind,request.amount,request.reason)
		if (!ok) then NW.Notify(client,why) end
	end
	NW.AddChatCommand("loyalty",{run=function(client,rest)
		local cid,amount,reason=string.match(rest or "","^%s*#?(%d+)%s+(%d+)%s+(.+)$")
		if (!cid) then return NW.Notify(client,"/loyalty <CID> <1–100> <причина>") end
		local ok,why=CZ.Award(client,cid,"loyalty",amount,reason)
		if (!ok) then NW.Notify(client,why) end
	end})

	hook.Add("NWTerminalProfile", "nwCitizens", function(client, extra)
		local points = client.nwCharacter and client.nwCharacter.data and client.nwCharacter.data.points or {}

		extra.loyalty = points.loyalty or 0
		extra.violations = points.violations or 0
	end)

	return
end

local CT = NW.cmbTerminal
local CMB = CT.screens.cmb

local function Up(text)
	return NW.terminal.Upper(tostring(text or ""))
end

net.Receive("nwCitizenFile", function()
	CZ.file = util.JSONToTable(net.ReadString() or "") or {}
	CZ.fileAt = RealTime()

	surface.PlaySound(CZ.file.missing and "buttons/combine_button_locked.wav" or "buttons/combine_button1.wav")

	if (CT.page == "citizens") then
		CT.Refresh()
	end

	if (NW.pda and NW.pda.page == "database" and IsValid(NW.pda.frame)) then
		NW.pda.Show("database")
	end
end)

if (CMB and !CMB.pages.citizens) then
	table.insert(CMB.order, 2, {"citizens", "База граждан"})
end

local function Points(info, kind)
	Derma_StringRequest(kind == "loyalty" and "Очки лояльности" or "Очки нарушений",
		"Сколько (1-" .. CZ.maxPoints .. ")", "1", function(amount)
		Derma_StringRequest("Причина", kind == "loyalty" and "За что начисляются ОЛ" or "Какое нарушение", "",
			function(reason)
			CT.Send("citizen_points", util.TableToJSON({cid = info.cid, kind = kind, amount = tonumber(amount) or 1,
				reason = reason}))
		end)
	end)
end

if (CMB) then
	CMB.pages.citizens = {
		title = "База граждан",
		subtitle = "Поиск по CID / очки лояльности (ОЛ) и нарушений (ОН)",
		Build = function(area, w, h)
			local C = CT.colors
			local gap = math.Round(h * 0.025)
			local fh = math.Round(h * 0.075)
			local entry = CT.Entry(area, 0, 0, w * 0.5, fh, "Номер CID, например 04217")

			entry:SetNumeric(true)

			local function Search()
				local value = entry:GetValue()

				if (value != "") then
					CT.Send("citizen_find", value)
				end
			end

			entry.OnEnter = Search
			CT.Button(area, "Найти", w * 0.5 + gap, 0, w * 0.18, fh, Search, true)

			local info = CZ.file

			if (!info) then
				CT.Label(area, "Введите номер CID гражданина", 0, fh + gap * 2, "nwCmtText", C.dim)

				return
			end

			if (info.missing) then
				CT.Label(area, "Номер #" .. tostring(info.cid or "?") .. " не найден в базе данных", 0, fh + gap * 2, "nwCmtText",
					C.red)

				return
			end

			entry:SetValue(tostring(info.cid))

			local y = fh + gap * 1.5
			local card = area:Add("DPanel")
			local ch = math.Round(h * 0.42)

			card:SetPos(0, y)
			card:SetSize(w, ch)
			card.Paint = function(_, cw, chh)
				surface.SetDrawColor(C.dark.r, C.dark.g, C.dark.b, 200)
				surface.DrawRect(0, 0, cw, chh)
				CT.LitBar(0, 0, cw, math.Round(chh * 0.16))
				draw.SimpleText(Up(info.name) .. "  ·  #" .. tostring(info.cid), "nwCmtHead", chh * 0.05, chh * 0.08, C.dark,
					TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText(info.online and "В СЕТИ" or "НЕ В СЕТИ", "nwCmtSmall", cw - chh * 0.05, chh * 0.08, C.dark,
					TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)

				local rows = {
					{"СТАТУС", Up(info.status)},
					{"МЕСТОНАХОЖДЕНИЕ", info.online and (info.zone != "" and Up(info.zone) or "НЕИЗВЕСТНО") or "—"},
					{"ЗАКЛЮЧЕНИЕ", info.prison and ("ОТБЫВАЕТ, ОСТАЛОСЬ " .. info.prison .. " МИН") or "НЕТ"},
					{"РОЗЫСК", info.wanted and "НАПАДЕНИЕ НА АЛЬЯНС" or "НЕТ"}
				}

				for index, row in ipairs(rows) do
					local ry = chh * 0.22 + (index - 1) * chh * 0.16

					draw.SimpleText(row[1], "nwCmtSmall", chh * 0.05, ry, C.dim)
					draw.SimpleText(row[2], "nwCmtText", chh * 0.05, ry + chh * 0.065,
						(index >= 3 and row[2] != "НЕТ") and C.red or C.text)
				end

				local px = cw * 0.55

				draw.SimpleText("ОЧКИ ЛОЯЛЬНОСТИ", "nwCmtSmall", px, chh * 0.22, C.dim)
				draw.SimpleText(tostring(info.loyalty), "nwCmtBig", px, chh * 0.3, Color(110, 232, 132))
				draw.SimpleText("ОЧКИ НАРУШЕНИЙ", "nwCmtSmall", px + cw * 0.22, chh * 0.22, C.dim)
				draw.SimpleText(tostring(info.violations), "nwCmtBig", px + cw * 0.22, chh * 0.3, C.red)

				local total = math.max(info.loyalty + info.violations, 1)
				local bw = cw * 0.42

				surface.SetDrawColor(C.red.r, C.red.g, C.red.b, 160)
				surface.DrawRect(px, chh * 0.56, bw, 6)
				surface.SetDrawColor(110, 232, 132, 220)
				surface.DrawRect(px, chh * 0.56, bw * info.loyalty / total, 6)
			end

			CT.Button(card, "+ ОЛ", w * 0.55, ch * 0.7, w * 0.2, ch * 0.18, function()
				Points(info, "loyalty")
			end, true)
			CT.Button(card, "+ ОН", w * 0.77, ch * 0.7, w * 0.2, ch * 0.18, function()
				Points(info, "violations")
			end, false, true)

			y = y + ch + gap
			CT.Label(area, "История записей", 0, y)

			local scroll = CT.Scroll(area, 0, y + h * 0.04, w, h - y - h * 0.04)

			if (#(info.log or {}) == 0) then
				CT.Label(scroll, "Записей нет", 0, 0, "nwCmtText", C.dim)
			end

			for _, record in ipairs(info.log or {}) do
				local row = scroll:Add("DPanel")

				row:Dock(TOP)
				row:DockMargin(0, 0, 8, 4)
				row:SetTall(math.Round(h * 0.06))
				row.Paint = function(_, rw, rh)
					local good = record.kind == "loyalty"

					surface.SetDrawColor(C.dark.r, C.dark.g, C.dark.b, 170)
					surface.DrawRect(0, 0, rw, rh)
					surface.SetDrawColor(good and Color(110, 232, 132) or C.red)
					surface.DrawRect(0, 0, 3, rh)
					draw.SimpleText((good and "ОЛ +" or "ОН +") .. record.amount, "nwCmtText", rh * 0.3, rh / 2,
						good and Color(110, 232, 132) or C.red, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					draw.SimpleText(Up(record.reason), "nwCmtSmall", rw * 0.12, rh / 2, C.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					draw.SimpleText(Up(record.by) .. "  ·  " .. tostring(record.time), "nwCmtSmall", rw - rh * 0.3, rh / 2, C.dim,
						TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				end
			end
		end
	}
end
