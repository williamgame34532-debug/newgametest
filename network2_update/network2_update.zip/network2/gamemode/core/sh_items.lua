NW.items = NW.items or {}

local I = NW.items

I.list = I.list or {}
I.columns, I.rows = 6, 4
I.gridSize = I.columns * I.rows
I.maxExtra = 24
I.maxSize = I.gridSize + I.maxExtra

I.slots = {
	{id = "primary", name = "Основное", group = "weapon", icon = "rifle"},
	{id = "secondary", name = "Вторичное", group = "weapon", icon = "pistol"},
	{id = "melee", name = "Холодное", group = "weapon", icon = "crowbar"},
	{id = "head", name = "Голова", group = "clothing", icon = "cap"},
	{id = "face", name = "Лицо", group = "clothing", icon = "gasmask"},
	{id = "torso", name = "Торс", group = "clothing", icon = "jacket"},
	{id = "hands", name = "Руки", group = "clothing", icon = "gloves"},
	{id = "legs", name = "Ноги", group = "clothing", icon = "trousers"},
	{id = "feet", name = "Обувь", group = "clothing", icon = "boots"},
	{id = "bag", name = "Сумка", group = "gear", icon = "bag"},
	{id = "carry", name = "В руках", group = "gear", icon = "bag"}
}

I.slotGroups = {head = "head", face = "face", torso = "torso", hands = "hands", legs = "legs", feet = "shoes"}
I.dressGroups = {"head", "face", "glasses", "torso", "hands", "legs", "shoes", "bag", "satchel"}

I.slotByID = {}

for _, slot in ipairs(I.slots) do
	I.slotByID[slot.id] = slot
end

I.categories = {
	food = {name = "Еда", color = Color(214, 178, 104)},
	drink = {name = "Напиток", color = Color(104, 176, 222)},
	medical = {name = "Медицина", color = Color(222, 104, 98)},
	weapon = {name = "Оружие", color = Color(226, 152, 72)},
	clothing = {name = "Одежда", color = Color(150, 170, 196)},
	misc = {name = "Разное", color = Color(170, 176, 182)}
}

function I.Register(id, item)
	item.id = id
	item.category = item.category or "misc"
	item.icon = item.icon or id
	item.model = item.model or "models/props_junk/cardboard_box004a.mdl"
	I.list[id] = item

	return item
end

function I.Get(id)
	return I.list[id or ""]
end

function I.WearIndex(entity, wear)
	local group = entity:FindBodygroupByName(wear.group)

	if (group < 0) then
		return
	end

	if (wear.index and wear.index < entity:GetBodygroupCount(group)) then
		return group, wear.index
	end

	if (wear.match) then
		for _, data in ipairs(entity:GetBodyGroups() or {}) do
			if (data.id == group) then
				for index, name in pairs(data.submodels or {}) do
					if (string.find(string.lower(name), wear.match, 1, true)) then
						return group, index
					end
				end
			end
		end
	end
end

function I.Capacity(equip)
	local cell = equip and equip.bag
	local item = cell and I.Get(cell.id)

	return I.gridSize + math.min(item and item.bag or 0, I.maxExtra)
end

function I.UseVerb(item, bEquipped)
	if (item.useVerb) then
		return item.useVerb
	end

	if (item.slot) then
		return bEquipped and "снять" or "надеть"
	elseif (item.category == "food") then
		return "съесть"
	elseif (item.category == "drink") then
		return "выпить"
	elseif (item.contents) then
		return "распаковать"
	elseif (item.category == "medical") then
		return "применить"
	end

	return "использовать"
end

function I.Effects(item)
	local lines = {}

	if (item.heal) then
		lines[#lines + 1] = "Здоровье +" .. item.heal
	end

	if (item.cure and item.cure != "health" and NW.medical) then
		lines[#lines + 1] = "Лечит: " .. string.lower(NW.medical.cureNames[item.cure] or item.cure)
	end

	if (item.hunger) then
		lines[#lines + 1] = "Сытость +" .. item.hunger
	end

	if (item.thirst) then
		lines[#lines + 1] = "Жажда +" .. item.thirst
	end

	if (item.slot) then
		local slot = I.slotByID[item.slot]

		lines[#lines + 1] = "Слот: " .. (slot and slot.name or item.slot)
	end

	if (item.bag) then
		lines[#lines + 1] = "Ячейки +" .. item.bag
	end

	local disguise = item.disguiseFaction and NW.char.factions[item.disguiseFaction]

	if (disguise or item.disguiseClass) then
		local class = item.disguiseClass and NW.classes and NW.classes.data[item.disguiseClass]

		lines[#lines + 1] = "Маскировка: " .. (class and class.name or (disguise and disguise.name) or item.disguiseClass)
	elseif (item.wearModel) then
		lines[#lines + 1] = "Меняет внешность"
	end

	if (item.contents) then
		lines[#lines + 1] = "Зажмите, чтобы распаковать"
	end

	if (item.contraband) then
		lines[#lines + 1] = "Контрабанда — изымается при обыске"
	end

	if (item.price and item.price > 0) then
		lines[#lines + 1] = "Цена: " .. item.price .. " ток."
	end

	return lines
end

I.bases = I.bases or {}

local ROOT = (GM or GAMEMODE).FolderName .. "/gamemode/framework/items/"

local function Run(path)
	if (SERVER) then
		AddCSLuaFile(path)
	end

	include(path)
end

function I.LoadFolder()
	for _, name in ipairs(file.Find(ROOT .. "base/*.lua", "LUA")) do
		BASE = {}
		Run(ROOT .. "base/" .. name)
		I.bases[string.StripExtension(name)] = BASE
		BASE = nil
	end

	local _, groups = file.Find(ROOT .. "*", "LUA")

	for _, group in ipairs(groups) do
		if (group != "base") then
			for _, name in ipairs(file.Find(ROOT .. group .. "/*.lua", "LUA")) do
				ITEM = {}
				Run(ROOT .. group .. "/" .. name)

				if (string.sub(name, 1, 1) != "_" and ITEM.name) then
					local item = table.Copy(I.bases[ITEM.base or ""] or {})

					for key, value in pairs(ITEM) do
						item[key] = value
					end

					item.group = group
					I.Register(ITEM.id or string.StripExtension(name), item)
				end

				ITEM = nil
			end
		end
	end
end

I.LoadFolder()

I.testSet = {"ration", "ration", "canned", "bread", "water", "soda", "medkit", "bandage", "pills", "pistol", "smg",
	"shotgun", "crowbar", "stunstick", "satchel", "backpack", "pouch", "cl_head_9", "cl_face_2", "cl_torso_41",
	"cl_hands_1", "cl_legs_10", "cl_shoes_6", "flashlight"}

function NW.items.ApplyAppearance(entity,item)
 if (!IsValid(entity) or !item) then return end
 local function Index(value,count)
  local n=tonumber(value) or 0
  if (n!=n or math.abs(n)==math.huge) then n=0 end
  return math.Clamp(math.floor(n),0,math.max(0,count-1))
 end
 entity:SetSkin(Index(item.itemSkin,entity:SkinCount()))
 for _,group in ipairs(entity:GetBodyGroups()) do
  local values=item.itemBodygroups or {}
  entity:SetBodygroup(group.id,Index(values[tostring(group.id)] or values[group.id],group.num))
 end
end
