NW.fabricator = NW.fabricator or {}

local FB = NW.fabricator

FB.sections = {
	{id = "primary", name = "Основное оружие", text = "Пистолеты-пулемёты и винтовки для патрулей и ударных групп."},
	{id = "secondary", name = "Вторичное оружие", text = "Личное оружие юнита: пистолет и электродубинка."},
	{id = "tertiary", name = "Третичное оружие", text = "Взрывные устройства и боевые машины Альянса."},
	{id = "misc", name = "Разное", text = "Снабжение: боеприпасы, броня, медицина, пробивные заряды и замки."}
}

FB.catalog = {
	{id = "smg", section = "primary", kind = "item", item = "smg", cost = 40, name = "Пистолет-пулемёт MP7",
		text = "Компактный пистолет-пулемёт с высоким темпом стрельбы.", model = "models/weapons/w_smg1.mdl"},
	{id = "ar2", section = "primary", kind = "item", item = "ar2", cost = 80, only = "combine",
		name = "Импульсная винтовка OSIPR", text = "Штатная винтовка Надзора с подствольной энергосферой. Только Надзор.",
		model = "models/weapons/w_irifle.mdl"},
	{id = "shotgun", section = "primary", kind = "item", item = "shotgun", cost = 60, only = "combine",
		name = "Дробовик SPAS-12", text = "Помповый дробовик для зачистки помещений. Только Надзор.",
		model = "models/weapons/w_shotgun.mdl"},
	{id = "pistol", section = "secondary", kind = "item", item = "pistol", cost = 20, name = "Пистолет USP Match",
		text = "Табельный пистолет юнита.", model = "models/weapons/w_pistol.mdl"},
	{id = "stunstick", section = "secondary", kind = "item", item = "stunstick", cost = 10, name = "Электродубинка",
		text = "Оглушает при ударе. Основной инструмент Гражданской Обороны.", model = "models/weapons/w_stunbaton.mdl"},
	{id = "grenade", section = "tertiary", kind = "item", item = "frag_grenade", cost = 25, name = "Осколочная граната",
		text = "Взрывное устройство Альянса. Взрывается через несколько секунд после броска.",
		model = "models/items/grenadeammo.mdl"},
	{id = "manhack", section = "tertiary", kind = "item", item = "deploy_manhack", cost = 35, name = "Мэнхек",
		text = "Летающий резак Альянса: атакует врагов Альянса.", model = "models/manhack.mdl"},
	{id = "rollermine", section = "tertiary", kind = "item", item = "deploy_rollermine", cost = 45, name = "Роллермина",
		text = "Шар, который катится к врагу и бьёт током.", model = "models/roller.mdl"},
	{id = "ammo", section = "misc", kind = "ammo", cost = 15, name = "Боеприпасы",
		text = "Пополняет боезапас всего оружия при вас до полного.", model = "models/items/boxmrounds.mdl"},
	{id = "armor", section = "misc", kind = "armor", cost = 20, name = "Ремонт бронекостюма",
		text = "Чинит броню, если она 50 или меньше.", model = "models/items/battery.mdl"},
	{id = "stim", section = "misc", kind = "item", item = "stimdose", cost = 15, name = "Стимдоза",
		text = "Шприц Альянса с лечебным составом: почти мгновенное восстановление.", model = "models/healthvial.mdl"},
	{id = "breach", section = "misc", kind = "item", item = "breach_charge", cost = 30, name = "Пробивной заряд",
		text = "Силой открывает закрытую или запертую дверь.", model = "models/weapons/w_slam.mdl"},
	{id = "lock", section = "misc", kind = "item", item = "combine_lock", cost = 25, name = "Замок Альянса",
		text = "Дверь открывается только юнитами Альянса.", model = "models/props_combine/combine_lock01.mdl"},
	{id = "health_vial", section = "misc", kind = "item", item = "health_vial", cost = 15, name = "Колба с личинкой",
		text = "Для станции первой помощи: вставьте колбу и удерживайте E.",
		model = "models/hla/health_station/health_vial.mdl"}
}

FB.byID = {}

for index, entry in ipairs(FB.catalog) do
	entry.index = index
	FB.byID[entry.id] = entry
end

FB.max = CreateConVar("nw_fabricator_resin", "200", {FCVAR_ARCHIVE, FCVAR_REPLICATED}, "Сколько смолы вмещает фабрикатор")
FB.resinValue = 25

FB.Model = "models/cf_rework/hla_station.mdl"
FB.CartridgeModel = "models/cf_rework/resin_cartridge.mdl"
FB.WakeRadius = 150
FB.CloseDelay = 1.2
FB.UseRange = 110
FB.LeaveRadius = 185
FB.IdleTimeout = 120
FB.RefillTimeout = 8
FB.FeedInterval = 0.45

FB.State = {DORMANT = 0, MENU = 1, DEPOSIT = 2, PRINT = 3, DONE = 4, REFILL = 5}

FB.ClickSounds = {"combine_fabricator/ui/click_01.mp3", "combine_fabricator/ui/click_02.mp3",
	"combine_fabricator/ui/click_03.mp3", "combine_fabricator/ui/click_04.mp3"}

FB.HoloCenter = Vector(7.5, -15.5, 62)
FB.HoloBox = {w = 10.5, h = 8.5}
FB.ItemFit = {len = 8.5, cross = 4.5}
FB.PANEL_W, FB.PANEL_H = 21.42, 12.05

local S = FB.State

function FB.Clamp(x, a, b)
	if (x < a) then return a elseif (x > b) then return b end
	return x
end

function FB.Smooth(x)
	x = FB.Clamp(x, 0, 1)
	return x * x * (3 - 2 * x)
end

function FB.SectionIndex(id)
	for index, section in ipairs(FB.sections) do
		if (section.id == id) then return index end
	end
end

function FB.TabCat(tab)
	tab = tonumber(tab) or 1
	return math.max(1, tab % 16), math.floor(tab / 16)
end

function FB.CategoryItems(cat)
	local out = {}
	local section = FB.sections[cat]

	for index, entry in ipairs(FB.catalog) do
		if (section and entry.section == section.id and !entry.off) then out[#out + 1] = index end
	end

	return out
end

function FB.PrintProgress(ent, t)
	local elapsed = (t or CurTime()) - ent:GetStageStarted()
	return FB.Clamp(elapsed / math.max(0.1, ent:GetStageUntil() - ent:GetStageStarted()), 0, 1)
end

function FB.BuildProgress(ent, t)
	return FB.Clamp((FB.PrintProgress(ent, t) - 0.18) / 0.62, 0, 1)
end

local Lay = {}
FB.Layout = Lay

Lay.W, Lay.H = 1024, 512
Lay.ROW = {x = 40, y = 78, w = 600, h = 56, gap = 12, max = 4}
Lay.TAB = {x = 40, y = 352, h = 38, gap = 8}
Lay.SUMMARY = {x = 684, y = 62, w = 306}
Lay.PANEL = {x = 24, y = 84, w = 624, h = 252}
Lay.CANCEL = {x = 498, y = 360, w = 150, h = 48}
Lay.EXIT = {x = 840, y = 384, w = 150, h = 44}
Lay.BOTTOM = 440

function Lay.TabWidth()
	local count = #FB.sections
	return math.floor((Lay.ROW.w - (count - 1) * Lay.TAB.gap) / count)
end

function Lay.Buttons(stage, tab)
	local b = {}

	if (stage == S.MENU) then
		local R = Lay.ROW
		local cat, page = FB.TabCat(tab)
		local list = FB.CategoryItems(cat)
		local paged = #list > 6
		local per = paged and 5 or #list
		local pages = paged and math.ceil(#list / per) or 1
		page = math.Clamp(page, 0, pages - 1)
		local slots = paged and 6 or math.min(#list, 6)
		local h, gap = R.h, R.gap

		if (slots > R.max) then
			gap = 8
			h = math.floor((R.max * R.h + (R.max - 1) * R.gap - (slots - 1) * gap) / slots)
		end

		local row = 0

		for i = page * per + 1, math.min(#list, page * per + per) do
			row = row + 1
			b[#b + 1] = {id = "select", arg = list[i], x = R.x, y = R.y + (row - 1) * (h + gap), w = R.w, h = h}
		end

		if (paged) then
			local y = R.y + 5 * (h + gap)
			local w = math.floor((R.w - gap) / 2)

			if (page > 0) then b[#b + 1] = {id = "page", arg = cat + (page - 1) * 16, label = "<  НАЗАД", x = R.x, y = y, w = w, h = h} end
			if (page < pages - 1) then b[#b + 1] = {id = "page", arg = cat + (page + 1) * 16, label = "ДАЛЕЕ  >", x = R.x + w + gap, y = y, w = w, h = h} end

			b.pageText = (page + 1) .. " / " .. pages
		end

		local T = Lay.TAB
		local tw = Lay.TabWidth()

		for i = 1, #FB.sections do
			b[#b + 1] = {id = "tab", arg = i, x = T.x + (i - 1) * (tw + T.gap), y = T.y, w = tw, h = T.h}
		end

		b[#b + 1] = {id = "exit", x = Lay.EXIT.x, y = Lay.EXIT.y, w = Lay.EXIT.w, h = Lay.EXIT.h}
	elseif (stage == S.DEPOSIT) then
		b[1] = {id = "cancel", x = Lay.CANCEL.x, y = Lay.CANCEL.y, w = Lay.CANCEL.w, h = Lay.CANCEL.h}
		b[2] = {id = "exit", x = Lay.EXIT.x, y = Lay.EXIT.y, w = Lay.EXIT.w, h = Lay.EXIT.h}
	elseif (stage == S.REFILL) then
		b[1] = {id = "exit", x = Lay.EXIT.x, y = Lay.EXIT.y, w = Lay.EXIT.w, h = Lay.EXIT.h}
	end

	return b
end

function Lay.ButtonAt(stage, tab, x, y)
	for _, b in ipairs(Lay.Buttons(stage, tab)) do
		if (x >= b.x and y >= b.y and x <= b.x + b.w and y <= b.y + b.h) then return b end
	end
end

function FB.Upper(s)
	s = string.upper(s)
	s = s:gsub("\208([\176-\191])", function(c) return "\208" .. string.char(c:byte() - 32) end)
	s = s:gsub("\209([\128-\143])", function(c) return "\208" .. string.char(c:byte() + 32) end)
	s = s:gsub("\209\145", "\208\129")
	return s
end

local function att(ent, name)
	local id = ent:LookupAttachment(name)
	if (!id or id <= 0) then return end
	local a = ent:GetAttachment(id)
	if (a) then return a.Pos, a.Ang end
end

FB.Attachment = att

function FB.Ready(ent)
	return IsValid(ent) and ent.GetDeployed != nil and ent:GetDeployed()
end

function FB.ScreenWorld(ent)
	local pos, ang = att(ent, "main_panel_fill")
	if (!pos) then return end
	local right, up, normal = ang:Forward(), -ang:Right(), ang:Up()
	local scale = FB.PANEL_W / Lay.W
	local margin = (FB.PANEL_H - Lay.H * scale) * 0.5
	local origin = pos + up * (FB.PANEL_H - margin)
	return origin, right, -up, normal, ang, scale, pos
end

function FB.HitScreen(ent, ply)
	if (!IsValid(ply) or !FB.Ready(ent)) then return end
	local origin, right, down, normal, _, scale = FB.ScreenWorld(ent)
	if (!origin) then return end
	local eye, dir = ply:EyePos(), ply:GetAimVector()
	if (eye:DistToSqr(origin) > FB.UseRange * FB.UseRange) then return end
	if (dir:Dot(normal) >= -0.05 or (eye - origin):Dot(normal) <= 0) then return end
	local hit = util.IntersectRayWithPlane(eye, dir, origin, normal)
	if (!hit) then return end
	local rel = hit - origin
	local x, y = rel:Dot(right) / scale, rel:Dot(down) / scale
	if (x < 0 or y < 0 or x > Lay.W or y > Lay.H) then return end
	return x, y, hit
end

local function raySphere(eye, dir, center, radius)
	local oc = center - eye
	local t = oc:Dot(dir)
	if (t < 0) then return end
	if (oc:LengthSqr() - t * t > radius * radius) then return end
	return t
end

function FB.CellsCenter(ent)
	local sum, n = Vector(0, 0, 0), 0

	for i = 0, 9 do
		local p = att(ent, string.format("resin_attach_%02d", i))
		if (p) then sum = sum + p n = n + 1 end
	end

	if (n > 0) then return sum / n end
end

function FB.ItemPoint(ent)
	local p, a = att(ent, "item_attach")
	return p or ent:WorldSpaceCenter(), a or ent:GetAngles()
end

function FB.CellsOpen(ent)
	local st = ent:GetStage()
	return (st == S.DEPOSIT or st == S.REFILL) and ent:GetTrayReady()
end

function FB.HitPart(ent, ply)
	if (!IsValid(ply)) then return end
	local eye, dir = ply:EyePos(), ply:GetAimVector()
	local best, bestT

	local function try(name, center, radius)
		if (!center) then return end
		local t = raySphere(eye, dir, center, radius)
		if (t and t < FB.UseRange and (!bestT or t < bestT)) then best, bestT = name, t end
	end

	if (FB.CellsOpen(ent)) then try("cells", FB.CellsCenter(ent), 9) end
	if (ent:GetStage() == S.DONE and ent:GetBayOpen()) then try("chamber", (FB.ItemPoint(ent)), 10) end

	return best
end

function FB.CanCatalog(client)
	return IsValid(client) and client:GetCharacterID() != 0 and NW.zones.UsesAlliance(client)
end

function FB.ResinBlocks(client)
	local inventory = SERVER and NW.inventory.Get(client) or NW.inventory.data
	local count = 0

	if (!inventory or !inventory.grid) then return 0 end

	for _, cell in pairs(inventory.grid) do
		if (cell and cell.id == "fabricator_resin") then count = count + 1 end
	end

	return count
end

if (CLIENT) then
	return
end

util.AddNetworkString("nwFabFocus")
util.AddNetworkString("nwFabPress")
util.AddNetworkString("nwFabFocusReq")

function FB.SetFocus(p, e)
	if (!IsValid(p)) then return end
	e = IsValid(e) and e or nil
	if (p.nwFabFocus == e) then return end
	if (!e) then p.nwFabNoFireUntil = CurTime() + 0.35 end
	p.nwFabFocus = e
	p.nwFabFocusAt = CurTime()
	net.Start("nwFabFocus")
	net.WriteEntity(e or NULL)
	net.Send(p)
end

function FB.Focused(p, e)
	return IsValid(p) and p.nwFabFocus != nil and p.nwFabFocus == e
end

local function target(p)
	for _, e in ipairs(ents.FindInSphere(p:EyePos(), FB.UseRange + 60)) do
		if (e.IsCombineFabricator) then
			local x, y = FB.HitScreen(e, p)
			if (x) then return e, x, y end
			local part = FB.HitPart(e, p)
			if (part) then return e, nil, nil, part end
		end
	end
end

hook.Add("StartCommand", "nwFabFocus", function(p, cmd)
	if (IsValid(p.nwFabFocus) or (p.nwFabNoFireUntil or 0) > CurTime()) then
		cmd:SetButtons(bit.band(cmd:GetButtons(), bit.bnot(bit.bor(IN_ATTACK, IN_ATTACK2))))
	end
end)

hook.Add("KeyPress", "nwFabUse", function(p, key)
	if (key != IN_USE or !p:Alive() or p:GetCharacterID() == 0 or (p.nwFabNextUse or 0) > CurTime()) then return end
	if (IsValid(p.nwFabFocus)) then
		if (CurTime() - (p.nwFabFocusAt or 0) > 0.4) then
			p.nwFabNextUse = CurTime() + 0.3
			FB.SetFocus(p, nil)
		end
		return
	end

	local e, x, y, part = target(p)

	if (e) then
		p.nwFabNextUse = CurTime() + 0.2
		if (x) then e:RequestFocus(p) else e:Interact(p, nil, nil, part) end
		return
	end

	local tr = p:GetEyeTrace()
	local hull = tr.Entity

	if (IsValid(hull) and hull.IsCombineFabricator and tr.HitPos:DistToSqr(p:EyePos()) < (FB.UseRange + 40) ^ 2) then
		p.nwFabNextUse = CurTime() + 0.4
		hull.LastNearby = CurTime()
		hull:UseAt(p)
	end
end)

net.Receive("nwFabFocusReq", function(_, p)
	local e = net.ReadEntity()

	if (!IsValid(e) or !e.IsCombineFabricator or !p:Alive() or IsValid(p.nwFabFocus) or (p.nwFabReqNext or 0) > CurTime()) then return end
	if (p:EyePos():DistToSqr(e:WorldSpaceCenter()) > (FB.UseRange + 60) ^ 2) then return end

	p.nwFabReqNext = CurTime() + 0.3
	p.nwFabNextUse = CurTime() + 0.3
	e.LastNearby = CurTime()

	if (e:GetStage() == FB.State.MENU) then
		e:RequestFocus(p)
	else
		e:UseAt(p)
	end
end)

net.Receive("nwFabPress", function(_, p)
	local x, y = net.ReadFloat(), net.ReadFloat()
	local e = p.nwFabFocus
	if (!IsValid(e) or !p:Alive() or (p.nwFabNextUse or 0) > CurTime()) then return end
	if (p:GetPos():DistToSqr(e:GetPos()) > FB.LeaveRadius * FB.LeaveRadius) then FB.SetFocus(p, nil) return end
	if (x != x or y != y or x < 0 or y < 0 or x > Lay.W or y > Lay.H) then return end
	p.nwFabNextUse = CurTime() + 0.15
	e:Interact(p, x, y, nil)
end)

net.Receive("nwFabFocus", function(_, p)
	if (net.ReadBool() == false) then FB.SetFocus(p, nil) end
end)

hook.Add("PlayerDeath", "nwFabFocus", function(p) FB.SetFocus(p, nil) end)
hook.Add("PlayerDisconnected", "nwFabFocus", function(p)
	for _, e in ipairs(ents.FindByClass("nw_fabricator")) do
		if (e:GetOperator() == p and e:GetStage() == S.DEPOSIT) then e:EndSession(true) end
	end
end)

function FB.AimedPart(e, p)
	if (FB.Focused(p, e)) then return nil end
	return FB.HitPart(e, p)
end

local INV = NW.inventory
local D = NW.doors

function FB.TakeResinBlock(client)
	local inventory = INV.Get(client)

	for i = 1, NW.items.maxSize do
		local cell = inventory.grid[i]

		if (cell and cell.id == "fabricator_resin") then
			inventory.grid[i] = nil
			INV.Changed(client)
			return true
		end
	end

	return false
end

local GIVE = {}
FB.GIVE = GIVE

function GIVE.ammo(client)
	local any = false

	for _, weapon in ipairs(client:GetWeapons()) do
		local ammo = weapon:GetPrimaryAmmoType()

		if (ammo >= 0) then
			local full = math.max(weapon:GetMaxClip1(), 1) * 4

			if (client:GetAmmoCount(ammo) < full) then
				client:SetAmmo(full, ammo)
				any = true
			end
		end

		local second = weapon:GetSecondaryAmmoType()

		if (second >= 0 and client:GetAmmoCount(second) < 2) then
			client:SetAmmo(2, second)
			any = true
		end
	end

	return any or "БОЕЗАПАС УЖЕ ПОЛНЫЙ"
end

function GIVE.armor(client)
	if (client:Armor() > 50) then
		return "БРОНЯ ЕЩЁ ЦЕЛА (БОЛЬШЕ 50)"
	end

	client:SetArmor(100)
	client:EmitSound("items/battery_pickup.wav", 60)
end

function FB.Deliver(client, entry)
	if (entry.only and client:GetFaction() != entry.only) then
		return false, "НЕДОСТУПНО ДЛЯ ВАШЕГО ПОДРАЗДЕЛЕНИЯ"
	end

	if (entry.kind == "item") then
		if (!INV.Add(client, entry.item)) then return false, "В ИНВЕНТАРЕ НЕТ МЕСТА" end
		INV.Changed(client)
		return true
	end

	local problem = GIVE[entry.kind] and GIVE[entry.kind](client, entry)
	if (isstring(problem)) then return false, problem end

	return true
end

function FB.PlaceLock(client)
	local trace = client:GetEyeTrace()
	local door = trace.Entity

	if (!D.IsDoor(door) or trace.HitPos:DistToSqr(client:GetShootPos()) > 100 * 100) then
		NW.Notify(client, "Посмотрите на дверь рядом")
		return false
	end

	local stored = scripted_ents.GetStored("nw_combinelock")
	local lock = stored and stored.t.SpawnFunction(stored.t, client, trace)

	if (!IsValid(lock)) then
		return false
	end

	client:EmitSound("doors/door_metal_thin_close2.wav", 60)
	NW.Notify(client, "Замок установлен")

	return true
end

function FB.Breach(client)
	local trace = client:GetEyeTrace()
	local door = trace.Entity

	if (!D.IsDoor(door) or trace.HitPos:DistToSqr(client:GetShootPos()) > 100 * 100) then
		NW.Notify(client, "Посмотрите на дверь рядом")
		return false
	end

	local charge = ents.Create("prop_physics")

	charge:SetModel("models/weapons/w_slam.mdl")
	charge:SetPos(trace.HitPos + trace.HitNormal * 1.5)
	charge:SetAngles(trace.HitNormal:Angle() + Angle(90, 0, 0))
	charge:Spawn()
	charge:SetMoveType(MOVETYPE_NONE)
	charge:SetCollisionGroup(COLLISION_GROUP_WORLD)
	charge:SetParent(door)

	NW.SayMe(client, "ставит пробивной заряд на дверь")

	for beep = 0, 4 do
		timer.Simple(beep * 0.6, function()
			if (IsValid(charge)) then
				charge:EmitSound("buttons/blip1.wav", 70, 100 + beep * 12)
			end
		end)
	end

	timer.Simple(3, function()
		if (!IsValid(charge)) then
			return
		end

		local pos = charge:GetPos()

		charge:Remove()

		local effect = EffectData()

		effect:SetOrigin(pos)
		util.Effect("Explosion", effect, true, true)
		util.BlastDamage(IsValid(client) and client or game.GetWorld(), IsValid(client) and client or game.GetWorld(),
			pos, 110, 35)

		if (!IsValid(door)) then
			return
		end

		local lock = door.nwCombineLock

		if (IsValid(lock) and lock.SetState) then
			lock:SetState(false)
		end

		local name = IsValid(client) and ("nwBreacher" .. client:EntIndex()) or ""

		if (IsValid(client)) then
			client:SetName(name)
		end

		for _, member in ipairs(D.Group(door)) do
			member.nwLocked = false
			member:Fire("Unlock")

			if (member:GetClass() == "prop_door_rotating" and name != "") then
				member:Fire("OpenAwayFrom", name)
			else
				member:Fire("Open")
			end
		end

		util.ScreenShake(pos, 8, 10, 0.6, 600)
	end)

	return true
end
