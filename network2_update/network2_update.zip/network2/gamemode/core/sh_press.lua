NW.press = NW.press or {}

local PR = NW.press

PR.maxCopies = 10
PR.printerRange = 350
PR.boardLimit = 12

function PR.Clean(text, bytes, multiline)
	text = tostring(text or "")
	text = multiline and string.gsub(text, "[%z\1-\9\11-\31]", " ") or string.gsub(text, "[%c]", " ")
	return NW.Cut(string.Trim(text), bytes)
end

if (SERVER) then
	util.AddNetworkString("nwPaperRead")
	util.AddNetworkString("nwPaperWrite")
	util.AddNetworkString("nwPrinterOpen")
	util.AddNetworkString("nwPrinterPrint")
	util.AddNetworkString("nwBoardOpen")
	util.AddNetworkString("nwBoardAction")

	local INV = NW.inventory

	function PR.Read(client, data)
		net.Start("nwPaperRead")
			net.WriteString(util.TableToJSON({title = data.title or "", text = data.text or "", author = data.author or "",
				time = data.time or ""}))
		net.Send(client)
	end

	function PR.UsePaper(client, cell)
		local data = cell.data or {}

		if ((data.text or "") != "") then
			PR.Read(client, data)
			return
		end

		client.nwPaperCell = cell
		net.Start("nwPaperWrite")
		net.Send(client)
	end

	net.Receive("nwPaperWrite", function(_, client)
		local title = PR.Clean(net.ReadString(), 80)
		local text = PR.Clean(net.ReadString(), 2000, true)
		local cell = client.nwPaperCell

		client.nwPaperCell = nil

		if (!cell or text == "") then return end

		local inventory = INV.Get(client)
		local found = false

		for index = 1, NW.items.maxSize do
			if (inventory.grid[index] == cell) then found = true break end
		end

		if (!found or cell.id != "paper" or (cell.data and (cell.data.text or "") != "")) then return end

		cell.data = {title = title != "" and title or "Записка", text = text, author = client:RealName(), time = os.date("%d.%m %H:%M")}
		INV.Changed(client)
		NW.SayMe(client, "что-то пишет на листке")
	end)

	function PR.Spawn(pos, ang, data)
		local entity = ents.Create("nw_item")
		if (!IsValid(entity)) then return end
		entity:SetItem("paper", data)
		entity:SetPos(pos)
		entity:SetAngles(ang)
		entity:Spawn()
		return entity
	end

	function PR.Print(printer, data, copies)
		copies = math.Clamp(math.floor(tonumber(copies) or 1), 1, PR.maxCopies)

		if ((printer.nwPrintBusy or 0) > CurTime()) then
			return false, "Принтер занят ещё " .. math.ceil(printer.nwPrintBusy - CurTime()) .. " с"
		end

		printer.nwPrintBusy = CurTime() + copies * 1.2 + 20

		local mine = {}

		for _, entity in ipairs(ents.FindByClass("nw_item")) do
			if (entity.nwPrintedBy == printer) then mine[#mine + 1] = entity end
		end

		for index = 1, #mine + copies - 20 do
			if (IsValid(mine[index])) then mine[index]:Remove() end
		end

		for index = 1, copies do
			timer.Simple(index * 1.2, function()
				if (!IsValid(printer)) then return end
				local pos = printer:WorldSpaceCenter() + printer:GetForward() * (printer:OBBMaxs().x + 6) + Vector(0, 0, 4)
				local sheet = PR.Spawn(pos, printer:GetAngles(), table.Copy(data))
				if (IsValid(sheet)) then sheet.nwPrintedBy = printer end
				printer:EmitSound("ambient/machines/keyboard" .. math.random(1, 6) .. "_clicks.wav", 60, 120)
			end)
		end

		printer:EmitSound("buttons/button9.wav", 60, 90)

		return true
	end

	function PR.Nearest(pos, range)
		local best, distance

		for _, printer in ipairs(ents.FindByClass("nw_printer")) do
			local d = printer:GetPos():DistToSqr(pos)
			if (d < (range or PR.printerRange) ^ 2 and (!distance or d < distance)) then best, distance = printer, d end
		end

		return best
	end

	function PR.CanUsePrinter(client, printer)
		local owner = printer:GetNW2Int("nwPrinterOwner", 0)
		return owner == 0 or owner == client:GetCharacterID() or client:IsAdmin()
	end

	function PR.Deploy(client)
		for _, printer in ipairs(ents.FindByClass("nw_printer")) do
			if (printer:GetNW2Int("nwPrinterOwner", 0) == client:GetCharacterID()) then
				NW.Notify(client, "Ваш принтер уже стоит. Alt + E по нему — сложить")
				return false
			end
		end

		local trace = util.TraceLine({start = client:EyePos(), endpos = client:EyePos() + client:GetAimVector() * 110, filter = client})

		if (!trace.Hit or trace.HitNormal.z < 0.7) then
			NW.Notify(client, "Посмотрите на пол или стол рядом")
			return false
		end

		local printer = ents.Create("nw_printer")
		if (!IsValid(printer)) then return false end
		printer:SetPos(trace.HitPos)
		printer:SetAngles(Angle(0, client:EyeAngles().y + 180, 0))
		printer:Spawn()
		printer:Activate()
		printer:SetPos(trace.HitPos - Vector(0, 0, printer:OBBMins().z))
		printer:SetNW2Int("nwPrinterOwner", client:GetCharacterID())
		printer:SetNW2String("nwPrinterOwnerName", client:RealName())
		NW.SayMe(client, "ставит принтер")

		local data = client.nwCharacter and client.nwCharacter.data
		if (data) then data.printerOut = true NW.char.SaveData(client) end

		return true
	end

	function PR.Fold(client, printer)
		if (printer:GetNW2Int("nwPrinterOwner", 0) != client:GetCharacterID()) then return false end

		if (!INV.Add(client, "printer_kit")) then
			NW.Notify(client, "Нет места в инвентаре")
			return true
		end

		INV.Changed(client)
		printer:Remove()
		NW.Notify(client, "Принтер сложен в инвентарь")

		local data = client.nwCharacter and client.nwCharacter.data
		if (data) then data.printerOut = nil NW.char.SaveData(client) end

		return true
	end

	net.Receive("nwPrinterPrint", function(_, client)
		local printer = net.ReadEntity()
		local title = PR.Clean(net.ReadString(), 80)
		local text = PR.Clean(net.ReadString(), 2000, true)
		local copies = net.ReadUInt(5)

		if (!IsValid(printer) or printer:GetClass() != "nw_printer" or client:GetPos():DistToSqr(printer:GetPos()) > 160 * 160 or
			!PR.CanUsePrinter(client, printer) or text == "") then
			return
		end

		local ok, why = PR.Print(printer, {title = title != "" and title or "Листовка", text = text, author = client:RealName(),
			time = os.date("%d.%m %H:%M")}, copies)

		NW.Notify(client, ok and ("Печать: " .. math.Clamp(copies, 1, PR.maxCopies) .. " экз.") or why)
	end)

	function PR.BoardInfo(board)
		local out = {}

		for index, note in ipairs(board.nwNotes or {}) do
			out[#out + 1] = {index = index, title = note.title, text = note.text, author = note.author, time = note.time,
				mine = false, char = note.char}
		end

		return out
	end

	function PR.SyncBoard(board)
		local titles = {}
		for _, note in ipairs(board.nwNotes or {}) do titles[#titles + 1] = note.title end
		board:SetNW2String("nwBoardTitles", util.TableToJSON(titles))
	end

	function PR.OpenBoard(client, board)
		net.Start("nwBoardOpen")
			net.WriteEntity(board)
			net.WriteString(util.TableToJSON(PR.BoardInfo(board)))
		net.Send(client)
	end

	net.Receive("nwBoardAction", function(_, client)
		local board = net.ReadEntity()
		local action = net.ReadString()
		local arg = net.ReadUInt(8)

		if (!IsValid(board) or board:GetClass() != "nw_notice_board" or client:GetPos():DistToSqr(board:GetPos()) > 180 * 180 or
			(client.nwBoardNext or 0) > CurTime()) then
			return
		end

		client.nwBoardNext = CurTime() + 0.4
		board.nwNotes = board.nwNotes or {}

		if (action == "pin") then
			local inventory = INV.Get(client)
			local cell = inventory.grid[arg]

			if (!cell or cell.id != "paper" or !cell.data or (cell.data.text or "") == "") then
				return NW.Notify(client, "Нужен исписанный листок")
			end

			if (#board.nwNotes >= PR.boardLimit) then
				return NW.Notify(client, "На доске нет места")
			end

			inventory.grid[arg] = nil
			INV.Changed(client)
			table.insert(board.nwNotes, 1, {title = cell.data.title or "Записка", text = cell.data.text, author = cell.data.author or "",
				time = cell.data.time or os.date("%d.%m %H:%M"), char = client:GetCharacterID(), pinned = os.time()})
			NW.SayMe(client, "вешает листок на доску объявлений")
		elseif (action == "take") then
			local note = board.nwNotes[arg]

			if (!note) then return end

			local allowed = note.char == client:GetCharacterID() or client:IsAdmin() or NW.zones.UsesAlliance(client)

			if (!allowed) then return NW.Notify(client, "Снять может автор, Альянс или администрация") end

			if (!INV.Add(client, "paper", {title = note.title, text = note.text, author = note.author, time = note.time})) then
				return NW.Notify(client, "Нет места в инвентаре")
			end

			INV.Changed(client)
			table.remove(board.nwNotes, arg)
			NW.SayMe(client, "снимает листок с доски объявлений")
		else
			return
		end

		PR.SyncBoard(board)
		NW.persist.Save("nw_notice_board")
		PR.OpenBoard(client, board)
	end)

	hook.Add("NWCharacterLoaded", "nwPress", function(client, character)
		timer.Simple(4, function()
			if (!IsValid(client) or client:GetCharacterID() != character.id) then return end
			local data = character.data or {}
			if (!data.printerOut) then return end
			for _, printer in ipairs(ents.FindByClass("nw_printer")) do
				if (printer:GetNW2Int("nwPrinterOwner", 0) == character.id) then return end
			end
			data.printerOut = nil
			if (!INV.Add(client, "printer_kit")) then INV.SpawnWorldItem(client, {id = "printer_kit", data = {}}) end
			INV.Changed(client)
			NW.Notify(client, "Ваш переносной принтер вернулся в инвентарь")
		end)
	end)

	timer.Create("nwBoardExpire", 300, 0, function()
		local cutoff = os.time() - 86400 * 3

		for _, board in ipairs(ents.FindByClass("nw_notice_board")) do
			local keep = {}
			for _, note in ipairs(board.nwNotes or {}) do
				if ((note.pinned or os.time()) > cutoff) then keep[#keep + 1] = note end
			end
			if (#keep != #(board.nwNotes or {})) then
				board.nwNotes = keep
				PR.SyncBoard(board)
				NW.persist.Save("nw_notice_board")
			end
		end
	end)

	return
end

local W = NW.widgets
local U = NW.ui

local function Sheet(title, w, h)
	local frame, box = W.Window(title, w, h)
	return frame, box, math.Round(ScrH() * 0.02)
end

net.Receive("nwPaperRead", function()
	PR.Show(util.JSONToTable(net.ReadString() or "") or {})
end)

local function Editor(title, onSend, withCopies)
	local sh = ScrH()
	local frame, box, pad = Sheet(title, math.Round(sh * 0.8), math.Round(sh * 0.75))
	local bw, bh = box:GetWide(), box:GetTall()
	local y = box.top

	W.Label(box, "Заголовок", pad, y)
	local head = W.Entry(box, "", "Заголовок")
	head:SetPos(pad, y + sh * 0.02)
	head:SetSize(bw - pad * 2, sh * 0.04)
	y = y + sh * 0.07

	W.Label(box, "Текст", pad, y)
	local body = W.Entry(box, "", "Текст", true)
	body:SetPos(pad, y + sh * 0.02)
	body:SetSize(bw - pad * 2, bh - y - sh * 0.12)

	local copies

	if (withCopies) then
		W.Label(box, "Экземпляров", pad, bh - sh * 0.09)
		copies = W.Number(box, 1, 1, NW.press.maxCopies)
		copies:SetPos(pad, bh - sh * 0.07)
		copies:SetSize(sh * 0.12, sh * 0.045)
	end

	local send = W.Button(box, withCopies and "Печать" or "Записать", function()
		onSend(head:GetValue(), body:GetValue(), copies and copies:GetNumber() or 1)
		frame:Remove()
	end, true)

	send:SetPos(bw - pad - sh * 0.22, bh - sh * 0.07)
	send:SetSize(sh * 0.22, sh * 0.045)

	return frame, head, body
end

PR.Editor = Editor

net.Receive("nwPaperWrite", function()
	Editor("Написать на листке", function(title, text)
		net.Start("nwPaperWrite")
			net.WriteString(title)
			net.WriteString(text)
		net.SendToServer()
	end)
end)

net.Receive("nwPrinterOpen", function()
	local printer = net.ReadEntity()

	Editor("Принтер · печать листовок", function(title, text, count)
		net.Start("nwPrinterPrint")
			net.WriteEntity(printer)
			net.WriteString(title)
			net.WriteString(text)
			net.WriteUInt(math.Clamp(count or 1, 1, NW.press.maxCopies), 5)
		net.SendToServer()
	end, true)
end)

local BOARD_SHEET = Material("network2/ui/board_sheet.png", "smooth")

net.Receive("nwBoardOpen", function()
	local board = net.ReadEntity()
	local notes = util.JSONToTable(net.ReadString() or "") or {}
	local sh = ScrH()

	if (IsValid(PR.boardFrame)) then PR.boardFrame:Remove() end

	local frame, box, pad = Sheet("Доска объявлений", math.Round(sh * 1.1), math.Round(sh * 0.78))
	PR.boardFrame = frame

	local bw, bh = box:GetWide(), box:GetTall()
	local scroll = W.Scroll(box)

	scroll:SetPos(pad, box.top)
	scroll:SetSize(bw * 0.62, bh - box.top - pad)

	local grid = scroll:Add("DIconLayout")
	grid:Dock(FILL)
	grid:SetSpaceX(8)
	grid:SetSpaceY(8)

	local me = LocalPlayer()

	for _, note in ipairs(notes) do
		local cell = grid:Add("DButton")
		local size = math.Round((bw * 0.62 - 24) / 3)

		cell:SetSize(size, size * 0.8)
		cell:SetText("")
		cell.Paint = function(self, w, h)
			if (!BOARD_SHEET:IsError()) then
				surface.SetMaterial(BOARD_SHEET)
				surface.SetDrawColor(255, 255, 255, 255)
				surface.DrawTexturedRect(0, 0, w, h)
			else
				draw.RoundedBox(4, 0, 0, w, h, Color(226, 220, 200))
			end
			if (self:IsHovered()) then
				surface.SetDrawColor(232, 196, 72, 200)
				surface.DrawOutlinedRect(0, 0, w, h, 2)
			end
			draw.SimpleText(NW.Cut(note.title or "", 40), "nwWidgetBold", w / 2, h * 0.2, Color(30, 30, 34), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText(NW.Cut(string.gsub(note.text or "", "\n", " "), 46), "nwWidgetLabel", w / 2, h * 0.5, Color(60, 60, 64),
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText((note.author or "") .. " · " .. (note.time or ""), "nwWidgetLabel", w / 2, h * 0.82, Color(90, 90, 96),
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		cell.DoClick = function()
			surface.PlaySound("network2/ui/click.wav")
			PR.Show({title = note.title, text = note.text, author = note.author, time = note.time})
		end
		cell.DoRightClick = function()
			local menu = DermaMenu()
			menu:AddOption("Сорвать / забрать", function()
				net.Start("nwBoardAction")
					net.WriteEntity(board)
					net.WriteString("take")
					net.WriteUInt(note.index, 8)
				net.SendToServer()
			end)
			menu:Open()
		end
	end

	local side = box:Add("EditablePanel")
	side:SetPos(bw * 0.62 + pad * 2, box.top)
	side:SetSize(bw * 0.38 - pad * 3, bh - box.top - pad)

	W.Label(side, "Повесить свой листок", 0, 0)

	local y = ScrH() * 0.025
	local grid2 = NW.inventory.data and NW.inventory.data.grid or {}
	local any = false

	for index, cell in SortedPairs(grid2) do
		if (cell.id == "paper" and cell.data and (cell.data.text or "") != "") then
			any = true
			local button = W.Button(side, NW.Cut(cell.data.title or "Записка", 40), function()
				net.Start("nwBoardAction")
					net.WriteEntity(board)
					net.WriteString("pin")
					net.WriteUInt(index, 8)
				net.SendToServer()
			end)
			button:SetPos(0, y)
			button:SetSize(side:GetWide(), sh * 0.042)
			y = y + sh * 0.048
		end
	end

	if (!any) then
		local hint = side:Add("DLabel")
		hint:SetPos(0, y)
		hint:SetSize(side:GetWide(), sh * 0.1)
		hint:SetWrap(true)
		hint:SetFont("nwWidget")
		hint:SetTextColor(W.MUTED)
		hint:SetText("Нет исписанных листков. Напишите на листке бумаги (используйте его в инвентаре) или напечатайте на принтере.")
	end

	local tip = side:Add("DLabel")
	tip:SetPos(0, side:GetTall() - sh * 0.06)
	tip:SetSize(side:GetWide(), sh * 0.06)
	tip:SetWrap(true)
	tip:SetFont("nwWidgetLabel")
	tip:SetTextColor(W.MUTED)
	tip:SetText("ЛКМ по листку — прочитать, ПКМ — сорвать (автор, Альянс, администрация). Листки висят 3 дня.")
end)

function PR.Show(data)
	local sh = ScrH()
	local frame, box, pad = Sheet(data.title or "Листок", math.Round(sh * 0.7), math.Round(sh * 0.75))
	local text = box:Add("RichText")

	text:SetPos(pad, box.top)
	text:SetSize(box:GetWide() - pad * 2, box:GetTall() - box.top - pad * 3)
	text.PerformLayout = function(self)
		self:SetFontInternal("nwWidget")
		self:SetFGColor(U.color.text)
	end
	text:AppendText(data.text or "")

	local footer = box:Add("DPanel")
	footer:SetPos(pad, box:GetTall() - pad * 2.5)
	footer:SetSize(box:GetWide() - pad * 2, pad * 2)
	footer.Paint = function(_, w, h)
		draw.SimpleText((data.author or "") .. "  ·  " .. (data.time or ""), "nwWidgetLabel", w, h / 2, W.MUTED, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	end
end
