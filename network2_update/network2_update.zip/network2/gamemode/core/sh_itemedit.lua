NW.itemEdit = NW.itemEdit or {}

local IE = NW.itemEdit
local I = NW.items

IE.types = {
	{id = "misc", name = "Предмет", category = "misc",
		hint = "Вещь без особых действий: хлам, документ, деталь, товар, сырьё для крафта."},
	{id = "food", name = "Еда", category = "food", base = "food",
		hint = "Съедается: снимает голод. «Остаётся после» — что ляжет в ячейку (пустая банка)."},
	{id = "drink", name = "Напиток", category = "drink", base = "drink",
		hint = "Выпивается: снимает жажду. Может оставлять пустую бутылку."},
	{id = "medical", name = "Медицина", category = "medical", base = "medical",
		hint = "Лечит: здоровье + и одно из ранений (кровотечение, перелом, боль, отравление) или всё сразу. " ..
			"Видна на странице «Состояние» инвентаря."},
	{id = "weapon", name = "Оружие", category = "weapon", base = "weapon",
		hint = "Кладётся в слот оружия и выдаёт SWEP (класс оружия, например weapon_pistol)."},
	{id = "clothing", name = "Одежда", category = "clothing", base = "clothing",
		hint = "Надевается в слот. Бодигруппа и вариант — как выглядит на модели; защита снижает урон."},
	{id = "bag", name = "Сумка", category = "misc", base = "bag",
		hint = "Слот «Сумка»: добавляет ячейки под сеткой инвентаря."},
	{id = "radio", name = "Рация", category = "misc",
		hint = "Работает как рация: ПКМ → каналы, говорить — клавиша рации (H)."},
	{id = "package", name = "Упаковка", category = "misc", base = "package",
		hint = "Внутри лежат предметы (ID через запятую): зажать мышь, чтобы открыть."},
	{id = "nvg", name = "ПНВ", category = "clothing", base = "clothing",
		hint = "Прибор ночного видения: надевается на голову, включается клавишей ПНВ (F), 30 с работы."},
	{id = "ammo", name = "Патроны", category = "weapon", base = "ammo",
		hint = "Коробка патронов: «Зарядить» — патроны уходят в запас оружия этого типа, коробка исчезает. Не в слот."},
	{id = "light", name = "Фонарик", category = "misc",
		hint = "Пока при себе — работает фонарик (F); «Использовать» включает и выключает свет."}
}

IE.typeByID = {}

for _, entry in ipairs(IE.types) do
	IE.typeByID[entry.id] = entry
end

IE.fields = {
 itemSkin="number",itemBodygroups="table",
	type = "string", name = "string", description = "string", model = "string", icon = "string", iconURL = "string",
	useVerb = "string", useSound = "string", leaves = "string", slot = "string", weapon = "string",
	wearGroup = "string", contents = "string", cure = "string", wearModel = "string", disguiseFaction = "string",
	disguiseClass = "string", disguiseName = "string", ammo = "string", rounds = "number",
	hunger = "number", thirst = "number", heal = "number", protect = "number", bag = "number", wearIndex = "number",
	price = "number", gasmask = "boolean", canPoison="boolean", poisonChance="number", poisonStrength="number",
	alcohol="boolean", alcoholPercent="number", servingML="number", alcoholPain="number", breakable="boolean", durability="number", deleted="boolean",
	carry = "boolean", walkSequence = "string"
}

IE.limits = {itemSkin=255,price = 100000,poisonChance=100,poisonStrength=120,alcoholPercent=100,servingML=2000,alcoholPain=100,durability=10000}

IE.data = IE.data or {}
IE.originals = IE.originals or {}

function IE.Sanitize(entry)
	local out = {}

	for key, kind in pairs(IE.fields) do
		local value = entry[key]

		if (kind=="table" and key=="itemBodygroups" and istable(value)) then
   out[key]={}
   for group,index in pairs(value) do
    local g,n=tonumber(group),tonumber(index)
    if (g and n and g==math.floor(g) and g>=0 and g<=63 and n==n and math.abs(n)<math.huge) then out[key][tostring(g)]=math.Clamp(math.floor(n),0,255) end
   end
  elseif (kind == "string" and isstring(value)) then
			out[key] = NW.Cut(string.Trim(value), key == "description" and 600 or 200)
		elseif (kind == "number" and tonumber(value) and tonumber(value)==tonumber(value) and math.abs(tonumber(value))<math.huge) then
			out[key] = math.Clamp(tonumber(value), IE.limits[key] and 0 or -1000, IE.limits[key] or 1000)
		elseif (kind == "boolean" and value != nil) then
			out[key] = tobool(value)
		end
	end

	if (!IE.typeByID[out.type or ""]) then
		out.type = "misc"
	end

	if (out.cure and NW.medical and !NW.medical.cureNames[out.cure]) then
		out.cure = nil
	end

	if (out.iconURL and !string.match(out.iconURL, "^https?://")) then
		out.iconURL = nil
	end

	for key, value in pairs(out) do
		if (value == "") then
			out[key] = nil
		end
	end

	return out
end

local function Apply(id, entry)
	local original = IE.originals[id]

	if (I.list[id] and !original) then
		original = table.Copy(I.list[id])
		IE.originals[id] = original
	end

	if (entry.deleted) then I.list[id]=nil return end

	local kind = IE.typeByID[entry.type or "misc"] or IE.typeByID.misc
	local item = table.Copy(original or I.bases[kind.base or ""] or {})

	item.custom = original == nil
	item.edited = true
	item.type = entry.type
	item.category = kind.category

	for key, value in pairs(entry) do
		if (key != "type") then
			item[key] = value
		end
	end

	if (entry.wearGroup) then
		item.wear = {group = entry.wearGroup, index = entry.wearIndex or 1}
	end

	if (entry.type == "bag") then
		item.slot = "bag"
	end

	if (entry.contents) then
		local list = {}

		for part in string.gmatch(entry.contents, "[^,%s]+") do
			list[#list + 1] = part
		end

		item.contents = list
	end

	if (entry.type == "radio") then
		item.radio = true
		item.icon = entry.icon or "radio"
		item.useVerb = entry.useVerb or "настроить"
		item.OnUse = function(client)
			NW.radio.Open(client)

			return false
		end
	end

	if (entry.type == "nvg") then
		item.nvg = true
		item.slot = "head"
		item.icon = entry.icon or "nvg"
	end

	if (entry.type == "light") then
		item.flashlight = true
		item.icon = entry.icon or "flashlight"
		item.useVerb = entry.useVerb or "включить / выключить"
		item.OnUse = function(client)
			NW.inventory.SetLight(client, !client:FlashlightIsOn())
			client:EmitSound("items/flashlight1.wav", 55)

			return false
		end
	end

	if (entry.type == "ammo") then
		item.slot, item.weapon = nil, nil
		item.ammo = entry.ammo or "Pistol"
		item.rounds = math.max(1, math.floor(entry.rounds or 18))

		if (NW.ammo and NW.ammo.MakeBox) then
			NW.ammo.MakeBox(item)
		end
	end

	if (entry.type == "weapon" and !item.slot) then
		item.slot = "secondary"
	elseif (entry.type == "clothing" and !item.slot) then
		item.slot = "torso"
	end

	if (entry.carry) then
		item.slot = "carry"
		item.weapon = nil
	elseif (entry.carry == false and item.slot == "carry") then
		item.slot = nil
	end

	item.walkSequence = entry.walkSequence

	item.icon = item.icon or id
	I.Register(id, item)
end

function IE.ApplyAll(data)
	for id, original in pairs(IE.originals) do
		if (!data[id]) then
			I.Register(id, table.Copy(original))
			IE.originals[id] = nil
		end
	end

	for id, item in pairs(I.list) do
		if (item.custom and !data[id]) then
			I.list[id] = nil
		end
	end

	for id, entry in pairs(data) do
		Apply(id, entry)
	end

	IE.data = data
	hook.Run("NWItemsChanged")
end

if (SERVER) then
	util.AddNetworkString("nwItemEditData")
	util.AddNetworkString("nwItemEditOpen")
	util.AddNetworkString("nwItemEditSave")
	util.AddNetworkString("nwItemEditDelete")
	util.AddNetworkString("nwItemEditGive")

	local PATH = "network2/items.json"

	local function Send(target)
		local json = util.Compress(util.TableToJSON(IE.data))

		net.Start("nwItemEditData")
			net.WriteUInt(#json, 32)
			net.WriteData(json, #json)
		if (target) then
			net.Send(target)
		else
			net.Broadcast()
		end
	end

	local function Save()
		file.CreateDir("network2")
		file.Write(PATH, util.TableToJSON(IE.data, true))
		Send()
	end

	local loaded = util.JSONToTable(file.Read(PATH, "DATA") or "") or {}
	local clean = {}

	for id, entry in pairs(loaded) do
		if (isstring(id) and istable(entry)) then
			clean[id] = IE.Sanitize(entry)
		end
	end

	IE.ApplyAll(clean)

	hook.Add("PlayerInitialSpawn", "nwItemEdit", function(client)
		timer.Simple(1, function()
			if (IsValid(client)) then
				Send(client)
			end
		end)
	end)

	NW.AddChatCommand("itemedit", {admin = true, run = function(client)
		net.Start("nwItemEditOpen")
		net.Send(client)
	end})

	net.Receive("nwItemEditSave", function(_, client)
		if (!client:IsAdmin()) then
			return
		end

		local id = string.lower(string.gsub(net.ReadString() or "", "[^%w_]", ""))
		local entry = util.JSONToTable(net.ReadString() or "") or {}

		if (id == "" or #id > 40) then
			return NW.Notify(client, "ID: латиница, цифры и _")
		end

		entry = IE.Sanitize(entry)

		if (!entry.name) then
			return NW.Notify(client, "Нужно название")
		end

		local count = 0
		for _ in string.gmatch(entry.contents or "", "[^,%s]+") do count = count + 1 end
		if (count > 6) then return NW.Notify(client, "В контейнере может быть максимум 6 предметов") end

		local data = table.Copy(IE.data)

		data[id] = entry
		IE.ApplyAll(data)
		Save()
		for _,entity in ipairs(ents.FindByClass("nw_item")) do
   if (entity:GetItemID()==id) then NW.items.ApplyAppearance(entity,NW.items.Get(id)) end
  end
  NW.Notify(client, "Предмет сохранён: " .. entry.name .. " (" .. id .. ")")
		MsgN(string.format("[ITEMEDIT] %s (%s) сохранил %s", client:Nick(), client:SteamName(), id))
	end)

	net.Receive("nwItemEditDelete", function(_, client)
		local id = net.ReadString()

		if (!client:IsAdmin() or !IE.data[id]) then
			return
		end

		local data = table.Copy(IE.data)
		local framework = IE.originals[id] != nil

		data[id] = nil
		IE.ApplyAll(data)
		Save()
		NW.Notify(client, framework and ("Предмет сброшен к исходному: " .. id) or ("Предмет удалён: " .. id))
	end)

	function IE.RemoveDefinition(client,id)
		if (!client:IsAdmin() or !I.Get(id)) then return false end
		for _,target in ipairs(player.GetAll()) do
			if (target:GetCharacterID()!=0) then NW.inventory.PurgeID(target,id) end
		end
		for _,ent in ipairs(ents.FindByClass("nw_item")) do if (ent:GetItemID()==id) then ent:Remove() end end
		local data=table.Copy(IE.data)
		data[id]={type="misc",name=id,deleted=true}
		IE.ApplyAll(data) Save()
		NW.Notify(client,"Предмет удалён из каталога: "..id..". Восстановление: /itemrestore "..id)
		MsgN("[ITEM DELETE] "..client:SteamID().." "..id)
		return true
	end
	util.AddNetworkString("nwItemEditPurge")
	net.Receive("nwItemEditPurge",function(_,client) IE.RemoveDefinition(client,net.ReadString()) end)
	NW.AddChatCommand("itemdelete",{admin=true,run=function(client,rest)
		if (!IE.RemoveDefinition(client,string.Trim(rest or ""))) then NW.Notify(client,"/itemdelete <существующий ID>") end
	end})
	NW.AddChatCommand("itemrestore",{admin=true,run=function(client,rest)
		local id=string.Trim(rest or "")
		if (!IE.data[id] or !IE.data[id].deleted) then return NW.Notify(client,"Нет удалённого определения с таким ID") end
		local data=table.Copy(IE.data) data[id]=nil IE.ApplyAll(data) Save()
		NW.Notify(client,"Запрет снят: "..id..". Пользовательский предмет создайте заново через /itemedit")
	end})
	net.Receive("nwItemEditGive", function(_, client)
		local id = net.ReadString()

		if (!client:IsAdmin() or !I.Get(id)) then
			return
		end

		if (!NW.inventory.Add(client, id)) then
			NW.inventory.SpawnWorldItem(client, {id = id, data = {}})
		end

		NW.inventory.Changed(client)
	end)

	return
end

net.Receive("nwItemEditData", function()
	local length = net.ReadUInt(32)
	local json = util.Decompress(net.ReadData(length) or "")

	IE.ApplyAll(util.JSONToTable(json or "") or {})
end)

local downloads = {}

local function Downloaded(url)
	local entry = downloads[url]

	if (entry) then
		return entry.material
	end

	entry = {}
	downloads[url] = entry

	local name = "network2/icons/" .. util.CRC(url) .. (string.find(string.lower(url), "%.jpe?g") and ".jpg" or ".png")

	local function Load()
		entry.material = Material("../data/" .. name, "smooth mips")
	end

	if (file.Exists(name, "DATA")) then
		Load()
	else
		http.Fetch(url, function(body)
			file.CreateDir("network2/icons")
			file.Write(name, body)
			Load()
		end)
	end

	return entry.material
end

function I.IconMaterial(item)
	if (item and item.iconURL) then
		local material = Downloaded(item.iconURL)

		if (material and !material:IsError()) then
			return material
		end
	end

	return NW.ui.Material("network2/items/" .. (item and item.icon or "bag") .. ".png")
end
