NW.deliveries = NW.deliveries or {}

local DL = NW.deliveries

DL.maxLines = 6
DL.maxCount = 10
DL.minTotal = 20
DL.categoryPrice = {food = 4, drink = 3, medical = 8, misc = 5, clothing = 10}
DL.safe = {food = true, drink = true, medical = true, clothing = true, bags = true}
DL.neverID = {health_vial = true, stimdose = true, morphine = true}

function DL.Price(id)
	local item = NW.items.Get(id)
	if (!item or DL.neverID[id] or !DL.safe[item.group or ""] or item.contraband) then return end
	if (item.price and item.price > 0) then return math.max(2, math.floor(item.price * 0.6)) end
	return DL.categoryPrice[item.category or "misc"] or 5
end

function DL.Catalog(kindID)
	local out = {}

	for id, item in pairs(NW.items.list or {}) do
		if (NW.business.CanSell(kindID, item, id) and DL.Price(id)) then
			out[#out + 1] = {id = id, name = item.name, price = DL.Price(id)}
		end
	end

	table.sort(out, function(a, b) return a.name < b.name end)

	return out
end

if (SERVER) then
	util.AddNetworkString("nwDeliveryOpen")
	util.AddNetworkString("nwDeliveryOrder")
	util.AddNetworkString("nwDeliveryList")

	local PATH = "network2/deliveries.json"
	local pay = CreateConVar("nw_delivery_pay", "20", FCVAR_ARCHIVE, "Сколько процентов суммы заказа получает курьер ГСР")
	local base = CreateConVar("nw_delivery_base", "8", FCVAR_ARCHIVE, "Сколько токенов курьер получает сверх процента")
	local INV = NW.inventory
	local SO = NW.social
	local CW = NW.cwu

	DL.state = util.JSONToTable(file.Read(PATH, "DATA") or "") or {}
	DL.state.nextID = DL.state.nextID or 1
	DL.state.orders = DL.state.orders or {}

	local function Save()
		file.CreateDir("network2")
		file.Write(PATH, util.TableToJSON(DL.state, true))
	end

	function DL.Get(id)
		for _, order in ipairs(DL.state.orders) do
			if (order.id == id) then return order end
		end
	end

	local function Premises(charID)
		local out = {}

		for _, door in ipairs(ents.GetAll()) do
			if (NW.doors.IsDoor(door) and door:GetNW2String("nwDoorKind", "") == "business") then
				for _, tenant in ipairs(NW.doors.Tenants(door)) do
					if (tenant == charID) then out[#out + 1] = door break end
				end
			end
		end

		return out
	end

	local function Online(charID)
		for _, client in ipairs(player.GetAll()) do
			if (client:GetCharacterID() == charID) then return client end
		end
	end

	local function Hand(client, items)
		for _, id in ipairs(items) do
			if (!INV.Add(client, id)) then
				INV.SpawnWorldItem(client, {id = id, data = {}})
			end
		end

		INV.Changed(client)
	end

	local function Expand(order)
		local out = {}

		for _, line in ipairs(order.lines) do
			for _ = 1, line.count do out[#out + 1] = line.id end
		end

		return out
	end

	function DL.Open(client)
		local license = NW.business.License(client:GetCharacterID())

		if (!license) then
			return NW.Notify(client, "Заказывать товар могут владельцы лицензии на торговлю")
		end

		local kind = license.fields.kind or "general"
		local mine = {}

		for _, order in ipairs(DL.state.orders) do
			if (order.char == client:GetCharacterID() and order.status != "done") then mine[#mine + 1] = order end
		end

		net.Start("nwDeliveryOpen")
			net.WriteString(util.TableToJSON({kind = kind, title = license.fields.title or "", catalog = DL.Catalog(kind),
				orders = mine, premises = #Premises(client:GetCharacterID()) > 0}))
		net.Send(client)
	end

	net.Receive("nwDeliveryOrder", function(_, client)
		local request = util.JSONToTable(net.ReadString() or "") or {}
		local license = NW.business.License(client:GetCharacterID())

		if (!license or (client.nwDeliveryNext or 0) > CurTime()) then return end
		client.nwDeliveryNext = CurTime() + 2

		if (#Premises(client:GetCharacterID()) == 0) then
			return NW.Notify(client, "Сначала арендуйте коммерческое помещение: товар везут туда")
		end

		local kind = license.fields.kind or "general"
		local lines, total = {}, 0

		for _, line in ipairs(istable(request.lines) and request.lines or {}) do
			local id = isstring(line.id) and line.id
			local count = math.Clamp(math.floor(tonumber(line.count) or 0), 0, DL.maxCount)
			local item = id and NW.items.Get(id)

			if (item and count > 0 and NW.business.CanSell(kind, item, id) and #lines < DL.maxLines) then
				lines[#lines + 1] = {id = id, count = count, price = DL.Price(id)}
				total = total + DL.Price(id) * count
			end
		end

		if (#lines == 0) then return NW.Notify(client, "Заказ пуст") end
		if (total < DL.minTotal) then return NW.Notify(client, "Минимальная сумма заказа — " .. DL.minTotal .. " ток.") end

		local data = client.nwCharacter and client.nwCharacter.data

		if (!data) then return end

		local bank = math.max(0, math.floor(tonumber(data.bank) or 0))
		local tokens = SO.GetTokens(client)

		if (bank + tokens < total) then
			return NW.Notify(client, "Не хватает средств: заказ стоит " .. total .. " ток.")
		end

		local fromBank = math.min(bank, total)

		data.bank = bank - fromBank
		SO.SetTokens(client, tokens - (total - fromBank))
		NW.char.SaveData(client)

		local order = {id = DL.state.nextID, char = client:GetCharacterID(), owner = client:RealName(),
			shop = license.fields.title or "", lines = lines, total = total, status = "open", created = os.time()}

		DL.state.nextID = DL.state.nextID + 1
		table.insert(DL.state.orders, order)
		Save()

		if (NW.exports and NW.exports.Deposit) then NW.exports.Deposit(total, "оптовый заказ №" .. order.id) end

		NW.Notify(client, "Заказ №" .. order.id .. " оформлен: " .. total .. " ток. Курьер ГСР привезёт его к вашему помещению")
		MsgN(string.format("[DELIVERY] %s ordered #%d for %d", client:Nick(), order.id, total))

		for _, other in ipairs(player.GetAll()) do
			if (CW.IsCWU(other) and CW.CanJob(other, "delivery")) then
				NW.Notify(other, "Новый заказ на доставку №" .. order.id .. " — терминал ГСР → «Доставки»")
			end
		end

		DL.Open(client)
	end)

	NW.AddChatCommand("order", {run = function(client)
		DL.Open(client)
	end})

	NW.terminal.actions.wholesale = function(client)
		DL.Open(client)
	end

	local function List()
		local out = {}

		for _, order in ipairs(DL.state.orders) do
			if (order.status == "open" or order.status == "taken") then
				out[#out + 1] = {id = order.id, owner = order.owner, shop = order.shop, lines = order.lines, total = order.total,
					status = order.status, courier = order.courierName or "",
					pay = math.min(math.floor(order.total * math.Clamp(pay:GetFloat(), 0, 100) / 100) + base:GetInt(), math.floor(order.total * 0.4))}
			end
		end

		return out
	end

	local function SendList(client)
		net.Start("nwDeliveryList")
			net.WriteString(util.TableToJSON(List()))
		net.Send(client)
	end

	local ACTIONS = NW.cmbTerminalActions

	function ACTIONS.dl_list(client, terminal)
		if (terminal:GetClass() != "nw_cwu_terminal") then return end
		SendList(client)
	end

	function ACTIONS.dl_take(client, terminal, arg)
		if (terminal:GetClass() != "nw_cwu_terminal") then return end

		local order = DL.Get(tonumber(arg) or 0)

		if (!CW.IsCWU(client) or !CW.CanJob(client, "delivery")) then
			NW.Notify(client, "Доставка не входит в работу вашего класса")
		elseif (!order or order.status != "open") then
			NW.Notify(client, "Этот заказ уже взят")
		else
			for _, other in ipairs(DL.state.orders) do
				if (other.status == "taken" and other.courier == client:GetCharacterID()) then
					SendList(client)
					return NW.Notify(client, "Сначала доставьте заказ №" .. other.id)
				end
			end

			if (!INV.Add(client, "delivery_parcel", {order = order.id, to = order.owner, shop = order.shop})) then
				return NW.Notify(client, "Нет места в инвентаре для посылки")
			end

			INV.Changed(client)
			order.status = "taken"
			order.courier = client:GetCharacterID()
			order.courierName = client:RealName()
			order.taken = os.time()
			Save()
			NW.Notify(client, "Посылка №" .. order.id .. " у вас. Доставьте её в помещение «" .. order.shop .. "» (" .. order.owner .. ")")
		end

		SendList(client)
	end

	function ACTIONS.dl_drop(client, terminal, arg)
		if (terminal:GetClass() != "nw_cwu_terminal") then return end

		local order = DL.Get(tonumber(arg) or 0)

		if (order and order.status == "taken" and order.courier == client:GetCharacterID()) then
			local inventory = INV.Get(client)

			for index = 1, NW.items.maxSize do
				local cell = inventory.grid[index]
				if (cell and cell.id == "delivery_parcel" and cell.data and cell.data.order == order.id) then
					inventory.grid[index] = nil
				end
			end

			INV.Changed(client)
			order.status = "open"
			order.courier = nil
			order.courierName = nil
			Save()
			NW.Notify(client, "Заказ №" .. order.id .. " возвращён в общий список")
		end

		SendList(client)
	end

	function DL.Deliver(client, cell)
		local order = DL.Get(cell.data and cell.data.order or 0)

		if (!order or order.status != "taken") then
			NW.Notify(client, "Этот заказ отменён или уже доставлен")
			return true
		end

		local owner = Online(order.char)
		local near = IsValid(owner) and owner:GetPos():DistToSqr(client:GetPos()) < 160 * 160

		if (!near) then
			for _, door in ipairs(Premises(order.char)) do
				if (door:GetPos():DistToSqr(client:GetPos()) < 260 * 260) then near = true break end
			end
		end

		if (!near) then
			NW.Notify(client, "Доставьте посылку к помещению «" .. order.shop .. "» или лично " .. order.owner)
			return false
		end

		local reward = CW.IsCWU(client) and math.min(math.floor(order.total * math.Clamp(pay:GetFloat(), 0, 100) / 100) + base:GetInt(),
			math.floor(order.total * 0.4)) or 0

		if (reward > 0 and NW.exports and NW.exports.Withdraw and !NW.exports.Withdraw(reward, "оплата курьеру, заказ №" .. order.id)) then
			reward = 0
			NW.Notify(client, "В казне нет денег на оплату доставки")
		end

		if (reward > 0) then

			SO.SetTokens(client, SO.GetTokens(client) + reward)
			NW.skills.Add(client, "strength", 6)
		end

		if (IsValid(owner)) then
			Hand(owner, Expand(order))
			order.status = "done"
			NW.Notify(owner, "Заказ №" .. order.id .. " доставлен: товар в инвентаре")
		else
			order.status = "waiting"
		end

		order.delivered = os.time()
		Save()
		client:EmitSound("physics/cardboard/cardboard_box_impact_soft" .. math.random(1, 7) .. ".wav", 60)
		NW.Notify(client, "Заказ №" .. order.id .. " доставлен" .. (reward > 0 and (": +" .. reward .. " ток.") or ""))
		MsgN(string.format("[DELIVERY] %s delivered #%d", client:Nick(), order.id))

		return true
	end

	hook.Add("NWCharacterLoaded", "nwDeliveries", function(client, character)
		timer.Simple(3, function()
			if (!IsValid(client) or client:GetCharacterID() != character.id) then return end

			local changed = false

			for _, order in ipairs(DL.state.orders) do
				if (order.status == "waiting" and order.char == character.id) then
					Hand(client, Expand(order))
					order.status = "done"
					changed = true
					NW.Notify(client, "Пока вас не было, доставлен заказ №" .. order.id .. ": товар в инвентаре")
				end
			end

			if (changed) then Save() end
		end)
	end)

	timer.Create("nwDeliveriesCleanup", 600, 0, function()
		local keep = {}
		local cutoff = os.time() - 86400 * 3

		for _, order in ipairs(DL.state.orders) do
			if (order.status != "done" or (order.delivered or order.created or 0) > cutoff) then keep[#keep + 1] = order end
		end

		if (#keep != #DL.state.orders) then
			DL.state.orders = keep
			Save()
		end
	end)

	return
end

local W = NW.widgets
local U = NW.ui

net.Receive("nwDeliveryOpen", function()
	local data = util.JSONToTable(net.ReadString() or "") or {}
	local sh = ScrH()
	local frame, box = W.Window("Оптовый заказ · «" .. tostring(data.title or "") .. "»", math.Round(sh * 1.05), math.Round(sh * 0.72))
	local pad = math.Round(sh * 0.02)
	local bw, bh = box:GetWide(), box:GetTall()
	local top = box.top
	local cart = {}

	local list = W.Scroll(box)
	list:SetPos(pad, top)
	list:SetSize(bw * 0.55 - pad * 1.5, bh - top - pad)

	local right = box:Add("EditablePanel")
	right:SetPos(bw * 0.55, top)
	right:SetSize(bw * 0.45 - pad, bh - top - pad)

	local function Total()
		local sum = 0
		for id, count in pairs(cart) do sum = sum + (DL.Price(id) or 0) * count end
		return sum
	end

	local Rebuild

	for _, entry in ipairs(data.catalog or {}) do
		local row = list:Add("DPanel")

		row:Dock(TOP)
		row:DockMargin(0, 0, 8, 4)
		row:SetTall(math.Round(sh * 0.045))
		row.Paint = function(_, w, h)
			draw.RoundedBox(4, 0, 0, w, h, Color(24, 27, 31, 240))
			draw.SimpleText(entry.name, "nwWidget", h * 0.3, h / 2, U.color.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(entry.price .. " ток.", "nwWidgetBold", w - h * 2.4, h / 2, W.ACCENT, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end

		local add = W.Button(row, "+", function()
			local lines = table.Count(cart)
			if (!cart[entry.id] and lines >= DL.maxLines) then return NW.notify.Add("Не больше " .. DL.maxLines .. " позиций") end
			cart[entry.id] = math.min(DL.maxCount, (cart[entry.id] or 0) + 1)
			Rebuild()
		end, true)

		add:SetSize(row:GetTall() * 1.6, row:GetTall() - 8)
		row.PerformLayout = function(_, w)
			add:SetPos(w - add:GetWide() - 4, 4)
		end
	end

	Rebuild = function()
		right:Clear()

		local y = 0

		W.Label(right, "Корзина", 0, y)
		y = y + sh * 0.025

		for id, count in SortedPairs(cart) do
			local item = NW.items.Get(id)
			local line = right:Add("DPanel")

			line:SetPos(0, y)
			line:SetSize(right:GetWide(), sh * 0.04)
			line.Paint = function(_, w, h)
				draw.RoundedBox(4, 0, 0, w, h, Color(24, 27, 31, 240))
				draw.SimpleText((item and item.name or id) .. " ×" .. count, "nwWidget", h * 0.3, h / 2, U.color.text, TEXT_ALIGN_LEFT,
					TEXT_ALIGN_CENTER)
			end

			local minus = W.Button(line, "−", function()
				cart[id] = cart[id] - 1
				if (cart[id] <= 0) then cart[id] = nil end
				Rebuild()
			end)

			minus:SetSize(sh * 0.05, sh * 0.032)
			minus:SetPos(line:GetWide() - sh * 0.054, sh * 0.004)
			y = y + sh * 0.044
		end

		y = y + sh * 0.01

		local sum = right:Add("DPanel")
		sum:SetPos(0, y)
		sum:SetSize(right:GetWide(), sh * 0.04)
		sum.Paint = function(_, w, h)
			draw.SimpleText("Итого: " .. Total() .. " ток. (со счёта, затем наличными)", "nwWidgetBold", 0, h / 2, W.ACCENT,
				TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		y = y + sh * 0.05

		if (!data.premises) then
			W.Label(right, "Нет арендованного помещения: товар некуда везти", 0, y)
			y = y + sh * 0.03
		end

		local send = W.Button(right, "Оформить заказ", function()
			local lines = {}
			for id, count in pairs(cart) do lines[#lines + 1] = {id = id, count = count} end
			net.Start("nwDeliveryOrder")
				net.WriteString(util.TableToJSON({lines = lines}))
			net.SendToServer()
			frame:Remove()
		end, true)

		send:SetPos(0, y)
		send:SetSize(right:GetWide(), sh * 0.045)
		send:SetEnabled(table.Count(cart) > 0 and data.premises == true)
		y = y + sh * 0.065

		W.Label(right, "Ваши заказы", 0, y)
		y = y + sh * 0.025

		local STATUS = {open = "ждёт курьера", taken = "в пути", waiting = "доставлен"}

		for _, order in ipairs(data.orders or {}) do
			local line = right:Add("DPanel")

			line:SetPos(0, y)
			line:SetSize(right:GetWide(), sh * 0.034)
			line.Paint = function(_, w, h)
				draw.SimpleText("№" .. order.id .. " · " .. order.total .. " ток. · " .. (STATUS[order.status] or order.status) ..
					(order.courierName and (" · " .. order.courierName) or ""), "nwWidget", 0, h / 2, W.MUTED, TEXT_ALIGN_LEFT,
					TEXT_ALIGN_CENTER)
			end
			y = y + sh * 0.036
		end
	end

	Rebuild()
end)

local CT = NW.cmbTerminal
local SCREEN = CT and CT.screens.cwu

net.Receive("nwDeliveryList", function()
	DL.list = util.JSONToTable(net.ReadString() or "") or {}

	if (CT and CT.page == "deliveries") then
		CT.Refresh()
	end
end)

if (SCREEN) then
	if (!SCREEN.pages.deliveries) then
		table.insert(SCREEN.order, {"deliveries", "Доставки"})
	end

	SCREEN.pages.deliveries = {
		title = "Доставки",
		subtitle = "Оптовые заказы бизнеса: взять посылку и отвезти владельцу",
		Build = function(area, w, h)
			local C = CT.colors
			local gap = math.Round(h * 0.025)

			if (!DL.asked or DL.asked < RealTime() - 3) then
				DL.asked = RealTime()
				CT.Send("dl_list", "")
			end

			local me = LocalPlayer()
			local can = NW.cwu.IsCWU(me) and NW.cwu.CanJob(me, "delivery")

			CT.Label(area, can and "Возьмите заказ: посылка появится в инвентаре. Используйте её у помещения владельца." or
				"Доставка не входит в работу вашего класса", 0, 0, "nwCmtText", can and C.dim or C.red)

			local scroll = CT.Scroll(area, 0, h * 0.07, w, h - h * 0.07)
			local list = DL.list or {}

			if (#list == 0) then
				CT.Label(scroll, "Заказов нет", 0, 0, "nwCmtText", C.dim)
				return
			end

			for _, order in ipairs(list) do
				local row = scroll:Add("DPanel")
				local rh = math.Round(h * 0.14)
				local goods = {}

				for _, line in ipairs(order.lines or {}) do
					local item = NW.items.Get(line.id)
					goods[#goods + 1] = (item and item.name or line.id) .. " ×" .. line.count
				end

				row:Dock(TOP)
				row:DockMargin(0, 0, 8, 4)
				row:SetTall(rh)
				row.Paint = function(_, rw, rhh)
					surface.SetDrawColor(C.dark.r, C.dark.g, C.dark.b, 170)
					surface.DrawRect(0, 0, rw, rhh)
					surface.SetDrawColor(order.status == "open" and C.cyan or C.dim)
					surface.DrawRect(0, 0, 3, rhh)
					draw.SimpleText("№" .. order.id .. "  ·  «" .. NW.terminal.Upper(order.shop) .. "»  ·  " .. NW.terminal.Upper(order.owner),
						"nwCmtText", gap, rhh * 0.22, C.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					draw.SimpleText(NW.Cut(table.concat(goods, ", "), 160), "nwCmtSmall", gap, rhh * 0.52, C.dim, TEXT_ALIGN_LEFT,
						TEXT_ALIGN_CENTER)
					draw.SimpleText(order.status == "open" and ("ОПЛАТА КУРЬЕРУ: " .. order.pay .. " ТОК.") or
						("ВЕЗЁТ: " .. NW.terminal.Upper(order.courier)), "nwCmtSmall", gap, rhh * 0.8, C.cyan, TEXT_ALIGN_LEFT,
						TEXT_ALIGN_CENTER)
				end

				if (order.status == "open" and can) then
					CT.Button(row, "Взять заказ", w * 0.72, rh * 0.25, w * 0.24, rh * 0.5, function()
						CT.Send("dl_take", tostring(order.id))
					end, true)
				elseif (order.status == "taken" and order.courier == me:RealName()) then
					CT.Button(row, "Вернуть заказ", w * 0.72, rh * 0.25, w * 0.24, rh * 0.5, function()
						CT.Send("dl_drop", tostring(order.id))
					end, false, true)
				end
			end
		end
	}
end
