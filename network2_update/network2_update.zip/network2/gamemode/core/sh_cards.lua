NW.cards = NW.cards or {}

local CA = NW.cards

CA.seats = 4
CA.suits = {"S", "C", "D", "H"}
CA.suitGlyph = {S = "♠", C = "♣", D = "♦", H = "♥"}
CA.rankName = {[2] = "2", [3] = "3", [4] = "4", [5] = "5", [6] = "6", [7] = "7", [8] = "8", [9] = "9", [10] = "10",
	[11] = "В", [12] = "Д", [13] = "К", [14] = "Т"}
CA.rankFile = {[11] = "J", [12] = "Q", [13] = "K", [14] = "A"}

CA.maxBet = CreateConVar("nw_casino_maxbet", "50", {FCVAR_ARCHIVE, FCVAR_REPLICATED}, "Наибольшая ставка за игральным столом (токены)")

function CA.Parse(code)
	local r, s = string.match(code or "", "^(%d+)(%a)$")
	return tonumber(r), s
end

if (SERVER) then
	util.AddNetworkString("nwCards")
	util.AddNetworkString("nwCardsAction")

	local SO = NW.social

	local function Deck(min)
		local deck = {}
		for _, s in ipairs(CA.suits) do
			for r = min, 14 do deck[#deck + 1] = r .. s end
		end
		for i = #deck, 2, -1 do
			local j = math.random(i)
			deck[i], deck[j] = deck[j], deck[i]
		end
		return deck
	end

	local function House(amount)
		if (!NW.exports) then return end
		if (amount > 0 and NW.exports.Deposit) then NW.exports.Deposit(amount, "игральный стол")
		elseif (amount < 0 and NW.exports.Withdraw) then NW.exports.Withdraw(-amount, "выигрыш за игральным столом") end
	end

	local function Pay(client, amount)
		if (IsValid(client) and amount > 0) then SO.SetTokens(client, SO.GetTokens(client) + amount) end
	end

	local function Charge(client, amount)
		if (SO.GetTokens(client) < amount) then return false end
		SO.SetTokens(client, SO.GetTokens(client) - amount)
		return true
	end

	function CA.Seated(desk, client)
		for index, seat in ipairs(desk.nwSeats or {}) do
			if (seat == client) then return index end
		end
	end

	local function Say(desk, text)
		desk.nwLog = desk.nwLog or {}
		table.insert(desk.nwLog, 1, text)
		while (#desk.nwLog > 6) do table.remove(desk.nwLog) end
	end

	local function Score(hand)
		local total, aces = 0, 0
		for _, code in ipairs(hand) do
			local r = CA.Parse(code)
			if (r == 14) then total = total + 11 aces = aces + 1
			elseif (r >= 11) then total = total + 10
			else total = total + r end
		end
		while (total > 21 and aces > 0) do total = total - 10 aces = aces - 1 end
		return total
	end

	CA.Score = Score

	local function Beats(card, attack, trump)
		local cr, cs = CA.Parse(card)
		local ar, as = CA.Parse(attack)
		return (cs == as and cr > ar) or (cs == trump and as != trump)
	end

	local function View(desk, client)
		local g = desk.nwGame
		local seats = {}

		for index, seat in ipairs(desk.nwSeats or {}) do
			seats[index] = {name = IsValid(seat) and seat:RealName() or "—", me = seat == client, tokens = IsValid(seat) and SO.GetTokens(seat) or 0}
		end

		local out = {seats = seats, log = desk.nwLog or {}, maxBet = CA.maxBet:GetInt(), entity = desk:EntIndex()}

		if (!g) then return out end

		out.kind = g.kind
		out.phase = g.phase
		out.deadline = g.deadline and math.max(0, math.ceil(g.deadline - CurTime())) or nil

		if (g.kind == "blackjack") then
			out.dealer = {}
			for index, code in ipairs(g.dealer or {}) do
				out.dealer[index] = (index == 2 and g.phase == "play") and "back" or code
			end
			out.dealerScore = g.phase != "play" and Score(g.dealer or {}) or nil
			out.players = {}
			for _, seat in ipairs(desk.nwSeats) do
				local hand = g.hands[seat]
				out.players[#out.players + 1] = {name = seat:RealName(), me = seat == client, bet = g.bets[seat] or 0, hand = hand or {},
					score = hand and Score(hand) or nil, turn = g.order and g.order[g.turn] == seat, result = g.results and g.results[seat]}
			end
		elseif (g.kind == "durak") then
			out.trump = g.trump
			out.trumpCard = g.trumpCard
			out.deck = g.deck and #g.deck or 0
			out.table = g.table or {}
			out.taking = g.taking
			out.ante = g.ante
			out.players = {}
			for index, seat in ipairs(g.order) do
				out.players[index] = {name = IsValid(seat) and seat:RealName() or "—", me = seat == client, count = #(g.hands[seat] or {}),
					attacker = index == g.attacker, defender = index == g.defender, out = g.out[seat] == true}
				if (seat == client) then out.hand = g.hands[seat] out.myIndex = index end
			end
			out.result = g.result
		end

		return out
	end

	function CA.Sync(desk)
		for _, seat in ipairs(desk.nwSeats or {}) do
			if (IsValid(seat)) then
				net.Start("nwCards")
					net.WriteString(util.TableToJSON(View(desk, seat)))
				net.Send(seat)
			end
		end
	end

	local function Close(client)
		net.Start("nwCards")
			net.WriteString("{\"closed\":true}")
		net.Send(client)
	end

	local function BJNextTurn(desk)
		local g = desk.nwGame
		g.turn = g.turn + 1
		while (g.order[g.turn] and (!IsValid(g.order[g.turn]) or g.left[g.order[g.turn]] or Score(g.hands[g.order[g.turn]]) >= 21)) do g.turn = g.turn + 1 end

		if (!g.order[g.turn]) then
			g.phase = "dealer"
			while (Score(g.dealer) < 17) do g.dealer[#g.dealer + 1] = table.remove(g.shoe) end
			local dealer = Score(g.dealer)
			local dealerBJ = dealer == 21 and #g.dealer == 2
			g.results = {}

			for _, seat in ipairs(g.order) do
				local hand = g.hands[seat]
				local score = Score(hand)
				local bet = g.bets[seat]
				local bj = score == 21 and #hand == 2
				local payout, text = 0, "проигрыш"

				if (score > 21) then text = "перебор"
				elseif (bj and !dealerBJ) then payout = bet + math.floor(bet * 1.5) text = "блэкджек!"
				elseif (dealer > 21 or score > dealer) then payout = bet * 2 text = "выигрыш"
				elseif (score == dealer and (!dealerBJ or bj)) then payout = bet text = "ничья" end

				g.results[seat] = text .. (payout > 0 and (" +" .. payout) or "")
				Pay(seat, payout)
				House(bet - payout)
				if (IsValid(seat)) then Say(desk, seat:RealName() .. ": " .. text) end
			end

			g.phase = "done"
			g.deadline = CurTime() + 7
		else
			g.deadline = CurTime() + 30
		end
	end

	local function BJDeal(desk)
		local g = desk.nwGame
		g.order = {}

		for _, seat in ipairs(desk.nwSeats) do
			if ((g.bets[seat] or 0) > 0) then g.order[#g.order + 1] = seat end
		end

		if (#g.order == 0) then return end

		local total = 0
		for _, seat in ipairs(g.order) do total = total + g.bets[seat] end

		if (NW.exports and NW.exports.state and (NW.exports.state.treasury or 0) < total * 1.5) then
			for _, seat in ipairs(g.order) do Pay(seat, g.bets[seat]) end
			g.bets = {}
			g.deadline = nil
			Say(desk, "Касса стола пуста: ставки возвращены")
			return
		end

		g.left = {}

		g.shoe = Deck(2)
		g.hands = {}
		g.dealer = {}

		for _ = 1, 2 do
			for _, seat in ipairs(g.order) do
				g.hands[seat] = g.hands[seat] or {}
				g.hands[seat][#g.hands[seat] + 1] = table.remove(g.shoe)
			end
			g.dealer[#g.dealer + 1] = table.remove(g.shoe)
		end

		g.phase = "play"
		g.turn = 0
		g.results = nil
		BJNextTurn(desk)
	end

	local function NewBlackjack(desk)
		desk.nwGame = {kind = "blackjack", phase = "bet", bets = {}, hands = {}, dealer = {}, left = {}}
	end

	local function DurakActive(g, index)
		local seat = g.order[index]
		return IsValid(seat) and !g.out[seat]
	end

	local function DurakNext(g, index)
		local count = #g.order
		for step = 1, count do
			local candidate = (index - 1 + step) % count + 1
			if (DurakActive(g, candidate)) then return candidate end
		end
		return index
	end

	local function DurakLimit(g)
		local defender = g.order[g.defender]
		return math.min(6, g.roundHand or #(g.hands[defender] or {}))
	end

	local function DurakRefill(g)
		local sequence = {g.attacker}
		local index = g.attacker
		for _ = 1, #g.order do
			index = DurakNext(g, index)
			if (index != g.defender and !table.HasValue(sequence, index)) then sequence[#sequence + 1] = index end
		end
		sequence[#sequence + 1] = g.defender

		for _, idx in ipairs(sequence) do
			local hand = g.hands[g.order[idx]]
			while (hand and #hand < 6 and #g.deck > 0) do hand[#hand + 1] = table.remove(g.deck) end
		end
	end

	local function DurakFinish(desk, durak)
		local g = desk.nwGame
		g.phase = "done"
		g.deadline = CurTime() + 10
		local players = {}
		for _, seat in ipairs(g.order) do if (IsValid(seat)) then players[#players + 1] = seat end end

		if (durak) then
			g.result = "Дурак: " .. (IsValid(durak) and durak:RealName() or "вышедший игрок")
			Say(desk, g.result)
			local winners = 0
			for _, seat in ipairs(players) do if (seat != durak) then winners = winners + 1 end end
			local pot = (g.ante or 0) * #g.order
			if (winners > 0 and pot > 0) then
				local share = math.floor(pot / winners)
				for _, seat in ipairs(players) do if (seat != durak) then Pay(seat, share) end end
			end
		else
			g.result = "Ничья"
			Say(desk, "Ничья: ставки возвращены")
			for _, seat in ipairs(players) do Pay(seat, g.ante or 0) end
		end
	end

	local function DurakCheck(desk)
		local g = desk.nwGame
		if (#g.deck == 0) then
			for _, seat in ipairs(g.order) do
				if (IsValid(seat) and #(g.hands[seat] or {}) == 0 and !g.out[seat]) then
					g.out[seat] = true
					Say(desk, seat:RealName() .. " вышел из игры")
				end
			end
		end

		local left = {}
		for index, seat in ipairs(g.order) do if (DurakActive(g, index)) then left[#left + 1] = seat end end

		if (#left <= 1) then
			DurakFinish(desk, left[1])
			return true
		end
	end

	local function DurakRound(desk, attacker)
		local g = desk.nwGame
		g.attacker = attacker
		g.defender = DurakNext(g, attacker)
		g.table = {}
		g.taking = false
		g.roundHand = #(g.hands[g.order[g.defender]] or {})
		g.deadline = CurTime() + 45
	end

	local function DurakEndRound(desk)
		local g = desk.nwGame
		local defender = g.order[g.defender]
		local nextAttacker

		if (g.taking) then
			for _, pair in ipairs(g.table) do
				g.hands[defender][#g.hands[defender] + 1] = pair.a
				if (pair.d) then g.hands[defender][#g.hands[defender] + 1] = pair.d end
			end
			Say(desk, (IsValid(defender) and defender:RealName() or "Игрок") .. " берёт карты")
			DurakRefill(g)
			nextAttacker = DurakNext(g, g.defender)
		else
			Say(desk, "Бито")
			DurakRefill(g)
			nextAttacker = g.defender
		end

		if (DurakCheck(desk)) then return end

		if (!DurakActive(g, nextAttacker)) then nextAttacker = DurakNext(g, nextAttacker) end

		DurakRound(desk, nextAttacker)
	end

	local function NewDurak(desk)
		local players = {}
		for _, seat in ipairs(desk.nwSeats) do players[#players + 1] = seat end

		local g = {kind = "durak", phase = "lobby", order = players, hands = {}, out = {}, ante = desk.nwAnte or 0}
		desk.nwGame = g
	end

	local function DurakStart(desk, ante)
		local g = desk.nwGame
		local players = {}
		for _, seat in ipairs(desk.nwSeats) do players[#players + 1] = seat end

		if (#players < 2) then return "Нужно минимум два игрока" end

		ante = math.Clamp(math.floor(tonumber(ante) or 0), 0, CA.maxBet:GetInt())

		for _, seat in ipairs(players) do
			if (SO.GetTokens(seat) < ante) then return seat:RealName() .. ": не хватает токенов на ставку" end
		end

		for _, seat in ipairs(players) do Charge(seat, ante) end

		g.order = players
		g.ante = ante
		g.deck = Deck(6)
		g.trumpCard = g.deck[1]
		local _, trump = CA.Parse(g.trumpCard)
		g.trump = trump
		g.out = {}
		g.hands = {}

		for _, seat in ipairs(players) do
			g.hands[seat] = {}
			for _ = 1, 6 do g.hands[seat][#g.hands[seat] + 1] = table.remove(g.deck) end
		end

		local first, lowest = 1
		for index, seat in ipairs(players) do
			for _, code in ipairs(g.hands[seat]) do
				local r, s = CA.Parse(code)
				if (s == trump and (!lowest or r < lowest)) then lowest, first = r, index end
			end
		end

		g.phase = "play"
		g.result = nil
		Say(desk, "Дурак: козырь " .. CA.suitGlyph[trump] .. ", ставка " .. ante)
		DurakRound(desk, first)
	end

	local function TakeCard(hand, code)
		for index, card in ipairs(hand or {}) do
			if (card == code) then table.remove(hand, index) return true end
		end
	end

	local function TableRanks(g)
		local ranks = {}
		for _, pair in ipairs(g.table) do
			ranks[CA.Parse(pair.a)] = true
			if (pair.d) then ranks[CA.Parse(pair.d)] = true end
		end
		return ranks
	end

	local function Undefended(g)
		local count = 0
		for _, pair in ipairs(g.table) do if (!pair.d) then count = count + 1 end end
		return count
	end

	local ACTIONS = {}

	function ACTIONS.sit(desk, client)
		if (CA.Seated(desk, client)) then return end
		desk.nwSeats = desk.nwSeats or {}
		if (#desk.nwSeats >= CA.seats) then return NW.Notify(client, "Все места заняты") end
		if (desk.nwGame and desk.nwGame.phase == "play") then return NW.Notify(client, "Идёт партия: дождитесь конца") end
		desk.nwSeats[#desk.nwSeats + 1] = client
		if (desk.nwGame and desk.nwGame.kind == "durak") then desk.nwGame.order = desk.nwSeats end
		Say(desk, client:RealName() .. " садится за стол")
	end

	function ACTIONS.leave(desk, client)
		local index = CA.Seated(desk, client)
		if (!index) then return end
		local g = desk.nwGame

		if (g and g.kind == "durak" and g.phase == "play" and !g.out[client]) then
			Say(desk, client:RealName() .. " бросает карты и проигрывает")
			table.remove(desk.nwSeats, index)
			DurakFinish(desk, client)
		else
			table.remove(desk.nwSeats, index)
			if (g and g.kind == "blackjack" and g.phase == "bet" and (g.bets[client] or 0) > 0) then
				Pay(client, g.bets[client])
				g.bets[client] = nil
			end
			if (g and g.kind == "blackjack" and g.phase == "play") then
				g.left = g.left or {}
				g.left[client] = true
				if (g.order[g.turn] == client) then BJNextTurn(desk) end
			end
		end

		Close(client)
		if (#desk.nwSeats == 0) then desk.nwGame = nil end
	end

	function ACTIONS.game(desk, client, arg)
		local g = desk.nwGame
		if (g and g.phase == "play") then return end
		if (g and g.kind == "blackjack" and g.bets) then
			for seat, bet in pairs(g.bets) do Pay(seat, bet) end
			g.bets = {}
		end
		if (arg == "") then desk.nwGame = nil Say(desk, "Выбор игры")
		elseif (arg == "blackjack") then NewBlackjack(desk) Say(desk, "Игра: блэкджек")
		elseif (arg == "durak") then NewDurak(desk) Say(desk, "Игра: дурак") end
	end

	function ACTIONS.bet(desk, client, arg)
		local g = desk.nwGame
		if (!g or g.kind != "blackjack" or g.phase != "bet" or (g.bets[client] or 0) > 0) then return end
		local amount = math.Clamp(math.floor(tonumber(arg) or 0), 1, CA.maxBet:GetInt())
		if (!Charge(client, amount)) then return NW.Notify(client, "Не хватает токенов") end
		g.bets[client] = amount
		g.deadline = g.deadline or CurTime() + 12
		Say(desk, client:RealName() .. " ставит " .. amount)
	end

	function ACTIONS.deal(desk, client)
		local g = desk.nwGame
		if (g and g.kind == "blackjack" and g.phase == "bet" and (g.bets[client] or 0) > 0) then BJDeal(desk) end
	end

	function ACTIONS.hit(desk, client)
		local g = desk.nwGame
		if (!g or g.kind != "blackjack" or g.phase != "play" or g.order[g.turn] != client) then return end
		local hand = g.hands[client]
		hand[#hand + 1] = table.remove(g.shoe)
		if (Score(hand) >= 21) then BJNextTurn(desk) else g.deadline = CurTime() + 30 end
	end

	function ACTIONS.stand(desk, client)
		local g = desk.nwGame
		if (!g or g.kind != "blackjack" or g.phase != "play" or g.order[g.turn] != client) then return end
		BJNextTurn(desk)
	end

	function ACTIONS.double(desk, client)
		local g = desk.nwGame
		if (!g or g.kind != "blackjack" or g.phase != "play" or g.order[g.turn] != client or #g.hands[client] != 2) then return end
		if (!Charge(client, g.bets[client])) then return NW.Notify(client, "Не хватает токенов, чтобы удвоить") end
		g.bets[client] = g.bets[client] * 2
		local hand = g.hands[client]
		hand[#hand + 1] = table.remove(g.shoe)
		BJNextTurn(desk)
	end

	function ACTIONS.start(desk, client, arg)
		local g = desk.nwGame
		if (!g or g.kind != "durak" or (g.phase != "lobby" and g.phase != "done")) then return end
		local why = DurakStart(desk, arg)
		if (why) then NW.Notify(client, why) end
	end

	function ACTIONS.play(desk, client, arg)
		local g = desk.nwGame
		if (!g or g.kind != "durak" or g.phase != "play") then return end
		local index
		for i, seat in ipairs(g.order) do if (seat == client) then index = i end end
		if (!index or index == g.defender or g.out[client]) then return end
		local hand = g.hands[client]
		if (!table.HasValue(hand, arg)) then return end

		local defenderHand = g.hands[g.order[g.defender]]

		if (#g.table == 0) then
			if (index != g.attacker) then return end
		else
			if (!TableRanks(g)[CA.Parse(arg)]) then return NW.Notify(client, "Подкидывать можно только карты тех же достоинств") end
		end

		if (#g.table >= DurakLimit(g) or (!g.taking and Undefended(g) + 1 > #defenderHand)) then
			return NW.Notify(client, "Больше подкидывать нельзя")
		end

		TakeCard(hand, arg)
		g.table[#g.table + 1] = {a = arg}
		g.deadline = CurTime() + 45
	end

	function ACTIONS.beat(desk, client, arg)
		local g = desk.nwGame
		if (!g or g.kind != "durak" or g.phase != "play" or g.order[g.defender] != client or g.taking) then return end
		local code, pairIndex = string.match(arg or "", "^(%w+):(%d+)$")
		pairIndex = tonumber(pairIndex)
		local pair = pairIndex and g.table[pairIndex]
		local hand = g.hands[client]
		if (!pair or pair.d or !table.HasValue(hand, code)) then return end
		if (!Beats(code, pair.a, g.trump)) then return NW.Notify(client, "Этой картой не побить") end
		TakeCard(hand, code)
		pair.d = code
		g.deadline = CurTime() + 45
	end

	function ACTIONS.take(desk, client)
		local g = desk.nwGame
		if (!g or g.kind != "durak" or g.phase != "play" or g.order[g.defender] != client or #g.table == 0) then return end
		g.taking = true
		g.deadline = CurTime() + 15
		Say(desk, client:RealName() .. ": беру")
	end

	function ACTIONS.done(desk, client)
		local g = desk.nwGame
		if (!g or g.kind != "durak" or g.phase != "play" or g.order[g.attacker] != client or #g.table == 0) then return end
		if (!g.taking and Undefended(g) > 0) then return NW.Notify(client, "Не все карты побиты") end
		DurakEndRound(desk)
	end

	function CA.Use(desk, client)
		ACTIONS.sit(desk, client)
		CA.Sync(desk)
	end

	net.Receive("nwCardsAction", function(_, client)
		local desk = net.ReadEntity()
		local action = net.ReadString()
		local arg = net.ReadString()

		if (!IsValid(desk) or desk:GetClass() != "nw_card_table" or !ACTIONS[action] or (client.nwCardsNext or 0) > CurTime()) then return end
		if (action != "sit" and !CA.Seated(desk, client)) then return end
		if (client:GetPos():DistToSqr(desk:GetPos()) > 200 * 200) then return end

		client.nwCardsNext = CurTime() + 0.2
		ACTIONS[action](desk, client, arg)
		CA.Sync(desk)
	end)

	timer.Create("nwCardTables", 1, 0, function()
		for _, desk in ipairs(ents.FindByClass("nw_card_table")) do
			local changed = false

			for index = #(desk.nwSeats or {}), 1, -1 do
				local seat = desk.nwSeats[index]
				if (!IsValid(seat) or !seat:Alive() or seat:GetPos():DistToSqr(desk:GetPos()) > 220 * 220) then
					if (IsValid(seat)) then ACTIONS.leave(desk, seat) else table.remove(desk.nwSeats, index) end
					changed = true
				end
			end

			local g = desk.nwGame

			if (g and g.kind == "durak" and g.phase == "play") then
				for _, seat in ipairs(g.order) do
					if (!IsValid(seat)) then
						DurakFinish(desk, seat)
						changed = true
						break
					end
				end
			end

			if (g and g.deadline and CurTime() > g.deadline) then
				g.deadline = nil
				changed = true

				if (g.kind == "blackjack") then
					if (g.phase == "bet") then BJDeal(desk)
					elseif (g.phase == "play") then BJNextTurn(desk)
					elseif (g.phase == "done") then NewBlackjack(desk) end
				elseif (g.kind == "durak") then
					if (g.phase == "play") then
						if (#g.table == 0) then
							local attacker = g.order[g.attacker]
							local hand = g.hands[attacker]
							if (hand and hand[1]) then
								g.table[1] = {a = table.remove(hand, 1)}
								g.deadline = CurTime() + 45
							end
						elseif (g.taking or Undefended(g) == 0) then
							DurakEndRound(desk)
						else
							g.taking = true
							g.deadline = CurTime() + 5
							Say(desk, "Время вышло: защитник берёт")
						end
					elseif (g.phase == "done") then
						g.phase = "lobby"
						g.order = desk.nwSeats
					end
				end
			end

			if (changed or (g and g.deadline and math.floor(CurTime()) % 5 == 0)) then CA.Sync(desk) end
		end
	end)

	return
end

local W = NW.widgets
local U = NW.ui

CA.textures = {}

local function CardTexture(code)
	if (CA.textures[code] == nil) then
		local r, s = CA.Parse(code)
		local name = code == "back" and "back" or ((CA.rankFile[r] or tostring(r)) .. s)
		local path = "materials/network2/cards/" .. name .. ".png"
		CA.textures[code] = file.Exists(path, "GAME") and Material("network2/cards/" .. name .. ".png", "smooth") or false
	end
	return CA.textures[code]
end

function CA.DrawCard(code, x, y, w, h, selected)
	local texture = CardTexture(code)

	if (texture) then
		surface.SetMaterial(texture)
		surface.SetDrawColor(255, 255, 255, 255)
		surface.DrawTexturedRect(x, y, w, h)
	elseif (code == "back") then
		draw.RoundedBox(6, x, y, w, h, Color(120, 30, 34))
		surface.SetDrawColor(255, 255, 255, 40)
		surface.DrawOutlinedRect(x + 4, y + 4, w - 8, h - 8, 2)
	else
		local r, s = CA.Parse(code)
		local red = s == "D" or s == "H"
		local color = red and Color(196, 30, 40) or Color(24, 24, 28)
		draw.RoundedBox(6, x, y, w, h, Color(244, 240, 230))
		draw.SimpleText(CA.rankName[r] or "?", "nwWidgetBold", x + w * 0.12, y + h * 0.06, color)
		draw.SimpleText(CA.suitGlyph[s] or "?", "nwWidgetTitle", x + w / 2, y + h / 2, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(CA.rankName[r] or "?", "nwWidgetBold", x + w * 0.88, y + h * 0.94, color, TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)
	end

	if (selected) then
		surface.SetDrawColor(232, 196, 72, 255)
		surface.DrawOutlinedRect(x - 2, y - 2, w + 4, h + 4, 3)
	end
end

local function Send(action, arg)
	net.Start("nwCardsAction")
		net.WriteEntity(Entity(CA.state and CA.state.entity or 0))
		net.WriteString(action)
		net.WriteString(tostring(arg or ""))
	net.SendToServer()
end

CA.Send = Send

local function CardButton(parent, code, x, y, w, h, onClick, selected)
	local button = parent:Add("DButton")
	button:SetText("")
	button:SetPos(x, y)
	button:SetSize(w, h)
	button.Paint = function(self, bw, bh)
		CA.DrawCard(code, 0, self:IsHovered() and onClick and -4 or 0, bw, bh, selected and selected())
	end
	button.DoClick = function()
		if (onClick) then surface.PlaySound("network2/ui/click.wav") onClick() end
	end
	return button
end

function CA.Build()
	local state = CA.state
	local frame = CA.frame
	if (!IsValid(frame) or !state) then return end

	local box = frame.box
	box.content:Clear()

	local area = box.content
	local w, h = area:GetWide(), area:GetTall()
	local sh = ScrH()
	local cw, ch = math.Round(sh * 0.075), math.Round(sh * 0.105)
	local fh = math.Round(sh * 0.042)

	local info = area:Add("DPanel")
	info:SetPos(0, 0)
	info:SetSize(w, h)
	info:SetMouseInputEnabled(false)
	info.Paint = function(_, iw, ih)
		draw.RoundedBox(12, 0, 0, iw, ih * 0.78, Color(24, 70, 44, 250))
		for index, line in ipairs(state.log or {}) do
			draw.SimpleText(line, "nwWidgetLabel", iw - 12, ih * 0.78 - 8 - (index - 1) * 16, Color(220, 230, 220, 255 - index * 30),
				TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)
		end
		if (state.deadline) then
			draw.SimpleText("⏱ " .. state.deadline, "nwWidgetBold", iw - 12, 12, Color(232, 196, 72), TEXT_ALIGN_RIGHT)
		end
	end

	local bottom = h * 0.8

	local function Btn(label, x, width, action, arg, accent, enabled)
		local b = W.Button(area, label, function() Send(action, arg) end, accent)
		b:SetPos(x, bottom + (h - bottom - fh) / 2)
		b:SetSize(width, fh)
		if (enabled == false) then b:SetEnabled(false) end
		return b
	end

	if (!state.kind) then
		local text = area:Add("DPanel")
		text:SetPos(0, h * 0.3)
		text:SetSize(w, sh * 0.05)
		text:SetMouseInputEnabled(false)
		text.Paint = function(_, tw, th)
			draw.SimpleText("Выберите игру", "nwWidgetTitle", tw / 2, th / 2, U.color.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		Btn("Блэкджек", 0, w * 0.3, "game", "blackjack", true)
		Btn("Дурак", w * 0.32, w * 0.3, "game", "durak", true)
		Btn("Встать из-за стола", w * 0.7, w * 0.3, "leave")
		return
	end

	if (state.kind == "blackjack") then
		local dx = w / 2 - (#(state.dealer or {}) * (cw + 6)) / 2

		for index, code in ipairs(state.dealer or {}) do
			CardButton(area, code, dx + (index - 1) * (cw + 6), sh * 0.04, cw, ch)
		end

		local dealerLabel = area:Add("DPanel")
		dealerLabel:SetPos(0, sh * 0.01)
		dealerLabel:SetSize(w, sh * 0.03)
		dealerLabel:SetMouseInputEnabled(false)
		dealerLabel.Paint = function(_, lw, lh)
			draw.SimpleText("КРУПЬЕ" .. (state.dealerScore and (" · " .. state.dealerScore) or ""), "nwWidgetBold", lw / 2, lh / 2,
				Color(232, 196, 72), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end

		local count = math.max(1, #(state.players or {}))
		local slot = w / count

		for index, player in ipairs(state.players or {}) do
			local px = (index - 1) * slot
			local label = area:Add("DPanel")
			label:SetPos(px, h * 0.36)
			label:SetSize(slot, sh * 0.05)
			label:SetMouseInputEnabled(false)
			label.Paint = function(_, lw, lh)
				draw.SimpleText(player.name .. (player.turn and "  ◄" or ""), "nwWidgetBold", lw / 2, lh * 0.3,
					player.me and Color(232, 196, 72) or U.color.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				draw.SimpleText("ставка " .. player.bet .. (player.score and ("  ·  очки " .. player.score) or "") ..
					(player.result and ("  ·  " .. player.result) or ""), "nwWidgetLabel", lw / 2, lh * 0.78, W.MUTED, TEXT_ALIGN_CENTER,
					TEXT_ALIGN_CENTER)
			end

			local hand = player.hand or {}
			local hx = px + slot / 2 - (#hand * (cw * 0.6) + cw * 0.4) / 2

			for c, code in ipairs(hand) do
				CardButton(area, code, hx + (c - 1) * cw * 0.6, h * 0.36 + sh * 0.055, cw, ch)
			end
		end

		local me

		for _, player in ipairs(state.players or {}) do if (player.me) then me = player end end

		if (state.phase == "bet") then
			if (!me or me.bet == 0) then
				local amount = W.Number(area, 5, 1, state.maxBet or 50)
				amount:SetPos(0, bottom + (h - bottom - fh) / 2)
				amount:SetSize(w * 0.12, fh)
				local b = W.Button(area, "Ставка (до " .. (state.maxBet or 50) .. ")", function() Send("bet", amount:GetNumber()) end, true)
				b:SetPos(w * 0.13, bottom + (h - bottom - fh) / 2)
				b:SetSize(w * 0.25, fh)
			else
				Btn("Раздать сейчас", 0, w * 0.3, "deal", nil, true)
			end
		elseif (state.phase == "play" and me and me.turn) then
			Btn("Ещё", 0, w * 0.18, "hit", nil, true)
			Btn("Хватит", w * 0.19, w * 0.18, "stand")
			Btn("Удвоить", w * 0.38, w * 0.18, "double", nil, false, #(me.hand or {}) == 2)
		end

		Btn("Другая игра", w * 0.58, w * 0.2, "game", "", false, state.phase != "play")
		Btn("Встать", w * 0.8, w * 0.2, "leave")

		return
	end

	if (state.kind == "durak") then
		local players = state.players or {}
		local slot = w / math.max(1, #players)

		for index, player in ipairs(players) do
			local label = area:Add("DPanel")
			label:SetPos((index - 1) * slot, sh * 0.01)
			label:SetSize(slot, sh * 0.05)
			label:SetMouseInputEnabled(false)
			label.Paint = function(_, lw, lh)
				local role = player.out and "вышел" or (player.attacker and "ходит" or (player.defender and "отбивается" or ""))
				draw.SimpleText(player.name, "nwWidgetBold", lw / 2, lh * 0.3, player.me and Color(232, 196, 72) or U.color.text,
					TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				draw.SimpleText(player.count .. " карт" .. (role != "" and ("  ·  " .. role) or ""), "nwWidgetLabel", lw / 2, lh * 0.78,
					W.MUTED, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end

		if (state.phase == "lobby" or state.phase == "done") then
			local text = area:Add("DPanel")
			text:SetPos(0, h * 0.3)
			text:SetSize(w, sh * 0.05)
			text:SetMouseInputEnabled(false)
			text.Paint = function(_, tw, th)
				draw.SimpleText(state.result or "Подкидной дурак · 2–4 игрока", "nwWidgetTitle", tw / 2, th / 2, U.color.text, TEXT_ALIGN_CENTER,
					TEXT_ALIGN_CENTER)
			end
			local ante = W.Number(area, 0, 0, state.maxBet or 50)
			ante:SetPos(0, bottom + (h - bottom - fh) / 2)
			ante:SetSize(w * 0.12, fh)
			local start = W.Button(area, "Начать (ставка с каждого)", function() Send("start", ante:GetNumber()) end, true)
			start:SetPos(w * 0.13, bottom + (h - bottom - fh) / 2)
			start:SetSize(w * 0.3, fh)
			Btn("Другая игра", w * 0.58, w * 0.2, "game", "")
			Btn("Встать", w * 0.8, w * 0.2, "leave")
			return
		end

		if (state.trumpCard) then
			CardButton(area, state.trumpCard, sh * 0.02, h * 0.3, cw, ch)
			local deck = area:Add("DPanel")
			deck:SetPos(sh * 0.02, h * 0.3 + ch + 4)
			deck:SetSize(cw * 2, sh * 0.03)
			deck:SetMouseInputEnabled(false)
			deck.Paint = function(_, dw, dh)
				draw.SimpleText("колода: " .. (state.deck or 0) .. "  козырь " .. (CA.suitGlyph[state.trump] or ""), "nwWidgetLabel", 0, dh / 2,
					U.color.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end
		end

		local me = players[state.myIndex or 0] or {}

		for index, pair in ipairs(state.table or {}) do
			local tx = w * 0.18 + (index - 1) * (cw + sh * 0.025)
			local ty = h * 0.22
			CardButton(area, pair.a, tx, ty, cw, ch, (me.defender and !pair.d and CA.selected) and function()
				Send("beat", CA.selected .. ":" .. index)
				CA.selected = nil
			end)
			if (pair.d) then
				CardButton(area, pair.d, tx + cw * 0.25, ty + ch * 0.35, cw, ch)
			end
		end

		local hand = state.hand or {}
		local step = math.min(cw + 6, (w - cw) / math.max(1, #hand))

		for index, code in ipairs(hand) do
			CardButton(area, code, w / 2 - (#hand * step) / 2 + (index - 1) * step, h * 0.6, cw, ch, function()
				if (me.defender) then
					CA.selected = CA.selected != code and code or nil
					CA.Build()
				else
					Send("play", code)
				end
			end, function() return CA.selected == code end)
		end

		if (me.defender) then
			Btn("Взять", 0, w * 0.2, "take", nil, false, !state.taking)
			local hint = area:Add("DPanel")
			hint:SetPos(w * 0.21, bottom)
			hint:SetSize(w * 0.37, h - bottom)
			hint:SetMouseInputEnabled(false)
			hint.Paint = function(_, hw, hh)
				draw.SimpleText(state.taking and "Вы берёте карты" or "Выберите карту, затем карту на столе", "nwWidgetLabel", 0, hh / 2, W.MUTED,
					TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end
		elseif (me.attacker) then
			Btn(state.taking and "Отдать" or "Бито", 0, w * 0.2, "done", nil, true)
		end

		Btn("Сдаться и встать", w * 0.8, w * 0.2, "leave")
	end
end

net.Receive("nwCards", function()
	local state = util.JSONToTable(net.ReadString() or "") or {}

	if (state.closed) then
		if (IsValid(CA.frame)) then CA.frame:Remove() end
		CA.state = nil
		return
	end

	CA.state = state

	if (!IsValid(CA.frame)) then
		local sh = ScrH()
		local frame, box = W.Window("Игральный стол", math.Round(math.min(ScrW() * 0.9, sh * 1.5)), math.Round(sh * 0.82), function()
			Send("leave")
		end)
		local pad = math.Round(sh * 0.02)
		local content = box:Add("EditablePanel")
		content:SetPos(pad, box.top)
		content:SetSize(box:GetWide() - pad * 2, box:GetTall() - box.top - pad)
		box.content = content
		frame.box = box
		CA.frame = frame
		CA.selected = nil
	end

	CA.Build()
end)

hook.Add("NWEscape", "nwCards", function()
	if (IsValid(CA.frame)) then
		Send("leave")
		CA.frame:Remove()
		return true
	end
end)
