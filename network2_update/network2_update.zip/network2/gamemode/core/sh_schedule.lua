NW.schedule = NW.schedule or {}

local SC = NW.schedule

SC.phases = {
	{id = "work", name = "Рабочая смена", convar = "nw_schedule_work", minutes = 12, allows = {factory = true, rations = true},
		text = "Граждане обязаны явиться на рабочие места. Завод открыт."},
	{id = "free", name = "Свободное время", convar = "nw_schedule_free", minutes = 10, allows = {rations = true},
		text = "Рабочая смена окончена. Завод закрыт."},
	{id = "curfew", name = "Комендантский час", convar = "nw_schedule_curfew", minutes = 6, allows = {},
		text = "Гражданам вернуться в жилые помещения. Нахождение на улице — нарушение."}
}

SC.byID = {}

for index, phase in ipairs(SC.phases) do
	phase.index = index
	SC.byID[phase.id] = phase
	phase.cvar = CreateConVar(phase.convar, tostring(phase.minutes), {FCVAR_ARCHIVE, FCVAR_REPLICATED},
		"Длительность фазы «" .. phase.name .. "» (минуты)")
end

local enabled = CreateConVar("nw_schedule", "1", {FCVAR_ARCHIVE, FCVAR_REPLICATED}, "Расписание города: смена, " ..
	"свободное время, комендантский час")

function SC.Current()
	if (!enabled:GetBool()) then
		return SC.byID.free, 0
	end

	local phase = SC.byID[GetGlobal2String("nwPhase", "free")] or SC.byID.free

	return phase, math.max(0, GetGlobal2Float("nwPhaseEnds", 0) - CurTime())
end

function SC.Allows(what)
	if (!enabled:GetBool()) then
		return true
	end

	return SC.Current().allows[what] == true
end

if (SERVER) then
	util.AddNetworkString("nwSchedule")

	local manual = false
	local curfewMin = CreateConVar("nw_schedule_curfew_min", "10", FCVAR_ARCHIVE,
		"Сколько игроков с персонажами нужно на сервере, чтобы наступал комендантский час (0 - всегда)")

	function SC.Online()
		local count = 0

		for _, client in ipairs(player.GetAll()) do
			if (client:GetCharacterID() != 0) then count = count + 1 end
		end

		return count
	end

	function SC.Set(id, bManual)
		local phase = SC.byID[id]

		if (!phase) then
			return
		end

		SetGlobal2String("nwPhase", id)
		SetGlobal2Float("nwPhaseEnds", CurTime() + math.max(1, phase.cvar:GetFloat()) * 60)
		manual = bManual == true

		net.Start("nwSchedule")
			net.WriteString(id)
		net.Broadcast()

		MsgN("[SCHEDULE] " .. phase.name)
		hook.Run("NWScheduleChanged", phase)
	end

	timer.Create("nwSchedule", 1, 0, function()
		if (!enabled:GetBool()) then
			return
		end

		local phase, left = SC.Current()

		if (GetGlobal2String("nwPhase", "") == "") then
			return SC.Set("work")
		end

		if (left <= 0) then
			local nextPhase = SC.phases[phase.index % #SC.phases + 1]

			if (nextPhase.id == "curfew" and SC.Online() < curfewMin:GetInt()) then
				nextPhase = SC.phases[nextPhase.index % #SC.phases + 1]
			end

			SC.Set(nextPhase.id, manual)
		end
	end)

	local WORDS = {["смена"] = "work", ["работа"] = "work", ["свободное"] = "free", ["комендантский"] = "curfew",
		work = "work", free = "free", curfew = "curfew"}

	NW.AddChatCommand("schedule", {admin = true, run = function(client, rest)
		local word = string.lower(string.Trim(rest or ""))

		if (word == "авто" or word == "auto") then
			manual = false

			return NW.Notify(client, "Расписание идёт само")
		end

		local id = WORDS[word]

		if (!id) then
			return NW.Notify(client, "/schedule <смена|свободное|комендантский|авто>")
		end

		SC.Set(id, true)
	end})

	return
end

local YELLOW = Color(240, 208, 70)

net.Receive("nwSchedule", function()
	local phase = SC.byID[net.ReadString()]

	if (!phase) then
		return
	end

	NW.chat.AddStyled("nwChat", YELLOW, "[ОПОВЕЩЕНИЕ] Наступает время: " .. phase.name .. ". " .. phase.text)
	surface.PlaySound("network2/schedule/reminder.mp3")
end)
