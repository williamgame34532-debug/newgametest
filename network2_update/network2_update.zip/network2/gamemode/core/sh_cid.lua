NW.cid = NW.cid or {}

local CI = NW.cid

CI.reissueCost = CreateConVar("nw_cid_reissue", "30", {FCVAR_ARCHIVE, FCVAR_REPLICATED},
	"Пошлина за заявку на новую CID-карту (со счёта)")

NW.requests.kinds.cid = {
	name = "Новая CID-карта",
	alliance = true,
	Describe = function(fields)
		return "Причина: " .. tostring(fields.reason or "")
	end
}
local FORGE_TIME = 20
local REACH = 100

if (SERVER) then
	util.AddNetworkString("nwCidForgeOpen")
	util.AddNetworkString("nwCidForge")
	util.AddNetworkString("nwCidResult")
	util.AddNetworkString("nwPdaOpen")
	util.AddNetworkString("nwPdaIssue")

	local INV = NW.inventory
	local SO = NW.social

	local function Notify(client, text)
		NW.Notify(client, text)
	end

	function CI.Find(client)
		local inventory = INV.Get(client)

		for index = 1, NW.items.maxSize do
			local cell = inventory.grid[index]

			if (cell and cell.id == "cid") then
				return cell, index
			end
		end
	end

	local function Give(client, card)
		if (!INV.Add(client, "cid", card)) then
			INV.SpawnWorldItem(client, {id = "cid", data = card})
		end

		INV.Changed(client)
	end

	function CI.Issue(client, fields)
		local character = client.nwCharacter

		if (!character) then
			return
		end

		fields = fields or {}

		local card = SO.MakeCard(character, fields.description or client:GetCharacterDescription())

		character.data = character.data or {}
		character.data.cid = character.data.cid or card.number
		card.number = character.data.cid
		card.owner = character.id
		card.name = fields.name or character.data.civName or card.name
		card.gender = fields.gender or card.gender
		NW.char.SaveData(client)
		Give(client, card)

		return card
	end

	NW.requests.kinds.cid.Approved = function(entry, client)
		local card = CI.Issue(client)

		if (card) then
			Notify(client, "CID-карта #" .. card.number .. " выдана — она в инвентаре")
		end
	end

	hook.Add("NWTerminalProfile", "nwCid", function(client, extra)
		local entry = NW.requests.Of(client:GetCharacterID(), "cid")

		extra.cidRequest = entry and entry.status or nil
	end)

	NW.terminal.actions.cid_request = function(client, terminal, input)
		local T = NW.terminal
		local data = T.Data(client)
		local cost = math.max(0, CI.reissueCost:GetInt())
		local reason = NW.Cut(string.Trim(string.gsub(tostring(input.reason or ""), "[%c]", " ")), 140)

		if (!data) then
			return
		end

		if (client:GetFaction() == "refugee") then
			return T.Result(client, terminal, "СНАЧАЛА РЕГИСТРАЦИЯ БЕЖЕНЦА")
		elseif ((utf8.len(reason) or 0) < 3) then
			return T.Result(client, terminal, "УКАЖИТЕ ПРИЧИНУ")
		elseif ((data.bank or 0) < cost) then
			return T.Result(client, terminal, "НА СЧЁТЕ НЕДОСТАТОЧНО СРЕДСТВ: " .. cost .. " ТК")
		end

		local entry, why = NW.requests.Submit(client, "cid", {reason = reason})

		if (!entry) then
			return T.Result(client, terminal, why)
		end

		data.bank = data.bank - cost
		T.Log(client, "ПОШЛИНА ЗА CID-КАРТУ −" .. cost .. " ТК", false)
		T.SaveData(client)
		T.Send(client, "profile", terminal, T.Profile(client))
		T.Result(client, terminal, "ЗАЯВКА ПРИНЯТА К РАССМОТРЕНИЮ")
	end

	function CI.OpenForge(client)
		if (client:GetFaction() != "rebel") then
			Notify(client, "Вы не знаете, как с этим обращаться")

			return
		end

		net.Start("nwCidForgeOpen")
			net.WriteString(client:RealName())
		net.Send(client)
	end

	net.Receive("nwCidForge", function(_, client)
		local name = string.Trim(string.gsub(net.ReadString() or "", "[%c]", ""))

		if (client:GetFaction() != "rebel" or !INV.Has(client, "forge_kit") or !client:Alive()) then
			return
		end

		if ((utf8.len(name) or 0) < 2 or (utf8.len(name) or 0) > 40) then
			return Notify(client, "Имя на карте: от 2 до 40 символов")
		end

		NW.progress.Start(client, "Подделываю CID-карту", FORGE_TIME, function()
			local inventory = INV.Get(client)

			for index = 1, NW.items.maxSize do
				local cell = inventory.grid[index]

				if (cell and cell.id == "forge_kit") then
					inventory.grid[index] = nil

					local card = SO.MakeCard({name = name, gender = client:GetNW2String("nwCharGender", "male"),
						model = client:GetModel(), skin = client:GetSkin(), faction = "citizen"},
						client:GetCharacterDescription())

					card.number = string.format("%05d", math.random(0, 99999))
					card.forged = true
					Give(client, card)
					client:EmitSound("physics/cardboard/cardboard_box_impact_soft" .. math.random(1, 7) .. ".wav", 55)
					Notify(client, "Готово: CID-карта на имя «" .. name .. "», #" .. card.number ..
						". В базе её нет — проверку ПДА она не пройдёт")

					return
				end
			end
		end, function()
			return client:Alive() and INV.Has(client, "forge_kit")
		end)
	end)

	local RV = "npc/overwatch/radiovoice/"

	function CI.Check(unit, target)
		local cell = CI.Find(target)
		local card = cell and cell.data or {}
		local result = {name = card.name or "", number = card.number or "", issued = card.issued or "",
			faction = NW.char.factions[card.faction or ""] and NW.char.factions[card.faction].name or ""}

		if (!cell) then
			result.verdict = "none"
		elseif (card.forged) then
			result.verdict = "forged"
		elseif ((card.owner and card.owner != target:GetCharacterID()) or (!card.owner and card.name and
			card.name != target:RealName() and card.name != (target.nwCharacter and target.nwCharacter.data and
			target.nwCharacter.data.civName))) then
			result.verdict = "foreign"
		else
			result.verdict = "valid"
		end

		result.target = target:EntIndex()
		result.time = os.date("%H:%M")

		net.Start("nwCidResult")
			net.WriteString(util.TableToJSON(result))
		net.Send(unit)

		NW.Notify(target, "Ваша CID-карта проверена")
		MsgN(string.format("[CID] %s проверил %s: %s", unit:Nick(), target:Nick(), result.verdict))

		if (result.verdict == "forged" and NW.dispatcher and NW.dispatcher.Queue) then
			local zone = NW.zones.At(target:GetPos())

			NW.dispatcher.Queue(function()
				NW.dispatcher.Say("Несоответствие данных CID #" .. result.number .. " («" .. result.name .. "»), зона «" ..
					(zone and zone.name or "неизвестно") .. "». Всем подразделениям: задержать и изолировать.",
					{RV .. "attention.wav", RV .. "violationofcivictrust.wav", RV .. "sector.wav", RV .. "isolate.wav"}, true)
			end, "cid:" .. target:EntIndex(), 30)
		end

		return result
	end

	function CI.OpenPda(client, page, target)
		net.Start("nwPdaOpen")
			net.WriteString(page or "")
			net.WriteEntity(IsValid(target) and target or NULL)
		net.Send(client)
	end

	net.Receive("nwPdaIssue", function(_, client)
		local target = net.ReadEntity()
		local fields = util.JSONToTable(net.ReadString() or "") or {}

		if (!NW.zones.UsesAlliance(client) or !client:HasWeapon("nw_cid_pda") or !IsValid(target) or !target:IsPlayer() or
			target:GetCharacterID() == 0 or target:GetPos():DistToSqr(client:GetPos()) > 220 * 220 or
			(client.nwPdaNext or 0) > CurTime()) then
			return
		end

		if (target:GetFaction() == "refugee") then
			return Notify(client, "Беженцу — сначала регистрация на терминале")
		end

		local name = NW.Cut(string.Trim(string.gsub(tostring(fields.name or ""), "[%c]", "")), 60)

		if ((utf8.len(name) or 0) < 2) then
			return Notify(client, "Укажите имя на карте")
		end

		client.nwPdaNext = CurTime() + 5

		NW.progress.Start(client, "Оформляю CID-карту", 3, function()
			local card = CI.Issue(target, {name = name, gender = fields.gender == "female" and "female" or "male",
				description = NW.Cut(string.Trim(tostring(fields.description or "")), 300)})

			if (card) then
				client:EmitSound("buttons/combine_button1.wav", 55)
				Notify(client, "CID-карта #" .. card.number .. " оформлена: " .. card.name)
				Notify(target, client:Nick() .. " выдал вам CID-карту #" .. card.number)
				MsgN(string.format("[CID] %s оформил карту %s (#%s, «%s»)", client:Nick(), target:Nick(), card.number, card.name))
			end
		end, function()
			return IsValid(target) and target:Alive() and client:Alive() and target:GetPos():DistToSqr(client:GetPos()) < 260 * 260
		end)
	end)

	hook.Add("NWInventoryChanged", "nwCidPda", function(client)
		if (client:HasWeapon("nw_cid_pda") and !INV.Has(client, "cid_pda") and !NW.classes.Grants(client, "nw_cid_pda")) then
			client:StripWeapon("nw_cid_pda")
		end
	end)

	return
end

net.Receive("nwCidForgeOpen", function()
	local name = net.ReadString()

	Derma_StringRequest("Подделка CID-карты", "Имя на карте (номер будет случайным)", name, function(value)
		net.Start("nwCidForge")
			net.WriteString(value)
		net.SendToServer()
	end)
end)

local VERDICTS = {
	valid = {"В БАЗЕ ДАННЫХ", Color(110, 232, 132)},
	forged = {"НЕТ В БАЗЕ — ПОДДЕЛКА", Color(236, 96, 80)},
	foreign = {"КАРТА НЕ ПРИНАДЛЕЖИТ ПРЕДЪЯВИТЕЛЮ", Color(244, 150, 64)},
	none = {"CID-КАРТЫ НЕТ", Color(240, 214, 90)}
}

net.Receive("nwCidResult", function()
	CI.last = util.JSONToTable(net.ReadString() or "") or {}
	CI.lastAt = RealTime()
	hook.Run("NWCidResult", CI.last)

	surface.PlaySound(CI.last.verdict == "valid" and "buttons/combine_button1.wav" or "buttons/combine_button_locked.wav")
end)

hook.Add("HUDPaint", "nwCidResult", function()
	local result = CI.last

	if (!result or RealTime() - (CI.lastAt or 0) > 10 or IsValid(NW.pda and NW.pda.frame)) then
		return
	end

	local sh = ScrH()
	local verdict = VERDICTS[result.verdict] or VERDICTS.none
	local a = math.Clamp((10 - (RealTime() - CI.lastAt)) / 0.6, 0, 1)
	local w, h = math.Round(sh * 0.42), math.Round(sh * 0.15)
	local x, y = math.Round(ScrW() / 2 - w / 2), math.Round(sh * 0.66)

	draw.RoundedBox(6, x, y, w, h, Color(10, 14, 20, 230 * a))
	surface.SetDrawColor(verdict[2].r, verdict[2].g, verdict[2].b, 255 * a)
	surface.DrawRect(x, y, w, 3)
	draw.SimpleText("ПРОВЕРКА CID", "nwWidget", x + sh * 0.015, y + sh * 0.022, Color(150, 160, 172, 255 * a))
	draw.SimpleText(verdict[1], "nwWidgetBold", x + sh * 0.015, y + sh * 0.05, ColorAlpha(verdict[2], 255 * a))

	if (result.verdict != "none") then
		draw.SimpleText("Имя: " .. result.name .. "   #" .. result.number, "nwWidget", x + sh * 0.015, y + sh * 0.088,
			Color(220, 224, 230, 255 * a))
		draw.SimpleText("Статус: " .. (result.faction != "" and result.faction or "—") .. "   Выдана: " .. result.issued,
			"nwWidget", x + sh * 0.015, y + sh * 0.115, Color(170, 176, 184, 255 * a))
	end
end)
