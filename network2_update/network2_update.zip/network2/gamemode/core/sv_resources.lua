resource.AddFile("materials/network2/emblem.png")
resource.AddFile("materials/network2/watermark.png")
resource.AddFile("materials/network2/menu/button.png")
resource.AddFile("materials/network2/menu/button_hover.png")
resource.AddFile("materials/network2/menu/vignette.png")
resource.AddFile("materials/network2/menu/splash.jpg")
resource.AddFile("resource/fonts/Jura-Medium.ttf")
resource.AddFile("resource/fonts/Jura-Bold.ttf")
resource.AddFile("sound/network2/ui/hover.wav")

for _, name in ipairs({"mic2_frame", "mic2_fill", "mic2_wave", "icons/mic2"}) do
	resource.AddFile("materials/network2/ui/" .. name .. ".png")
end

for _, name in ipairs({"visor_glass", "visor_night", "visor_worn"}) do
	resource.AddFile("materials/network2/overlay/" .. name .. ".png")
end

for _, name in ipairs({"key1", "key2", "key3", "key4", "key5", "key6", "key7", "key8", "hum"}) do
	resource.AddFile("sound/network2/computer/" .. name .. ".wav")
end

for index = 1, 5 do
	resource.AddFile("sound/network2/ota/gear" .. index .. ".wav")
end

for index = 1, 4 do
	resource.AddFile("sound/network2/metrocop/gear" .. index .. ".wav")
end
resource.AddFile("sound/network2/ui/click.wav")
resource.AddFile("sound/network2/ui/confirm.mp3")
for _, name in ipairs({"hover_mech", "select_mech", "press_mech", "start_mech", "open_mech", "hover_cine",
	"select_cine", "start_cine", "success_cine", "open_cine"}) do
	resource.AddFile("sound/network2/ui/alt/" .. name .. ".wav")
end

for _, name in ipairs({"say", "whisper", "yell", "ooc", "looc", "pm", "roll", "me", "it", "admin", "radio", "rebel",
	"dispatch", "system"}) do
	resource.AddFile("materials/network2/chat/" .. name .. ".png")
end

for _, name in ipairs({"Exo2-Regular", "Exo2-SemiBold", "Exo2-Bold", "Exo2-Italic", "Montserrat-Medium",
	"Montserrat-SemiBold", "Oswald-Light", "Oswald-Medium", "Oswald-SemiBold", "JetBrainsMono-Medium",
	"JetBrainsMono-ExtraBold"}) do
	resource.AddFile("resource/fonts/" .. name .. ".ttf")
end

for _, name in ipairs({"panel", "button", "outline", "card_shade", "chat_panel", "chat_tab", "board_sheet",
	"board_edge", "board_menu"}) do
	resource.AddFile("materials/network2/ui/" .. name .. ".png")
end

for _, name in ipairs({"male", "female", "strength", "endurance", "medicine", "engineering", "stealth", "speech",
	"plus", "trash", "play", "back", "faction", "user", "height", "skin", "check", "chat", "resize"}) do
	resource.AddFile("materials/network2/ui/icons/" .. name .. ".png")
end

for _, name in ipairs({"hls_ui_appear", "hls_ui_affirm", "textline_1", "textline_2", "textline_3", "textline_4",
	"textline_5", "textline_6", "textline_7", "textline_8", "textline_end"}) do
	resource.AddFile("sound/network2/ui/char/" .. name .. ".wav")
end

for _, name in ipairs(NW.char.logos) do
	resource.AddFile("materials/network2/factions/" .. name .. ".png")
end

resource.AddFile("sound/network2/ui/chat_receive.wav")
resource.AddFile("sound/network2/weapon_equip.wav")

for _, name in ipairs({"inv_slot", "inv_cell", "inv_tip", "inv_shade"}) do
	resource.AddFile("materials/network2/ui/" .. name .. ".png")
end

local icons = {}

for _, item in pairs(NW.items.list) do
	icons[item.icon] = true
end

for _, slot in ipairs(NW.items.slots) do
	icons[slot.icon] = true
end

for name in pairs(icons) do
	resource.AddFile("materials/network2/items/" .. name .. ".png")
end

for _, name in ipairs({"inventory", "settings", "authors", "config", "health", "hunger", "thirst", "stamina", "take",
	"interact", "drop", "close", "mic", "voice_whisper", "voice_normal", "voice_yell", "acts", "back", "act_sit",
	"act_ground", "act_wall", "act_lie", "act_injured", "act_handsup", "act_arrest", "act_lean", "act_stand",
	"act_check", "act_foldarms", "act_kneel", "act_shiver", "door", "meet", "tokens", "cid", "examine", "pulse",
	"helpup", "heal", "search", "swap", "storage", "trade", "quest", "talk", "edit", "skull", "shield"}) do
	resource.AddFile("materials/network2/ui/icons/" .. name .. ".png")
end

for _, name in ipairs({"handle_small_leather", "handle_small_leather2", "drop_leather", "cloth_belt", "cloth_belt2",
	"cloth1", "cloth2", "cloth3", "cloth4", "belt_handle1", "belt_handle2", "metal_latch", "draw_knife1",
	"inv_move1", "inv_move2", "inv_move3", "inv_bandage", "choreo_foley_jacket1", "choreo_foley_jacket2"}) do
	resource.AddFile("sound/network2/inv/" .. name .. ".wav")
end

resource.AddFile("sound/network2/inv/inv_move4.mp3")

for _, name in ipairs({"drink_water", "drink_soda", "eat_bread", "eat_canned", "eat_ration", "pills", "medkit",
	"bandage", "search_1", "search_2", "search_3", "search_4"}) do
	resource.AddFile("sound/network2/use/" .. name .. ".wav")
end

resource.AddFile("sound/network2/music/menu/a1_intro_strider2.mp3")

for i = 1, 10 do
	resource.AddFile(string.format("sound/network2/music/passive/passivemusic_%02d.mp3", i))
end

for i = 1, 5 do
	resource.AddFile("sound/network2/music/combat/combinemusic_" .. i .. ".mp3")
end

resource.AddFile("materials/network2/ui/crosshair.png")
resource.AddFile("materials/network2/ui/blood_overlay.png")

for _, name in ipairs({"mic_frame", "mic_fill", "mic_wave"}) do
	resource.AddFile("materials/network2/ui/" .. name .. ".png")
end

resource.AddFile("materials/network2/ui/key.png")
resource.AddFile("materials/network2/ui/unknown.png")

resource.AddFile("sound/network2/ui/hls_hint.wav")

resource.AddFile("materials/network2/ui/death_bg.png")
resource.AddFile("materials/network2/ui/knock_bg.png")

for _, name in ipairs({"panel", "answer", "answer_hover", "card", "plate", "shade"}) do
	resource.AddFile("materials/network2/ui/npc/" .. name .. ".png")
end

for _, name in ipairs({"wallpaper", "cursor", "cursor_hover"}) do
	resource.AddFile("materials/network2/terminal/" .. name .. ".png")
end

for _, name in ipairs({"station_hum_loop", "station_menu_alarm", "station_menu_appear", "station_menu_disappear",
	"station_menu_hover", "station_menu_select", "station_menu_select_denied", "station_slide_open",
	"station_slide_closed"}) do
	resource.AddFile("sound/network2/terminal/civic/" .. name .. ".wav")
end

for i = 1, 6 do
	resource.AddFile("sound/network2/metrocop/metrocop_foley_step_" .. i .. ".wav")
end

for i = 1, 5 do
	resource.AddFile(string.format("sound/network2/radio/combine_radio_on_%02d.wav", i))
end

for i = 1, 6 do
	resource.AddFile(string.format("sound/network2/radio/combine_radio_off_%02d.wav", i))
end

for _, name in ipairs({"cmb_overlay", "soldier_overlay", "elite_overlay"}) do
	resource.AddSingleFile("materials/network2/overlay/" .. name .. ".vmt")
end

for _, name in ipairs({"combine_overlay", "combine_overlay_normal", "soldier_overlay", "elite_overlay"}) do
	resource.AddSingleFile("materials/network2/overlay/" .. name .. ".vtf")
end

for _, name in ipairs({"Combine_Alphabet.ttf", "combine_alphabet.ttf", "Combine_Alphabet.otf"}) do
	if (file.Exists("resource/fonts/" .. name, "GAME")) then
		resource.AddSingleFile("resource/fonts/" .. name)
	end
end

local function Folder(path)
	local files, folders = file.Find(path .. "/*", "GAME")

	for _, name in ipairs(files or {}) do
		resource.AddSingleFile(path .. "/" .. name)
	end

	for _, name in ipairs(folders or {}) do
		Folder(path .. "/" .. name)
	end
end

for _, path in ipairs({"materials/network2/ui/icons", "materials/network2/items", "materials/network2/squad",
	"materials/network2/cmb", "materials/network2/forcefield", "materials/network2/fx", "sound/network2/squad",
	"sound/network2/radio2", "sound/network2/dispatch", "sound/network2/overwatch", "sound/network2/forcefield",
	"sound/network2/lock", "sound/network2/dispenser", "sound/network2/cmbterminal", "sound/network2/stunstick",
	"sound/network2/factory", "sound/network2/voices/male01", "sound/network2/voices/female01", "sound/network2/weather", "sound/network2/fabricator", "sound/network2/combine",
	"sound/network2/schedule"}) do
	Folder(path)
end

for _, path in ipairs({"models/cf_rework", "materials/cf_rework", "materials/models/cf_rework", "sound/combine_fabricator",
	"models/hla/health_station", "materials/models/hla", "materials/hla", "sound/hla"}) do
	Folder(path)
end

if (file.Exists("shaders/fxc/hla_monitor_ps30.vcs", "GAME")) then
	resource.AddSingleFile("shaders/fxc/hla_monitor_ps30.vcs")
end

for _, name in ipairs({"RobotoCondensed-Regular", "RobotoCondensed-Bold"}) do
	if (file.Exists("resource/fonts/" .. name .. ".ttf", "GAME")) then
		resource.AddFile("resource/fonts/" .. name .. ".ttf")
	end
end

resource.AddFile("materials/network2/terminal/glass43.vmt")
resource.AddFile("materials/network2/terminal/glass43.vtf")

