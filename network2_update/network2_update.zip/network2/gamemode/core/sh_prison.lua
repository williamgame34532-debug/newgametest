NW.prison = NW.prison or {}

local PR = NW.prison

PR.charges = {
	{id = "noncompliance", text = "Неподчинение требованиям", word = "publicnoncompliance507", minutes = 4},
	{id = "unity", text = "Нарушение общественного порядка", word = "disturbingunity415", minutes = 5},
	{id = "attempt", text = "Попытка совершения преступления", word = "attemptedcrime27", minutes = 4},
	{id = "trespass", text = "Незаконное проникновение", word = "criminaltrespass63", minutes = 6},
	{id = "entry", text = "Незаконное вторжение", word = "unlawfulentry603", minutes = 6},
	{id = "possession", text = "Хранение запрещённого", word = "posession69", minutes = 6},
	{id = "property", text = "Угроза имуществу Альянса", word = "threattoproperty51b", minutes = 6},
	{id = "resisting", text = "Сопротивление при задержании", word = "resistingpacification148", minutes = 8},
	{id = "fugitive", text = "Уклонение от задержания", word = "fugitive17f", minutes = 8},
	{id = "trust", text = "Нарушение гражданского доверия", word = "violationofcivictrust", minutes = 8},
	{id = "weapon", text = "Незаконное ношение оружия", word = "illegalcarrying95", minutes = 10},
	{id = "arson", text = "Несанкционированный поджог", word = "nonsanctionedarson51", minutes = 10},
	{id = "unrest", text = "Подстрекательство к беспорядкам", word = "promotingcommunalunrest", minutes = 10},
	{id = "assault", text = "Нападение на Альянс", word = "assault243", minutes = 15},
	{id = "anticivil", text = "Антигражданская деятельность", word = "level5anticivilactivity", minutes = 15}
}

PR.chargeByID = {}

for _, charge in ipairs(PR.charges) do
	PR.chargeByID[charge.id] = charge
end

PR.maxMinutes = 60
PR.workCut = CreateConVar("nw_prison_work", "60", {FCVAR_ARCHIVE, FCVAR_REPLICATED},
	"На сколько секунд одна работа в тюрьме сокращает срок")
PR.reach = 400

PR.jobs = {
	{name = "Сортировка вторсырья", verb = "Сортирую вторсырьё", model = "models/props_wasteland/controlroom_desk001b.mdl"},
	{name = "Стирка формы", verb = "Стираю форму", model = "models/props_c17/FurnitureWashingmachine001a.mdl"},
	{name = "Уборка блока", verb = "Убираю блок", model = "models/props_junk/MetalBucket01a.mdl"}
}

local meta = FindMetaTable("Player")

function meta:IsCuffed()
	return self:GetNW2Bool("nwCuffed", false)
end

function meta:IsImprisoned()
	return self:GetNW2Float("nwPrisonEnd", 0) > CurTime()
end

function PR.Term(ids)
	local minutes = 0

	for _, id in ipairs(ids) do
		minutes = minutes + (PR.chargeByID[id] and PR.chargeByID[id].minutes or 0)
	end

	return math.Clamp(minutes, 1, PR.maxMinutes)
end

function PR.CanJail(target)
	return IsValid(target) and target:IsPlayer() and target:GetCharacterID() != 0 and target:Alive() and
		!NW.zones.IsAlliance(target) and !target:IsImprisoned()
end

local ESCORT_GAP = 70

hook.Add("SetupMove", "nwCuffs", function(client, mv, cmd)
	if (!client:IsCuffed()) then
		return
	end

	mv:SetButtons(bit.band(mv:GetButtons(), bit.bnot(bit.bor(IN_JUMP, IN_SPEED, IN_ATTACK, IN_ATTACK2, IN_USE))))

	local escort = client:GetNW2Entity("nwEscort")

	if (!IsValid(escort)) then
		mv:SetMaxClientSpeed(math.min(mv:GetMaxClientSpeed(), client:GetWalkSpeed() * 0.75))

		return
	end

	mv:SetMaxSpeed(260)
	mv:SetMaxClientSpeed(260)
	mv:SetForwardSpeed(0)
	mv:SetSideSpeed(0)

	local delta = escort:GetPos() - mv:GetOrigin()

	delta.z = 0

	local distance = delta:Length()

	if (distance > ESCORT_GAP) then
		local velocity = delta:GetNormalized() * math.min((distance - ESCORT_GAP) * 4 + 60, 240)

		velocity.z = mv:GetVelocity().z
		mv:SetVelocity(velocity)
	end
end)

if (SERVER) then
	local radius = CreateConVar("nw_prison_radius", "1500", FCVAR_ARCHIVE, "Дальше этого от камер заключённый возвращается")

	local function Notify(client, text)
		NW.Notify(client, text)
	end

	local function Data(client)
		return client.nwCharacter and client.nwCharacter.data
	end

	local POSE = {
		["ValveBiped.Bip01_R_UpperArm"] = Angle(-28, 18, -21),
		["ValveBiped.Bip01_R_Forearm"] = Angle(0, 50, 0),
		["ValveBiped.Bip01_R_Hand"] = Angle(45, 34, -15),
		["ValveBiped.Bip01_L_UpperArm"] = Angle(15, 26, 0),
		["ValveBiped.Bip01_L_Forearm"] = Angle(15, 20, 40),
		["ValveBiped.Bip01_L_Hand"] = Angle(0, 0, 119)
	}

	local function Pose(client, bOn)
		for name, angle in pairs(POSE) do
			local bone = client:LookupBone(name)

			if (bone) then
				client:ManipulateBoneAngles(bone, bOn and angle or angle_zero)
			end
		end
	end

	function PR.Cuff(client, bOn, by)
		client:SetNW2Bool("nwCuffed", bOn)
		client:SetNW2Entity("nwEscort", NULL)
		Pose(client, bOn)

		if (bOn) then
			NW.progress.Cancel(client)

			if (client:HasWeapon("nw_hands")) then
				client:SelectWeapon("nw_hands")
			end
		end

		client:EmitSound(bOn and "weapons/357/357_reload1.wav" or "weapons/357/357_reload3.wav", 60, 120)

		if (IsValid(by)) then
			MsgN(string.format("[PRISON] %s (%s) %s %s", by:Nick(), by:SteamName(), bOn and "надел наручники на" or
				"снял наручники с", client:Nick()))
		end
	end

	function PR.Escort(client, unit)
		client:SetNW2Entity("nwEscort", IsValid(unit) and unit or NULL)
	end

	hook.Add("PlayerSwitchWeapon", "nwCuffs", function(client, _, new)
		if ((client:IsCuffed() or client:IsImprisoned()) and IsValid(new) and new:GetClass() != "nw_hands") then
			return true
		end
	end)

	hook.Add("PlayerUse", "nwCuffs", function(client, entity)
		if (client:IsCuffed()) then
			return false
		end
	end)

	hook.Add("NWInventoryChanged", "nwCuffs", function(client)
		if (client:HasWeapon("nw_handcuffs") and !NW.inventory.Has(client, "handcuffs") and !NW.classes.Grants(client, "nw_handcuffs")) then
			client:StripWeapon("nw_handcuffs")
		end
	end)

	hook.Add("PlayerSpawn", "nwCuffs", function(client)
		if (client:IsCuffed()) then
			PR.Cuff(client, false)
		end
	end)

	timer.Create("nwEscort", 0.5, 0, function()
		for _, client in ipairs(player.GetAll()) do
			local escort = client:GetNW2Entity("nwEscort")

			if (IsValid(escort) and (!escort:Alive() or !client:IsCuffed() or !client:Alive() or
				escort:GetPos():DistToSqr(client:GetPos()) > 400 * 400)) then
				PR.Escort(client, nil)
			end
		end
	end)

	local S = NW.spawns

	local function Points(key)
		return S.list[key] or {}
	end

	local function Nearest(client)
		local best

		for _, point in ipairs(Points("prison")) do
			local distance = client:GetPos():DistToSqr(Vector(point[1], point[2], point[3]))

			best = (!best or distance < best) and distance or best
		end

		return best
	end

	local function ToCell(client)
		local pos, angle = S.Pick(client, "prison")

		if (pos) then
			client:SetPos(pos)
			client:SetEyeAngles(angle)
			client:SetVelocity(-client:GetVelocity())
		end

		return pos != nil
	end

	local function AddPoint(client, key)
		local pos = client:GetPos()

		S.list[key] = S.list[key] or {}

		if (key == "prison_exit") then
			S.list[key] = {}
		end

		table.insert(S.list[key], {math.Round(pos.x, 1), math.Round(pos.y, 1), math.Round(pos.z + 2, 1),
			math.Round(client:EyeAngles().y, 1)})
		S.Save()
	end

	NW.AddChatCommand("prisonadd", {admin = true, run = function(client)
		AddPoint(client, "prison")
		Notify(client, "Камера тюрьмы добавлена (всего " .. #Points("prison") .. ")")
	end})

	NW.AddChatCommand("prisonexit", {admin = true, run = function(client)
		AddPoint(client, "prison_exit")
		Notify(client, "Точка выхода из тюрьмы задана")
	end})

	NW.AddChatCommand("prisonremove", {admin = true, run = function(client)
		local best, bestKey, bestIndex = 128 * 128

		for _, key in ipairs({"prison", "prison_exit"}) do
			for index, point in ipairs(Points(key)) do
				local distance = client:GetPos():DistToSqr(Vector(point[1], point[2], point[3]))

				if (distance < best) then
					best, bestKey, bestIndex = distance, key, index
				end
			end
		end

		if (!bestKey) then
			return Notify(client, "Рядом нет точек тюрьмы")
		end

		table.remove(S.list[bestKey], bestIndex)
		S.Save()
		Notify(client, bestKey == "prison" and "Камера убрана" or "Точка выхода убрана")
	end})

	local function Sync(client)
		local prison = Data(client) and Data(client).prison

		client:SetNW2Float("nwPrisonEnd", prison and (CurTime() + prison.left) or 0)
		client:SetNW2String("nwPrisonCharges", prison and prison.charges or "")
	end

	function PR.Release(client, by)
		local data = Data(client)

		if (!data or !data.prison) then
			return
		end

		data.prison = nil
		NW.char.SaveData(client)
		Sync(client)

		local exit = Points("prison_exit")[1]

		if (exit and client:Alive()) then
			client:SetPos(Vector(exit[1], exit[2], exit[3]))
			client:SetEyeAngles(Angle(0, exit[4] or 0, 0))
		end

		Notify(client, "Срок окончен. Вы свободны")

		if (IsValid(by)) then
			Notify(by, client:Nick() .. " освобождён")
			MsgN(string.format("[PRISON] %s (%s) освободил %s", by:Nick(), by:SteamName(), client:Nick()))
		end
	end

	local RV = "npc/overwatch/radiovoice/"

	local function Announce(unit, target, ids)
		local listeners = {}
		local seen = {}

		local function Add(client)
			if (IsValid(client) and !seen[client]) then
				seen[client] = true
				listeners[#listeners + 1] = client
			end
		end

		Add(unit)
		Add(target)

		for _, client in ipairs(player.GetAll()) do
			if (client:GetPos():DistToSqr(target:GetPos()) < 700 * 700 or
				(client:GetCharacterID() != 0 and NW.zones.IsAlliance(client))) then
				Add(client)
			end
		end

		local voice = {RV .. "on1.wav"}
		local call = NW.dispatcher.Callsign and select(2, NW.dispatcher.Callsign(unit)) or {}

		for index, path in ipairs(call) do
			if (index <= 4) then
				voice[#voice + 1] = path
			end
		end

		voice[#voice + 1] = RV .. "attentionyouhavebeenchargedwith.wav"

		for index, id in ipairs(ids) do
			if (index <= 4) then
				voice[#voice + 1] = RV .. PR.chargeByID[id].word .. ".wav"
			end
		end

		voice[#voice + 1] = RV .. "youarejudgedguilty.wav"
		voice[#voice + 1] = RV .. "off2.wav"

		NW.units.Voice(listeners, voice)

		local length = 0

		for _, path in ipairs(voice) do
			local duration = SoundDuration(path)

			length = length + ((duration and duration > 0.05 and duration < 5) and duration + 0.05 or 0.6)
		end

		return length
	end

	function PR.Jail(unit, target, ids, minutes)
		local data = Data(target)

		if (!data) then
			return false
		end

		if (#Points("prison") == 0) then
			Notify(unit, "Камеры тюрьмы не заданы (администратор: /prisonadd)")

			return false
		end

		local names = {}

		for _, id in ipairs(ids) do
			names[#names + 1] = PR.chargeByID[id].text
		end

		data.prison = {left = minutes * 60, charges = table.concat(names, ", "), by = unit:Nick()}
		NW.char.SaveData(target)

		if (target:IsCuffed()) then
			PR.Cuff(target, false)
		end

		local speech = Announce(unit, target, ids)

		Sync(target)
		NW.progress.Cancel(target)

		if (target:HasWeapon("nw_hands")) then
			target:SelectWeapon("nw_hands")
		end

		target.nwPrisonArrive = CurTime() + math.max(speech + 0.5, 1.5)

		timer.Simple(math.max(speech + 0.5, 1.5), function()
			if (IsValid(target) and target:IsImprisoned()) then
				ToCell(target)
			end
		end)

		Notify(target, "Вы осуждены на " .. minutes .. " мин.: " .. data.prison.charges ..
			". Работа в тюрьме сокращает срок")
		Notify(unit, target:Nick() .. " — " .. minutes .. " мин. заключения")
		MsgN(string.format("[PRISON] %s (%s) посадил %s на %d мин.: %s", unit:Nick(), unit:SteamName(), target:Nick(),
			minutes, data.prison.charges))

		return true
	end

	function PR.Work(client, seconds)
		local data = Data(client)

		if (!data or !data.prison) then
			return
		end

		data.prison.left = data.prison.left - seconds

		if (data.prison.left <= 0) then
			return PR.Release(client)
		end

		Sync(client)
		NW.char.SaveData(client)
		Notify(client, "Срок сокращён на " .. math.Round(seconds) .. " с. Осталось " .. string.FormattedTime(data.prison.left,
			"%02i:%02i"))
	end

	local tick = 0

	timer.Create("nwPrison", 1, 0, function()
		tick = tick + 1

		for _, client in ipairs(player.GetAll()) do
			local data = Data(client)

			if (data and data.prison and client:Alive()) then
				data.prison.left = data.prison.left - 1

				if (data.prison.left <= 0) then
					PR.Release(client)
				else
					local nearest = Nearest(client)

					if (nearest and nearest > radius:GetFloat() ^ 2 and (client.nwPrisonArrive or 0) < CurTime()) then
						ToCell(client)
						Notify(client, "Побег пресечён. Вы возвращены в камеру")
					end

					if (tick % 30 == 0) then
						NW.char.SaveData(client)
						Sync(client)
					end
				end
			end
		end
	end)

	hook.Add("NWCharacterLoaded", "nwPrison", function(client)
		if (client:IsCuffed()) then
			PR.Cuff(client, false)
		end

		Sync(client)
	end)

	hook.Add("PlayerSpawn", "nwPrison", function(client)
		timer.Simple(0.2, function()
			if (IsValid(client) and client:IsImprisoned()) then
				ToCell(client)

				if (client:HasWeapon("nw_hands")) then
					client:SelectWeapon("nw_hands")
				end
			end
		end)
	end)

	NW.AddChatCommand("unjail", {admin = true, run = function(client, rest)
		local target = NW.FindPlayer and NW.FindPlayer(rest)

		if (!IsValid(target)) then
			for _, other in ipairs(player.GetAll()) do
				if (rest != "" and string.find(string.lower(other:Nick()), string.lower(rest), 1, true)) then
					target = other
				end
			end
		end

		if (!IsValid(target) or !target:IsImprisoned()) then
			return Notify(client, "Заключённый не найден")
		end

		PR.Release(target, client)
	end})

	local ACTIONS = NW.cmbTerminalActions

	function ACTIONS.prison_jail(client, terminal, arg)
		local request = util.JSONToTable(arg or "") or {}
		local target = Entity(tonumber(request.target) or 0)

		if (terminal:GetClass() != "nw_cmb_terminal" or !NW.zones.UsesAlliance(client)) then
			return
		end

		if (!PR.CanJail(target) or target:GetPos():DistToSqr(terminal:GetPos()) > PR.reach ^ 2) then
			return Notify(client, "Гражданин должен быть рядом с терминалом")
		end

		local ids, seen = {}, {}

		for _, id in ipairs(istable(request.charges) and request.charges or {}) do
			if (isstring(id) and PR.chargeByID[id] and !seen[id] and #ids < 6) then
				seen[id] = true
				ids[#ids + 1] = id
			end
		end

		if (#ids == 0) then
			return Notify(client, "Выберите статьи")
		end

		PR.Jail(client, target, ids, math.Clamp(math.floor(tonumber(request.minutes) or PR.Term(ids)), 1, PR.maxMinutes))
	end

	function ACTIONS.prison_release(client, terminal, arg)
		local target = Entity(tonumber(arg) or 0)

		if (terminal:GetClass() == "nw_cmb_terminal" and NW.zones.UsesAlliance(client) and IsValid(target) and
			target:IsPlayer() and target:IsImprisoned()) then
			PR.Release(target, client)
		end
	end

	return
end

local CHAIN = Material("cable/cable2")
local STEEL = Color(150, 156, 162)

local function Ring(pos, normal, size)
	local up = normal:Angle():Up()
	local right = normal:Angle():Right()
	local last

	for i = 0, 8 do
		local a = i / 8 * math.pi * 2
		local point = pos + up * math.cos(a) * size + right * math.sin(a) * size

		if (last) then
			render.DrawBeam(last, point, 0.9, 0, 1, STEEL)
		end

		last = point
	end
end

hook.Add("PostPlayerDraw", "nwCuffs", function(client)
	if (!client:IsCuffed() or !client:Alive()) then
		return
	end

	local left = client:LookupBone("ValveBiped.Bip01_L_Hand")
	local right = client:LookupBone("ValveBiped.Bip01_R_Hand")

	if (!left or !right) then
		return
	end

	local lm, rm = client:GetBoneMatrix(left), client:GetBoneMatrix(right)

	if (!lm or !rm) then
		return
	end

	local lp, rp = lm:GetTranslation(), rm:GetTranslation()

	render.SetMaterial(CHAIN)
	Ring(lp, lm:GetForward(), 2)
	Ring(rp, rm:GetForward(), 2)
	render.DrawBeam(lp, rp, 0.6, 0, 1, STEEL)
end)

hook.Add("HUDPaint", "nwPrison", function()
	local client = LocalPlayer()

	if (!IsValid(client) or client:GetCharacterID() == 0) then
		return
	end

	local sw, sh = ScrW(), ScrH()

	if (client:IsImprisoned()) then
		local left = client:GetNW2Float("nwPrisonEnd", 0) - CurTime()
		local charges = client:GetNW2String("nwPrisonCharges", "")

		draw.SimpleTextOutlined("ЗАКЛЮЧЕНИЕ  ·  " .. string.FormattedTime(left, "%02i:%02i"), "nwWidgetBold", sw / 2,
			sh * 0.06, Color(236, 96, 80), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, 200))

		if (charges != "") then
			draw.SimpleTextOutlined(charges, "nwWidget", sw / 2, sh * 0.06 + draw.GetFontHeight("nwWidgetBold"),
				Color(220, 222, 226), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, 200))
		end
	elseif (client:IsCuffed()) then
		draw.SimpleTextOutlined(IsValid(client:GetNW2Entity("nwEscort")) and "ВЫ В НАРУЧНИКАХ  ·  ВАС ВЕДУТ" or
			"ВЫ В НАРУЧНИКАХ", "nwWidgetBold", sw / 2, sh * 0.06, Color(236, 96, 80), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1,
			Color(0, 0, 0, 200))
	end
end)

local CT = NW.cmbTerminal
local CMB = CT.screens.cmb

local function Up(text)
	return NW.terminal.Upper(tostring(text or ""))
end

local selected = {target = nil, charges = {}, minutes = nil}

local function Near()
	local out = {}

	if (!IsValid(CT.entity)) then
		return out
	end

	for _, other in ipairs(player.GetAll()) do
		if (PR.CanJail(other) and other:GetPos():DistToSqr(CT.entity:GetPos()) < PR.reach ^ 2) then
			out[#out + 1] = other
		end
	end

	return out
end

local function Prisoners()
	local out = {}

	for _, other in ipairs(player.GetAll()) do
		if (other:IsImprisoned()) then
			out[#out + 1] = other
		end
	end

	return out
end

local function Chosen()
	local ids = {}

	for _, charge in ipairs(PR.charges) do
		if (selected.charges[charge.id]) then
			ids[#ids + 1] = charge.id
		end
	end

	return ids
end

local function Minutes()
	local ids = Chosen()

	return selected.minutes or (#ids > 0 and PR.Term(ids) or 0)
end

local function Row(scroll, height, Paint, DoClick)
	local row = scroll:Add("DButton")

	row:Dock(TOP)
	row:DockMargin(0, 0, 6, 4)
	row:SetTall(height)
	row:SetText("")
	row.Paint = Paint
	row.DoClick = DoClick or function() end

	return row
end

if (CMB and !CMB.pages.prison) then
	CMB.order[#CMB.order + 1] = {"prison", "Тюрьма"}
end

if (CMB) then
	CMB.pages.prison = {
		title = "Тюрьма",
		subtitle = "Гражданин рядом / статьи / срок / заключённые",
		Build = function(area, w, h)
			local C = CT.colors
			local gap = math.Round(h * 0.025)
			local lw = math.Round(w * 0.4)
			local rx = lw + gap * 2
			local rw = w - rx
			local rowH = math.Round(h * 0.075)

			if (!IsValid(selected.target) or !PR.CanJail(selected.target)) then
				selected.target = nil
			end

			CT.Label(area, "Граждане рядом с терминалом", 0, 0)

			local near = CT.Scroll(area, 0, h * 0.05, lw, h * 0.42)
			local list = Near()

			if (#list == 0) then
				CT.Label(near, "Никого рядом", 0, 0, "nwCmtText", C.dim)
			end

			for _, other in ipairs(list) do
				Row(near, rowH, function(self, rw2, rh)
					if (!IsValid(other)) then
						return
					end

					local on = selected.target == other

					surface.SetDrawColor(C.dark.r, C.dark.g, C.dark.b, 190)
					surface.DrawRect(0, 0, rw2, rh)

					if (on) then
						CT.LitBar(0, 0, 4, rh)
					end

					draw.SimpleText(Up(other:Nick()), "nwCmtText", rh * 0.3, rh / 2, on and C.cyan or C.text, TEXT_ALIGN_LEFT,
						TEXT_ALIGN_CENTER)
					draw.SimpleText(other:IsCuffed() and "В НАРУЧНИКАХ" or (math.Round(other:GetPos():Distance(CT.entity:GetPos()) /
						52.5) .. " М"), "nwCmtSmall", rw2 - rh * 0.3, rh / 2, other:IsCuffed() and C.red or C.dim,
						TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				end, function()
					selected.target = other
					CT.Refresh()
				end)
			end

			CT.Label(area, "Заключённые", 0, h * 0.5)

			local jail = CT.Scroll(area, 0, h * 0.55, lw, h * 0.45)
			local prisoners = Prisoners()

			if (#prisoners == 0) then
				CT.Label(jail, "Камеры пусты", 0, 0, "nwCmtText", C.dim)
			end

			for _, other in ipairs(prisoners) do
				local row = Row(jail, rowH * 1.3, function(self, rw2, rh)
					if (!IsValid(other)) then
						return
					end

					surface.SetDrawColor(C.dark.r, C.dark.g, C.dark.b, 190)
					surface.DrawRect(0, 0, rw2, rh)
					surface.SetDrawColor(C.red)
					surface.DrawRect(0, 0, 3, rh)
					draw.SimpleText(Up(other:Nick()), "nwCmtText", rh * 0.25, rh * 0.32, C.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					draw.SimpleText(string.FormattedTime(math.max(other:GetNW2Float("nwPrisonEnd", 0) - CurTime(), 0), "%02i:%02i"),
						"nwCmtSmall", rh * 0.25, rh * 0.72, C.red, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				end)

				CT.Button(row, "Освободить", lw - 6 - lw * 0.36 - 6, rowH * 1.3 * 0.2, lw * 0.36, rowH * 1.3 * 0.6, function()
					CT.Send("prison_release", other:EntIndex())
					timer.Simple(0.6, CT.Refresh)
				end, false, true)
			end

			CT.Label(area, "Статьи (озвучит диспетчер)", rx, 0)

			local columns = 2
			local bw = (rw - gap) / columns
			local bh = math.Round(h * 0.062)

			for index, charge in ipairs(PR.charges) do
				local column = (index - 1) % columns
				local row = math.floor((index - 1) / columns)
				local button = area:Add("DButton")

				button:SetPos(rx + column * (bw + gap), h * 0.05 + row * (bh + 4))
				button:SetSize(bw, bh)
				button:SetText("")
				button.Paint = function(self, pw, ph)
					local on = selected.charges[charge.id]

					if (on) then
						CT.LitBar(0, 0, pw, ph, self:IsHovered() and 1 or 0.85)
					else
						surface.SetDrawColor(C.dark.r, C.dark.g, C.dark.b, 170)
						surface.DrawRect(0, 0, pw, ph)
						surface.SetDrawColor(C.cyan.r, C.cyan.g, C.cyan.b, self:IsHovered() and 230 or 120)
						surface.DrawOutlinedRect(0, 0, pw, ph, 1)
					end

					draw.SimpleText(Up(charge.text), "nwCmtSmall", ph * 0.25, ph / 2, on and C.dark or C.text, TEXT_ALIGN_LEFT,
						TEXT_ALIGN_CENTER)
					draw.SimpleText(charge.minutes .. " М", "nwCmtSmall", pw - ph * 0.25, ph / 2, on and C.dark or C.dim,
						TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				end
				button.DoClick = function()
					surface.PlaySound("network2/cmbterminal/combine_tech_click_0" .. math.random(1, 5) .. ".wav")
					selected.charges[charge.id] = !selected.charges[charge.id] or nil
					selected.minutes = nil
				end
			end

			local ty = h * 0.05 + math.ceil(#PR.charges / columns) * (bh + 4) + gap
			local term = area:Add("DPanel")

			term:SetPos(rx, ty)
			term:SetSize(rw * 0.5, bh)
			term.Paint = function(_, pw, ph)
				surface.SetDrawColor(C.dark.r, C.dark.g, C.dark.b, 200)
				surface.DrawRect(0, 0, pw, ph)
				draw.SimpleText("СРОК: " .. Minutes() .. " МИН", "nwCmtText", ph * 0.3, ph / 2, C.text, TEXT_ALIGN_LEFT,
					TEXT_ALIGN_CENTER)
			end

			CT.Button(area, "−", rx + rw * 0.5 + gap, ty, bh * 1.4, bh, function()
				selected.minutes = math.max(Minutes() - 1, 1)
			end)
			CT.Button(area, "+", rx + rw * 0.5 + gap * 2 + bh * 1.4, ty, bh * 1.4, bh, function()
				selected.minutes = math.min(math.max(Minutes(), 0) + 1, PR.maxMinutes)
			end)

			local go = CT.Button(area, "Заключить", rx, ty + bh + gap, rw, bh * 1.2, function()
				local ids = Chosen()

				if (!IsValid(selected.target) or #ids == 0) then
					return
				end

				CT.Send("prison_jail", util.TableToJSON({target = selected.target:EntIndex(), charges = ids, minutes = Minutes()}))
				selected = {target = nil, charges = {}, minutes = nil}
				timer.Simple(0.8, CT.Refresh)
			end, true, true)

			go.Think = function(self)
				self:SetEnabled(IsValid(selected.target) and #Chosen() > 0)
			end
		end
	}
end
