NW.taxes = NW.taxes or {}

local TX = NW.taxes

TX.interval = CreateConVar("nw_tax_interval", "30", {FCVAR_ARCHIVE, FCVAR_REPLICATED}, "Как часто берутся налоги (минуты игры персонажа)")
TX.apartment = CreateConVar("nw_tax_apartment", "10", {FCVAR_ARCHIVE, FCVAR_REPLICATED}, "Налог за квартиру за период (токены)")
TX.business = CreateConVar("nw_tax_business", "25", {FCVAR_ARCHIVE, FCVAR_REPLICATED}, "Налог за коммерческое помещение за период")
TX.license = CreateConVar("nw_tax_license", "15", {FCVAR_ARCHIVE, FCVAR_REPLICATED}, "Налог с лицензии на торговлю за период")
TX.debtLimit = CreateConVar("nw_tax_debt_limit", "100", {FCVAR_ARCHIVE, FCVAR_REPLICATED}, "Долг, после которого начисляются очки нарушений")
TX.evict = CreateConVar("nw_tax_evict", "300", {FCVAR_ARCHIVE, FCVAR_REPLICATED}, "Долг, после которого помещения отбираются (0 - никогда)")

if (CLIENT) then
	return
end

local D = NW.doors
local SO = NW.social

local function Data(client)
	local character = client.nwCharacter
	if (!character) then return end
	character.data = character.data or {}
	return character.data
end

function TX.Properties(client)
	local out, seen = {}, {}

	for _, door in ipairs(ents.GetAll()) do
		if (D.IsDoor(door) and !seen[door] and D.IsOwner(client, door)) then
			for _, member in ipairs(D.Group(door)) do seen[member] = true end
			out[#out + 1] = door
		end
	end

	return out
end

function TX.Bill(client)
	local total, lines = 0, {}

	for _, door in ipairs(TX.Properties(client)) do
		local kind = door:GetNW2String("nwDoorKind", "")
		local amount = kind == "business" and TX.business:GetInt() or (kind == "apartment" and TX.apartment:GetInt() or 0)

		if (amount > 0) then
			amount = math.ceil(amount / math.max(1, #D.Tenants(door)))
		end

		if (amount > 0) then
			total = total + amount
			lines[#lines + 1] = door:GetNW2String("nwDoorName", "помещение") .. " " .. amount
		end
	end

	if (NW.business and NW.business.License and NW.business.License(client:GetCharacterID()) and TX.license:GetInt() > 0) then
		total = total + TX.license:GetInt()
		lines[#lines + 1] = "лицензия " .. TX.license:GetInt()
	end

	return total, lines
end

local function BankLog(data, text)
	data.bankLog = istable(data.bankLog) and data.bankLog or {}
	table.insert(data.bankLog, 1, {time = os.date("%H:%M"), text = text, positive = false})
	while (#data.bankLog > 8) do table.remove(data.bankLog) end
end

function TX.Collect(client, debtOnly)
	local data = Data(client)
	if (!data) then return end

	local bill, lines = 0, {}
	if (!debtOnly) then bill, lines = TX.Bill(client) end
	local due = bill + math.max(0, math.floor(tonumber(data.taxDebt) or 0))

	if (due <= 0) then return end

	local bank = math.max(0, math.floor(tonumber(data.bank) or 0))
	local fromBank = math.min(bank, due)

	data.bank = bank - fromBank
	due = due - fromBank

	local tokens = SO.GetTokens(client)
	local fromHand = math.min(tokens, due)

	due = due - fromHand

	local paid = fromBank + fromHand

	data.taxDebt = due
	data.taxPaid = (tonumber(data.taxPaid) or 0) + paid

	if (fromBank > 0) then BankLog(data, "Налоги: −" .. fromBank) end
	if (fromHand > 0) then SO.SetTokens(client, tokens - fromHand) end
	if (paid > 0 and NW.exports and NW.exports.Deposit) then NW.exports.Deposit(paid, "налоги граждан") end

	client:SetNW2Int("nwTaxDebt", due)
	NW.char.SaveData(client)

	if (bill > 0) then
		NW.Notify(client, "Налоги: начислено " .. bill .. " ток. (" .. table.concat(lines, ", ") .. "), оплачено " .. paid ..
			(due > 0 and (", долг " .. due) or ""))
	elseif (paid > 0) then
		NW.Notify(client, "Погашен налоговый долг: " .. paid .. " ток." .. (due > 0 and (", осталось " .. due) or ""))
	end

	MsgN(string.format("[TAXES] %s: bill %d, paid %d, debt %d", client:Nick(), bill, paid, due))

	if (due > TX.debtLimit:GetInt() and (data.taxFlagged or 0) < due and NW.citizens) then
		data.taxFlagged = due
		data.points = data.points or {}
		data.points.violations = math.min(1000000, (tonumber(data.points.violations) or 0) + 5)
		data.points.log = data.points.log or {}
		table.insert(data.points.log, 1, {time = os.date("%d.%m %H:%M"), by = "Налоговая служба", kind = "violations", amount = 5,
			reason = "Неуплата налогов: долг " .. due})
		while (#data.points.log > 25) do table.remove(data.points.log) end
		NW.char.SaveData(client)
		NW.Notify(client, "Налоговый долг превысил " .. TX.debtLimit:GetInt() .. " ток.: ОН +5")
	end

	if (TX.evict:GetInt() > 0 and due > TX.evict:GetInt()) then
		for _, door in ipairs(TX.Properties(client)) do
			if (D.Mode(door) == "terminal") then
				D.RemoveTenant(door, client)
				NW.Notify(client, "За долги вы выселены: " .. door:GetNW2String("nwDoorName", "помещение"))
			end
		end
	end
end

timer.Create("nwTaxes", 60, 0, function()
	local period = math.max(1, TX.interval:GetInt())

	for _, client in ipairs(player.GetAll()) do
		if (client:GetCharacterID() != 0) then
			client.nwTaxMinutes = (client.nwTaxMinutes or 0) + 1

			if (client.nwTaxMinutes >= period) then
				client.nwTaxMinutes = 0
				TX.Collect(client)
			end
		end
	end
end)

hook.Add("NWCharacterLoaded", "nwTaxes", function(client, character)
	client.nwTaxMinutes = 0
	client:SetNW2Int("nwTaxDebt", math.max(0, math.floor(tonumber(character.data and character.data.taxDebt) or 0)))
end)

hook.Add("NWTerminalProfile", "nwTaxes", function(client, extra)
	local data = Data(client) or {}
	local bill = TX.Bill(client)

	extra.taxBill = bill
	extra.taxDebt = math.max(0, math.floor(tonumber(data.taxDebt) or 0))
	extra.taxEvery = TX.interval:GetInt()
end)

NW.AddChatCommand("taxes", {run = function(client)
	local bill, lines = TX.Bill(client)
	local data = Data(client) or {}

	NW.Notify(client, "Налог за период (" .. TX.interval:GetInt() .. " мин): " .. bill .. " ток." ..
		(#lines > 0 and (" — " .. table.concat(lines, ", ")) or "") .. ". Долг: " .. math.floor(tonumber(data.taxDebt) or 0))
end})

NW.AddChatCommand("paytaxes", {run = function(client)
	local data = Data(client)
	if (!data or (tonumber(data.taxDebt) or 0) <= 0) then return NW.Notify(client, "Налогового долга нет") end
	TX.Collect(client, true)
end})
