local FB = NW.fabricator
local S = FB.State
local Lay = FB.Layout
local UI = {}
FB.UI = UI

local function rgb(r, g, b, a) return {r, g, b, a or 255} end
local COL = {
	bg = rgb(7, 38, 50), bg2 = rgb(10, 50, 64), panel = rgb(13, 58, 74), rowbg = rgb(7, 38, 50, 0),
	line = rgb(48, 178, 200), lineDim = rgb(24, 96, 115), bar = rgb(36, 196, 236),
	text = rgb(110, 214, 236), textHi = rgb(150, 232, 248), textDim = rgb(52, 128, 150),
	sel = rgb(78, 206, 232), selText = rgb(4, 32, 44), red = rgb(222, 52, 70), amber = rgb(255, 186, 92),
}
UI.COL = COL

local function A(c, a) return {c[1], c[2], c[3], a} end

local function wrap(D, str, font, x, y, w, color, lh)
	local line = ""
	for word in string.gmatch(str, "%S+") do
		local cand = line == "" and word or (line .. " " .. word)
		if (D.size(cand, font) > w and line != "") then
			D.text(line, font, x, y, color)
			y = y + lh
			line = word
		else
			line = cand
		end
	end
	if (line != "") then D.text(line, font, x, y, color) y = y + lh end
	return y
end

local function glyph(D, x, y, s, color)
	D.outline(x, y, s, s, color, 2)
	D.poly({{x + s * 0.25, y + s * 0.72}, {x + s * 0.5, y + s * 0.28}, {x + s * 0.75, y + s * 0.72}}, color)
	D.rect(x + s * 0.45, y + s * 0.15, s * 0.1, s * 0.12, color)
end

local function chevron(D, x, y, s, color)
	D.poly({{x, y}, {x + s * 0.32, y}, {x + s * 0.82, y + s * 0.5}, {x + s * 0.32, y + s}, {x, y + s}, {x + s * 0.5, y + s * 0.5}}, color)
end

local function warn(D, x, y, s, color)
	D.poly({{x + s * 0.5, y}, {x + s, y + s * 0.9}, {x, y + s * 0.9}}, color)
	D.rect(x + s * 0.45, y + s * 0.3, s * 0.1, s * 0.32, COL.bg)
	D.rect(x + s * 0.45, y + s * 0.7, s * 0.1, s * 0.1, COL.bg)
end

local BARS = {}
do
	local seed = 7
	local x = 0
	while (x < 210) do
		seed = (seed * 1103515245 + 12345) % 2147483648
		local w = 1 + seed % 4
		local gap = 2 + math.floor(seed / 7) % 5
		BARS[#BARS + 1] = {x, w, 18 + math.floor(seed / 13) % 14}
		x = x + w + gap
	end
end

local function fit(D, str, fonts, w)
	for _, font in ipairs(fonts) do
		if (D.size(str, font) <= w) then return font end
	end
	return fonts[#fonts]
end

local function frame(D, ctx, title)
	local W, H = Lay.W, Lay.H
	D.rect(0, 0, W, H, COL.bg)
	for y = 0, H, 3 do D.rect(0, y, W, 1, A(COL.bg2, 120)) end
	D.rect(0, (ctx.t * 40) % H, W, 2, A(COL.line, 14))
	D.rect(6, 0, 12, 424, COL.bar)
	D.rect(6, 436, 12, H - 436, COL.bar)
	D.text(title, fit(D, title, {"nwFabHdr", "nwFabS"}, 620), 38, 10, COL.textHi)
	D.text("СТАНЦИЯ КОМПЛЕКТОВАНИЯ 6.3.5.333", "nwFabXxs", W - 74, 18, COL.textDim, 2)
	glyph(D, W - 58, 9, 26, COL.line)
	D.rect(38, 44, W - 60, 1, COL.lineDim)
	D.rect(28, Lay.BOTTOM, W - 50, 2, COL.lineDim)
	if (D.barcode) then
		D.barcode(40, Lay.BOTTOM + 10, 210, 38, {255, 255, 255, 230})
	else
		for _, b in ipairs(BARS) do D.rect(40 + b[1], Lay.BOTTOM + 12 + (32 - b[3]), b[2], b[3], A(COL.lineDim, 230)) end
	end
	D.text("ПРИЛОЖЕНИЕ ПО ГРАЖДАНСКОЙ ОБОРОНЕ 6-3-5", "nwFabXxs", 40, Lay.BOTTOM + 50, A(COL.textDim, 200))
	local num = tostring(ctx.resin or 0)
	local nw = D.size(num, "nwFabNum")
	D.text("СМОЛА В РЕЗЕРВУАРЕ:", "nwFabS", 552, Lay.BOTTOM + 30, COL.text, 2)
	D.text(num, "nwFabNum", 560, Lay.BOTTOM + 6, COL.textHi)
	D.rect(360, Lay.BOTTOM + 50, 200 + nw + 8, 2, COL.text)
	D.line(560 + nw + 24, Lay.BOTTOM + 46, W - 24, Lay.BOTTOM + 8, COL.lineDim)
	D.text("БЛОКОВ У ВАС: " .. (ctx.blocks or 0), "nwFabXs", W - 34, Lay.BOTTOM + 52, COL.textDim, 2)
end

local function summary(D, entry, y0, head)
	local Sx = Lay.SUMMARY
	D.text(head or "ОПИСАНИЕ", "nwFabXs", Sx.x, Sx.y - 2, COL.textDim)
	if (!entry) then return end
	local y = wrap(D, FB.Upper(entry.name), "nwFabM", Sx.x, (y0 or Sx.y) + 18, Sx.w, COL.textHi, 24)
	wrap(D, entry.text or "", "nwFabS", Sx.x, y + 6, Sx.w, COL.text, 22)
end

local function button(D, b, label, hover)
	if (hover) then
		D.rect(b.x, b.y, b.w, b.h, COL.sel)
		D.text(label, "nwFabM", b.x + b.w / 2, b.y + b.h / 2, COL.selText, 1, 1)
	else
		D.rect(b.x, b.y, b.w, b.h, COL.rowbg)
		D.outline(b.x, b.y, b.w, b.h, COL.line, 2)
		D.text(label, "nwFabM", b.x + b.w / 2, b.y + b.h / 2, COL.textHi, 1, 1)
	end
end

local function isHover(ctx, id, arg)
	local h = ctx.hover
	return h and h.id == id and (arg == nil or h.arg == arg)
end

function UI.Exit(D, ctx)
	local E = Lay.EXIT
	button(D, {x = E.x, y = E.y, w = E.w, h = E.h}, "ОТОЙТИ", isHover(ctx, "exit"))
end

local function locked(ctx, entry)
	return entry.only and IsValid(ctx.viewer) and ctx.viewer:GetFaction() != entry.only
end

function UI.Menu(D, ctx)
	local cat = FB.TabCat(ctx.tab)
	local section = FB.sections[cat]
	frame(D, ctx, FB.Upper(section and section.name or ""))
	D.text("ПРЕДМЕТЫ", "nwFabXs", 52, 58, COL.textDim)
	D.text("СТОИМОСТЬ", "nwFabXs", 626, 58, COL.textDim, 2)
	local shown
	local buttons = Lay.Buttons(S.MENU, ctx.tab)
	if (buttons.pageText) then D.text("СТР. " .. buttons.pageText, "nwFabXs", 340, 58, COL.textDim, 1) end
	local budget = (ctx.resin or 0) + (ctx.blocks or 0) * FB.resinValue
	for _, b in ipairs(buttons) do
		if (b.id == "page") then
			local over = isHover(ctx, "page", b.arg)
			D.rect(b.x, b.y, b.w, b.h, over and COL.sel or COL.rowbg)
			D.outline(b.x, b.y, b.w, b.h, COL.line, 2)
			D.text(b.label, "nwFabRow", b.x + b.w / 2, b.y + b.h / 2, over and COL.selText or COL.textHi, 1, 1)
		elseif (b.id == "select") then
			local entry = FB.catalog[b.arg]
			local over = isHover(ctx, "select", b.arg)
			if (over) then shown = entry end
			local poor = budget < entry.cost or locked(ctx, entry)
			if (over) then
				D.rect(b.x, b.y, b.w, b.h, COL.sel)
			else
				D.rect(b.x, b.y, b.w, b.h, COL.rowbg)
				D.outline(b.x, b.y, b.w, b.h, COL.line, 2)
			end
			local tc = over and COL.selText or (locked(ctx, entry) and COL.textDim or COL.textHi)
			D.text(FB.Upper(entry.name), "nwFabRow", b.x + 18, b.y + b.h / 2, tc, 0, 1)
			local cost = tostring(entry.cost)
			D.text(cost, "nwFabRow", b.x + b.w - 16, b.y + b.h / 2, over and COL.selText or COL.text, 2, 1)
			if (poor) then
				local cw = D.size(cost, "nwFabRow")
				warn(D, b.x + b.w - 16 - cw - 30, b.y + b.h / 2 - 11, 22, over and COL.selText or COL.red)
			end
		elseif (b.id == "tab") then
			local on = cat == b.arg
			local over = isHover(ctx, "tab", b.arg)
			local label = FB.Upper(FB.sections[b.arg].name)
			D.rect(b.x, b.y, b.w, b.h, (on or over) and COL.panel or COL.bg)
			D.outline(b.x, b.y, b.w, b.h, on and COL.bar or COL.lineDim, on and 2 or 1)
			if (on) then D.rect(b.x, b.y + b.h - 4, b.w, 4, COL.bar) end
			D.text(label, fit(D, label, {"nwFabS", "nwFabXs", "nwFabXxs"}, b.w - 8), b.x + b.w / 2, b.y + b.h / 2 - 1,
				(on or over) and COL.textHi or COL.text, 1, 1)
		end
	end
	summary(D, shown)
	if (!shown) then
		D.text("НАВЕДИТЕ НА ПОЗИЦИЮ", "nwFabS", Lay.SUMMARY.x, Lay.SUMMARY.y + 20, COL.textDim)
		D.text("И НАЖМИТЕ ЛКМ", "nwFabS", Lay.SUMMARY.x, Lay.SUMMARY.y + 42, COL.textDim)
		if (section) then wrap(D, section.text, "nwFabXs", Lay.SUMMARY.x, Lay.SUMMARY.y + 80, Lay.SUMMARY.w, COL.textDim, 18) end
	end
	UI.Exit(D, ctx)
end

local function panel(D)
	local P = Lay.PANEL
	D.rect(P.x, P.y, P.w, P.h, COL.panel)
	D.rect(P.x, P.y, P.w, 6, COL.bar)
end

local function cells(D, cx, ctx)
	local bx, by, bw, bh = cx - 250, 214, 500, 30
	D.outline(bx, by, bw, bh, COL.line, 2)
	local f = (ctx.cost or 0) > 0 and math.min(1, (ctx.paid or 0) / ctx.cost) or 0
	if (f > 0) then D.rect(bx + 4, by + 4, (bw - 8) * f, bh - 8, COL.bar) end
	local filled = math.floor(f * 10 + 0.001)
	for i = 1, 10 do
		local x = cx - 5 * 34 + (i - 1) * 34 + 6
		local on = i <= filled
		D.outline(x, 268, 22, 22, on and COL.bar or COL.lineDim, 2)
		if (on) then D.rect(x + 5, 273, 12, 12, COL.bar) end
	end
end

function UI.Deposit(D, ctx)
	local entry = FB.catalog[ctx.sel]
	frame(D, ctx, FB.Upper(entry and entry.name or ""))
	panel(D)
	local P = Lay.PANEL
	local cx = P.x + P.w / 2
	D.text(string.format("%02d/%02d", ctx.paid or 0, ctx.cost or 0), "nwFabL", cx, 132, COL.textHi, 1, 1)
	D.text("ВСТАВЬТЕ БЛОКИ СМОЛЫ", "nwFabL", cx, 172, COL.textHi, 1, 1)
	cells(D, cx, ctx)
	D.text("ОТОЙДИТЕ ОТ ЭКРАНА • УДЕРЖИВАЙТЕ E У ЯЧЕЕК • БЛОК = " .. FB.resinValue, "nwFabXs", cx, 312, COL.textDim, 1, 1)
	D.rect(176, 382, 6, 6, COL.red)
	D.rect(190, 382, 6, 6, COL.red)
	button(D, Lay.Buttons(S.DEPOSIT)[1], "ОТМЕНА", isHover(ctx, "cancel"))
	UI.Exit(D, ctx)
	summary(D, entry)
end

function UI.Refill(D, ctx)
	frame(D, ctx, "ЗАГРУЗКА СМОЛЫ")
	panel(D)
	local P = Lay.PANEL
	local cx = P.x + P.w / 2
	D.text(string.format("%d/%d", ctx.paid or 0, ctx.cost or 0), "nwFabL", cx, 132, COL.textHi, 1, 1)
	D.text("ПОПОЛНЕНИЕ РЕЗЕРВУАРА", "nwFabL", cx, 172, COL.textHi, 1, 1)
	cells(D, cx, ctx)
	D.text("УДЕРЖИВАЙТЕ E У ЯЧЕЕК • БЛОК = " .. FB.resinValue .. " СМОЛЫ", "nwFabXs", cx, 312, COL.textDim, 1, 1)
	UI.Exit(D, ctx)
	local Sx = Lay.SUMMARY
	D.text("ОПИСАНИЕ", "nwFabXs", Sx.x, Sx.y - 2, COL.textDim)
	wrap(D, "Смола из блоков идёт в общий резервуар фабрикатора. Из него оплачиваются заказы Альянса.", "nwFabS", Sx.x, Sx.y + 18, Sx.w, COL.text, 22)
end

function UI.Print(D, ctx)
	local entry = FB.catalog[ctx.sel]
	frame(D, ctx, FB.Upper(entry and entry.name or ""))
	panel(D)
	local P = Lay.PANEL
	local cx = P.x + P.w / 2
	local f = ctx.printFrac or 0
	D.text("ФАБРИКАЦИЯ", "nwFabL", cx, 140, COL.textHi, 1, 1)
	local n = 30
	for i = 1, n do
		local on = i / n <= f
		D.rect(cx - 255 + (i - 1) * 17, 190, 12, 34, on and COL.bar or A(COL.lineDim, 160))
	end
	D.text(math.floor(f * 100) .. "%", "nwFabNum", cx, 262, COL.textHi, 1, 1)
	local phase = f < 0.01 and "ПОДГОТОВКА КАМЕРЫ" or (f >= 1 and "КОНТРОЛЬ КАЧЕСТВА" or "СИНТЕЗ МАТЕРИАЛА")
	D.text(phase, "nwFabXs", cx, 310, COL.textDim, 1, 1)
	summary(D, entry)
end

function UI.Done(D, ctx)
	local entry = FB.catalog[ctx.sel]
	frame(D, ctx, FB.Upper(entry and entry.name or ""))
	local P = Lay.PANEL
	D.rect(P.x + 20, P.y - 20, P.w - 20, 210, COL.panel)
	D.rect(P.x + 20, P.y - 20, P.w - 20, 5, COL.bar)
	local cx = P.x + 20 + (P.w - 20) / 2
	D.text("ФАБРИКАЦИЯ ЗАВЕРШЕНА", "nwFabM", cx, P.y + 18, COL.text, 1, 1)
	D.text("ВОЗЬМИТЕ", "nwFabBig", cx, P.y + 72, COL.text, 1, 1)
	D.text("ПРЕДМЕТ", "nwFabBig", cx, P.y + 134, COL.text, 1, 1)
	summary(D, entry, nil, "ГОТОВО К ВЫДАЧЕ")
	for i = 0, 2 do chevron(D, cx - 40 + i * 30, 320, 36, A(COL.bar, 110 + 100 * math.sin(ctx.t * 3 - i))) end
	D.text("E — ЗАБРАТЬ ИЗ КАМЕРЫ", "nwFabS", cx, 378, COL.textHi, 1, 1)
end

function UI.Boot(D, ctx)
	frame(D, ctx, "ФАБРИКАТОР")
	local f = ctx.boot or 0
	glyph(D, Lay.W / 2 - 40, 130, 80, A(COL.line, 255 * f))
	D.text("ИНИЦИАЛИЗАЦИЯ", "nwFabM", Lay.W / 2, 250, COL.text, 1, 1)
	D.outline(Lay.W / 2 - 200, 280, 400, 12, COL.lineDim, 1)
	D.rect(Lay.W / 2 - 198, 282, 396 * f, 8, COL.bar)
end

function UI.Busy(D, ctx)
	D.rect(24, 60, Lay.W - 48, 370, A(COL.bg, 240))
	D.outline(24, 60, Lay.W - 48, 370, COL.line, 2)
	D.text("ТЕРМИНАЛ ЗАНЯТ", "nwFabL", Lay.W / 2, 210, COL.textHi, 1, 1)
	D.text(ctx.busy or "", "nwFabM", Lay.W / 2, 252, COL.text, 1, 1)
end

function UI.Draw(D, ctx)
	if (ctx.boot and ctx.boot < 1) then
		UI.Boot(D, ctx)
	elseif (ctx.stage == S.DEPOSIT) then UI.Deposit(D, ctx)
	elseif (ctx.stage == S.REFILL) then UI.Refill(D, ctx)
	elseif (ctx.stage == S.PRINT) then UI.Print(D, ctx)
	elseif (ctx.stage == S.DONE) then UI.Done(D, ctx)
	else UI.Menu(D, ctx) end
	if (ctx.busy) then UI.Busy(D, ctx) end
	if (ctx.status and ctx.status != "") then
		D.rect(38, 400, 610, 32, A(rgb(60, 36, 20), 245))
		D.text(ctx.status, "nwFabS", 343, 416, COL.amber, 1, 1)
	end
	if (ctx.cursor and !ctx.busy) then
		local x, y = ctx.cursor[1], ctx.cursor[2]
		D.rect(x - 9, y - 1, 6, 2, COL.textHi) D.rect(x + 3, y - 1, 6, 2, COL.textHi)
		D.rect(x - 1, y - 9, 2, 6, COL.textHi) D.rect(x - 1, y + 3, 2, 6, COL.textHi)
	end
end

local MON = {}
FB.Monitor = MON

MON.W, MON.H = 1024, 512
MON.JitterSpeed, MON.VSyncJump, MON.Grain = 0.6, 0.04, 0.12
MON.Shift = {0.12, 0.0, -0.12}
MON.ScanTiling, MON.ScanScroll = 128, 0.0
MON.Tint, MON.Vignette = {0.95, 1.0, 1.0}, 0.4

local monitorFX = CreateClientConVar("nw_fab_monitor_fx", "1", true, false, "Эффект монитора HL:A на экране фабрикатора")

function MON.Available()
	if (MON.ok == nil) then MON.ok = file.Exists("shaders/fxc/hla_monitor_ps30.vcs", "GAME") end
	return MON.ok and monitorFX:GetBool()
end

local rtUI, rtFX, matFX, matOut

local function setup()
	if (matOut) then return end
	local flags = bit.bor(4, 8, 16, 256)
	rtUI = GetRenderTargetEx("nw_fab_monitor_ui", MON.W, MON.H, RT_SIZE_NO_CHANGE, MATERIAL_RT_DEPTH_NONE, flags, 0, IMAGE_FORMAT_RGBA8888)
	rtFX = GetRenderTargetEx("nw_fab_monitor_fx", MON.W, MON.H, RT_SIZE_NO_CHANGE, MATERIAL_RT_DEPTH_NONE, flags, 0, IMAGE_FORMAT_RGBA8888)
	matFX = CreateMaterial("nw_fab_monitor_pass", "screenspace_general", {
		["$pixshader"] = "hla_monitor_ps30",
		["$basetexture"] = rtUI:GetName(),
		["$texture1"] = "hla/monitor/scanlines",
		["$texture2"] = "hla/monitor/grain",
		["$texture3"] = "hla/monitor/jitter",
		["$ignorez"] = 1, ["$vertextransform"] = 1, ["$vertexcolor"] = 0,
		["$alpha_blend"] = 0, ["$alpha_blend_color_overlay"] = 0, ["$copyalpha"] = 0,
		["$linearread_basetexture"] = 0, ["$linearread_texture1"] = 1, ["$linearread_texture2"] = 1,
		["$linearread_texture3"] = 1, ["$linearwrite"] = 0,
	})
	matOut = CreateMaterial("nw_fab_monitor_out", "UnlitGeneric", {["$basetexture"] = rtFX:GetName(), ["$translucent"] = 0})
end

function MON.Draw(pos, ang, scale, paint)
	if (!MON.Available()) then return false end
	setup()
	render.PushRenderTarget(rtUI)
		render.Clear(0, 0, 0, 255, true, true)
		cam.Start2D()
			paint()
		cam.End2D()
	render.PopRenderTarget()
	local t = CurTime()
	local slot = math.floor(t * 2)
	local rnd = (math.sin(slot * 12.9898) * 43758.5453) % 1
	local burst = rnd > 0.93 and 2.5 or 1
	matFX:SetFloat("$c0_x", t)
	matFX:SetFloat("$c0_y", MON.JitterSpeed)
	matFX:SetFloat("$c0_z", MON.VSyncJump)
	matFX:SetFloat("$c0_w", MON.Grain)
	matFX:SetFloat("$c1_x", MON.Shift[1] * burst)
	matFX:SetFloat("$c1_y", MON.Shift[2])
	matFX:SetFloat("$c1_z", MON.Shift[3] * burst)
	matFX:SetFloat("$c1_w", MON.ScanTiling)
	matFX:SetFloat("$c2_x", MON.Tint[1]) matFX:SetFloat("$c2_y", MON.Tint[2]) matFX:SetFloat("$c2_z", MON.Tint[3])
	matFX:SetFloat("$c2_w", MON.Vignette)
	matFX:SetFloat("$c3_x", MON.ScanScroll)
	matFX:SetFloat("$c3_y", 0)
	matFX:SetFloat("$c3_z", 0.75 + 0.25 * math.sin(t * 13) * math.sin(t * 3.7))
	render.PushRenderTarget(rtFX)
		render.SetMaterial(matFX)
		render.DrawScreenQuad()
	render.PopRenderTarget()
	cam.Start3D2D(pos, ang, scale)
		surface.SetMaterial(matOut)
		surface.SetDrawColor(255, 255, 255, 255)
		surface.DrawTexturedRect(0, 0, MON.W, MON.H)
	cam.End3D2D()
	return true
end

local F = {cursor = {512, 256}, blend = 0}
FB.FocusState = F

function FB.FocusEnt()
	local e = F.ent
	if (IsValid(e)) then return e end
end

function FB.FocusCursor(e)
	if (F.ent == e and IsValid(e)) then return F.cursor end
end

net.Receive("nwFabFocus", function()
	local e = net.ReadEntity()
	if (IsValid(e)) then
		if (!IsValid(F.ent)) then F.cursor = {Lay.W * 0.5, Lay.H * 0.45} end
		F.ent = e
	else
		if (IsValid(F.ent)) then F.holdFire = true end
		F.ent = nil
	end
end)

hook.Add("InputMouseApply", "nwFabFocus", function(cmd, x, y)
	if (!FB.FocusEnt()) then return end
	local k = 0.55 * (GetConVarNumber("sensitivity") / 3)
	F.cursor[1] = math.Clamp(F.cursor[1] + x * k, 0, Lay.W)
	F.cursor[2] = math.Clamp(F.cursor[2] + y * k, 0, Lay.H)
	cmd:SetMouseX(0)
	cmd:SetMouseY(0)
	return true
end)

local wasDown = false

hook.Add("CreateMove", "nwFabFocus", function(cmd)
	local e = FB.FocusEnt()
	if (!e) then
		wasDown = false
		if (F.holdFire) then
			if (bit.band(cmd:GetButtons(), bit.bor(IN_ATTACK, IN_ATTACK2)) != 0) then
				cmd:SetButtons(bit.band(cmd:GetButtons(), bit.bnot(bit.bor(IN_ATTACK, IN_ATTACK2))))
			else
				F.holdFire = nil
			end
		end
		return
	end
	local down = bit.band(cmd:GetButtons(), IN_ATTACK) != 0
	if (down and !wasDown) then
		net.Start("nwFabPress")
		net.WriteFloat(F.cursor[1])
		net.WriteFloat(F.cursor[2])
		net.SendToServer()
	end
	wasDown = down
	cmd:ClearMovement()
	cmd:SetButtons(bit.band(cmd:GetButtons(), IN_USE))
end)

local function target(e, eye)
	local origin, right, down, normal, _, scale = FB.ScreenWorld(e)
	if (!origin) then return eye, (e:GetPos() - eye):Angle() end
	local W, H = Lay.W * scale, Lay.H * scale
	local center = origin + right * (W * 0.5) + down * (H * 0.5)
	local u = F.cursor[1] / Lay.W - 0.5
	local v = F.cursor[2] / Lay.H - 0.5
	local look, pos
	if (e:GetStage() == S.PRINT) then
		local item = FB.ItemPoint(e)
		look = item
		pos = item + e:GetForward() * 30 + e:GetUp() * 16 - e:GetRight() * 8
	else
		look = center
		pos = look + normal * 27 + right * (u * 4.5) + down * (v * 3.2)
		look = look + right * (u * W * 0.22) + down * (v * H * 0.22)
	end
	return pos, (look - pos):Angle()
end

local last

hook.Add("CalcView", "nwFabFocus", function(p, origin, angles, fov)
	local e = FB.FocusEnt()
	local dt = FrameTime()
	F.blend = math.Clamp(F.blend + (e and dt or -dt) * 2.8, 0, 1)
	if (e) then F.lastEnt = e end
	local src = e or F.lastEnt
	if (F.blend <= 0 or !IsValid(src)) then last = nil return end
	local pos, ang = target(src, origin)
	if (last) then
		local k = math.min(dt * 7, 1)
		pos = LerpVector(k, last.pos, pos)
		ang = LerpAngle(k, last.ang, ang)
	end
	last = {pos = pos, ang = ang}
	local b = FB.Smooth(F.blend)
	return {origin = LerpVector(b, origin, pos), angles = LerpAngle(b, angles, ang), fov = Lerp(b, fov, 62), drawviewer = false}
end)

hook.Add("HUDShouldDraw", "nwFabFocus", function(name)
	if (F.blend > 0 and name != "CHudChat") then return false end
end)

hook.Add("PreDrawViewModel", "nwFabFocus", function()
	if (F.blend > 0) then return true end
end)

hook.Add("PlayerBindPress", "nwFabFocusReq", function(client, bind, pressed)
	if (!pressed or !string.find(bind, "+use", 1, true) or FB.FocusEnt()) then return end

	for _, e in ipairs(ents.FindByClass("nw_fabricator")) do
		if (e:GetStage() == S.MENU and FB.HitScreen(e, client)) then
			net.Start("nwFabFocusReq")
				net.WriteEntity(e)
			net.SendToServer()
			return
		end
	end
end)

local lastHover

hook.Add("Think", "nwFabFocusHover", function()
	local e = FB.FocusEnt()
	if (!e) then lastHover = nil return end
	local b = Lay.ButtonAt(e:GetStage(), e:GetTab(), F.cursor[1], F.cursor[2])
	local key = b and (b.id .. (b.arg or "")) or nil
	if (key and key != lastHover) then
		surface.PlaySound(FB.ClickSounds[math.random(3, 4)])
	end
	lastHover = key
end)
