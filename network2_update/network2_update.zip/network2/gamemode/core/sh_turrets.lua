NW.turrets = NW.turrets or {}

local TU = NW.turrets

TU.classes = {npc_turret_ceiling = "Потолочная турель", npc_turret_floor = "Напольная турель"}

if (SERVER) then
	util.AddNetworkString("nwTurrets")

	function TU.List()
		local out = {}

		for class in pairs(TU.classes) do
			for _, entity in ipairs(ents.FindByClass(class)) do
				out[#out + 1] = entity
			end
		end

		table.sort(out, function(a, b) return a:EntIndex() < b:EntIndex() end)

		return out
	end

	function TU.IsOn(entity)
		return entity:GetNW2Bool("nwTurretOff", false) == false
	end

	function TU.Set(entity, on)
		if (!IsValid(entity) or !TU.classes[entity:GetClass()]) then return end

		entity:Fire(on and "Enable" or "Disable")
		entity:SetNW2Bool("nwTurretOff", !on)
		entity:EmitSound(on and "buttons/combine_button1.wav" or "buttons/combine_button2.wav", 65)
	end

	function TU.Info()
		local out = {}

		for _, entity in ipairs(TU.List()) do
			local zone = NW.zones.At(entity:GetPos())

			out[#out + 1] = {id = entity:EntIndex(), kind = TU.classes[entity:GetClass()], on = TU.IsOn(entity),
				zone = zone and zone.name or "", hp = entity:Health()}
		end

		return out
	end

	local function Send(client)
		net.Start("nwTurrets")
			net.WriteString(util.TableToJSON(TU.Info()))
		net.Send(client)
	end

	local ACTIONS = NW.cmbTerminalActions

	function ACTIONS.turret_list(client, terminal)
		if (terminal:GetClass() != "nw_cmb_terminal" or !NW.zones.UsesAlliance(client)) then return end
		Send(client)
	end

	function ACTIONS.turret_toggle(client, terminal, arg)
		if (terminal:GetClass() != "nw_cmb_terminal" or !NW.zones.UsesAlliance(client)) then return end

		local request = util.JSONToTable(arg or "") or {}

		if (request.all) then
			for _, entity in ipairs(TU.List()) do TU.Set(entity, request.on == true) end
			MsgN(string.format("[TURRETS] %s: все турели %s", client:Nick(), request.on and "включены" or "сложены"))
		else
			local entity = Entity(tonumber(request.id) or 0)

			if (IsValid(entity) and TU.classes[entity:GetClass()]) then
				TU.Set(entity, request.on == true)
				MsgN(string.format("[TURRETS] %s: турель %d %s", client:Nick(), entity:EntIndex(), request.on and "включена" or "сложена"))
			end
		end

		Send(client)
	end

	hook.Add("PlayerUse", "nwTurretToggle", function(client, entity)
		if (!IsValid(entity) or entity:GetClass() != "npc_turret_ceiling" or !client:KeyDown(IN_WALK) or
			!NW.zones.UsesAlliance(client) or (client.nwTurretNext or 0) > CurTime()) then return end

		client.nwTurretNext = CurTime() + 1
		TU.Set(entity, !TU.IsOn(entity))
		NW.Notify(client, TU.IsOn(entity) and "Турель развёрнута" or "Турель сложена")

		return false
	end)

	return
end

local CT = NW.cmbTerminal
local CMB = CT and CT.screens.cmb

net.Receive("nwTurrets", function()
	TU.info = util.JSONToTable(net.ReadString() or "") or {}

	if (CT and CT.page == "turrets") then
		CT.Refresh()
	end
end)

if (CMB and !CMB.pages.turrets) then
	table.insert(CMB.order, {"turrets", "Турели"})
end

if (CMB) then
	CMB.pages.turrets = {
		title = "Турели",
		subtitle = "Состояние турелей Альянса: развернуть или сложить",
		Build = function(area, w, h)
			local C = CT.colors
			local gap = math.Round(h * 0.025)
			local fh = math.Round(h * 0.075)

			if (!TU.askedAt or RealTime() - TU.askedAt > 2) then
				TU.askedAt = RealTime()
				CT.Send("turret_list", "")
			end

			CT.Button(area, "Развернуть все", 0, 0, w * 0.3, fh, function()
				CT.Send("turret_toggle", util.TableToJSON({all = true, on = true}))
			end, true)
			CT.Button(area, "Сложить все", w * 0.3 + gap, 0, w * 0.3, fh, function()
				CT.Send("turret_toggle", util.TableToJSON({all = true, on = false}))
			end, false, true)
			CT.Button(area, "Обновить", w * 0.6 + gap * 2, 0, w * 0.2, fh, function()
				CT.Send("turret_list", "")
			end)

			local scroll = CT.Scroll(area, 0, fh + gap, w, h - fh - gap)
			local list = TU.info or {}

			if (#list == 0) then
				CT.Label(scroll, "Турелей на карте нет", 0, 0, "nwCmtText", C.dim)
				return
			end

			for _, turret in ipairs(list) do
				local row = scroll:Add("DPanel")
				local rh = math.Round(h * 0.09)

				row:Dock(TOP)
				row:DockMargin(0, 0, 8, 4)
				row:SetTall(rh)
				row.Paint = function(_, rw, rhh)
					surface.SetDrawColor(C.dark.r, C.dark.g, C.dark.b, 170)
					surface.DrawRect(0, 0, rw, rhh)
					surface.SetDrawColor(turret.on and C.cyan or C.red)
					surface.DrawRect(0, 0, 3, rhh)
					draw.SimpleText(NW.terminal.Upper(turret.kind) .. "  #" .. turret.id, "nwCmtText", rhh * 0.3, rhh * 0.32, C.text,
						TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					draw.SimpleText((turret.zone != "" and NW.terminal.Upper(turret.zone) or "ВНЕ ЗОН") .. "  ·  " ..
						(turret.on and "РАЗВЁРНУТА" or "СЛОЖЕНА"), "nwCmtSmall", rhh * 0.3, rhh * 0.72,
						turret.on and C.dim or C.red, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				end

				CT.Button(row, turret.on and "Сложить" or "Развернуть", w * 0.7, rh * 0.18, w * 0.25, rh * 0.64, function()
					CT.Send("turret_toggle", util.TableToJSON({id = turret.id, on = !turret.on}))
				end, !turret.on, turret.on)
			end
		end
	}
end
