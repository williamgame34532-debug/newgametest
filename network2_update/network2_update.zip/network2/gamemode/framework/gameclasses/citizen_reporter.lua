CLASS.faction = "citizen"
CLASS.name = "Репортёр"
CLASS.description = "Пишет городские новости и объявления. Получает переносной принтер: печатает листовки пачкой и вешает их на доски объявлений."
CLASS.color = Color(196, 214, 120)
CLASS.items = {"printer_kit", "paper", "paper"}
CLASS.limit = 2
