CLASS.faction = "cwu"
CLASS.name = "Разнорабочий ГСР"
CLASS.description = "Берётся за любую работу союза: ремонт, дезинфекция, завод, доставка заказов."
CLASS.color = Color(214, 164, 92)
CLASS.default = true
CLASS.jobs = {"all"}
