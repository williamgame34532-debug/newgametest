CLASS.faction = "cwu"
CLASS.name = "Инженер ГСР"
CLASS.description = "Ремонт трубопроводов, электрощитов и панелей Альянса. Носит свой набор инструментов. Работа: только ремонт поломок."
CLASS.color = Color(232, 170, 64)
CLASS.items = {"toolkit"}
CLASS.jobs = {"repair"}
