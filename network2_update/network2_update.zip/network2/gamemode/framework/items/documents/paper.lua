ITEM.name = "Лист бумаги"
ITEM.description = "Лист бумаги. Чистый можно исписать (использовать), исписанный — прочитать или повесить на доску объявлений."
ITEM.model = "models/props_c17/paper01.mdl"
ITEM.category = "misc"
ITEM.useVerb = "читать / писать"
ITEM.price = 1
ITEM.wall = true

function ITEM.OnUse(client, cell)
	NW.press.UsePaper(client, cell)

	return false
end
