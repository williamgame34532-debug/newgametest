ITEM.base = "junk"
ITEM.name = "Блок смолы"
ITEM.description = "25 единиц сырья для фабрикатора. Заказ: выберите предмет на экране и удерживайте E у выдвинутого лотка. Пополнить резервуар: E на корпусе, затем удерживайте E у лотка."
ITEM.model = "models/items/combine_rifle_ammo01.mdl"
ITEM.icon = "factory_crate"
ITEM.OnUse = function(client)
	NW.Notify(client, "Подойдите к фабрикатору: E на корпусе выдвигает лоток, удерживайте E у лотка, чтобы вставить блоки")
	return false
end
