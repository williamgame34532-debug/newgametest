ITEM.base = "food"

ITEM.name = "Консервы"
ITEM.description = "Жестяная банка рыбных консервов без этикетки. Срок годности неизвестен. Сначала откройте: ПКМ → «Открыть консервы»."
ITEM.model = "models/props_junk/garbage_metalcan001a.mdl"
ITEM.useVerb = "открыть"

function ITEM.OnUse(client)
	NW.Notify(client, "Банка закрыта: ПКМ по консервам → «Открыть консервы»")

	return false
end
