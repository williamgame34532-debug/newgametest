ITEM.base = "food"

ITEM.name = "Открытые консервы"
ITEM.description = "Вскрытая банка рыбных консервов. Есть лучше сразу."
ITEM.model = "models/props_junk/garbage_metalcan001a.mdl"
ITEM.icon = "canned"
ITEM.hunger = 25
ITEM.leaves = "tin_empty"
ITEM.useSound = "network2/use/eat_canned.wav"
