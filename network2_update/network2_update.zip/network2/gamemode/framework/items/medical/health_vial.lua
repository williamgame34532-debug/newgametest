ITEM.base = "junk"
ITEM.category = "medical"
ITEM.name = "Колба с личинкой"
ITEM.description = "Личинка муравьиного льва в колбе Альянса. Посмотрите на станцию первой помощи и используйте колбу, затем удерживайте E у станции, чтобы восстановить здоровье."
ITEM.model = "models/hla/health_station/health_vial.mdl"
ITEM.useSound = "items/medshot4.wav"
ITEM.OnUse = function(client)
	local station = NW.healthStation and NW.healthStation.Aimed(client)
	if (!IsValid(station)) then
		NW.Notify(client, "Посмотрите на станцию первой помощи, чтобы вставить колбу")
		return false
	end
	if (!station:CanTakeVial()) then
		NW.Notify(client, "В станции уже есть колба")
		return false
	end
	if (!station:AcceptItem(client, "health_vial")) then return false end
end
