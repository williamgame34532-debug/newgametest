ITEM.name = "Переносной принтер"
ITEM.description = "Старый матричный принтер с запасом бумаги. Используйте, глядя на пол или стол рядом, — принтер встанет там. Alt + E по своему принтеру — сложить обратно."
ITEM.model = "models/props_c17/consolebox01a.mdl"
ITEM.category = "misc"
ITEM.useVerb = "установить"
ITEM.price = 80

function ITEM.OnUse(client)
	return NW.press.Deploy(client)
end
