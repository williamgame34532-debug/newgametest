ITEM.name = "Посылка с заказом"
ITEM.description = "Опломбированная коробка со склада Альянса. Отнесите к помещению владельца и используйте её там."
ITEM.model = "models/props_junk/cardboard_box003a.mdl"
ITEM.category = "misc"
ITEM.useVerb = "сдать заказ"
ITEM.icon = "factory_crate"

function ITEM.OnUse(client, cell)
	if (!NW.deliveries or !NW.deliveries.Deliver) then return false end

	return NW.deliveries.Deliver(client, cell) == true
end
