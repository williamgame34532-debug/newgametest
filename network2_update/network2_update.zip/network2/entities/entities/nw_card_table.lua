AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Игральный стол"
ENT.Category = "Network"
ENT.Spawnable = true
ENT.AdminOnly = true
ENT.Model = "models/props_c17/FurnitureTable001a.mdl"

if (SERVER) then
	function ENT:SpawnFunction(client, trace, class)
		if (!trace.Hit) then return end
		local entity = ents.Create(class)
		entity:SetPos(trace.HitPos + trace.HitNormal * 2)
		entity:SetAngles(Angle(0, client:EyeAngles().y + 180, 0))
		entity:Spawn()
		entity:Activate()
		entity:SetPos(trace.HitPos - Vector(0, 0, entity:OBBMins().z))
		NW.persist.Save("nw_card_table")
		return entity
	end

	function ENT:Initialize()
		self:SetModel(self.nwModel or self.Model)
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetMoveType(MOVETYPE_VPHYSICS)
		self:SetSolid(SOLID_VPHYSICS)
		self:SetUseType(SIMPLE_USE)
		local physics = self:GetPhysicsObject()
		if (IsValid(physics)) then physics:EnableMotion(false) end
		self.nwSeats = {}
	end

	function ENT:Use(client)
		if (!IsValid(client) or !client:IsPlayer() or client:GetCharacterID() == 0) then return end
		NW.cards.Use(self, client)
	end

	function ENT:Think()
		self:SetNW2Int("nwCardSeats", #(self.nwSeats or {}))
		self:SetNW2String("nwCardGame", self.nwGame and self.nwGame.kind or "")
		self:NextThink(CurTime() + 1)
		return true
	end

	function ENT:OnRemove()
		self.nwRemoving = true
	end

	timer.Simple(0, function()
		NW.persist.Register("nw_card_table", {
			Create = function(data, pos, ang)
				local entity = ents.Create("nw_card_table")
				if (!IsValid(entity)) then return end
				entity.nwModel = isstring(data.model) and util.IsValidModel(data.model) and data.model or nil
				entity:SetPos(pos)
				entity:SetAngles(ang)
				entity:Spawn()
				entity:Activate()
				return entity
			end,
			Save = function(entity)
				return {model = entity.nwModel}
			end
		})
	end)

	return
end

local NAMES = {blackjack = "Блэкджек", durak = "Дурак"}

function ENT:Draw()
	self:DrawModel()

	if (EyePos():DistToSqr(self:GetPos()) > 300 * 300) then return end

	local pos = self:WorldSpaceCenter() + Vector(0, 0, self:OBBMaxs().z + 10)
	local ang = Angle(0, EyeAngles().y - 90, 90)
	local kind = NAMES[self:GetNW2String("nwCardGame", "")] or "Свободен"

	cam.Start3D2D(pos, ang, 0.07)
		draw.SimpleTextOutlined("ИГРАЛЬНЫЙ СТОЛ · " .. kind, "nwWidgetBold", 0, 0, Color(232, 196, 72), TEXT_ALIGN_CENTER,
			TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, 180))
		draw.SimpleTextOutlined("Игроков: " .. self:GetNW2Int("nwCardSeats", 0) .. "/" .. NW.cards.seats .. " · E — сесть", "nwWidget", 0, 22,
			color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, 180))
	cam.End3D2D()
end
