AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Станция первой помощи"
ENT.Category = "Network"
ENT.Spawnable = true
ENT.AdminOnly = true
ENT.RenderGroup = RENDERGROUP_BOTH
ENT.IsHealthStation = true
ENT.AutomaticFrameAdvance = true

NW.healthStation = NW.healthStation or {
	Dir = "models/hla/health_station/",
	VialHP = 50,
	HealRate = 15,
	UseRange = 90,
}

local ST = NW.healthStation

function ENT:SetupDataTables()
	self:NetworkVar("Bool", 0, "HasVial")
	self:NetworkVar("Float", 0, "Charge")
	self:NetworkVar("Entity", 0, "Healer")
	self:NetworkVar("Entity", 1, "Gauge")
	self:NetworkVar("Entity", 2, "Vial")
end

function ENT:CanTakeVial() return !self:GetHasVial() end

function ENT:VialSlot()
	local g = self:GetGauge()
	if (!IsValid(g)) then return end
	local id = g:LookupAttachment("health_vial_attach")
	if (!id or id <= 0) then return end
	local a = g:GetAttachment(id)
	if (a) then return a.Pos, self:GetAngles() end
end

function ENT:Levels()
	local f = 1 - self:GetCharge() / ST.VialHP
	return f, IsValid(self:GetHealer()) or self:GetCharge() <= 0
end

local function aimsAt(p, self)
	local tr = p:GetEyeTrace()
	local e = tr.Entity
	return IsValid(e) and (e == self or e:GetParent() == self or (IsValid(e:GetParent()) and e:GetParent():GetParent() == self))
		and tr.HitPos:DistToSqr(p:EyePos()) < ST.UseRange * ST.UseRange
end

ST.AimsAt = aimsAt

function ST.Aimed(p)
	for _, e in ipairs(ents.FindInSphere(p:EyePos(), ST.UseRange + 40)) do
		if (e.IsHealthStation and aimsAt(p, e)) then return e end
	end
end

if (SERVER) then
	local SND = "hla/health_station/"

	local function rnd(list) return SND .. list[math.random(#list)] end
	local NEEDLES = {"combine_tech_needle_impacts_01.wav", "combine_tech_needle_impacts_02.wav", "combine_tech_needle_impacts_03.wav", "combine_tech_needle_impacts_04.wav"}
	local PAIN = {"health_station_grub_pain_01.mp3", "health_station_grub_pain_02.mp3", "health_station_grub_pain_03.mp3", "health_station_grub_pain_04.mp3"}
	local BREATH = {"health_station_grub_breath_01.mp3", "health_station_grub_breath_02.mp3", "health_station_grub_breath_03.mp3", "health_station_grub_breath_04.mp3"}
	local SLIDES = {"combine_tech_long_slide_sm_01.wav", "combine_tech_long_slide_sm_02.wav", "combine_tech_long_slide_sm_03.wav"}
	local OPEN_TIME = 1.6

	function ENT:SpawnFunction(p, tr, class)
		if (!tr.Hit) then return end
		if (math.abs(tr.HitNormal.z) > 0.3) then
			local fwd = Angle(0, p:EyeAngles().y, 0):Forward()
			tr = util.TraceLine({start = p:EyePos(), endpos = p:EyePos() + fwd * 400, filter = p, mask = MASK_SOLID_BRUSHONLY})
			if (!tr.Hit or math.abs(tr.HitNormal.z) > 0.3) then
				p:ChatPrint("Станцию нужно ставить на стену: посмотрите на стену.")
				return
			end
		end
		local n = Vector(tr.HitNormal.x, tr.HitNormal.y, 0):GetNormalized()
		local e = ents.Create(class)
		e:SetPos(tr.HitPos + n * 2)
		e:SetAngles(n:Angle())
		e:Spawn()
		e:Activate()
		NW.persist.Save("nw_health_station")
		return e
	end

	local function part(self, name, seq)
		local m = ents.Create("prop_dynamic")
		m:SetModel(ST.Dir .. name .. ".mdl")
		m:SetPos(self:GetPos())
		m:SetAngles(self:GetAngles())
		m:SetParent(self)
		m:SetKeyValue("DefaultAnim", seq)
		m:Spawn()
		m:SetSolid(SOLID_NONE)
		m:DrawShadow(false)
		self:DeleteOnRemove(m)
		return m
	end

	local function anim(m, seq, hold)
		if (!IsValid(m)) then return end
		m:Fire("SetDefaultAnimation", hold)
		m:Fire("SetAnimation", seq)
		m:Fire("SetPlaybackRate", "1")
	end

	local function freeze(m, seq, f)
		if (!IsValid(m)) then return end
		local id = m:LookupSequence(seq)
		if (!id or id < 0) then return end
		if (m:GetSequence() != id) then m:ResetSequence(id) end
		m:SetPlaybackRate(0)
		m:SetCycle(math.Clamp(f, 0, 0.995))
	end

	function ENT:Initialize()
		if (!util.IsValidModel(ST.Dir .. "charger.mdl")) then
			local msg = "[Network] Нет моделей станции первой помощи (" .. ST.Dir .. "): установите аддон с моделями HL:A"
			NW.Warn(msg)
			for _, p in ipairs(player.GetAll()) do if (p:IsAdmin()) then p:ChatPrint(msg) end end
		end
		self:SetModel(ST.Dir .. "charger.mdl")
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetMoveType(MOVETYPE_VPHYSICS)
		self:SetSolid(SOLID_VPHYSICS)
		local ph = self:GetPhysicsObject()
		if (IsValid(ph)) then ph:EnableMotion(false) end
		local deploy = self:LookupSequence("deploy")
		if (deploy and deploy >= 0) then self:ResetSequence(deploy) end
		self:SetPlaybackRate(0)
		self:SetCycle(0)
		self.OpenF = 0
		self.Internals = part(self, "charger_internals", "idle_retracted")
		self.Pad = part(self, "charger_pad", "rest")
		self:SetGauge(part(self, "charger_gauge", "drained"))
	end

	function ENT:UpdateGauge()
		local g = self:GetGauge()
		if (!IsValid(g)) then return end
		if (!self:GetHasVial()) then
			local drained = g:LookupSequence("drained")
			if (drained and drained >= 0 and g:GetSequence() != drained) then g:ResetSequence(drained) end
			return
		end
		freeze(g, "idle_full", 1 - self:GetCharge() / ST.VialHP)
	end

	function ENT:AcceptItem(p, id, charge)
		if (id != "health_vial" or self:GetHasVial()) then return false end
		local g = self:GetGauge()
		local v = ents.Create("prop_dynamic")
		v:SetModel(ST.Dir .. "health_vial.mdl")
		local idle = "health_vial_larva_idle_" .. math.random(1, 7) .. "_anim"
		v:SetKeyValue("DefaultAnim", idle)
		v:Spawn()
		v:SetSolid(SOLID_NONE)
		local pos, ang = self:VialSlot()
		v:SetPos(pos or self:WorldSpaceCenter())
		v:SetAngles(ang or self:GetAngles())
		v:SetParent(IsValid(g) and g or self)
		self:DeleteOnRemove(v)
		self.Vial = v
		self:SetVial(v)
		self.VialIdle = idle
		self:SetHasVial(true)
		self:SetCharge(math.Clamp(charge or ST.VialHP, 0, ST.VialHP))
		anim(v, "health_vial_deploy_anim", idle)
		self:UpdateGauge()
		if (IsValid(p)) then
			self:EmitSound(SND .. "combine_health_station_powerup_01.wav", 65)
			self:EmitSound(rnd(BREATH), 55)
		end
		NW.persist.Save("nw_health_station")
		return true
	end

	function ENT:Eject()
		if (!self:GetHasVial()) then return end
		self:StopHeal()
		local v = self.Vial
		local pos, ang = IsValid(v) and v:GetPos() or self:WorldSpaceCenter(), IsValid(v) and v:GetAngles() or self:GetAngles()
		if (IsValid(v)) then v:Remove() end
		self.Vial = nil
		self:SetHasVial(false)
		self:SetCharge(0)
		local d = ents.Create("prop_physics")
		d:SetModel(ST.Dir .. "health_vial.mdl")
		d:SetPos(pos + self:GetForward() * 3)
		d:SetAngles(ang)
		d:Spawn()
		d:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
		freeze(d, "health_vial_larva_flush_finished_idle", 0)
		local ph = d:GetPhysicsObject()
		if (IsValid(ph)) then ph:Wake() ph:SetVelocity(self:GetForward() * 60 + Vector(0, 0, 40)) end
		SafeRemoveEntityDelayed(d, 20)
		self:UpdateGauge()
		self:EmitSound(rnd(SLIDES), 60)
		NW.persist.Save("nw_health_station")
	end

	function ENT:StartHeal(p)
		if (IsValid(self:GetHealer()) or !self:GetHasVial() or self:GetCharge() <= 0) then return end
		if (p:Health() >= p:GetMaxHealth()) then NW.Notify(p, "Вы и так здоровы") return end
		self:SetHealer(p)
		self.HealAcc = 0
		self.HealSerial = (self.HealSerial or 0) + 1
		local serial = self.HealSerial
		anim(self.Internals, "prepare_inject", "inject_loop")
		anim(self.Pad, "step01", "extended")
		timer.Simple(0.7, function()
			if (IsValid(self) and self.HealSerial == serial and IsValid(self:GetHealer())) then anim(self.Pad, "step02", "extended") end
		end)
		self:EmitSound(rnd(NEEDLES), 65)
		self:EmitSound(rnd(PAIN), 60)
		self.Loop = self.Loop or CreateSound(self, SND .. "health_station_healing_lp_01.wav")
		self.Loop:Play()
		self.NextPain = CurTime() + 1.5
		freeze(self.Vial, "health_vial_larva_flush_anim", 1 - self:GetCharge() / ST.VialHP)
	end

	function ENT:StopHeal()
		if (!IsValid(self:GetHealer())) then return end
		self.HealSerial = (self.HealSerial or 0) + 1
		self:SetHealer(NULL)
		if (self.Loop) then self.Loop:Stop() end
		anim(self.Internals, "retract", "idle_retracted")
		anim(self.Pad, "retract", "rest")
		self:UpdateGauge()
		NW.persist.Save("nw_health_station")
		if (!IsValid(self.Vial)) then return end
		if (self:GetCharge() <= 0) then
			self:EmitSound(SND .. "health_station_grub_flush_01.mp3", 62)
			anim(self.Vial, "health_vial_larva_flush_finished_idle", "health_vial_larva_flush_finished_idle")
		else
			anim(self.Vial, self.VialIdle or "health_vial_larva_idle_1_anim", self.VialIdle or "health_vial_larva_idle_1_anim")
		end
	end

	function ENT:Think()
		local want = IsValid(self:GetHealer()) and 1 or 0
		if (self.OpenF != want) then
			self.OpenF = math.Approach(self.OpenF or 0, want, FrameTime() / OPEN_TIME)
			self:SetPlaybackRate(0)
			self:SetCycle(self.OpenF)
		end
		local p = self:GetHealer()
		if (IsValid(p)) then
			if (!p:Alive() or !p:KeyDown(IN_USE) or !aimsAt(p, self) or p:Health() >= p:GetMaxHealth() or self:GetCharge() <= 0) then
				self:StopHeal()
			else
				self.HealAcc = (self.HealAcc or 0) + ST.HealRate * engine.TickInterval()
				local whole = math.floor(self.HealAcc)
				if (whole >= 1) then
					self.HealAcc = self.HealAcc - whole
					whole = math.min(whole, p:GetMaxHealth() - p:Health(), math.ceil(self:GetCharge()))
					p:SetHealth(p:Health() + whole)
					self:SetCharge(math.max(0, self:GetCharge() - whole))
				end
				freeze(self.Vial, "health_vial_larva_flush_anim", 1 - self:GetCharge() / ST.VialHP)
				self:UpdateGauge()
				if (CurTime() > (self.NextPain or 0)) then
					self.NextPain = CurTime() + math.Rand(1.2, 2.2)
					self:EmitSound(rnd(PAIN), 55)
				end
			end
		end
		self:NextThink(CurTime())
		return true
	end

	function ENT:OnRemove()
		self.nwRemoving = true
		if (self.Loop) then self.Loop:Stop() end
	end

	hook.Add("KeyPress", "nwHealthStation", function(p, k)
		if (k != IN_USE or !p:Alive() or p:GetCharacterID() == 0) then return end
		local e = ST.Aimed(p)
		if (!e) then return end
		if (e:GetHasVial() and e:GetCharge() <= 0) then
			e:Eject()
		elseif (!e:GetHasVial()) then
			NW.Notify(p, "В станции нет колбы: используйте «Колбу с личинкой» из инвентаря, глядя на станцию")
		else
			e:StartHeal(p)
		end
	end)

	hook.Add("OnPhysgunPickup", "nwHealthStation", function(p, e)
		if (!e.IsHealthStation) then return end
		local ph = e:GetPhysicsObject()
		if (IsValid(ph)) then ph:EnableCollisions(false) ph:EnableGravity(false) end
	end)

	hook.Add("PhysgunDrop", "nwHealthStation", function(p, e)
		if (!e.IsHealthStation) then return end
		local ph = e:GetPhysicsObject()
		if (IsValid(ph)) then ph:EnableCollisions(true) ph:EnableMotion(false) ph:Sleep() end
		NW.persist.Save("nw_health_station")
	end)

	timer.Simple(0, function()
		NW.persist.Register("nw_health_station", {
			Save = function(entity)
				return {charge = entity:GetHasVial() and entity:GetCharge() or nil}
			end,
			Load = function(entity, data)
				local charge = tonumber(data.charge)
				if (charge) then
					timer.Simple(0.5, function()
						if (IsValid(entity)) then entity:AcceptItem(nil, "health_vial", charge) end
					end)
				end
			end
		})
	end)

	return
end

local holo = Material("cf_rework/holo/hologram")
local glow = Material("sprites/light_glow02_add")

function ENT:Initialize()
	self:SetRenderBounds(Vector(-4, -20, -25), Vector(25, 18, 30))
end

function ENT:Think()
	if (!self:GetHasVial()) then return end
	local f, draining = self:Levels()
	local g = self:GetGauge()
	if (IsValid(g) and g:GetSequence() == g:LookupSequence("idle_full")) then g:SetCycle(math.Clamp(f, 0, 0.995)) end
	local v = self:GetVial()
	if (IsValid(v) and draining and v:GetSequence() == v:LookupSequence("health_vial_larva_flush_anim")) then v:SetCycle(math.Clamp(f, 0, 0.995)) end
end

function ENT:OnRemove()
	if (IsValid(self.Ghost)) then self.Ghost:Remove() end
end

function ENT:Draw()
	self:DrawModel()
	if (self:GetHasVial() or EyePos():DistToSqr(self:GetPos()) > 600 * 600) then return end
	local pos, ang = self:VialSlot()
	if (!pos) then return end
	if (!IsValid(self.Ghost)) then
		self.Ghost = ClientsideModel(ST.Dir .. "health_vial.mdl", RENDERGROUP_TRANSLUCENT)
		if (!IsValid(self.Ghost)) then return end
		self.Ghost:SetNoDraw(true)
	end
	self.Ghost:SetPos(pos)
	self.Ghost:SetAngles(ang)
	self.Ghost:SetupBones()
	local k = 0.6 + 0.4 * math.abs(math.sin(CurTime() * 2))
	render.MaterialOverride(holo)
	render.SetColorModulation(0.4 * k, 0.7 * k, 1.0 * k)
	self.Ghost:DrawModel()
	render.SetColorModulation(1, 1, 1)
	render.MaterialOverride()
	render.SetMaterial(glow)
	render.DrawSprite(pos, 10 * k, 10 * k, Color(80, 170, 255, 90))
end
