AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Доска объявлений"
ENT.Category = "Network"
ENT.Spawnable = true
ENT.AdminOnly = true
ENT.RenderGroup = RENDERGROUP_BOTH
ENT.Model = "models/hunter/plates/plate1x2.mdl"

if (SERVER) then
	function ENT:SpawnFunction(client, trace, class)
		if (!trace.Hit) then return end
		local dir = client:GetPos() - trace.HitPos
		dir.z = 0
		dir:Normalize()
		local ang = dir:Angle()
		ang.p = 90
		local entity = ents.Create(class)
		entity:SetPos(trace.HitPos + dir * 2 + Vector(0, 0, math.abs(trace.HitNormal.z) > 0.7 and 60 or 0))
		entity:SetAngles(ang)
		entity:Spawn()
		entity:Activate()
		NW.persist.Save("nw_notice_board")
		return entity
	end

	function ENT:Initialize()
		self:SetModel(self.nwModel or self.Model)
		if (!self.nwModel) then self:SetMaterial("phoenix_storms/wood") end
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetMoveType(MOVETYPE_VPHYSICS)
		self:SetSolid(SOLID_VPHYSICS)
		self:SetUseType(SIMPLE_USE)
		local physics = self:GetPhysicsObject()
		if (IsValid(physics)) then physics:EnableMotion(false) end
		self.nwNotes = self.nwNotes or {}
		NW.press.SyncBoard(self)
	end

	function ENT:Use(client)
		if (!IsValid(client) or !client:IsPlayer() or client:GetCharacterID() == 0) then return end
		NW.press.OpenBoard(client, self)
	end

	function ENT:OnRemove()
		self.nwRemoving = true
	end

	timer.Simple(0, function()
		NW.persist.Register("nw_notice_board", {
			Create = function(data, pos, ang)
				local entity = ents.Create("nw_notice_board")
				if (!IsValid(entity)) then return end
				entity.nwModel = isstring(data.model) and util.IsValidModel(data.model) and data.model or nil
				entity.nwNotes = istable(data.notes) and data.notes or {}
				entity:SetPos(pos)
				entity:SetAngles(ang)
				entity:Spawn()
				entity:Activate()
				return entity
			end,
			Save = function(entity)
				return {model = entity.nwModel, notes = entity.nwNotes}
			end
		})
	end)

	return
end

local SHEET = Material("network2/ui/board_sheet.png", "smooth")

function ENT:DrawTranslucent()
	self:DrawModel()

	if (EyePos():DistToSqr(self:GetPos()) > 500 * 500) then return end

	local raw = self:GetNW2String("nwBoardTitles", "[]")

	if (self.nwTitlesRaw != raw) then
		self.nwTitlesRaw = raw
		self.nwTitles = util.JSONToTable(raw) or {}
	end

	local mins, maxs = self:OBBMins(), self:OBBMaxs()
	local normal = self:GetUp()
	local down = self:GetForward()
	local right = normal:Cross(down)

	if ((EyePos() - self:GetPos()):Dot(normal) < 0) then return end

	local height = maxs.x - mins.x
	local width = maxs.y - mins.y
	local scale = 0.1
	local origin = self:LocalToWorld(Vector(mins.x, 0, maxs.z + 0.3)) - right * (width / 2)
	local ang = right:AngleEx(normal)
	local W, H = width / scale, height / scale

	cam.Start3D2D(origin, ang, scale)
		draw.SimpleTextOutlined("ДОСКА ОБЪЯВЛЕНИЙ", "nwWidgetTitle", W / 2, 24, Color(232, 196, 72), TEXT_ALIGN_CENTER,
			TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, 200))

		local cols, rows = 4, 3
		local cw, ch = (W - 40) / cols, (H - 70) / rows

		for index, title in ipairs(self.nwTitles or {}) do
			if (index > cols * rows) then break end
			local col = (index - 1) % cols
			local row = math.floor((index - 1) / cols)
			local x, y = 20 + col * cw + 6, 56 + row * ch + 6
			if (!SHEET:IsError()) then
				surface.SetMaterial(SHEET)
				surface.SetDrawColor(255, 255, 255, 255)
				surface.DrawTexturedRect(x, y, cw - 12, ch - 12)
			else
				surface.SetDrawColor(226, 220, 200, 255)
				surface.DrawRect(x, y, cw - 12, ch - 12)
			end
			draw.SimpleText(NW.Cut(tostring(title), 28), "nwWidgetBold", x + (cw - 12) / 2, y + (ch - 12) / 2, Color(30, 30, 34),
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end

		if (#(self.nwTitles or {}) == 0) then
			draw.SimpleText("Объявлений нет · E — повесить", "nwWidget", W / 2, H / 2, Color(220, 220, 220), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	cam.End3D2D()
end

function ENT:Draw()
	self:DrawTranslucent()
end
