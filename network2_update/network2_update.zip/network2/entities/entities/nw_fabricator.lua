AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Фабрикатор Альянса"
ENT.Category = "Network"
ENT.Spawnable = true
ENT.AdminOnly = true
ENT.RenderGroup = RENDERGROUP_BOTH
ENT.IsCombineFabricator = true
ENT.AutomaticFrameAdvance = true

function ENT:SetupDataTables()
	self:NetworkVar("Int", 0, "Stage")
	self:NetworkVar("Int", 1, "Tab")
	self:NetworkVar("Int", 2, "Selection")
	self:NetworkVar("Int", 3, "Paid")
	self:NetworkVar("Int", 4, "Cost")
	self:NetworkVar("Int", 5, "Resin")
	self:NetworkVar("Int", 6, "Feeds")
	self:NetworkVar("Entity", 0, "Operator")
	self:NetworkVar("String", 0, "StatusText")
	self:NetworkVar("Float", 0, "StageStarted")
	self:NetworkVar("Float", 1, "StageUntil")
	self:NetworkVar("Float", 2, "DeployedAt")
	self:NetworkVar("Float", 3, "FeedStarted")
	self:NetworkVar("Bool", 0, "Deployed")
	self:NetworkVar("Bool", 1, "TrayReady")
	self:NetworkVar("Bool", 2, "BayOpen")
	self:NetworkVar("Bool", 3, "TrayOut")
end

if (SERVER) then
	local FB = NW.fabricator
	local S = FB.State
	local SND = "combine_fabricator/"
	local UPGRADING = SND .. "combine_3d_printer_upgrading_01.wav"

	local LOOPS = {dormant = true, menu_idle = true, hatch_idle = true, bay_idle = true, print_done = true}
	for i = 0, 9 do LOOPS[string.format("tray_idle_%02d", i)] = true end

	local ON = {}
	ON.eye_deploy = function(self) self:Snd("combine_3d_printer_eyestalk_extend_01.wav", 60) end
	ON.interface_deploy = function(self) self:Snd("combine_3d_printer_interface_open_01.wav", 62) end
	ON.menu_idle = function(self)
		if (!self:GetDeployed()) then self:SetDeployed(true) self:SetDeployedAt(CurTime()) end
	end
	ON.interface_retract = function(self) self:SetDeployed(false) self:Snd("combine_3d_printer_interface_open_01.wav", 56, 80) end
	ON.eye_retract = function(self) self:Snd("combine_3d_printer_eyestalk_retract_01.wav", 58) end
	ON.hatch_open = function(self) self.Mech.hatch = true self:Snd("combine_3d_printer_chamber_open_01.wav", 62) end
	ON.hatch_close = function(self) self.Mech.hatch = false self:SetTrayOut(false) self:Snd("combine_3d_printer_chamber_open_01.wav", 58, 85) end
	ON.tray_deploy = function(self) self.Mech.tray = true self:SetTrayOut(true) self:Snd("combine_3d_printer_resin_tray_open_01.wav", 62) end
	ON.tray_retract = function(self) self.Mech.tray = false self:SetTrayReady(false) self:Snd("combine_3d_printer_resin_tray_retract_01.wav", 60) end
	ON.bay_open = function(self) self.Mech.bay = true self:Snd("combine_3d_printer_upgrader_open_01.wav", 62) end
	ON.bay_close = function(self) self.Mech.bay = false self:SetBayOpen(false) self:Snd("combine_3d_printer_resin_tray_retract_01.wav", 56, 90) end
	ON.print = function(self, dur)
		self.Mech.bay = false
		self:SetTrayOut(false)
		self:SetStageStarted(CurTime())
		self:SetStageUntil(CurTime() + dur)
		self:Snd("combine_3d_printer_upgrading_01.wav", 64)
		self.PrintSounds = {{CurTime() + dur * 0.62, "combine_3d_printer_gun_attach_print_01.wav"}}
	end
	ON.bay_idle = function(self) self:SetBayOpen(true) end

	for i = 0, 9 do
		ON[string.format("tray_idle_%02d", i)] = function(self)
			local st = self:GetStage()
			self:SetTrayReady(st == S.DEPOSIT or st == S.REFILL)
		end
		ON[string.format("tray_cycle_%02d", i)] = function(self)
			self:Snd("combine_3d_printer_resin_tray_advance_01.wav", 60, 96 + i * 2)
		end
	end

	function ENT:SpawnFunction(client, trace, class)
		if (!trace.Hit) then return end

		local e = ents.Create(class)
		e:SetPos(trace.HitPos + trace.HitNormal * 1)
		e:SetAngles(Angle(0, client:EyeAngles().y + 180, 0))
		e:Spawn()
		e:Activate()
		e:SetResin(FB.max:GetInt())
		NW.persist.Save("nw_fabricator")

		return e
	end

	function ENT:StartSeq(name)
		local seq = self:LookupSequence(name)
		if (!seq or seq < 0) then
			self.SeqName = name
			self.SeqEnd = (!LOOPS[name]) and CurTime() + 0.1 or nil
			if (ON[name]) then ON[name](self, 3) end
			return
		end
		self:ResetSequence(seq)
		self:SetCycle(0)
		self:SetPlaybackRate(1)
		self.SeqName = name
		self.SeqSerial = (self.SeqSerial or 0) + 1
		local dur = self:SequenceDuration(seq)
		self.SeqEnd = (!LOOPS[name]) and CurTime() + dur or nil
		if (ON[name]) then ON[name](self, dur) end
	end

	function ENT:Advance()
		while (self.Queue[1]) do
			local nxt = table.remove(self.Queue, 1)

			if (isfunction(nxt)) then
				local serial = self.SeqSerial
				nxt(self)
				if (self.SeqSerial != serial) then return end
			else
				self:StartSeq(nxt)
				return
			end
		end
	end

	function ENT:Play(list, cut)
		self.Queue = table.Copy(list)
		if (cut or !self.SeqEnd or self.SeqName == "print") then self:Advance() end
	end

	function ENT:CloseList(tail)
		local out = {}
		local m = self.Mech
		if (m.tray) then out[#out + 1] = "tray_retract" end
		if (m.bay) then out[#out + 1] = "bay_close" end
		if (m.hatch) then out[#out + 1] = "hatch_close" end
		for _, v in ipairs(tail or {}) do out[#out + 1] = v end
		return out
	end

	function ENT:Initialize()
		if (!util.IsValidModel(FB.Model)) then
			local msg = "[Network] Нет модели " .. FB.Model .. ": установите аддон hla_fabricator_content"
			NW.Warn(msg)
			for _, p in ipairs(player.GetAll()) do if (p:IsAdmin()) then p:ChatPrint(msg) end end
		end

		self:SetModel(FB.Model)
		self:PhysicsInit(SOLID_VPHYSICS)
		if (!IsValid(self:GetPhysicsObject())) then self:PhysicsInitBox(Vector(-18, -52, 0), Vector(18, 52, 42)) end
		self:SetMoveType(MOVETYPE_VPHYSICS)
		self:SetSolid(SOLID_VPHYSICS)
		self:SetUseType(SIMPLE_USE)

		local ph = self:GetPhysicsObject()
		if (IsValid(ph)) then ph:SetMass(400) ph:EnableMotion(false) end

		self:SetTab(1)
		self:SetStage(S.DORMANT)
		self.Mech = {}
		self.Queue = {}
		self.Awake = false
		self.LastNearby = -100
		self:StartSeq("dormant")
	end

	function ENT:SetPhase(stage, duration)
		self:SetStage(stage)
		self:SetStageStarted(CurTime())
		self:SetStageUntil(CurTime() + (duration or 0))
	end

	function ENT:Notify(p, text)
		self:SetStatusText(text)
		self.MessageUntil = CurTime() + 3.5
		if (IsValid(p)) then p:EmitSound("buttons/button10.wav", 45, 110) end
	end

	function ENT:Snd(name, level, pitch)
		self:EmitSound(SND .. name, level or 62, pitch or 100)
	end

	function ENT:Use() end

	function ENT:Busy(p)
		local op = self:GetOperator()
		return IsValid(op) and op != p
	end

	function ENT:RequestFocus(p)
		if (!FB.Ready(self) or self:GetStage() == S.DORMANT) then return end
		if (!FB.CanCatalog(p)) then
			self:EmitSound("buttons/combine_button_locked.wav", 55)
			NW.Notify(p, "Каталог доступен Альянсу. Смолу можно загрузить: E на корпусе")
			return
		end
		if (self:Busy(p)) then self:Notify(p, "ТЕРМИНАЛ ЗАНЯТ") return end
		for _, v in ipairs(player.GetAll()) do
			if (v != p and v.nwFabFocus == self) then self:Notify(p, "ТЕРМИНАЛ ЗАНЯТ") return end
		end
		if (self:GetStage() == S.DONE) then return end
		self.LastAction = CurTime()
		FB.SetFocus(p, self)
		self:EmitSound("buttons/lightswitch2.wav", 45, 140)
	end

	function ENT:ReleaseFocus()
		for _, v in ipairs(player.GetAll()) do
			if (v.nwFabFocus == self) then FB.SetFocus(v, nil) end
		end
	end

	function ENT:HullUse(p)
		if (!self.Awake) then self:WakeUp() return end
		if (self:GetStage() != S.MENU or self:Busy(p) or self.SeqEnd) then return end
		if (self:GetResin() + FB.resinValue > FB.max:GetInt()) then
			NW.Notify(p, "Резервуар фабрикатора полон: " .. self:GetResin() .. " / " .. FB.max:GetInt())
			return
		end
		if (FB.ResinBlocks(p) <= 0) then
			NW.Notify(p, "Нужен блок смолы в инвентаре, чтобы пополнить фабрикатор")
			return
		end
		self.SessionSerial = (self.SessionSerial or 0) + 1
		self:SetOperator(p)
		self:SetFeeds(0)
		self:SetPaid(self:GetResin())
		self:SetCost(FB.max:GetInt())
		self.LastAction = CurTime()
		self:SetPhase(S.REFILL)
		self:Play({"hatch_open", "tray_deploy", "tray_idle_00"})
	end

	function ENT:Interact(p, x, y, part)
		if (!IsValid(p) or !p:Alive()) then return end
		local st = self:GetStage()
		if (st == S.DORMANT) then return end

		if (part == "chamber" and st == S.DONE) then
			self:Collect(p)
			return
		end

		if (self:Busy(p)) then self:Notify(p, "ТЕРМИНАЛ ЗАНЯТ") return end
		self.LastAction = CurTime()

		if (x) then
			local b = FB.Layout.ButtonAt(st, self:GetTab(), x, y)
			if (!b) then return end
			self:SetStatusText("")
			self:EmitSound(FB.ClickSounds[math.random(1, 2)], 50, 100)

			if (b.id == "exit") then
				FB.SetFocus(p, nil)
				return
			end

			if (st == S.MENU) then
				if (b.id == "tab" or b.id == "page") then
					self:SetTab(b.arg)
				elseif (b.id == "select") then
					self:Order(p, b.arg)
				end
			elseif (st == S.DEPOSIT and b.id == "cancel") then
				self:EndSession(true)
			end

			return
		end

		if (part == "cells" and FB.CellsOpen(self)) then
			self:InsertResin(p)
		end
	end

	function ENT:Order(p, index)
		local entry = FB.catalog[index]
		if (!entry or entry.off or !FB.Ready(self) or !FB.CanCatalog(p)) then return end
		if (entry.only and p:GetFaction() != entry.only) then self:Notify(p, "НЕДОСТУПНО ДЛЯ ВАШЕГО ПОДРАЗДЕЛЕНИЯ") return end

		local fromTank = math.min(self:GetResin(), entry.cost)
		local need = entry.cost - fromTank

		if (need > 0 and FB.ResinBlocks(p) * FB.resinValue < need) then
			self:Notify(p, "НЕДОСТАТОЧНО СМОЛЫ — НУЖНО ЕЩЁ " .. need)
			return
		end

		self.SessionSerial = (self.SessionSerial or 0) + 1
		self:SetOperator(p)
		self.OrderEntry = entry
		self:SetSelection(index)
		self:SetCost(entry.cost)
		self:SetResin(self:GetResin() - fromTank)
		self:SetPaid(fromTank)
		self:SetFeeds(0)
		self:SetPhase(S.DEPOSIT)
		MsgN(string.format("[FABRICATOR] %s (%s): %s", p:Nick(), p:SteamName(), entry.id))

		if (need <= 0) then
			self:SetPhase(S.PRINT, 13)
			self:Play({"hatch_open", "tray_deploy", "tray_retract", "bay_open", "print", "bay_open", function(s) s:FinishPrint() end, "bay_idle"})
			NW.persist.Save("nw_fabricator")
		else
			self:Play({"hatch_open", "tray_deploy", "tray_idle_00"})
		end
	end

	function ENT:InsertResin(p)
		if (self:GetOperator() != p or !FB.CellsOpen(self)) then return end
		if ((self.NextFeed or 0) > CurTime() or self:GetPaid() >= self:GetCost()) then return end
		if (self.SeqEnd) then return end

		self.NextFeed = CurTime() + FB.FeedInterval

		if (!FB.TakeResinBlock(p)) then self:Notify(p, "НЕТ БЛОКОВ СМОЛЫ В ИНВЕНТАРЕ") return end

		local refill = self:GetStage() == S.REFILL

		self:SetStatusText("")
		self:SetFeedStarted(CurTime())
		self:SetFeeds(self:GetFeeds() + 1)
		self:SetPaid(math.min(self:GetPaid() + FB.resinValue, refill and FB.max:GetInt() or math.huge))
		self.LastAction = CurTime()

		local k = self:GetFeeds() % 10
		local list = {string.format("tray_cycle_%02d", k), string.format("tray_idle_%02d", k)}

		if (refill) then
			self:SetResin(self:GetPaid())
			NW.persist.Save("nw_fabricator")
			if (self:GetResin() + FB.resinValue > FB.max:GetInt()) then
				local serial = self.SessionSerial
				list[2] = function(s) if (s.SessionSerial == serial) then s:EndSession(false) end end
			end
		elseif (self:GetPaid() >= self:GetCost()) then
			local excess = self:GetPaid() - self:GetCost()
			self:SetResin(math.min(FB.max:GetInt(), self:GetResin() + excess))
			self:SetPaid(self:GetCost())
			local serial = self.SessionSerial
			list[2] = function(s) if (s.SessionSerial == serial) then s:StartPrint() end end
		end

		self:Play(list, true)
	end

	function ENT:StartPrint()
		if (self:GetStage() != S.DEPOSIT or self:GetPaid() < self:GetCost()) then return end
		self:SetTrayReady(false)
		self:SetPhase(S.PRINT, 13)
		self:Play({"tray_retract", "bay_open", "print", "bay_open", function(s) s:FinishPrint() end, "bay_idle"})
		NW.persist.Save("nw_fabricator")
	end

	function ENT:FinishPrint()
		self:ReleaseFocus()
		self:StopSound(UPGRADING)
		self:SetPhase(S.DONE)
		self.ReadyID = self.OrderEntry and self.OrderEntry.id
		self:Snd("combine_3d_printer_work_complete_01.wav", 66)
		self.PrintSounds = nil
		local op = self:GetOperator()
		if (IsValid(op) and self.OrderEntry) then NW.Notify(op, "Готово: " .. self.OrderEntry.name .. ". Заберите из камеры кнопкой E") end
		NW.persist.Save("nw_fabricator")
	end

	function ENT:Collect(p)
		if (self:GetStage() != S.DONE or !self:GetBayOpen()) then return end
		local op = self:GetOperator()
		if (IsValid(op) and op != p and op:Alive() and op:GetPos():DistToSqr(self:GetPos()) < FB.LeaveRadius ^ 2) then
			self:Notify(p, "ПРЕДМЕТ ЗАКАЗАН ДРУГИМ ЮНИТОМ")
			return
		end
		if (!FB.CanCatalog(p)) then NW.Notify(p, "Забрать изготовленное может только Альянс") return end
		local entry = self.OrderEntry or FB.catalog[self:GetSelection()]
		if (!entry) then self:EndSession(false) return end
		local ok, why = FB.Deliver(p, entry)
		if (!ok) then self:Notify(p, why or "ВЫДАЧА НЕ УДАЛАСЬ") return end
		p:EmitSound("items/itempickup.wav", 60)
		self:Snd("print_item.wav", 55)
		NW.Notify(p, "Забрано: " .. entry.name)
		self.ReadyID = nil
		self.OrderEntry = nil
		self:EndSession(false)
	end

	function ENT:EndSession(refund, fold)
		self.SessionSerial = (self.SessionSerial or 0) + 1
		self:StopSound(UPGRADING)
		self.PrintSounds = nil

		local st = self:GetStage()

		if (refund and self.OrderEntry) then
			local amount = (st == S.DEPOSIT) and self:GetPaid() or ((st == S.PRINT or st == S.DONE) and self:GetCost() or 0)
			self:SetResin(math.min(FB.max:GetInt(), self:GetResin() + amount))
			self.OrderEntry = nil
			self.ReadyID = nil
		end

		self:SetOperator(NULL)
		self:SetPaid(0)
		self:SetCost(0)
		self:SetFeeds(0)
		self:SetTrayReady(false)
		self:SetBayOpen(false)

		if (fold) then
			self:Fold()
		else
			self:SetPhase(S.MENU)
			self:Play(self:CloseList({"menu_idle"}), self.SeqName == "print")
		end

		NW.persist.Save("nw_fabricator")
	end

	function ENT:WakeUp()
		if (self.Awake) then return end
		self.Awake = true

		if (self.ReadyID and FB.byID[self.ReadyID]) then
			self.OrderEntry = FB.byID[self.ReadyID]
			self:SetSelection(self.OrderEntry.index)
			self:SetCost(self.OrderEntry.cost)
			self:SetPhase(S.DONE)
			self:Play({"eye_deploy", "interface_deploy", "hatch_open", "bay_open",
				function(s) s:SetDeployed(true) s:SetDeployedAt(CurTime()) end, "bay_idle"})
			return
		end

		self:SetPhase(S.MENU)
		self:Play({"eye_deploy", "interface_deploy", "menu_idle"})
	end

	function ENT:Fold()
		if (!self.Awake) then return end
		self.Awake = false
		self:ReleaseFocus()
		self:SetPhase(S.DORMANT)
		self:SetBayOpen(false)
		self:SetTrayReady(false)
		self:Play(self:CloseList({"interface_retract", "eye_retract", "dormant"}), self.SeqName == "print")
	end

	function ENT:Think()
		local now = CurTime()

		if (self.SeqEnd and now >= self.SeqEnd) then
			self.SeqEnd = nil
			self:Advance()
		end

		local st = self:GetStage()

		if (now >= (self.NextScan or 0)) then
			self.NextScan = now + 0.3
			local near = false
			for _, v in ipairs(player.GetAll()) do
				if (v:Alive() and v:GetPos():DistToSqr(self:GetPos()) < FB.WakeRadius * FB.WakeRadius) then near = true break end
			end
			if (near) then self.LastNearby = now end
			local awake = near or now - self.LastNearby < FB.CloseDelay or st == S.PRINT
			if (!awake and self.Awake) then
				if (st == S.DEPOSIT or st == S.REFILL) then self:EndSession(true, true) else self:Fold() end
			end
		end

		st = self:GetStage()

		if (st == S.DEPOSIT or st == S.REFILL) then
			local p = self:GetOperator()
			local gone = !IsValid(p) or !p:Alive() or p:GetPos():DistToSqr(self:GetPos()) > FB.LeaveRadius * FB.LeaveRadius
			local idle = now - (self.LastAction or now) > (st == S.REFILL and FB.RefillTimeout or FB.IdleTimeout)
			if (gone or idle) then self:EndSession(true) st = self:GetStage() end
		end

		for _, v in ipairs(player.GetAll()) do
			if (v.nwFabFocus == self and (!v:Alive() or v:GetPos():DistToSqr(self:GetPos()) > FB.LeaveRadius * FB.LeaveRadius or !FB.Ready(self))) then
				FB.SetFocus(v, nil)
			end
		end

		if (st == S.DEPOSIT or st == S.REFILL) then
			local p = self:GetOperator()
			if (IsValid(p) and p:KeyDown(IN_USE) and FB.AimedPart(self, p) == "cells") then
				self.LastAction = now
				self:InsertResin(p)
			end
		end

		if (self.PrintSounds) then
			for _, s in ipairs(self.PrintSounds) do
				if (s[1] and now >= s[1]) then self:Snd(s[2], 64) s[1] = nil end
			end
		end

		if (self.MessageUntil and now >= self.MessageUntil) then self.MessageUntil = nil self:SetStatusText("") end
		self:NextThink(now + 0.05)
		return true
	end

	function ENT:OnRemove()
		self.nwRemoving = true
		self:ReleaseFocus()
		self:StopSound(UPGRADING)
	end

	timer.Simple(0, function()
		NW.persist.Register("nw_fabricator", {
			Save = function(entity)
				local st = entity:GetStage()
				local held = 0
				if (entity.OrderEntry and !entity.ReadyID) then
					held = (st == S.DEPOSIT) and entity:GetPaid() or (st == S.PRINT and entity:GetCost() or 0)
				end
				local ready = entity.ReadyID
				if (!ready and st == S.PRINT and entity.OrderEntry) then ready = entity.OrderEntry.id held = 0 end
				return {resin = math.min(FB.max:GetInt(), entity:GetResin() + held), ready = ready}
			end,
			Load = function(entity, data)
				entity:SetResin(math.Clamp(tonumber(data.resin) or 0, 0, FB.max:GetInt()))
				if (isstring(data.ready) and FB.byID[data.ready]) then entity.ReadyID = data.ready end
			end
		})
	end)

	return
end

local FB = NW.fabricator
local S = FB.State

local FONTS = {nwFabHdr = {26, 700}, nwFabXs = {14, 500}, nwFabXxs = {11, 500}, nwFabS = {17, 700},
	nwFabM = {22, 700}, nwFabRow = {21, 700}, nwFabL = {32, 700}, nwFabNum = {42, 700}, nwFabBig = {46, 800}}

for name, f in pairs(FONTS) do
	surface.CreateFont(name, {font = "Roboto Condensed", size = f[1], weight = f[2], extended = true, antialias = true})
end

local function col(c) return c[1], c[2], c[3], c[4] or 255 end
local XA = {[0] = TEXT_ALIGN_LEFT, [1] = TEXT_ALIGN_CENTER, [2] = TEXT_ALIGN_RIGHT}
local YA = {[0] = TEXT_ALIGN_TOP, [1] = TEXT_ALIGN_CENTER, [2] = TEXT_ALIGN_BOTTOM}
local D = {}
local barcode = Material("cf_rework/ui/barcode.png", "smooth")

if (!barcode:IsError()) then
	function D.barcode(x, y, w, h, c)
		surface.SetMaterial(barcode)
		surface.SetDrawColor(col(c))
		surface.DrawTexturedRect(x, y, w, h)
	end
end

function D.rect(x, y, w, h, c) surface.SetDrawColor(col(c)) surface.DrawRect(x, y, w, h) end
function D.outline(x, y, w, h, c, t) surface.SetDrawColor(col(c)) surface.DrawOutlinedRect(x, y, w, h, t or 1) end
function D.line(x1, y1, x2, y2, c) surface.SetDrawColor(col(c)) surface.DrawLine(x1, y1, x2, y2) end
function D.poly(pts, c)
	local p = {}
	for i, v in ipairs(pts) do p[i] = {x = v[1], y = v[2]} end
	draw.NoTexture()
	surface.SetDrawColor(col(c))
	surface.DrawPoly(p)
end
function D.size(s, font) surface.SetFont(font) return surface.GetTextSize(s) end
function D.text(s, font, x, y, c, ax, ay)
	draw.SimpleText(s, font, x, y, Color(col(c)), XA[ax or 0], YA[ay or 0])
end

local beamMat = Material("trails/laser")
local holoMat = CreateMaterial("nw_fab_holo", "UnlitGeneric", {
	["$basetexture"] = "cf_rework/holo/scanlines", ["$additive"] = 1, ["$model"] = 1, ["$nocull"] = 1,
	["$basetexturetransform"] = "center .5 .5 scale 1 6 rotate 0 translate 0 0",
	["Proxies"] = {["TextureScroll"] = {["texturescrollvar"] = "$basetexturetransform", ["texturescrollrate"] = 0.12, ["texturescrollangle"] = 90}},
})
local blockMat = CreateMaterial("nw_fab_holo_block", "UnlitGeneric", {
	["$basetexture"] = "vgui/white", ["$additive"] = 1, ["$vertexcolor"] = 1, ["$vertexalpha"] = 1, ["$nocull"] = 1,
})

function ENT:Initialize()
	self:SetRenderBounds(Vector(-30, -60, -2), Vector(40, 62, 82))
	self.Models = {}
	self.Look = {0, 0}
end

function ENT:ClientModel(key, path)
	self.ModelsUsed = self.ModelsUsed or {}
	self.ModelsUsed[key] = true
	local m = self.Models[key]
	if (IsValid(m) and m.Path == path) then m:SetNoDraw(true) return m end
	if (IsValid(m)) then m:Remove() end
	m = ClientsideModel(path, RENDERGROUP_OPAQUE)
	if (!IsValid(m)) then return end
	m:SetNoDraw(true)
	m:DrawShadow(false)
	m.Path = path
	self.Models[key] = m
	return m
end

function ENT:FreeUnusedModels()
	local used = self.ModelsUsed or {}
	for key, m in pairs(self.Models) do
		if (!used[key]) then
			if (IsValid(m)) then m:Remove() end
			self.Models[key] = nil
		end
	end
	self.ModelsUsed = {}
end

function ENT:OnRemove()
	for _, m in pairs(self.Models or {}) do if (IsValid(m)) then m:Remove() end end
end

function ENT:UpdateLook()
	local target = self:GetOperator()
	if (!IsValid(target)) then
		local best
		for _, p in ipairs(player.GetAll()) do
			local d = p:GetPos():DistToSqr(self:GetPos())
			if (p:Alive() and d < 300 * 300 and (!best or d < best)) then best, target = d, p end
		end
	end
	local want = {0, 0}
	local eyeBone = self:LookupBone("joint28")
	if (IsValid(target) and self:GetDeployed() and eyeBone) then
		local head = self:GetBonePosition(eyeBone)
		local d = self:WorldToLocal(target:EyePos()) - self:WorldToLocal(head)
		local yaw = math.deg(math.atan2(d.y, d.x))
		local pitch = math.deg(math.atan2(d.z, math.sqrt(d.x * d.x + d.y * d.y)))
		want = {math.Clamp(pitch, -35, 35), math.Clamp(math.NormalizeAngle(yaw), -70, 70)}
	end
	local k = 1 - math.exp(-FrameTime() * 4)
	self.Look[1] = Lerp(k, self.Look[1], want[1])
	self.Look[2] = Lerp(k, self.Look[2], want[2])
	local yawBone, pitchBone = self:LookupBone("eye"), eyeBone
	if (yawBone) then self:ManipulateBoneAngles(yawBone, Angle(self.Look[2], 0, 0)) end
	if (pitchBone) then self:ManipulateBoneAngles(pitchBone, Angle(0, -self.Look[1], 0)) end
end

local function placeModel(m, center, ang, scale)
	m:SetModelScale(scale, 0)
	m:SetAngles(ang)
	m:SetPos(center)
	m:SetupBones()
	local off = LocalToWorld(m:OBBCenter() * scale, angle_zero, vector_origin, ang)
	m:SetPos(center - off)
end

local function longAxis(m)
	local mins, maxs = m:GetModelBounds()
	local d = maxs - mins
	if (d.z > d.x and d.z >= d.y) then return Angle(90, 0, 0), d.z, d.y, d.x end
	if (d.y > d.x) then return Angle(0, 90, 0), d.y, d.x, d.z end
	return Angle(0, 0, 0), d.x, d.y, d.z
end

function ENT:DrawItem(st, entry)
	if (!entry) then return end
	local m = self:ClientModel("item", entry.model)
	if (!IsValid(m)) then return end
	local center, aang = FB.ItemPoint(self)
	local a, len, w, h = longAxis(m)
	local scale = math.min(1, FB.ItemFit.len / math.max(len, 1), FB.ItemFit.cross / math.max(w, h, 1))
	local _, ang = LocalToWorld(vector_origin, a, vector_origin, aang)
	NW.items.ApplyAppearance(m, NW.items.Get(entry.item or ""))

	if (st == S.PRINT) then
		local f = FB.BuildProgress(self)
		if (f <= 0) then return end
		placeModel(m, center, ang, scale)
		render.MaterialOverride(holoMat)
		local k = 0.45 + 0.2 * math.sin(CurTime() * 12)
		render.SetColorModulation(0.25 * k, 0.9 * k, 1.0 * k)
		m:DrawModel()
		render.SetColorModulation(1, 1, 1)
		render.MaterialOverride()
		local up = self:GetUp()
		local half = math.max(h * scale * 0.5, 1)
		local zcut = center + up * (-half + 2 * half * f)
		local prev = render.EnableClipping(true)
		render.PushCustomClipPlane(-up, (-up):Dot(zcut))
		m:DrawModel()
		render.PopCustomClipPlane()
		render.EnableClipping(prev)
		local along = ang:Forward() * (len * scale * 0.55)
		render.SetMaterial(beamMat)
		render.DrawBeam(zcut - along, zcut + along, 0.8, 0, 1, Color(90, 230, 255, 220))
	else
		placeModel(m, center, ang, scale)
		m:DrawModel()
	end
end

local function hash(i, t) return (math.sin(i * 12.9898 + t * 78.233) * 43758.5453) % 1 end

function ENT:DrawHologram(entry)
	if (!entry or !self:GetDeployed()) then return end
	local m = self:ClientModel("holo", entry.model)
	if (!IsValid(m)) then return end
	local center = self:LocalToWorld(FB.HoloCenter)
	local ang = self:LocalToWorldAngles(Angle(0, 90 + math.sin(CurTime() * 0.5) * 12, 0))
	local mins, maxs = m:GetModelBounds()
	local d = maxs - mins
	local scale = math.min(1.6, FB.HoloBox.w / math.max(d.x, d.y, 1), FB.HoloBox.h / math.max(d.z, 1))
	placeModel(m, center, ang, scale)
	local flick = 0.9 + 0.1 * math.sin(CurTime() * 23)
	render.MaterialOverride(holoMat)
	render.SetColorModulation(0.75 * flick, 1.0 * flick, 0.95 * flick)
	m:DrawModel()
	render.SetColorModulation(1, 1, 1)
	render.MaterialOverride()
	local right, up, fwd = self:GetRight(), self:GetUp(), self:GetForward()
	local t = math.floor(CurTime() * 8)
	render.SetMaterial(blockMat)
	for i = 1, 26 do
		local u = (hash(i, 0) - 0.5) * FB.HoloBox.w * 1.1
		local v = (hash(i, 1) - 0.5) * FB.HoloBox.h * 1.1
		if (hash(i, t) > 0.35) then
			local s = 1.2 + hash(i, 2) * 2.4
			local p = center + right * u + up * v + fwd * (hash(i, 3) - 0.5) * 2
			local a = 30 + 60 * hash(i, t + 1)
			render.DrawQuadEasy(p, fwd, s * 1.6, s, Color(40, 230, 190, a), 0)
		end
	end
end

function ENT:DrawResin(st)
	if (!self:GetTrayOut()) then return end
	local feeds = self:GetFeeds()
	if (feeds <= 0) then return end
	local n = feeds % 10
	local seqName = self:GetSequenceName(self:GetSequence()) or ""
	if (n == 0) then n = (seqName == "tray_cycle_00" or (st != S.DEPOSIT and st != S.REFILL)) and 10 or 0 end
	if (n == 0) then return end
	local m = self:ClientModel("resin", FB.CartridgeModel)
	if (!IsValid(m)) then return end
	for i = 0, n - 1 do
		local p, a = FB.Attachment(self, string.format("resin_attach_%02d", i))
		if (p) then
			m:SetModelScale(1, 0)
			m:SetPos(p)
			m:SetAngles(a)
			m:SetupBones()
			m:DrawModel()
		end
	end
end

function ENT:ScreenContext(st, cursor)
	local p = self:GetOperator()
	local viewer = LocalPlayer()
	local ctx = {
		stage = st, t = CurTime(), tab = self:GetTab(), sel = self:GetSelection(),
		resin = self:GetResin(), blocks = FB.ResinBlocks(viewer), paid = self:GetPaid(), cost = self:GetCost(),
		printFrac = FB.BuildProgress(self), status = self:GetStatusText(), max = FB.max:GetInt(),
		boot = math.Clamp((CurTime() - self:GetDeployedAt()) / 0.8, 0, 1), viewer = viewer,
	}
	if (IsValid(p) and p != viewer and st > S.MENU and st != S.DONE) then ctx.busy = NW.Cut(p:Nick(), 32) end
	if (cursor) then
		ctx.cursor = cursor
		ctx.hover = FB.Layout.ButtonAt(st, self:GetTab(), cursor[1], cursor[2])
	end
	return ctx
end

function ENT:Draw()
	self:DrawModel()
	local dist = EyePos():DistToSqr(self:GetPos())
	if (dist > 1500 * 1500) then self:FreeUnusedModels() return end
	local st = self:GetStage()
	local entry = FB.catalog[self:GetSelection()]

	self:DrawResin(st)
	if (st == S.PRINT or st == S.DONE) then self:DrawItem(st, entry) end

	local holo
	if (st == S.DEPOSIT or st == S.PRINT) then holo = entry
	elseif (st == S.MENU) then
		local cur = FB.FocusCursor(self)
		if (!cur) then local x, y = FB.HitScreen(self, LocalPlayer()) cur = x and {x, y} end
		local b = cur and FB.Layout.ButtonAt(st, self:GetTab(), cur[1], cur[2])
		if (b and b.id == "select") then holo = FB.catalog[b.arg] end
	end
	self:DrawHologram(holo)
	self:FreeUnusedModels()

	if (self:GetDeployed() and dist < 420 * 420) then
		local origin, right, down, normal, _, scale, corner = FB.ScreenWorld(self)
		if (origin and (EyePos() - origin):Dot(normal) > 0) then
			render.SetColorMaterial()
			local h = FB.PANEL_H
			local up = -down
			render.DrawQuad(corner + normal * 0.015, corner + right * FB.PANEL_W + normal * 0.015,
				corner + right * FB.PANEL_W + up * h + normal * 0.015, corner + up * h + normal * 0.015, Color(4, 26, 32, 245))
			local cur = FB.FocusCursor(self)
			if (!cur) then
				local x, y = FB.HitScreen(self, LocalPlayer())
				cur = x and {x, y}
			end
			local ctx = self:ScreenContext(st, cur)
			local pos3, ang3 = origin + normal * 0.03, right:AngleEx(normal)
			if (!(FB.Monitor and FB.Monitor.Draw(pos3, ang3, scale, function() FB.UI.Draw(D, ctx) end))) then
				cam.Start3D2D(pos3, ang3, scale)
					FB.UI.Draw(D, ctx)
				cam.End3D2D()
			end
		end
	end
end

function ENT:Think()
	self:UpdateLook()
	if (self:GetStage() != S.PRINT or EyePos():DistToSqr(self:GetPos()) > 500 * 500) then return end
	local progress = FB.BuildProgress(self)
	if (progress <= 0 or progress >= 1) then return end
	if ((self.NextSpark or 0) > CurTime()) then return end
	self.NextSpark = CurTime() + 0.12
	local origin = FB.ItemPoint(self)
	local em = ParticleEmitter(origin, false)
	if (!em) then return end
	for i = 1, 3 do
		local p = em:Add("effects/spark", origin + VectorRand() * 4)
		if (p) then
			p:SetVelocity(VectorRand() * 30 + self:GetUp() * 15)
			p:SetDieTime(0.35)
			p:SetStartAlpha(255) p:SetEndAlpha(0)
			p:SetStartSize(0.6) p:SetEndSize(0)
			p:SetStartLength(1.5) p:SetEndLength(0)
			p:SetColor(120, 230, 255)
			p:SetGravity(Vector(0, 0, -200))
		end
	end
	em:Finish()
	local dl = DynamicLight(self:EntIndex())
	if (dl) then
		dl.pos = origin dl.r = 60 dl.g = 200 dl.b = 255 dl.brightness = 1.5
		dl.decay = 600 dl.size = 120 dl.dietime = CurTime() + 0.2
	end
end
