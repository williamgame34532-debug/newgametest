AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Принтер"
ENT.Category = "Network"
ENT.Spawnable = true
ENT.AdminOnly = true
ENT.Model = "models/props_c17/consolebox01a.mdl"

if (SERVER) then
	function ENT:SpawnFunction(client, trace, class)
		if (!trace.Hit) then return end
		local entity = ents.Create(class)
		entity:SetPos(trace.HitPos + trace.HitNormal * 4)
		entity:SetAngles(Angle(0, client:EyeAngles().y + 180, 0))
		entity:Spawn()
		entity:Activate()
		NW.persist.Save("nw_printer")
		return entity
	end

	function ENT:Initialize()
		self:SetModel(self.nwModel or self.Model)
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetMoveType(MOVETYPE_VPHYSICS)
		self:SetSolid(SOLID_VPHYSICS)
		self:SetUseType(SIMPLE_USE)
		local physics = self:GetPhysicsObject()
		if (IsValid(physics)) then physics:EnableMotion(false) end
	end

	function ENT:Use(client)
		if (!IsValid(client) or !client:IsPlayer() or client:GetCharacterID() == 0) then return end

		if (client:KeyDown(IN_WALK) and NW.press.Fold(client, self)) then return end

		if (!NW.press.CanUsePrinter(client, self)) then
			return NW.Notify(client, "Это принтер " .. self:GetNW2String("nwPrinterOwnerName", "другого человека"))
		end

		net.Start("nwPrinterOpen")
			net.WriteEntity(self)
		net.Send(client)
	end

	function ENT:OnRemove()
		self.nwRemoving = true
		if (self:GetNW2Int("nwPrinterOwner", 0) == 0) then NW.persist.Save("nw_printer") end
	end

	timer.Simple(0, function()
		NW.persist.Register("nw_printer", {
			Create = function(data, pos, ang)
				if (data.skip) then return end
				local entity = ents.Create("nw_printer")
				if (!IsValid(entity)) then return end
				entity.nwModel = isstring(data.model) and util.IsValidModel(data.model) and data.model or nil
				entity:SetPos(pos)
				entity:SetAngles(ang)
				entity:Spawn()
				entity:Activate()
				return entity
			end,
			Save = function(entity)
				if (entity:GetNW2Int("nwPrinterOwner", 0) != 0) then return {skip = true} end
				return {model = entity.nwModel}
			end
		})
	end)

	return
end

function ENT:Draw()
	self:DrawModel()

	if (EyePos():DistToSqr(self:GetPos()) > 200 * 200) then return end

	local owner = self:GetNW2String("nwPrinterOwnerName", "")
	local pos = self:WorldSpaceCenter() + Vector(0, 0, self:OBBMaxs().z + 4)
	local ang = Angle(0, EyeAngles().y - 90, 90)

	cam.Start3D2D(pos, ang, 0.06)
		draw.SimpleTextOutlined("ПРИНТЕР" .. (owner != "" and (" · " .. owner) or ""), "nwWidgetBold", 0, 0, Color(232, 196, 72),
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, 180))
	cam.End3D2D()
end
