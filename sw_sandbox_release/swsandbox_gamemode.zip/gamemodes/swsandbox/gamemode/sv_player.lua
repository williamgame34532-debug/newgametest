--[[
	Игрок: выбор стороны, режимы (командир / свободный / вселение), камера командира и видимость.
]]

util.AddNetworkString("SWS_ChooseSide")
util.AddNetworkString("SWS_SetMode")
util.AddNetworkString("SWS_Camera")
util.AddNetworkString("SWS_Notify")

function SWS.Notify(client, text, kind)
	-- владельцем может быть ИИ-командир (не игрок) — ему сообщения не нужны
	if (!IsValid(client) or !client:IsPlayer()) then
		return
	end

	net.Start("SWS_Notify")
		net.WriteString(text)
		net.WriteUInt(kind or 0, 2)
	net.Send(client)
end

-- отношения VJ: игрок — союзник только своей стороны
local function ApplyRelations(client)
	local faction = SWS.GetFaction(client)

	client.VJ_NPC_Class = faction and {faction.vjClass} or {"CLASS_SWS_NEUTRAL"}
end

local function SetMode(client, mode)
	client:SetNW2Int("SWS_Mode", mode)
	client.SWS_WantedMode = mode
end

-- командир: невидим, неуязвим, без оружия, NPC его не замечают; позицию двигает камера
local function SetupCommander(client)
	client:StripWeapons()
	client:SetNoDraw(true)
	client:DrawShadow(false)
	client:SetNotSolid(true)
	client:SetCollisionGroup(COLLISION_GROUP_IN_VEHICLE)
	client:GodEnable()
	client:SetNoTarget(true)
	client:SetMoveType(MOVETYPE_NOCLIP)
	client:SetAvoidPlayers(false)
	client:DrawViewModel(false)
end

local function SetupFree(client)
	client:SetNoDraw(false)
	client:DrawShadow(true)
	client:SetNotSolid(false)
	client:SetCollisionGroup(COLLISION_GROUP_PLAYER)
	client:GodDisable()
	client:SetNoTarget(false)
	client:SetMoveType(MOVETYPE_WALK)
	client:DrawViewModel(true)

	-- бластеры своей стороны (если не выбрано снаряжение на экране высадки)
	local faction = SWS.GetFaction(client)

	if (faction and !client.SWS_Loadout) then
		for _, choices in ipairs(faction.weapons) do
			for _, class in ipairs(choices) do
				if (weapons.GetStored(class)) then
					client:Give(class)
					break
				end
			end
		end

		local first = faction.weapons[1]

		for _, class in ipairs(first or {}) do
			if (client:HasWeapon(class)) then
				client:SelectWeapon(class)
				break
			end
		end
	end
end

function GM:PlayerInitialSpawn(client, transition)
	self.BaseClass.PlayerInitialSpawn(self, client, transition)

	SetMode(client, SWS.MODE_MENU)
	client:SetNW2Int("SWS_Side", 0)
	client:SetTeam(TEAM_UNASSIGNED)
end

function GM:PlayerSpawn(client, transition)
	ApplyRelations(client)

	-- после выхода из бойца (контроллер VJ убивает и возрождает игрока) — обратно в командование
	if (client.SWS_ReturnToCommander) then
		client.SWS_ReturnToCommander = nil
		SetMode(client, SWS.MODE_COMMANDER)
	end

	local mode = SWS.GetMode(client)

	if (mode == SWS.MODE_FREE) then
		self.BaseClass.PlayerSpawn(self, client, transition)
		SetupFree(client)

		-- снаряжение и точка с экрана высадки
		if (client.SWS_Loadout) then
			SWS.ApplyLoadout(client)
		end

		SWS.ApplyDeployPoint(client)
		return
	end

	-- меню выбора стороны и командир: без тела в мире
	player_manager.SetPlayerClass(client, "player_sandbox")
	client:UnSpectate()
	client:SetupHands()
	player_manager.OnPlayerSpawn(client, transition)
	player_manager.RunClass(client, "Spawn")
	hook.Call("PlayerSetModel", self, client)

	SetupCommander(client)

	if (client.SWS_CameraFocus) then
		client:SetPos(client.SWS_CameraFocus)
	end
end

-- в режиме командира оружие не выдаём (песочница выдаёт физган и тулган)
function GM:PlayerLoadout(client)
	if (SWS.GetMode(client) != SWS.MODE_FREE) then
		return true
	end

	return self.BaseClass.PlayerLoadout(self, client)
end

-- в бою после гибели игрок возрождается через экран высадки (SWS_Deploy); командира убить нельзя
function GM:PlayerDeathThink(client)
	local mode = SWS.GetMode(client)

	if (mode == SWS.MODE_COMMANDER or mode == SWS.MODE_MENU) then
		client:Spawn()
		return true
	end

	if (mode == SWS.MODE_FREE and SWS.GetFaction(client)) then
		return
	end

	return self.BaseClass.PlayerDeathThink(self, client)
end

-- командир не может подбирать оружие и пользоваться предметами
function GM:PlayerCanPickupWeapon(client, weapon)
	if (SWS.GetMode(client) != SWS.MODE_FREE) then
		return false
	end

	return self.BaseClass.PlayerCanPickupWeapon(self, client, weapon)
end

function GM:PlayerUse(client, entity)
	if (SWS.GetMode(client) != SWS.MODE_FREE) then
		return false
	end

	return self.BaseClass.PlayerUse(self, client, entity)
end

-- носклип в свободном режиме — как в песочнице; командиру не нужен
function GM:PlayerNoClip(client, desired)
	if (SWS.GetMode(client) != SWS.MODE_FREE) then
		return false
	end

	return self.BaseClass.PlayerNoClip(self, client, desired)
end

-- командир стоит на месте: камера своя, движение игрока не нужно
hook.Add("StartCommand", "SWS_CommanderInput", function(client, command)
	local mode = SWS.GetMode(client)

	if (mode == SWS.MODE_COMMANDER or mode == SWS.MODE_MENU) then
		command:ClearMovement()
		command:ClearButtons()
	end
end)

-- выбор стороны
net.Receive("SWS_ChooseSide", function(length, client)
	local index = net.ReadUInt(4)
	local faction = SWS.Factions[index]

	if (!faction or (client.SWS_NextSide or 0) > CurTime()) then
		return
	end

	client.SWS_NextSide = CurTime() + 2

	local oldSide = client:GetNW2Int("SWS_Side", 0)

	-- смена стороны: старые войска распускаются
	if (oldSide != 0 and oldSide != index) then
		SWS.DismissAll(client)
	end

	client:SetNW2Int("SWS_Side", index)
	client:SetTeam(index)
	ApplyRelations(client)

	if (IsValid(client.VJ_TheControllerEntity)) then
		client.VJ_TheControllerEntity:StopControlling(true)
	end

	SetMode(client, SWS.MODE_COMMANDER)
	client:KillSilent()
	client:Spawn()

	PrintMessage(HUD_PRINTTALK, client:Nick() .. " воюет за: " .. faction.name)
end)

-- переключение командир <-> свободный режим
net.Receive("SWS_SetMode", function(length, client)
	local mode = net.ReadUInt(2)

	if (!SWS.GetFaction(client) or (client.SWS_NextMode or 0) > CurTime()) then
		return
	end

	client.SWS_NextMode = CurTime() + 0.5

	-- из бойца — через контроллер VJ (он сам возродит игрока)
	if (SWS.GetMode(client) == SWS.MODE_POSSESS) then
		SWS.StopPossess(client)
		return
	end

	if (mode != SWS.MODE_COMMANDER and mode != SWS.MODE_FREE) then
		return
	end

	-- выходим в свободный режим туда, куда смотрит камера
	local focus = client.SWS_CameraFocus

	SetMode(client, mode)
	client:KillSilent()
	client:Spawn()

	if (mode == SWS.MODE_FREE and focus) then
		local trace = util.TraceHull({
			start = focus + Vector(0, 0, 64),
			endpos = focus - Vector(0, 0, 256),
			mins = Vector(-16, -16, 0),
			maxs = Vector(16, 16, 72),
			filter = client
		})

		if (!trace.StartSolid) then
			client:SetPos(trace.HitPos)
		end
	end
end)

-- камера командира: точка на земле под центром экрана; игрок стоит там, чтобы слышать бой
-- и получать сущности вокруг (PVS)
net.Receive("SWS_Camera", function(length, client)
	local focus = net.ReadVector()
	local eye = net.ReadVector()

	if (SWS.GetMode(client) != SWS.MODE_COMMANDER) then
		return
	end

	if (!util.IsInWorld(focus)) then
		return
	end

	client.SWS_CameraFocus = focus
	client.SWS_CameraEye = util.IsInWorld(eye) and eye or focus
	client:SetPos(focus)
end)

-- видимость для командира: точка обзора камеры и места, где стоят его войска
function GM:SetupPlayerVisibility(client, viewEntity)
	if (SWS.GetMode(client) != SWS.MODE_COMMANDER) then
		return
	end

	if (client.SWS_CameraEye) then
		AddOriginToPVS(client.SWS_CameraEye)
	end

	-- войска: одна точка на квадрат 1024 юнита, чтобы не перегружать PVS
	local added = {}

	for _, entity in ipairs(SWS.GetUnits(client)) do
		local position = entity:GetPos()
		local key = math.floor(position.x / 1024) .. ":" .. math.floor(position.y / 1024)

		if (!added[key]) then
			added[key] = true
			AddOriginToPVS(position + Vector(0, 0, 32))
		end
	end
end

-- вселение в бойца: контроллер VJ Base, вид от первого лица
function SWS.Possess(client, npc)
	if (SWS.GetMode(client) != SWS.MODE_COMMANDER or client.VJ_IsControllingNPC or IsValid(client.SWS_Controller)) then
		return false
	end

	if (!IsValid(npc) or !npc.IsVJBaseSNPC or npc.VJ_IsBeingControlled or npc:Health() <= 0) then
		return false
	end

	if (!scripted_ents.GetStored("obj_vj_controller")) then
		SWS.Notify(client, "Контроллер VJ Base не найден — обновите VJ Base.", 2)
		return false
	end

	local controller = ents.Create("obj_vj_controller")

	if (!IsValid(controller)) then
		return false
	end

	SetMode(client, SWS.MODE_POSSESS)
	client:SetNoDraw(false)
	client:SetNotSolid(false)
	client:GodDisable()

	controller.VJCE_Player = client
	controller:SetControlledNPC(npc)
	controller:Spawn()
	controller:StartControlling()

	-- сразу от первого лица, после выхода — обратно в командира
	controller.VJC_Camera_Mode = 2
	controller.VJC_Player_CanRespawn = true
	controller.VJC_Player_CanExit = true

	local oldStop = controller.OnStopControlling

	-- контроллер уже возродил игрока и вернул ему видимость — делаем из него снова командира
	controller.OnStopControlling = function(this, keyPressed)
		if (oldStop) then
			oldStop(this, keyPressed)
		end

		if (!IsValid(client)) then
			return
		end

		client.SWS_CameraFocus = IsValid(npc) and npc:GetPos() or client.SWS_CameraFocus
		client.SWS_Controller = nil

		-- камера командира — туда, где был боец
		if (client.SWS_CameraFocus) then
			client:SetNW2Vector("SWS_FocusTo", client.SWS_CameraFocus)
			client:SetNW2Float("SWS_FocusAt", CurTime())
		end
		client:SetNW2Entity("SWS_Possessed", NULL)

		if (SWS.GetMode(client) != SWS.MODE_POSSESS) then
			return
		end

		SetMode(client, SWS.MODE_COMMANDER)

		timer.Simple(0, function()
			if (!IsValid(client)) then
				return
			end

			if (!client:Alive()) then
				client:Spawn()
			else
				SetupCommander(client)
			end

			if (client.SWS_CameraFocus) then
				client:SetPos(client.SWS_CameraFocus)
			end
		end)
	end

	client.SWS_Controller = controller
	client:SetNW2Entity("SWS_Possessed", npc)

	return true
end

function SWS.StopPossess(client)
	local controller = client.SWS_Controller

	if (IsValid(controller)) then
		controller:StopControlling(true)
	else
		client.SWS_ReturnToCommander = true
		client:KillSilent()
		client:Spawn()
	end

	client:SetNW2Entity("SWS_Possessed", NULL)
end

-- F2 — выбор стороны, F3 — командир / свободный режим (обрабатывает клиент)
function GM:ShowTeam(client)
	client:ConCommand("sws_sidemenu")
end

function GM:ShowHelp(client)
	client:ConCommand("sws_help")
end

function GM:ShowSpare1(client)
	client:ConCommand("sws_togglemode")
end

hook.Add("PlayerDisconnected", "SWS_Cleanup", function(client)
	SWS.DismissAll(client)
end)
