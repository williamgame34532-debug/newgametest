--[[
	ИИ-командиры: стороны без игроков (или назначенные админом) воюют сами.
	- место базы — случайная доступная точка: узлы AI-навигации карты (их же используют NPC),
	  иначе навмеш, иначе точки появления игроков; выбирается подальше от других сторон;
	- строят командный пост, казармы и завод техники рядом с базой, отстраивают разрушенное;
	- держат очереди производства заполненными (пехота, специалисты, элита, техника);
	- точка сбора — у базы; при угрозе зданиям поднимают ближайших бойцов на защиту;
	- набрав отряд, идут волной на ближайший чужой или нейтральный командный пост,
	  затем на здания врага.
	Консоль (админ): sws_ai 0/1, sws_ai_max, sws_ai_population, sws_ai_difficulty 1–3,
	sws_ai_add <republic|cis|empire|rebels>, sws_ai_remove <сторона>, sws_ai_clear.
]]

SWS.AI = SWS.AI or {commanders = {}}

local AI = SWS.AI
local THINK = 1.5

-- ===== доступные точки карты =====
local spots

local function CollectSpots()
	spots = {}

	-- узлы AI-навигации (VJ Base читает .ain карты)
	local graph = VJ_Nodegraph and VJ_Nodegraph.GetNodegraph and VJ_Nodegraph:GetNodegraph()

	if (graph and graph.Nodes) then
		for _, node in pairs(graph.Nodes) do
			if (node.type == 2 and node.pos) then
				spots[#spots + 1] = node.pos
			end
		end
	end

	-- навмеш
	if (#spots < 20 and navmesh and navmesh.IsLoaded and navmesh.IsLoaded()) then
		for _, area in ipairs(navmesh.GetAllNavAreas()) do
			if (area:GetSizeX() > 64 and area:GetSizeY() > 64 and !area:IsUnderwater()) then
				spots[#spots + 1] = area:GetCenter()
			end
		end
	end

	-- точки появления игроков и разброс вокруг них
	if (#spots < 20) then
		for _, class in ipairs({"info_player_start", "info_player_deathmatch", "info_player_combine", "info_player_rebel",
			"info_player_terrorist", "info_player_counterterrorist"}) do
			for _, entity in ipairs(ents.FindByClass(class)) do
				local origin = entity:GetPos()

				spots[#spots + 1] = origin

				for _ = 1, 12 do
					local angle = math.rad(math.random(0, 359))
					local distance = math.random(300, 2400)
					local position = origin + Vector(math.cos(angle) * distance, math.sin(angle) * distance, 0)
					local trace = util.TraceLine({
						start = position + Vector(0, 0, 256),
						endpos = position - Vector(0, 0, 1024),
						mask = MASK_SOLID_BRUSHONLY
					})

					if (trace.Hit and !trace.StartSolid and trace.HitNormal.z > 0.8) then
						spots[#spots + 1] = trace.HitPos
					end
				end
			end
		end
	end

	MsgC(Color(120, 200, 255), "[Star Wars Sandbox] ИИ: доступных точек карты — " .. #spots .. "\n")
end

local function GetSpots()
	if (!spots or #spots == 0) then
		CollectSpots()
	end

	return spots
end

-- случайная точка в кольце вокруг центра (или по всей карте)
local function RandomSpot(center, minDistance, maxDistance)
	local list = GetSpots()

	if (#list == 0) then
		return nil
	end

	for _ = 1, 40 do
		local spot = list[math.random(#list)]

		if (!center) then
			return spot
		end

		local distance = spot:Distance(center)

		if (distance >= minDistance and distance <= maxDistance) then
			return spot
		end
	end
end

-- место для здания у базы: перебираем точки и повороты, пока не встанет
local function FindBuildingSpot(ai, buildingType, minDistance, maxDistance)
	local info = SWS.Buildings[buildingType]

	for _ = 1, 25 do
		local spot = RandomSpot(ai.base, minDistance, maxDistance)

		if (!spot) then
			break
		end

		local ground = util.TraceLine({
			start = spot + Vector(0, 0, 64),
			endpos = spot - Vector(0, 0, 256),
			mask = MASK_SOLID_BRUSHONLY
		})

		if (ground.Hit) then
			-- фасадом к центру базы
			local yaw = ai.base and (ai.base - ground.HitPos):Angle().y or math.random(0, 359)

			if (SWS.CanPlaceBuilding(info, ground.HitPos, yaw)) then
				return ground.HitPos, yaw
			end
		end
	end
end

-- ===== состояние стороны =====
local function Units(ai)
	return SWS.GetUnits(ai.entity)
end

local function Buildings(ai, buildingType)
	local list = {}

	for _, building in ipairs(ents.FindByClass("sws_building")) do
		if (building:GetCommander() == ai.entity and (!buildingType or building:GetBuildingType() == buildingType)) then
			list[#list + 1] = building
		end
	end

	return list
end

local function IsEnemy(entity, sideIndex)
	if (!IsValid(entity)) then
		return false
	end

	if (entity:IsPlayer()) then
		return entity:Alive() and entity:Team() >= 1 and entity:Team() <= #SWS.Factions and entity:Team() != sideIndex
			and SWS.GetMode(entity) == SWS.MODE_FREE
	end

	if (entity:IsNPC()) then
		local side = entity:GetNW2Int("SWS_Side", 0)

		return side > 0 and side != sideIndex and entity:Health() > 0
	end

	return false
end

-- ===== выбор базы: подальше от других сторон =====
local function ChooseBase(ai)
	local others = {}

	for _, other in pairs(AI.commanders) do
		if (other != ai and other.base) then
			others[#others + 1] = other.base
		end
	end

	for _, building in ipairs(ents.FindByClass("sws_building")) do
		if (building:GetSide() != ai.faction.index and building:GetSide() != 0) then
			others[#others + 1] = building:GetPos()
		end
	end

	for _, client in ipairs(player.GetAll()) do
		if (client:Team() != ai.faction.index) then
			others[#others + 1] = client:GetPos()
		end
	end

	local best, bestScore

	for _ = 1, 40 do
		local spot = RandomSpot()

		if (!spot) then
			break
		end

		local score = 1e9

		for _, other in ipairs(others) do
			score = math.min(score, spot:Distance(other))
		end

		if (!bestScore or score > bestScore) then
			best, bestScore = spot, score
		end
	end

	return best
end

-- ===== постройка =====
local buildPlan = {
	{type = "command", count = 1, near = {0, 500}},
	{type = "barracks", count = 1, near = {350, 1100}},
	{type = "factory", count = 1, near = {450, 1400}},
	{type = "barracks", count = 2, near = {350, 1300}}
}

local function ThinkBuild(ai)
	if ((ai.nextBuild or 0) > CurTime()) then
		return
	end

	for _, step in ipairs(buildPlan) do
		local info = SWS.Buildings[step.type]
		local limit = GetConVar(info.limitConVar):GetInt()
		local have = #Buildings(ai, step.type)

		if (have < math.min(step.count, limit)) then
			ai.reach = ai.reach or {}

			local extra = ai.reach[step.type] or 0
			local position, yaw = FindBuildingSpot(ai, step.type, step.near[1], step.near[2] + extra)

			if (position) then
				SWS.CreateBuilding(step.type, position, yaw, ai.faction.index, ai.entity)
				ai.nextBuild = CurTime() + 12
			else
				-- не нашлось места — попробуем позже и шире
				ai.reach[step.type] = math.min(extra + 300, 3000)
				ai.nextBuild = CurTime() + 4
			end

			return
		end
	end
end

-- ===== производство =====
local roleWeights = {["Пехота"] = 55, ["Специалисты"] = 30, ["Элита"] = 15}

local function PickUnit(ai, building)
	local info = building:GetInfo()
	local candidates, total = {}, 0
	local units = SWS.Units[ai.faction.id] or {}

	for _, unit in ipairs(units) do
		if (info.produces[unit.role]) then
			local weight

			if (unit.role == "Техника") then
				-- турели и самые тяжёлые шагоходы — реже
				weight = unit.tier >= 4 and 8 or (unit.id == "sentry" and 4 or 20)
			else
				weight = (roleWeights[unit.role] or 10) / math.max(unit.tier, 1)
			end

			candidates[#candidates + 1] = {unit, weight}
			total = total + weight
		end
	end

	local roll = math.Rand(0, total)

	for _, entry in ipairs(candidates) do
		roll = roll - entry[2]

		if (roll <= 0) then
			return entry[1]
		end
	end

	return candidates[1] and candidates[1][1]
end

local function ThinkProduction(ai)
	for _, building in ipairs(Buildings(ai)) do
		local info = building:GetInfo()

		if (!info or !info.produces or !building:IsBuilt()) then
			continue
		end

		-- сбор — между зданием и центром базы
		if (!building:GetHasRally() and ai.base) then
			building:SetRally(LerpVector(0.6, building:GetExitPos(1), ai.base))
			building:SetHasRally(true)
		end

		local queue = SWS.ParseQueue(building:GetQueue())

		if (#queue < 2) then
			local unit = PickUnit(ai, building)

			if (unit) then
				queue[#queue + 1] = {id = unit.id, variant = math.random(#unit.variants)}
				building:SetQueue(SWS.SerializeQueue(queue))
			end
		end
	end
end

-- ===== оборона и атаки =====
local function ThinkArmy(ai)
	local units = Units(ai)
	local now = CurTime()
	local side = ai.faction.index
	local difficulty = math.Clamp(GetConVar("sws_ai_difficulty"):GetInt(), 1, 3)

	-- оборона: враги у наших зданий
	for _, building in ipairs(Buildings(ai)) do
		local threat

		for _, entity in ipairs(ents.FindInSphere(building:GetPos(), 1100)) do
			if (IsEnemy(entity, side)) then
				threat = entity
				break
			end
		end

		if (threat and (ai.nextDefense or 0) < now) then
			ai.nextDefense = now + 6

			local defenders = {}

			for _, npc in ipairs(units) do
				if (npc:GetPos():Distance(building:GetPos()) < 2000 and !npc.SWS_Order) then
					defenders[#defenders + 1] = npc
				end
			end

			if (#defenders > 0) then
				SWS.OrderGroup(defenders, SWS.ORDER_ATTACK, threat:GetPos(), true)
			end

			break
		end
	end

	-- волна: набрали отряд — в атаку
	local idle = {}

	for _, npc in ipairs(units) do
		if (!npc.SWS_Order and !npc.SWS_InWave) then
			idle[#idle + 1] = npc
		end
	end

	local garrison = 3
	local waveSize = ({5, 7, 9})[difficulty] + math.min(math.floor((now - ai.started) / 300), 6)

	if (#idle - garrison < waveSize or (ai.nextWave or 0) > now) then
		return
	end

	local target = AI.FindTarget(ai)

	if (!target) then
		return
	end

	local wave = {}

	for index = garrison + 1, #idle do
		local npc = idle[index]

		npc.SWS_InWave = true
		wave[#wave + 1] = npc
	end

	SWS.OrderGroup(wave, SWS.ORDER_ATTACK, target, true)

	ai.nextWave = now + ({90, 60, 40})[difficulty]
end

-- цель волны: ближайший не наш пост, затем вражеские здания, затем враги
function AI.FindTarget(ai)
	local side = ai.faction.index
	local origin = ai.base or vector_origin
	local best, bestDistance

	for _, building in ipairs(ents.FindByClass("sws_building")) do
		if (building:GetBuildingType() == "command" and building:GetSide() != side) then
			local distance = building:GetPos():Distance(origin)

			if (!bestDistance or distance < bestDistance) then
				best, bestDistance = building:GetPos(), distance
			end
		end
	end

	if (best) then
		return best
	end

	for _, building in ipairs(ents.FindByClass("sws_building")) do
		if (building:GetSide() != side and building:GetSide() != 0) then
			local distance = building:GetPos():Distance(origin)

			if (!bestDistance or distance < bestDistance) then
				best, bestDistance = building:GetPos(), distance
			end
		end
	end

	if (best) then
		return best
	end

	for _, npc in ipairs(ents.FindByClass("npc_*")) do
		if (IsEnemy(npc, side)) then
			local distance = npc:GetPos():Distance(origin)

			if (!bestDistance or distance < bestDistance) then
				best, bestDistance = npc:GetPos(), distance
			end
		end
	end

	-- врагов нет — разведка в случайную доступную точку
	return best or RandomSpot(origin, 1500, 8000)
end

-- ===== жизненный цикл =====
function AI.Add(faction)
	if (AI.commanders[faction.id]) then
		return AI.commanders[faction.id]
	end

	local entity = ents.Create("sws_ai_commander")
	entity:SetSide(faction.index)
	entity:SetCommanderName("ИИ · " .. faction.short)
	entity:Spawn()

	local ai = {faction = faction, entity = entity, started = CurTime()}
	ai.base = ChooseBase(ai)

	if (!ai.base) then
		entity:Remove()
		MsgC(Color(255, 120, 80), "[Star Wars Sandbox] ИИ: не нашлось места для базы (" .. faction.short .. ")\n")
		return
	end

	entity:SetPos(ai.base)
	AI.commanders[faction.id] = ai

	SWS.Broadcast("ИИ-командир вступил в бой: " .. faction.name, 1)

	return ai
end

function AI.Remove(faction)
	local ai = AI.commanders[faction.id]

	if (!ai) then
		return
	end

	if (IsValid(ai.entity)) then
		SWS.DismissAll(ai.entity)
		ai.entity:Remove()
	end

	AI.commanders[faction.id] = nil
end

-- auto: ИИ для сторон, за которые никто не играет
local function ThinkAuto()
	if (!GetConVar("sws_ai"):GetBool()) then
		for _, faction in ipairs(SWS.Factions) do
			if (AI.commanders[faction.id] and !AI.commanders[faction.id].bManual) then
				AI.Remove(faction)
			end
		end

		return
	end

	local count = table.Count(AI.commanders)
	local limit = GetConVar("sws_ai_max"):GetInt()

	for _, faction in ipairs(SWS.Factions) do
		if (count >= limit) then
			break
		end

		if (!AI.commanders[faction.id] and #team.GetPlayers(faction.index) == 0) then
			if (AI.Add(faction)) then
				count = count + 1
			end
		end
	end
end

timer.Create("SWS_AIThink", THINK, 0, function()
	if (#player.GetAll() == 0) then
		return
	end

	for id, ai in pairs(AI.commanders) do
		if (!IsValid(ai.entity)) then
			AI.commanders[id] = nil
			continue
		end

		ThinkBuild(ai)
		ThinkProduction(ai)
		ThinkArmy(ai)
	end
end)

-- первые ИИ — когда зашёл игрок и прогрузился VJ (узлы читаются через пару секунд после старта)
timer.Create("SWS_AIAuto", 20, 0, ThinkAuto)

hook.Add("PlayerInitialSpawn", "SWS_AIStart", function()
	timer.Simple(15, ThinkAuto)
end)

-- ===== консоль =====
local function FactionArg(arguments)
	local id = string.lower(arguments[1] or "")

	return SWS.FactionByID[id]
end

concommand.Add("sws_ai_add", function(client, command, arguments)
	if (IsValid(client) and !client:IsAdmin()) then
		return
	end

	local faction = FactionArg(arguments)

	if (faction) then
		local ai = AI.Add(faction)

		if (ai) then
			ai.bManual = true
		end
	else
		print("sws_ai_add republic|cis|empire|rebels")
	end
end)

concommand.Add("sws_ai_remove", function(client, command, arguments)
	if (IsValid(client) and !client:IsAdmin()) then
		return
	end

	local faction = FactionArg(arguments)

	if (faction) then
		AI.Remove(faction)
	end
end)

concommand.Add("sws_ai_clear", function(client)
	if (IsValid(client) and !client:IsAdmin()) then
		return
	end

	for _, faction in ipairs(SWS.Factions) do
		AI.Remove(faction)
	end
end)
