--[[
	Отрисовка в мире для командира: кольца под своими и выбранными бойцами, метки приказов,
	призрак строя при высадке, красная метка врага под курсором.
]]

local Cmd = SWS.Cmd

local ringMaterial = Material("sws/ring.png", "smooth mips")
local ringDashMaterial = Material("sws/ring_dash.png", "smooth mips")
local arrowMaterial = Material("sws/chevron.png", "smooth mips")

local vectorUp = Vector(0, 0, 1)

local function DrawRing(position, radius, color, material, rotation)
	material = material or ringMaterial

	if (material:IsError()) then
		cam.Start3D2D(position + vectorUp * 2, Angle(0, rotation or 0, 0), 1)
			surface.DrawCircle(0, 0, radius, color.r, color.g, color.b, color.a)
		cam.End3D2D()
		return
	end

	render.SetMaterial(material)
	render.DrawQuadEasy(position + vectorUp * 2, vectorUp, radius * 2, radius * 2, color, rotation or 0)
end

local function GroundBelow(entity)
	local position = entity:GetPos()

	return position
end

-- та же раскладка строя, что и на сервере (для призрака высадки)
local function FormationSlots(center, direction, count, spacing)
	local columns = math.max(1, math.ceil(math.sqrt(count * 1.6)))
	local rows = math.ceil(count / columns)
	local right = direction:Angle():Right()
	local slots = {}

	for i = 0, count - 1 do
		local row = math.floor(i / columns)
		local column = i % columns
		local inRow = math.min(columns, count - row * columns)

		slots[#slots + 1] = center + right * ((column - (inRow - 1) * 0.5) * spacing) - direction * ((row - (rows - 1) * 0.5) * spacing)
	end

	return slots
end

hook.Add("PostDrawTranslucentRenderables", "SWS_CommanderWorld", function(bDepth, bSkybox)
	if (bSkybox or !Cmd.IsActive()) then
		return
	end

	local faction = SWS.GetFaction(LocalPlayer())
	local color = faction and faction.color or color_white
	local now = RealTime()

	-- свои бойцы: тонкое кольцо, выбранные — яркое вращающееся
	for _, entity in ipairs(Cmd.units) do
		if (!IsValid(entity)) then
			continue
		end

		local radius = math.max(entity:OBBMaxs().x - entity:OBBMins().x, 24) * 0.75

		if (Cmd.selection[entity]) then
			DrawRing(GroundBelow(entity), radius, Color(color.r, color.g, color.b, 235), ringMaterial)
			DrawRing(GroundBelow(entity), radius * 1.18, Color(255, 255, 255, 90), ringDashMaterial, now * 40 % 360)
		else
			DrawRing(GroundBelow(entity), radius * 0.9, Color(color.r, color.g, color.b, 55), ringMaterial)
		end
	end

	-- метки приказов: расходящееся кольцо и шевроны
	for index = #Cmd.markers, 1, -1 do
		local marker = Cmd.markers[index]
		local age = now - marker.start

		if (age > 1.2 or (marker.entity and !IsValid(marker.entity))) then
			table.remove(Cmd.markers, index)
			continue
		end

		local fade = 1 - age / 1.2
		local markerColor = (marker.order == SWS.ORDER_ATTACK or marker.order == SWS.ORDER_TARGET) and Color(240, 70, 60)
			or (marker.order == 0 and Color(255, 255, 255) or color)
		local position = marker.entity and marker.entity:GetPos() or marker.position

		DrawRing(position, 18 + age * 50, Color(markerColor.r, markerColor.g, markerColor.b, 255 * fade), ringMaterial)
		DrawRing(position, 12, Color(markerColor.r, markerColor.g, markerColor.b, 200 * fade), ringDashMaterial, age * 180)

		if (!arrowMaterial:IsError() and marker.order != SWS.ORDER_TARGET) then
			render.SetMaterial(arrowMaterial)

			for i = 0, 3 do
				local direction = Angle(0, i * 90 + 45, 0):Forward()

				render.DrawQuadEasy(position + vectorUp * 3 + direction * (30 - age * 14), vectorUp, 16, 16,
					Color(markerColor.r, markerColor.g, markerColor.b, 255 * fade), i * 90 + 45 + 180)
			end
		end
	end

	-- свои здания: точка сбора (флажок и пунктир от фасада), выбранное — кольцо
	for _, building in ipairs(Cmd.buildings or {}) do
		if (!IsValid(building)) then
			continue
		end

		local info = building:GetInfo()
		local bSelected = Cmd.building == building
		local rally = building:GetRally()

		if (bSelected and info) then
			local radius = math.max(info.maxs.x, info.maxs.y) * 1.25

			DrawRing(building:GetPos(), radius, Color(color.r, color.g, color.b, 200), ringMaterial)
			DrawRing(building:GetPos(), radius * 1.06, Color(255, 255, 255, 80), ringDashMaterial, now * 20 % 360)
		end

		if (building:GetHasRally() and info and (bSelected or info.produces)) then
			local rallyColor = building:GetRallyAttack() and Color(240, 70, 60) or color
			local alpha = bSelected and 255 or 90
			local start = building:GetExitPos(1)

			render.SetColorMaterial()

			-- пунктир по земле
			local distance = start:Distance(rally)
			local direction = (rally - start):GetNormalized()

			for d = 0, distance, 40 do
				local a = start + direction * d + vectorUp * 4
				local b = start + direction * math.min(d + 22, distance) + vectorUp * 4

				render.DrawBeam(a, b, 3, 0, 1, Color(rallyColor.r, rallyColor.g, rallyColor.b, alpha))
			end

			-- флажок
			render.DrawBeam(rally, rally + vectorUp * 64, 2, 0, 1, Color(255, 255, 255, alpha))
			render.DrawQuadEasy(rally + vectorUp * 54 + Angle(0, EyeAngles().y + 90, 0):Forward() * 10, -EyeAngles():Forward(),
				20, 14, Color(rallyColor.r, rallyColor.g, rallyColor.b, alpha), 0)

			DrawRing(rally, 22, Color(rallyColor.r, rallyColor.g, rallyColor.b, alpha), ringDashMaterial, now * 60 % 360)
		end
	end

	local panel = Cmd.panel

	if (!IsValid(panel)) then
		return
	end

	-- призрак здания при постройке
	if (Cmd.placingBuilding and vgui.GetHoveredPanel() == panel) then
		local x, y = panel:CursorPos()
		local trace = Cmd.TraceScreen(x, y, true)
		local info = SWS.Buildings[Cmd.placingBuilding.type]

		if (trace.Hit and info) then
			local angles = Angle(0, Cmd.placingBuilding.yaw, 0)
			local pulse = 0.6 + math.sin(now * 5) * 0.2

			render.SetColorMaterial()
			render.DrawBox(trace.HitPos, angles, info.mins, info.maxs, Color(color.r, color.g, color.b, 40 * pulse))
			render.DrawWireframeBox(trace.HitPos, angles, info.mins, info.maxs, Color(255, 255, 255, 200), true)

			-- стрелка фасада: куда выходят бойцы
			local front = trace.HitPos + angles:Forward() * (info.maxs.x + 40) + vectorUp * 6

			if (!arrowMaterial:IsError()) then
				render.SetMaterial(arrowMaterial)
				render.DrawQuadEasy(front, vectorUp, 40, 40, Color(color.r, color.g, color.b, 230), Cmd.placingBuilding.yaw + 90)
			end
		end
	end

	local x, y = panel:CursorPos()

	-- призрак строя при высадке
	if (Cmd.placing and vgui.GetHoveredPanel() == panel) then
		local trace = Cmd.TraceScreen(x, y, true)

		if (trace.Hit) then
			local unit = Cmd.placing.unit
			local spacing = 52 * math.max(unit.size, 1) ^ 0.75
			local slots = FormationSlots(trace.HitPos, Angle(0, Cmd.yaw, 0):Forward(), Cmd.placing.count, spacing)
			local pulse = 0.6 + math.sin(now * 6) * 0.25

			for _, slot in ipairs(slots) do
				DrawRing(slot, 14 * math.max(unit.size, 1) ^ 0.6, Color(color.r, color.g, color.b, 220 * pulse), ringMaterial)
			end

			DrawRing(trace.HitPos, spacing * 1.2 + #slots * 3, Color(255, 255, 255, 60), ringDashMaterial, now * 30)
		end
	end

	-- враг под курсором
	if (!Cmd.placing and table.Count(Cmd.selection) > 0 and vgui.GetHoveredPanel() == panel) then
		local enemy = Cmd.EnemyAt(x, y)

		if (enemy) then
			local radius = math.max(enemy:OBBMaxs().x - enemy:OBBMins().x, 24) * 0.8

			DrawRing(enemy:GetPos(), radius, Color(240, 60, 50, 230), ringMaterial)
			DrawRing(enemy:GetPos(), radius * 1.25, Color(240, 60, 50, 120), ringDashMaterial, -now * 60)
		end
	end
end)
