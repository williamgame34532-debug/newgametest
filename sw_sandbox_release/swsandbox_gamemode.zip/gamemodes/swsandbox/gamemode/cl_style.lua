--[[
	Стиль интерфейса в духе Star Wars Battlefront: тёмные полупрозрачные плашки с размытием,
	тонкие белые линии, крупные узкие заголовки (Oswald), текст Exo 2, выбранное — белая заливка
	с тёмным текстом, акцент — цвет стороны. Шрифты лежат в контенте (resource/fonts/SWS*.ttf).
]]

SWS.UI = SWS.UI or {}

local UI = SWS.UI

UI.colors = {
	bg = Color(6, 8, 11, 235),
	panel = Color(12, 15, 20, 205),
	panelLight = Color(28, 33, 41, 215),
	line = Color(255, 255, 255, 32),
	lineBright = Color(255, 255, 255, 120),
	text = Color(242, 244, 247),
	dim = Color(158, 166, 178),
	dark = Color(14, 16, 20),
	danger = Color(232, 68, 58),
	good = Color(96, 210, 120)
}

local function CreateFonts()
	local function font(name, face, size, weight, minimum)
		surface.CreateFont(name, {
			font = face,
			size = math.max(math.Round(ScreenScale(size)), minimum or 12),
			weight = weight,
			extended = true,
			antialias = true
		})
	end

	font("SWSHuge", "SWS Oswald Bold", 30, 700, 56)
	font("SWSTitle", "SWS Oswald Bold", 15, 700, 30)
	font("SWSHeader", "SWS Oswald Semi", 9.5, 600, 20)
	font("SWSTab", "SWS Oswald Regular", 7.5, 400, 16)
	font("SWSLabel", "SWS Exo Semi", 6, 600, 14)
	font("SWSBody", "SWS Exo Regular", 5.8, 400, 14)
	font("SWSSmall", "SWS Exo Semi", 4.6, 600, 11)
	font("SWSTiny", "SWS Exo Bold", 3.9, 700, 10)
	font("SWSKey", "SWS Exo Bold", 4.4, 700, 11)
	font("SWSNumber", "SWS Oswald Bold", 9, 700, 20)
end

CreateFonts()
hook.Add("OnScreenSizeChanged", "SWS_Fonts", CreateFonts)

local materials = {}

function UI.Material(path, params)
	local key = path .. (params or "")

	if (!materials[key]) then
		materials[key] = Material(path, params or "smooth mips")
	end

	return materials[key]
end

-- иконка юнита из VJ-пака (materials/entities/<класс>.png)
function UI.UnitIcon(class)
	return UI.Material("entities/" .. string.lower(class) .. ".png")
end

local gradientUp = Material("vgui/gradient-u")
local gradientDown = Material("vgui/gradient-d")
local gradientLeft = Material("vgui/gradient-l")
local gradientRight = Material("vgui/gradient-r")

function UI.Gradient(x, y, w, h, color, direction)
	surface.SetMaterial((direction == "up" and gradientUp) or (direction == "left" and gradientLeft)
		or (direction == "right" and gradientRight) or gradientDown)
	surface.SetDrawColor(color)
	surface.DrawTexturedRect(x, y, w, h)
end

local blur = Material("pp/blurscreen")

-- размытие под панелью (координаты панели)
function UI.Blur(panel, amount)
	local x, y = panel:LocalToScreen(0, 0)

	surface.SetMaterial(blur)
	surface.SetDrawColor(255, 255, 255, 255)

	for i = 1, 3 do
		blur:SetFloat("$blur", (i / 3) * (amount or 5))
		blur:Recompute()
		render.UpdateScreenEffectTexture()
		surface.DrawTexturedRect(-x, -y, ScrW(), ScrH())
	end
end

-- плашка Battlefront: тёмная, тонкая светлая линия сверху
function UI.Panel(x, y, w, h, alpha, accent)
	alpha = alpha or 1

	surface.SetDrawColor(UI.colors.panel.r, UI.colors.panel.g, UI.colors.panel.b, UI.colors.panel.a * alpha)
	surface.DrawRect(x, y, w, h)

	surface.SetDrawColor(255, 255, 255, 22 * alpha)
	surface.DrawOutlinedRect(x, y, w, h)

	if (accent) then
		surface.SetDrawColor(accent.r, accent.g, accent.b, 255 * alpha)
		surface.DrawRect(x, y, w, 2)
	end
end

-- уголки рамки
function UI.Corners(x, y, w, h, length, color, thickness)
	thickness = thickness or 2
	surface.SetDrawColor(color)

	surface.DrawRect(x, y, length, thickness)
	surface.DrawRect(x, y, thickness, length)
	surface.DrawRect(x + w - length, y, length, thickness)
	surface.DrawRect(x + w - thickness, y, thickness, length)
	surface.DrawRect(x, y + h - thickness, length, thickness)
	surface.DrawRect(x, y + h - length, thickness, length)
	surface.DrawRect(x + w - length, y + h - thickness, length, thickness)
	surface.DrawRect(x + w - thickness, y + h - length, thickness, length)
end

-- текст с разрядкой (заголовки Battlefront)
function UI.Spaced(text, font, x, y, color, spacing, alignX, alignY)
	surface.SetFont(font)

	local chars = {}
	local total = 0

	for _, code in utf8.codes(text) do
		local char = utf8.char(code)
		local width = surface.GetTextSize(char)

		chars[#chars + 1] = {char, width}
		total = total + width + spacing
	end

	total = math.max(total - spacing, 0)

	local _, height = surface.GetTextSize("W")

	if (alignX == TEXT_ALIGN_CENTER) then
		x = x - total * 0.5
	elseif (alignX == TEXT_ALIGN_RIGHT) then
		x = x - total
	end

	if (alignY == TEXT_ALIGN_CENTER) then
		y = y - height * 0.5
	elseif (alignY == TEXT_ALIGN_BOTTOM) then
		y = y - height
	end

	surface.SetTextColor(color)

	for _, data in ipairs(chars) do
		surface.SetTextPos(x, y)
		surface.DrawText(data[1])
		x = x + data[2] + spacing
	end

	return total, height
end

-- клавиша-подсказка: светлая рамка с буквой
function UI.Key(text, x, y, alpha, alignX)
	alpha = alpha or 255

	surface.SetFont("SWSKey")

	local textW, textH = surface.GetTextSize(text)
	local w, h = math.max(textW + 10, textH + 6), textH + 6

	if (alignX == TEXT_ALIGN_RIGHT) then
		x = x - w
	elseif (alignX == TEXT_ALIGN_CENTER) then
		x = x - w * 0.5
	end

	surface.SetDrawColor(255, 255, 255, alpha * 0.9)
	surface.DrawOutlinedRect(x, y, w, h, 1)

	surface.SetDrawColor(255, 255, 255, alpha * 0.08)
	surface.DrawRect(x + 1, y + 1, w - 2, h - 2)

	draw.SimpleText(text, "SWSKey", x + w * 0.5, y + h * 0.5, Color(255, 255, 255, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

	return w, h
end

-- обрезать строку под ширину с многоточием
function UI.Fit(text, font, maxWidth)
	surface.SetFont(font)

	if (surface.GetTextSize(text) <= maxWidth) then
		return text
	end

	local length = utf8.len(text) or #text

	while (length > 1) do
		length = length - 1

		local result = string.sub(text, 1, (utf8.offset(text, length + 1) or (#text + 1)) - 1) .. "…"

		if (surface.GetTextSize(result) <= maxWidth) then
			return result
		end
	end

	return text
end

-- звуки интерфейса (стандартные звуки Half-Life 2 / GMod)
function UI.Sound(kind)
	if (kind == "hover") then
		surface.PlaySound("ui/buttonrollover.wav")
	elseif (kind == "click") then
		surface.PlaySound("ui/buttonclick.wav")
	elseif (kind == "error") then
		surface.PlaySound("buttons/button10.wav")
	elseif (kind == "order") then
		surface.PlaySound("buttons/blip1.wav")
	elseif (kind == "spawn") then
		surface.PlaySound("buttons/button14.wav")
	end
end

-- уведомления (сервер шлёт SWS_Notify)
UI.notices = UI.notices or {}

function UI.Notify(text, kind)
	table.insert(UI.notices, 1, {text = text, kind = kind or 0, start = RealTime()})
	UI.notices[6] = nil

	if (kind == 2) then
		UI.Sound("error")
	end
end

net.Receive("SWS_Notify", function()
	UI.Notify(net.ReadString(), net.ReadUInt(2))
end)

function UI.PaintNotices(centerX, y)
	local now = RealTime()

	for index = #UI.notices, 1, -1 do
		local notice = UI.notices[index]

		if (now - notice.start > 4.5) then
			table.remove(UI.notices, index)
		end
	end

	for _, notice in ipairs(UI.notices) do
		local age = now - notice.start
		local alpha = math.Clamp(math.min(age / 0.15, (4.5 - age) / 0.4), 0, 1)
		local color = notice.kind == 2 and UI.colors.danger or (notice.kind == 1 and Color(240, 190, 60) or UI.colors.text)

		surface.SetFont("SWSLabel")

		local textW, textH = surface.GetTextSize(notice.text)
		local w, h = textW + ScreenScale(14), textH + ScreenScale(5)

		UI.Panel(centerX - w * 0.5, y, w, h, alpha)

		surface.SetDrawColor(color.r, color.g, color.b, 255 * alpha)
		surface.DrawRect(centerX - w * 0.5, y, 3, h)

		draw.SimpleText(notice.text, "SWSLabel", centerX, y + h * 0.5, ColorAlpha(UI.colors.text, 255 * alpha),
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

		y = y + h + 4
	end
end
