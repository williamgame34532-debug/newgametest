--[[
	Снаряжение игрока как в Battlefront: четыре класса на сторону — Штурмовик, Тяжёлый, Специалист, Офицер.
	У класса — основное оружие (выбор из трёх), пистолет, снаряжение (граната / ракетомёт), здоровье, броня, скорость.
	Оружие — TFA «Star Wars Upgraded»; если TFA нет, берётся аналог из «Star Wars Weapons» (weapon_752_*).
	Формат оружия: {"название", "класс TFA", "запасной класс"}.
]]

local function W(name, tfa, fallback)
	return {name = name, classes = {tfa, fallback}}
end

local GRENADE_THERMAL = W("Термальный детонатор", "tfa_sw_grenade_thermal", "weapon_swrc_det")
local GRENADE_IMPACT = W("Ударная граната", "tfa_sw_grenade_impact", "weapon_swrc_det")
local GRENADE_BACTA = W("Бакта-граната", "tfa_sw_grenade_bacta", nil)
local GRENADE_FLASH = W("Светошумовая", "tfa_sw_grenade_flash", nil)
local GRENADE_STUN = W("Оглушающая", "tfa_sw_grenade_stun", nil)
local GRENADE_SMOKE = W("Дымовая", "tfa_sw_grenade_smoke", nil)

SWS.Classes = {
	{id = "assault", name = "Штурмовик", icon = "assault", description = "Универсальный боец передовой.",
		health = 100, armor = 50, speed = 1},
	{id = "heavy", name = "Тяжёлый", icon = "heavy", description = "Пулемёт и ракеты. Медленный, но крепкий.",
		health = 150, armor = 75, speed = 0.85},
	{id = "specialist", name = "Специалист", icon = "specialist", description = "Снайпер: дальний бой и разведка.",
		health = 90, armor = 25, speed = 1.05},
	{id = "officer", name = "Офицер", icon = "officer", description = "Пистолеты и поддержка отряда.",
		health = 110, armor = 50, speed = 1}
}

SWS.Loadouts = {
	republic = {
		assault = {
			primary = {W("DC-15A", "tfa_sw_blaster_dc15a_upgrade", "weapon_752_dc15a"), W("DC-17m", "tfa_sw_blaster_dc17m_upgrade", "weapon_752_dc17m_br"),
				W("Westar-11", "tfa_sw_blaster_westar11_upgrade", "weapon_752_westar34")},
			secondary = {W("DC-17", "tfa_sw_blaster_dc17_upgrade", "weapon_752_dc17"), W("DC-17 удлинённый", "tfa_sw_blaster_dc17s_upgrade", "weapon_752_dc17")},
			gadget = {GRENADE_THERMAL, GRENADE_IMPACT}
		},
		heavy = {
			primary = {W("Z-6", "tfa_sw_blaster_z6_upgrade", "weapon_752_dc15a"), W("DC-15LE", "tfa_sw_blaster_dc15le_upgrade", "weapon_752_dc15a"),
				W("TL-50", "tfa_sw_blaster_tl50_upgrade", "weapon_752_dc15a")},
			secondary = {W("DC-17", "tfa_sw_blaster_dc17_upgrade", "weapon_752_dc17")},
			gadget = {W("Ракетомёт PLX-1", "tfa_sw_rocket_plx1_upgrade", "weapon_752_dc17m_at"), GRENADE_THERMAL}
		},
		specialist = {
			primary = {W("Valken-38x", "tfa_sw_blaster_valken38x_upgrade", "weapon_752_dc17m_sn"), W("DC-19", "tfa_sw_blaster_dc19_upgrade", "weapon_752_dc15s"),
				W("IQA-11", "tfa_sw_blaster_iqa11_upgrade", "weapon_752_dc17m_sn")},
			secondary = {W("DC-17 удлинённый", "tfa_sw_blaster_dc17s_upgrade", "weapon_752_dc17")},
			gadget = {GRENADE_STUN, GRENADE_SMOKE}
		},
		officer = {
			primary = {W("DC-15S", "tfa_sw_blaster_dc15s_upgrade", "weapon_752_dc15s"), W("Westar-35", "tfa_sw_blaster_westar35_upgrade", "weapon_752_westar34"),
				W("SE-14C", "tfa_ibad_sw_blaster_se14c", "weapon_752_se14c")},
			secondary = {W("DC-17", "tfa_sw_blaster_dc17_upgrade", "weapon_752_dc17")},
			gadget = {GRENADE_BACTA, GRENADE_FLASH}
		}
	},
	cis = {
		assault = {
			primary = {W("E-5", "tfa_sw_blaster_e5_upgrade", "weapon_752_e5"), W("E-5 BX", "tfa_sw_blaster_e5bx_upgrade", "weapon_752_e5"),
				W("DP-24", "tfa_ibad_sw_blaster_dp24", "weapon_752_e5")},
			secondary = {W("SE-14C", "tfa_ibad_sw_blaster_se14c", "weapon_752_se14c"), W("RG-4D", "tfa_sw_blaster_rg4d_upgrade", "weapon_752_se14c")},
			gadget = {GRENADE_THERMAL, GRENADE_IMPACT}
		},
		heavy = {
			primary = {W("E-5C", "tfa_sw_blaster_e5c_upgrade", "weapon_752_e5"), W("TL-50C", "tfa_ibad_sw_blaster_tl50c", "weapon_752_e5"),
				W("Z-6I", "tfa_ibad_sw_blaster_z6i", "weapon_752_e5")},
			secondary = {W("SE-14C", "tfa_ibad_sw_blaster_se14c", "weapon_752_se14c")},
			gadget = {W("Ракетомёт E-60R", "tfa_sw_rocket_e60r_upgrade", "weapon_752_e60r"), GRENADE_THERMAL}
		},
		specialist = {
			primary = {W("E-5S", "tfa_sw_blaster_e5s_upgrade", "weapon_752_e5"), W("Valken-38", "tfa_ibad_sw_blaster_valken38", "weapon_752_e5"),
				W("IQA-11", "tfa_sw_blaster_iqa11_upgrade", "weapon_752_e5")},
			secondary = {W("RG-4D", "tfa_sw_blaster_rg4d_upgrade", "weapon_752_se14c")},
			gadget = {GRENADE_STUN, GRENADE_SMOKE}
		},
		officer = {
			primary = {W("SE-14", "tfa_ibad_sw_blaster_se14", "weapon_752_se14c"), W("P-108", "tfa_ibad_sw_blaster_p108", "weapon_752_se14c"),
				W("RK-3", "tfa_sw_blaster_rk3_upgrade", "weapon_752_se14c")},
			secondary = {W("SE-14C", "tfa_ibad_sw_blaster_se14c", "weapon_752_se14c")},
			gadget = {GRENADE_BACTA, GRENADE_FLASH}
		}
	},
	empire = {
		assault = {
			primary = {W("E-11", "tfa_sw_blaster_e11_upgrade", "weapon_752_e11"), W("E-11D", "tfa_sw_blaster_e11d_upgrade", "weapon_752_e11"),
				W("EE-3", "tfa_sw_blaster_ee3_upgrade", "weapon_752_ee3")},
			secondary = {W("SE-14R", "tfa_sw_blaster_se14r_upgrade", "weapon_752_se14c"), W("RK-3", "tfa_sw_blaster_rk3_upgrade", "weapon_752_se14c")},
			gadget = {GRENADE_THERMAL, GRENADE_IMPACT}
		},
		heavy = {
			primary = {W("DLT-19", "tfa_sw_blaster_dlt19_upgrade", "weapon_752_dlt19"), W("RT-97C", "tfa_sw_blaster_rt97c_upgrade", "weapon_752_dlt19"),
				W("T-21", "tfa_sw_blaster_t21_upgrade", "weapon_752_t21")},
			secondary = {W("SE-14R", "tfa_sw_blaster_se14r_upgrade", "weapon_752_se14c")},
			gadget = {W("Ракетомёт HH-12", "tfa_sw_rocket_hh12_upgrade", "weapon_752_e60r"), GRENADE_THERMAL}
		},
		specialist = {
			primary = {W("E-11S", "tfa_sw_blaster_e11s_upgrade", "weapon_752_e11"), W("DLT-19X", "tfa_sw_blaster_dlt19x_upgrade", "weapon_752_dlt19"),
				W("DLT-20A", "tfa_sw_blaster_dlt20a_upgrade", "weapon_752_dlt19")},
			secondary = {W("SE-14R", "tfa_sw_blaster_se14r_upgrade", "weapon_752_se14c")},
			gadget = {GRENADE_STUN, GRENADE_SMOKE}
		},
		officer = {
			primary = {W("SE-14R", "tfa_sw_blaster_se14r_upgrade", "weapon_752_se14c"), W("SX-25S", "tfa_sw_blaster_scatter_upgrade", "weapon_752_e11"),
				W("DT-29", "tfa_sw_blaster_dt29_upgrade", "weapon_752_se14c")},
			secondary = {W("RK-3", "tfa_sw_blaster_rk3_upgrade", "weapon_752_se14c")},
			gadget = {GRENADE_BACTA, GRENADE_FLASH}
		}
	},
	rebels = {
		assault = {
			primary = {W("A-280", "tfa_sw_blaster_a280_upgrade", "weapon_752_dh17"), W("A-280C", "tfa_sw_blaster_a280c_upgrade", "weapon_752_dh17"),
				W("CR-2", "tfa_sw_blaster_cr2_upgrade", "weapon_752_dh17")},
			secondary = {W("DH-17", "tfa_sw_blaster_dh17_upgrade", "weapon_752_dh17"), W("DL-44", "tfa_sw_blaster_dl44_upgrade", "weapon_752_dl44")},
			gadget = {GRENADE_THERMAL, GRENADE_IMPACT}
		},
		heavy = {
			primary = {W("TL-50", "tfa_sw_blaster_tl50_upgrade", "weapon_752_dh17"), W("Z-6", "tfa_sw_blaster_z6_upgrade", "weapon_752_dh17"),
				W("DP-23", "tfa_sw_blaster_dp23_upgrade", "weapon_752_dh17")},
			secondary = {W("DH-17", "tfa_sw_blaster_dh17_upgrade", "weapon_752_dh17")},
			gadget = {W("Ракетомёт PRS-6", "tfa_sw_rocket_prs6_upgrade", "weapon_752_e60r"), GRENADE_THERMAL}
		},
		specialist = {
			primary = {W("A-280 CFE", "tfa_sw_blaster_a280cfe_upgrade", "weapon_752_ee3"), W("NT-242", "tfa_sw_blaster_nt242_upgrade", "weapon_752_ee3"),
				W("Сайклер", "tfa_sw_blaster_cycler_upgrade", "weapon_752_ee3")},
			secondary = {W("DL-44", "tfa_sw_blaster_dl44_upgrade", "weapon_752_dl44")},
			gadget = {GRENADE_STUN, GRENADE_SMOKE}
		},
		officer = {
			primary = {W("DL-44", "tfa_sw_blaster_dl44_upgrade", "weapon_752_dl44"), W("S-5", "tfa_sw_blaster_s5_upgrade", "weapon_752_dl44"),
				W("Боукастер", "tfa_sw_blaster_bowcaster_upgrade", "weapon_752_bowcaster")},
			secondary = {W("DH-17", "tfa_sw_blaster_dh17_upgrade", "weapon_752_dh17")},
			gadget = {GRENADE_BACTA, GRENADE_FLASH}
		}
	}
}

-- первое установленное оружие из записи (TFA, затем запасное)
function SWS.ResolveWeapon(entry)
	if (!entry) then
		return nil
	end

	for _, class in ipairs(entry.classes) do
		if (class and weapons.GetStored(class)) then
			return class
		end
	end
end

-- характеристики для карточек оружия (урон, темп, магазин) из таблицы SWEP
function SWS.WeaponStats(class)
	local stored = class and weapons.GetStored(class)

	if (!stored) then
		return nil
	end

	local primary = stored.Primary or {}
	local rpm = primary.RPM or (primary.Delay and primary.Delay > 0 and 60 / primary.Delay) or 0

	return {
		damage = tonumber(primary.Damage) or 0,
		rpm = tonumber(rpm) or 0,
		clip = tonumber(primary.ClipSize) or 0,
		name = stored.PrintName or class
	}
end
