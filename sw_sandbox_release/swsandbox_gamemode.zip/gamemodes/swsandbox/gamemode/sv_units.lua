--[[
	Войска: высадка юнитов, приказы, строй, удержание точки.
	Юниты — NPC VJ Base. Принадлежность: NW2 «SWS_Owner» / «SWS_Side» / «SWS_Cost».
	Движение — штатное поведение VJ «охрана точки» (IsGuard + GuardData):
	NPC сам возвращается на точку, стреляет с неё и не уходит в погоню.
]]

util.AddNetworkString("SWS_Spawn")
util.AddNetworkString("SWS_Order")
util.AddNetworkString("SWS_Spawned")

local vectorUp = Vector(0, 0, 1)

function SWS.GetUnits(client)
	local units = {}

	for _, entity in ipairs(ents.FindByClass("npc_*")) do
		if (entity:GetNW2Entity("SWS_Owner") == client and entity:Health() > 0) then
			units[#units + 1] = entity
		end
	end

	return units
end

function SWS.DismissAll(client)
	for _, entity in ipairs(SWS.GetUnits(client)) do
		entity:Remove()
	end

	for _, building in ipairs(ents.FindByClass("sws_building")) do
		if (building:GetCommander() == client) then
			building:Remove()
		end
	end
end

function SWS.Broadcast(text, kind)
	for _, client in ipairs(player.GetAll()) do
		SWS.Notify(client, text, kind)
	end
end

-- точка на земле под позицией (или nil, если там стена / пустота)
local function GroundAt(position, size)
	local trace = util.TraceLine({
		start = position + vectorUp * 96,
		endpos = position - vectorUp * 512,
		mask = MASK_NPCSOLID_BRUSHONLY
	})

	if (!trace.Hit or trace.StartSolid) then
		return nil
	end

	-- место свободно от стен для корпуса NPC
	local hull = util.TraceHull({
		start = trace.HitPos + vectorUp * 4,
		endpos = trace.HitPos + vectorUp * 4,
		mins = Vector(-14 * size, -14 * size, 0),
		maxs = Vector(14 * size, 14 * size, 64),
		mask = MASK_NPCSOLID -- с учётом других NPC: не ставим бойца в бойца
	})

	if (hull.StartSolid) then
		return nil
	end

	return trace.HitPos
end

-- строй: прямоугольник рядами поперёк направления движения
local function FormationSlots(center, direction, count, spacing)
	local columns = math.max(1, math.ceil(math.sqrt(count * 1.6)))
	local rows = math.ceil(count / columns)
	local right = direction:Angle():Right()
	local slots = {}

	for i = 0, count - 1 do
		local row = math.floor(i / columns)
		local column = i % columns
		local inRow = math.min(columns, count - row * columns)
		local offsetX = (column - (inRow - 1) * 0.5) * spacing
		local offsetY = (row - (rows - 1) * 0.5) * spacing

		slots[#slots + 1] = center + right * offsetX - direction * offsetY
	end

	return slots
end

-- приказ одному NPC: идти в точку; bGuard — держать её (иначе свободный бой после прихода)
local function OrderMove(npc, position, direction, bGuard, bRun)
	if (!npc.IsVJBaseSNPC or npc.VJ_IsBeingControlled) then
		if (npc.SetLastPosition) then
			npc:SetLastPosition(position)
			npc:SetSchedule(bRun and SCHED_FORCED_GO_RUN or SCHED_FORCED_GO)
		end

		return
	end

	if (npc.IsFollowing) then
		npc:ResetFollowBehavior()
	end

	npc.IsGuard = bGuard
	npc.GuardData = {Position = bGuard and position or false, Direction = bGuard and (position + direction * 51) or false}
	npc.SWS_Order = {position = position, direction = direction, bRun = bRun != false,
		expires = CurTime() + 4 + npc:GetPos():Distance(position) / 120}

	-- пока идёт, бой не отменяет приказ (VJ не начнёт погоню до NextChaseTime)
	npc.NextChaseTime = npc.SWS_Order.expires

	npc:StopMoving()
	npc:SetLastPosition(position)
	npc:SCHEDULE_GOTO_POSITION(bRun == false and "TASK_WALK_PATH" or "TASK_RUN_PATH", function(schedule)
		schedule.CanShootWhenMoving = true
		schedule.TurnData = {Type = VJ.FACE_ENEMY}
	end)
end

-- держать текущую позицию
local function OrderHold(npc)
	if (!npc.IsVJBaseSNPC) then
		npc:SetSchedule(SCHED_IDLE_STAND)
		return
	end

	local position = npc:GetPos()

	npc.SWS_Order = nil
	npc.NextChaseTime = 0
	npc.IsGuard = true
	npc.GuardData = {Position = position, Direction = position + npc:GetForward() * 51}
	npc:StopMoving()
end

-- свободный бой: без точки охраны, преследует врагов
local function OrderFree(npc)
	npc.SWS_Order = nil

	if (npc.IsVJBaseSNPC) then
		npc.NextChaseTime = 0
		npc.IsGuard = false
		npc.GuardData = {Position = false, Direction = false}
	end
end

-- групповой приказ идти / атаковать с ходу: строй вокруг точки, лицом от центра группы к цели
function SWS.OrderGroup(units, order, position, bRun)
	if (#units == 0 or !util.IsInWorld(position)) then
		return
	end

	local center = Vector(0, 0, 0)
	local maxSize = 1

	for _, npc in ipairs(units) do
		center = center + npc:GetPos()
		maxSize = math.max(maxSize, SWS.GetUnitCost(npc))
	end

	center = center / #units

	local direction = position - center
	direction.z = 0

	if (direction:LengthSqr() < 1) then
		direction = units[1]:GetForward()
	end

	direction:Normalize()

	local slots = FormationSlots(position, direction, #units, 60 * maxSize ^ 0.75)

	-- дальние выбирают первыми, каждому — ближайшее свободное место
	table.sort(units, function(a, b)
		return a:GetPos():DistToSqr(position) > b:GetPos():DistToSqr(position)
	end)

	for _, npc in ipairs(units) do
		local bestIndex, bestDistance

		for index, slot in ipairs(slots) do
			local distance = slot:DistToSqr(npc:GetPos())

			if (!bestDistance or distance < bestDistance) then
				bestIndex, bestDistance = index, distance
			end
		end

		local slot = table.remove(slots, bestIndex)
		local ground = GroundAt(slot, SWS.GetUnitCost(npc)) or position

		OrderMove(npc, ground, direction, order == SWS.ORDER_MOVE, bRun)
	end
end

-- создать бойцов: строем вокруг точки, лицом по yaw; сразу держат позицию
function SWS.SpawnUnits(client, faction, unit, variantIndex, count, position, yaw)
	local variant = unit.variants[variantIndex] or unit.variants[1]
	local spawned = {}

	if (!scripted_ents.GetStored(variant.class)) then
		SWS.Notify(client, "NPC «" .. unit.name .. "» не установлен на сервере.", 2)
		return spawned
	end

	local direction = Angle(0, yaw, 0):Forward()
	local spacing = 52 * math.max(unit.size, 1) ^ 0.75
	local slots = FormationSlots(position, direction, count, spacing)

	for _, slot in ipairs(slots) do
		local ground = GroundAt(slot, unit.size)

		if (!ground) then
			continue
		end

		local npc = ents.Create(variant.class)

		if (!IsValid(npc)) then
			break
		end

		npc:SetPos(ground + vectorUp * 6)
		npc:SetAngles(Angle(0, yaw, 0))

		-- оружие из списка пака (как в меню спавна VJ)
		if (variant.weapons and #variant.weapons > 0) then
			npc:SetKeyValue("additionalequipment", variant.weapons[math.random(#variant.weapons)])
		end

		if (client:IsPlayer()) then
			npc:SetCreator(client)
		end
		npc:Spawn()
		npc:Activate()

		npc:SetNW2Entity("SWS_Owner", client)
		npc:SetNW2Int("SWS_Side", faction.index)
		npc:SetNW2Int("SWS_Cost", unit.size)
		npc:SetNW2String("SWS_Unit", unit.id)
		npc:SetNW2Int("SWS_HP", npc:Health())
		npc:SetNW2Int("SWS_MaxHP", math.max(npc:GetMaxHealth(), npc:Health(), 1))
		npc.SWS_Faction = faction

		-- только своя сторона: убираем «союзник всех игроков», чтобы клоны не дружили с повстанцами
		npc.VJ_NPC_Class = {faction.vjClass}
		npc.AlliedWithPlayerAllies = false

		OrderHold(npc)

		spawned[#spawned + 1] = npc
	end

	-- некоторые паки выставляют классы при первом думанье — повторим
	timer.Simple(0, function()
		for _, npc in ipairs(spawned) do
			if (IsValid(npc)) then
				npc.VJ_NPC_Class = {faction.vjClass}
			end
		end
	end)

	if (#spawned > 0 and client:IsPlayer()) then
		undo.Create("SWS: " .. unit.name)
			for _, npc in ipairs(spawned) do
				undo.AddEntity(npc)
			end

			undo.SetPlayer(client)
		undo.Finish()
	end

	return spawned
end

-- прямая высадка с орбиты (только если разрешена: sws_free_landing 1)
net.Receive("SWS_Spawn", function(length, client)
	local unitID = net.ReadString()
	local variantIndex = net.ReadUInt(5)
	local count = net.ReadUInt(5)
	local position = net.ReadVector()
	local yaw = net.ReadFloat()

	local faction = SWS.GetFaction(client)

	if (!faction or SWS.GetMode(client) != SWS.MODE_COMMANDER) then
		return
	end

	if (!GetConVar("sws_free_landing"):GetBool()) then
		SWS.Notify(client, "Высадка отключена: стройте казармы и заводы.", 2)
		return
	end

	if ((client.SWS_NextSpawn or 0) > CurTime()) then
		return
	end

	client.SWS_NextSpawn = CurTime() + 0.4

	local unit = SWS.UnitIndex[faction.id] and SWS.UnitIndex[faction.id][unitID]

	if (!unit) then
		return
	end

	count = math.Clamp(count, 1, math.max(GetConVar("sws_spawn_batch"):GetInt(), 1))

	-- лимит очков войск
	local limit = GetConVar("sws_population"):GetInt()
	local used = SWS.GetPopulation(client)
	local canAfford = math.floor((limit - used) / unit.size)

	if (canAfford <= 0) then
		SWS.Notify(client, string.format("Лимит войск: %d / %d. Распустите часть отрядов.", used, limit), 2)
		return
	end

	if (count > canAfford) then
		SWS.Notify(client, string.format("Хватает очков только на %d.", canAfford), 1)
		count = canAfford
	end

	local spawned = SWS.SpawnUnits(client, faction, unit, variantIndex, count, position, yaw)

	if (#spawned == 0) then
		SWS.Notify(client, "Здесь не высадить: нет места.", 2)
		return
	end

	-- клиенту: выделить только что высаженных
	net.Start("SWS_Spawned")
		net.WriteUInt(#spawned, 6)

		-- индексы, а не сущности: клиент мог ещё не получить новых NPC
		for _, npc in ipairs(spawned) do
			net.WriteUInt(npc:EntIndex(), 13)
		end
	net.Send(client)
end)

-- приказы
net.Receive("SWS_Order", function(length, client)
	local order = net.ReadUInt(3)
	local position = net.ReadVector()
	local target = net.ReadEntity()
	local bRun = net.ReadBool()
	local count = net.ReadUInt(8)
	local units = {}

	for _ = 1, count do
		local entity = net.ReadEntity()

		if (IsValid(entity) and entity:GetNW2Entity("SWS_Owner") == client and entity:Health() > 0) then
			units[#units + 1] = entity
		end
	end

	if (#units == 0 or (client.SWS_NextOrder or 0) > CurTime()) then
		return
	end

	client.SWS_NextOrder = CurTime() + 0.1

	if (order == SWS.ORDER_DISMISS) then
		for _, npc in ipairs(units) do
			npc:Remove()
		end

		return
	end

	if (order == SWS.ORDER_POSSESS) then
		SWS.Possess(client, units[1])
		return
	end

	if (order == SWS.ORDER_HOLD) then
		for _, npc in ipairs(units) do
			OrderHold(npc)
		end

		return
	end

	if (order == SWS.ORDER_FREE) then
		for _, npc in ipairs(units) do
			OrderFree(npc)
		end

		return
	end

	if (order == SWS.ORDER_TARGET) then
		if (!IsValid(target) or !(target:IsNPC() or target:IsPlayer() or target:IsNextBot())) then
			return
		end

		-- по своим не стреляем
		local side = client:GetNW2Int("SWS_Side", 0)

		if ((target:IsPlayer() and target:Team() == side) or (target:IsNPC() and target:GetNW2Int("SWS_Side", 0) == side)) then
			return
		end

		for _, npc in ipairs(units) do
			OrderFree(npc)

			if (npc.ForceSetEnemy) then
				npc:ForceSetEnemy(target, false)
			else
				npc:SetEnemy(target)
				npc:UpdateEnemyMemory(target, target:GetPos())
			end
		end

		return
	end

	if (order == SWS.ORDER_MOVE or order == SWS.ORDER_ATTACK) then
		SWS.OrderGroup(units, order, position, bRun)
	end
end)

-- проверка приказов: застрявших подталкиваем, дошедших снимаем с приказа
timer.Create("SWS_OrderThink", 0.5, 0, function()
	local now = CurTime()

	for _, npc in ipairs(ents.FindByClass("npc_*")) do
		local order = npc.SWS_Order

		if (!order or npc:Health() <= 0 or npc.VJ_IsBeingControlled) then
			continue
		end

		local distance = npc:GetPos():Distance(order.position)

		if (distance < 48 or now > order.expires) then
			npc.SWS_Order = nil
			npc.NextChaseTime = 0

			-- атака с ходу: дошли — свободный бой
			if (!npc.IsGuard) then
				OrderFree(npc)
			end
		elseif (!npc:IsMoving() and !(npc.IsBusy and npc:IsBusy("Activities"))) then
			npc.NextChaseTime = order.expires
			npc:SetLastPosition(order.position)
			npc:SCHEDULE_GOTO_POSITION(order.bRun and "TASK_RUN_PATH" or "TASK_WALK_PATH", function(schedule)
				schedule.CanShootWhenMoving = true
				schedule.TurnData = {Type = VJ.FACE_ENEMY}
			end)
		end
	end
end)

-- здоровье юнитов для клиентов (полоски и портреты)
local function SyncHealth(npc)
	if (IsValid(npc) and npc:IsNPC() and npc:GetNW2Int("SWS_Side", 0) > 0) then
		npc:SetNW2Int("SWS_HP", math.max(npc:Health(), 0))
		npc:SetNW2Int("SWS_MaxHP", math.max(npc:GetMaxHealth(), 1))
	end
end

hook.Add("PostEntityTakeDamage", "SWS_SyncHealth", function(entity)
	SyncHealth(entity)
end)

timer.Create("SWS_HealthThink", 1, 0, function()
	for _, npc in ipairs(ents.FindByClass("npc_*")) do
		SyncHealth(npc)
	end
end)
