--[[
	Кинематографичная картинка (встроенная постобработка Source, свои шейдеры GMod без модулей не поддерживает):
	- цветокоррекция под сторону: Республика — чистый холодный, КНС — пыльный оранжевый,
	  Империя — холодный контрастный и приглушённый, Повстанцы — тёплый золотистый;
	- мягкое свечение (bloom), солнечные лучи и блики линзы от солнца, лёгкая резкость;
	- хроматическая аберрация к краям кадра, плёночное зерно, виньетка;
	- у командира — «миниатюра» (tilt-shift): размытые верх и низ кадра, как у RTS;
	- мало здоровья — красная пульсирующая виньетка и обесцвечивание.
	Настройки (консоль): sws_fx 0/1 — всё; sws_fx_bloom, sws_fx_sunbeams, sws_fx_aberration,
	sws_fx_grain, sws_fx_vignette, sws_fx_tiltshift — по отдельности.
]]

local fxEnabled = CreateClientConVar("sws_fx", "1", true, false, "Кинематографичная постобработка Star Wars Sandbox")
local fxBloom = CreateClientConVar("sws_fx_bloom", "1", true, false)
local fxSunbeams = CreateClientConVar("sws_fx_sunbeams", "1", true, false)
local fxAberration = CreateClientConVar("sws_fx_aberration", "1", true, false)
local fxGrain = CreateClientConVar("sws_fx_grain", "1", true, false)
local fxVignette = CreateClientConVar("sws_fx_vignette", "1", true, false)
local fxTiltShift = CreateClientConVar("sws_fx_tiltshift", "1", true, false)

local vignette = Material("sws/vignette.png", "smooth")
local grain = Material("sws/grain.png", "noclamp smooth")
local flare = Material("sws/flare.png", "smooth")

-- экран для аберрации: каналы рисуются аддитивно со сдвигом масштаба
local screenAdditive = CreateMaterial("SWS_ScreenAdditive", "UnlitGeneric", {
	["$basetexture"] = "_rt_FullFrameFB",
	["$additive"] = "1",
	["$vertexcolor"] = "1",
	["$vertexalpha"] = "1",
	["$ignorez"] = "1"
})

-- цветокоррекция: id стороны → параметры pp_colour
local grades = {
	republic = {addr = 0, addg = 0.004, addb = 0.016, brightness = -0.015, contrast = 1.12, colour = 1.06, mulr = 0, mulg = 0.02, mulb = 0.08},
	cis = {addr = 0.026, addg = 0.012, addb = 0, brightness = -0.02, contrast = 1.12, colour = 1.04, mulr = 0.1, mulg = 0.04, mulb = 0},
	empire = {addr = 0, addg = 0.002, addb = 0.012, brightness = -0.035, contrast = 1.2, colour = 0.78, mulr = 0.02, mulg = 0, mulb = 0.04},
	rebels = {addr = 0.02, addg = 0.016, addb = 0, brightness = -0.01, contrast = 1.08, colour = 1.12, mulr = 0.06, mulg = 0.05, mulb = 0},
	neutral = {addr = 0.012, addg = 0.006, addb = 0.01, brightness = -0.02, contrast = 1.1, colour = 1.02, mulr = 0.03, mulg = 0, mulb = 0.03}
}

local grade = {}

local function ApplyGrade(id, lowHealth, bCommander)
	local base = grades[id] or grades.neutral

	grade["$pp_colour_addr"] = base.addr
	grade["$pp_colour_addg"] = base.addg
	grade["$pp_colour_addb"] = base.addb
	grade["$pp_colour_brightness"] = base.brightness
	grade["$pp_colour_contrast"] = base.contrast * (bCommander and 0.97 or 1)
	grade["$pp_colour_colour"] = base.colour * (1 - lowHealth * 0.6)
	grade["$pp_colour_mulr"] = base.mulr + lowHealth * 0.3
	grade["$pp_colour_mulg"] = base.mulg
	grade["$pp_colour_mulb"] = base.mulb

	if (DrawColorModify) then
		DrawColorModify(grade)
	end
end

-- солнце на экране: позиция и насколько видно
local function SunOnScreen()
	local sun = util.GetSunInfo()

	if (!sun or !sun.direction or (sun.obstruction or 0) <= 0) then
		return nil
	end

	local position = EyePos() + sun.direction * 4096
	local screen = position:ToScreen()
	local dot = sun.direction:Dot(EyeVector())

	if (dot < 0.3) then
		return nil
	end

	return screen.x, screen.y, sun.obstruction * math.Clamp((dot - 0.3) / 0.5, 0, 1)
end

local function DrawAberration(strength)
	local width, height = ScrW(), ScrH()

	render.UpdateScreenEffectTexture()

	cam.Start2D()
		surface.SetDrawColor(0, 0, 0, 255)
		surface.DrawRect(0, 0, width, height)

		surface.SetMaterial(screenAdditive)

		-- красный чуть крупнее, синий чуть мельче — цветная кайма к краям
		local channels = {
			{Color(255, 0, 0), 1 + strength},
			{Color(0, 255, 0), 1},
			{Color(0, 0, 255), 1 - strength}
		}

		for _, channel in ipairs(channels) do
			local scale = channel[2]
			local w, h = width * scale, height * scale

			surface.SetDrawColor(channel[1])
			surface.DrawTexturedRect(width * 0.5 - w * 0.5, height * 0.5 - h * 0.5, w, h)
		end
	cam.End2D()
end

hook.Add("RenderScreenspaceEffects", "SWS_Cinematic", function()
	if (!fxEnabled:GetBool()) then
		return
	end

	local client = LocalPlayer()
	local faction = SWS.GetFaction(client)
	local mode = SWS.GetMode(client)
	local bCommander = mode == SWS.MODE_COMMANDER or mode == SWS.MODE_MENU
	local lowHealth = 0

	if (mode == SWS.MODE_FREE and client:Alive()) then
		lowHealth = math.Clamp(1 - client:Health() / (math.max(client:GetMaxHealth(), 1) * 0.35), 0, 1)
	elseif (mode == SWS.MODE_POSSESS) then
		local npc = client:GetNW2Entity("SWS_Possessed")

		if (IsValid(npc)) then
			lowHealth = math.Clamp(1 - SWS.GetHealth(npc) / (SWS.GetMaxHealth(npc) * 0.35), 0, 1)
		end
	end

	ApplyGrade(faction and faction.id or "neutral", lowHealth, bCommander)

	if (fxBloom:GetBool() and DrawBloom) then
		DrawBloom(0.68, 0.85, 9, 9, 2, 1.2, 1, 1, 1)
	end

	local sunX, sunY, sunAmount = SunOnScreen()

	if (sunX and fxSunbeams:GetBool() and DrawSunbeams) then
		DrawSunbeams(0.88, 0.22 * sunAmount, 0.22, sunX / ScrW(), sunY / ScrH())
	end

	if (DrawSharpen) then
		DrawSharpen(0.55, 0.8)
	end

	if (bCommander and fxTiltShift:GetBool() and DrawToyTown) then
		DrawToyTown(2, ScrH() * 0.32)
	end

	if (fxAberration:GetBool()) then
		DrawAberration(0.0028)
	end

	cam.Start2D()
		local width, height = ScrW(), ScrH()

		-- блики линзы вдоль линии солнце → центр
		if (sunX and fxSunbeams:GetBool() and !flare:IsError()) then
			render.OverrideBlend(true, BLEND_SRC_ALPHA, BLEND_ONE, BLENDFUNC_ADD)
				surface.SetMaterial(flare)

				local centerX, centerY = width * 0.5, height * 0.5
				local ghosts = {{0, 260, Color(255, 236, 200)}, {0.4, 60, Color(120, 180, 255)}, {0.9, 110, Color(255, 160, 90)},
					{1.3, 40, Color(160, 255, 200)}, {1.7, 150, Color(110, 140, 255)}}

				for _, ghost in ipairs(ghosts) do
					local t = ghost[1]
					local x = sunX + (centerX - sunX) * t
					local y = sunY + (centerY - sunY) * t
					local size = ghost[2] * (height / 1080)
					local alpha = (t == 0 and 120 or 26) * sunAmount

					surface.SetDrawColor(ghost[3].r, ghost[3].g, ghost[3].b, alpha)
					surface.DrawTexturedRect(x - size * 0.5, y - size * 0.5, size, size)
				end
			render.OverrideBlend(false)
		end

		-- зерно: смещается каждый кадр
		if (fxGrain:GetBool() and !grain:IsError()) then
			local u, v = math.random(), math.random()

			surface.SetMaterial(grain)
			surface.SetDrawColor(255, 255, 255, 10)
			surface.DrawTexturedRectUV(0, 0, width, height, u, v, u + width / 256, v + height / 256)
		end

		-- виньетка
		if (fxVignette:GetBool() and !vignette:IsError()) then
			surface.SetMaterial(vignette)
			surface.SetDrawColor(0, 0, 0, bCommander and 235 or 200)
			surface.DrawTexturedRect(0, 0, width, height)
		end

		-- мало здоровья: красная пульсация по краям
		if (lowHealth > 0 and !vignette:IsError()) then
			local pulse = 0.65 + math.sin(RealTime() * 5) * 0.35

			surface.SetMaterial(vignette)
			surface.SetDrawColor(200, 20, 20, 255 * lowHealth * pulse)
			surface.DrawTexturedRect(0, 0, width, height)
		end
	cam.End2D()
end)

-- в меню настроек песочницы (Q → Утилиты) — галочки эффектов
hook.Add("PopulateToolMenu", "SWS_FXOptions", function()
	spawnmenu.AddToolMenuOption("Utilities", "Star Wars Sandbox", "SWS_FX", "Графика", "", "", function(panel)
		panel:ClearControls()
		panel:CheckBox("Кинематографичная картинка", "sws_fx")
		panel:CheckBox("Свечение (bloom)", "sws_fx_bloom")
		panel:CheckBox("Солнечные лучи и блики", "sws_fx_sunbeams")
		panel:CheckBox("Хроматическая аберрация", "sws_fx_aberration")
		panel:CheckBox("Плёночное зерно", "sws_fx_grain")
		panel:CheckBox("Виньетка", "sws_fx_vignette")
		panel:CheckBox("Миниатюра у командира (tilt-shift)", "sws_fx_tiltshift")
	end)
end)
