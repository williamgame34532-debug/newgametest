--[[
	Здания — команды командира: постройка, очередь производства, повтор, точка сбора, снос.
]]

util.AddNetworkString("SWS_Build")
util.AddNetworkString("SWS_BuildingCmd")

local MAX_QUEUE = 10

-- свободная буква для командного поста (A, B, C...)
function SWS.NextPostLetter()
	local used = {}

	for _, building in ipairs(ents.FindByClass("sws_building")) do
		if (building:GetBuildingType() == "command") then
			used[building:GetLetter()] = true
		end
	end

	for letter = 1, 26 do
		if (!used[letter]) then
			return letter
		end
	end

	return 26
end

function SWS.CreateBuilding(buildingType, position, yaw, side, commander, bInstant)
	local building = ents.Create("sws_building")

	building:SetBuildingType(buildingType)
	building:SetSide(side or 0)
	building:SetCommander(IsValid(commander) and commander or NULL)
	building:SetPos(position)
	building:SetAngles(Angle(0, yaw, 0))
	building.SWS_Instant = bInstant

	if (buildingType == "command") then
		building:SetLetter(SWS.NextPostLetter())
	end

	building:Spawn()
	building:Activate()

	return building
end

-- можно ли поставить здание: ровная свободная площадка, не вплотную к другим
local function CanPlace(info, position, yaw)
	local angles = Angle(0, yaw, 0)
	local radius = math.max(info.maxs.x - info.mins.x, info.maxs.y - info.mins.y) * 0.5

	local hull = util.TraceHull({
		start = position + Vector(0, 0, 32),
		endpos = position + Vector(0, 0, 32),
		mins = Vector(-radius * 0.8, -radius * 0.8, 0),
		maxs = Vector(radius * 0.8, radius * 0.8, info.maxs.z - 20),
		mask = MASK_SOLID
	})

	if (hull.Hit) then
		return false, "Место занято."
	end

	-- углы на земле, перепад не больше 48
	local lowest, highest

	for _, corner in ipairs({Vector(info.mins.x, info.mins.y, 0), Vector(info.mins.x, info.maxs.y, 0),
		Vector(info.maxs.x, info.mins.y, 0), Vector(info.maxs.x, info.maxs.y, 0)}) do
		corner:Rotate(angles)

		local trace = util.TraceLine({
			start = position + corner + Vector(0, 0, 64),
			endpos = position + corner - Vector(0, 0, 128),
			mask = MASK_SOLID_BRUSHONLY
		})

		if (!trace.Hit or trace.StartSolid) then
			return false, "Нужна ровная земля."
		end

		lowest = math.min(lowest or trace.HitPos.z, trace.HitPos.z)
		highest = math.max(highest or trace.HitPos.z, trace.HitPos.z)
	end

	if (highest - lowest > 48) then
		return false, "Слишком большой уклон."
	end

	for _, other in ipairs(ents.FindByClass("sws_building")) do
		local otherInfo = other:GetInfo()
		local otherRadius = otherInfo and math.max(otherInfo.maxs.x, otherInfo.maxs.y) or 100

		if (other:GetPos():Distance(position) < radius + otherRadius + 40) then
			return false, "Слишком близко к другому зданию."
		end
	end

	return true
end

SWS.CanPlaceBuilding = CanPlace

net.Receive("SWS_Build", function(length, client)
	local buildingType = net.ReadString()
	local position = net.ReadVector()
	local yaw = net.ReadFloat()
	local info = SWS.Buildings[buildingType]
	local faction = SWS.GetFaction(client)

	if (!info or !faction or SWS.GetMode(client) != SWS.MODE_COMMANDER) then
		return
	end

	if ((client.SWS_NextBuild or 0) > CurTime()) then
		return
	end

	client.SWS_NextBuild = CurTime() + 0.5

	-- лимит зданий этого типа на командира
	local limit = GetConVar(info.limitConVar):GetInt()
	local count = 0

	for _, building in ipairs(ents.FindByClass("sws_building")) do
		if (building:GetCommander() == client and building:GetBuildingType() == buildingType) then
			count = count + 1
		end
	end

	if (count >= limit) then
		SWS.Notify(client, string.format("%s: не больше %d.", info.name, limit), 2)
		return
	end

	local ground = util.TraceLine({
		start = position + Vector(0, 0, 64),
		endpos = position - Vector(0, 0, 256),
		mask = MASK_SOLID_BRUSHONLY
	})

	if (!ground.Hit) then
		return
	end

	local bCanPlace, reason = CanPlace(info, ground.HitPos, yaw)

	if (!bCanPlace) then
		SWS.Notify(client, reason, 2)
		return
	end

	local building = SWS.CreateBuilding(buildingType, ground.HitPos, yaw, faction.index, client)

	undo.Create("SWS: " .. info.name)
		undo.AddEntity(building)
		undo.SetPlayer(client)
	undo.Finish()

	SWS.Notify(client, "Строится: " .. info.name, 0)
end)

net.Receive("SWS_BuildingCmd", function(length, client)
	local building = net.ReadEntity()
	local action = net.ReadUInt(3)

	if (!SWS.IsBuilding(building) or building:GetCommander() != client) then
		return
	end

	if ((client.SWS_NextBuildingCmd or 0) > CurTime()) then
		return
	end

	client.SWS_NextBuildingCmd = CurTime() + 0.05

	local faction = SWS.GetFaction(client)
	local info = building:GetInfo()

	if (action == SWS.BUILDING_QUEUE) then
		local unitID = net.ReadString()
		local variant = net.ReadUInt(5)
		local count = math.Clamp(net.ReadUInt(5), 1, MAX_QUEUE)
		local unit = faction and SWS.UnitIndex[faction.id] and SWS.UnitIndex[faction.id][unitID]

		if (!unit or !info.produces or !info.produces[unit.role]) then
			return
		end

		local queue = SWS.ParseQueue(building:GetQueue())

		for _ = 1, count do
			if (#queue >= MAX_QUEUE) then
				SWS.Notify(client, "Очередь заполнена.", 1)
				break
			end

			queue[#queue + 1] = {id = unit.id, variant = math.Clamp(variant, 1, #unit.variants)}
		end

		building:SetQueue(SWS.SerializeQueue(queue))
	elseif (action == SWS.BUILDING_UNQUEUE) then
		local index = net.ReadUInt(5)
		local queue = SWS.ParseQueue(building:GetQueue())

		if (queue[index]) then
			table.remove(queue, index)

			-- отменили текущий — производство заново
			if (index == 1) then
				building:SetProdEnd(0)
			end

			building:SetQueue(SWS.SerializeQueue(queue))
		end
	elseif (action == SWS.BUILDING_REPEAT) then
		building:SetRepeat(!building:GetRepeat())
	elseif (action == SWS.BUILDING_RALLY) then
		local position = net.ReadVector()
		local bAttack = net.ReadBool()

		if (util.IsInWorld(position)) then
			building:SetRally(position)
			building:SetHasRally(true)
			building:SetRallyAttack(bAttack)
		end
	elseif (action == SWS.BUILDING_DEMOLISH) then
		building:Remove()
	end
end)
