--[[
	Star Wars Sandbox — клиент.
]]

include("shared.lua")
include("cl_style.lua")
include("cl_commander.lua")
include("cl_world.lua")
include("cl_hud.lua")
include("cl_sidemenu.lua")
include("cl_deploy.lua")
include("cl_playerhud.lua")
include("cl_fx.lua")

-- F1 (сервер шлёт sws_help) — подсказка по управлению
concommand.Add("sws_help", function()
	SWS.showHelp = !SWS.showHelp
end)

-- шрифты из контента могут подгрузиться позже — пересоздадим после входа
hook.Add("InitPostEntity", "SWS_ReloadFonts", function()
	timer.Simple(1, function()
		hook.Run("OnScreenSizeChanged", ScrW(), ScrH())
	end)
end)
