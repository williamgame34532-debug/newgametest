--[[
	Раздача контента: аддоны Workshop, без которых режим не работает, и свой контент (шрифты, арты).
	Клиенты при входе скачают их сами.
]]

local workshop = {
	"131759821",  -- VJ Base
	"2052642961", -- SNPC Particle Resource Pack
	"3658522900", -- [VJ] Star Wars: Clone Wars Era SNPCs
	"3468429737", -- [VJ] Star Wars: Galactic Civil War SNPCs
	"183549197",  -- Star Wars Weapons
	"3731061226"  -- [TFA] [AT] | Star Wars Upgraded, Personal Edition
}

for _, id in ipairs(workshop) do
	resource.AddWorkshop(id)
end

-- контент режима (папка sws_content в addons/ или Workshop)
local folders = {
	{"materials/sws/", "*"},
	{"sound/sws/", "*"},
	{"resource/fonts/", "SWS*.ttf"}
}

for _, folder in ipairs(folders) do
	local files = file.Find(folder[1] .. folder[2], "GAME")

	for _, name in ipairs(files or {}) do
		resource.AddSingleFile(folder[1] .. name)
	end
end

-- без VJ Base и паков юнитов режим бесполезен — предупредим в консоли
hook.Add("Initialize", "SWS_CheckAddons", function()
	timer.Simple(5, function()
		if (!VJ) then
			MsgC(Color(255, 80, 80), "[Star Wars Sandbox] VJ Base не найден! Подпишитесь на аддоны из списка в описании режима.\n")
		end

		for factionID, list in pairs(SWS.Units) do
			for _, unit in ipairs(list) do
				for _, variant in ipairs(unit.variants) do
					if (!scripted_ents.GetStored(variant.class)) then
						MsgC(Color(255, 180, 60), "[Star Wars Sandbox] Нет NPC " .. variant.class .. " (" .. factionID .. ")\n")
					end
				end
			end
		end
	end)
end)
