--[[
	Здания командира.
	- Командный пост: точка высадки игроков своей стороны, его можно захватить (стоять рядом войсками),
	  не разрушается.
	- Казарма: выпускает пехоту, специалистов и элиту.
	- Завод техники: выпускает технику.
	Здания собраны из стандартных моделей GMod (блоки PHX, детали Combine) — parts рисует клиент.
	Оси: +X — фасад (выход бойцов), размеры в юнитах.
]]

SWS.Buildings = {
	command = {
		id = "command",
		name = "Командный пост",
		short = "ПОСТ",
		description = "Точка высадки игроков. Захватывается войсками: держите рядом бойцов.",
		health = 0, -- неразрушаемый
		buildTime = 8,
		limitConVar = "sws_max_posts",
		mins = Vector(-90, -90, 0),
		maxs = Vector(90, 90, 150),
		captureRadius = 380,
		parts = {
			{box = {0, 0, 6}, size = {180, 180, 12}, material = "phoenix_storms/metalset_1-2", shade = 0.55},
			{box = {0, 0, 14}, size = {150, 150, 4}, material = "phoenix_storms/metalset_1-2", shade = 0.8},
			{model = "models/props_combine/combine_interface001.mdl", pos = {-20, 0, 16}, ang = {0, 0, 0}},
			{box = {40, 40, 110}, size = {6, 6, 200}, material = "phoenix_storms/metalset_1-2", shade = 0.45},
			{box = {40, 56, 186}, size = {3, 30, 44}, faction = true},
			{box = {75, 0, 20}, size = {8, 120, 10}, faction = true},
			{box = {-75, 0, 20}, size = {8, 120, 10}, faction = true}
		}
	},
	barracks = {
		id = "barracks",
		name = "Казарма",
		short = "КАЗАРМА",
		description = "Обучает пехоту, специалистов и элиту. ПКМ при выбранной казарме — точка сбора.",
		health = 3000,
		buildTime = 10,
		limitConVar = "sws_max_barracks",
		produces = {["Пехота"] = true, ["Специалисты"] = true, ["Элита"] = true},
		mins = Vector(-120, -95, 0),
		maxs = Vector(120, 95, 130),
		parts = {
			{box = {0, 0, 4}, size = {250, 200, 8}, material = "phoenix_storms/metalset_1-2", shade = 0.45},
			{box = {-10, 0, 62}, size = {220, 180, 112}, material = "phoenix_storms/metalset_1-2", shade = 0.9},
			{box = {-10, 0, 122}, size = {236, 196, 10}, material = "phoenix_storms/metalset_1-2", shade = 0.55},
			{box = {102, 0, 48}, size = {8, 92, 88}, material = "phoenix_storms/metalset_1-2", shade = 0.25},
			{box = {104, 0, 96}, size = {6, 110, 10}, faction = true},
			{box = {-10, 91, 100}, size = {200, 2, 12}, faction = true},
			{box = {-10, -91, 100}, size = {200, 2, 12}, faction = true},
			{box = {-70, 55, 160}, size = {4, 4, 70}, material = "phoenix_storms/metalset_1-2", shade = 0.4},
			{model = "models/props_combine/combine_light001a.mdl", pos = {108, 60, 70}, ang = {0, 0, 0}},
			{model = "models/props_combine/combine_light001a.mdl", pos = {108, -60, 70}, ang = {0, 0, 0}}
		}
	},
	factory = {
		id = "factory",
		name = "Завод техники",
		short = "ЗАВОД",
		description = "Собирает технику: шагоходы, дроидов-пауков, турели, танки.",
		health = 4500,
		buildTime = 14,
		limitConVar = "sws_max_factories",
		produces = {["Техника"] = true},
		mins = Vector(-180, -150, 0),
		maxs = Vector(180, 150, 190),
		parts = {
			{box = {0, 0, 5}, size = {380, 320, 10}, material = "phoenix_storms/metalset_1-2", shade = 0.4},
			{box = {-20, 0, 92}, size = {320, 280, 170}, material = "phoenix_storms/metalset_1-2", shade = 0.85},
			{box = {-20, 0, 182}, size = {336, 296, 12}, material = "phoenix_storms/metalset_1-2", shade = 0.5},
			{box = {142, 0, 72}, size = {8, 200, 130}, material = "phoenix_storms/metalset_1-2", shade = 0.22},
			{box = {146, 0, 145}, size = {6, 220, 12}, faction = true},
			{box = {-100, 90, 230}, size = {40, 40, 90}, material = "phoenix_storms/metalset_1-2", shade = 0.5},
			{box = {-100, -90, 230}, size = {40, 40, 90}, material = "phoenix_storms/metalset_1-2", shade = 0.5},
			{box = {-20, 141, 150}, size = {300, 2, 16}, faction = true},
			{box = {-20, -141, 150}, size = {300, 2, 16}, faction = true},
			{model = "models/props_combine/combine_light001a.mdl", pos = {150, 115, 100}, ang = {0, 0, 0}},
			{model = "models/props_combine/combine_light001a.mdl", pos = {150, -115, 100}, ang = {0, 0, 0}}
		}
	}
}

SWS.BuildingOrder = {"command", "barracks", "factory"}

-- команды зданию (SWS_BuildingCmd)
SWS.BUILDING_QUEUE = 1
SWS.BUILDING_UNQUEUE = 2
SWS.BUILDING_REPEAT = 3
SWS.BUILDING_RALLY = 4
SWS.BUILDING_DEMOLISH = 5

CreateConVar("sws_max_posts", "3", {FCVAR_ARCHIVE, FCVAR_REPLICATED}, "Командных постов на командира")
CreateConVar("sws_max_barracks", "2", {FCVAR_ARCHIVE, FCVAR_REPLICATED}, "Казарм на командира")
CreateConVar("sws_max_factories", "1", {FCVAR_ARCHIVE, FCVAR_REPLICATED}, "Заводов техники на командира")
CreateConVar("sws_free_landing", "0", {FCVAR_ARCHIVE, FCVAR_REPLICATED}, "Разрешить высадку войск в любую точку без зданий")

-- время выпуска юнита (сек): уровень и размер
function SWS.GetUnitBuildTime(unit)
	return 3 + ((unit.tier or 1) - 1) * 3 + ((unit.size or 1) - 1) * 3
end

-- здание, которое выпускает эту роль
function SWS.BuildingProduces(buildingType, role)
	local info = SWS.Buildings[buildingType]

	return info and info.produces and info.produces[role] or false
end

function SWS.IsBuilding(entity)
	return IsValid(entity) and entity:GetClass() == "sws_building"
end

-- очередь производства: «id:вариант,id:вариант»
function SWS.ParseQueue(text)
	local queue = {}

	for token in string.gmatch(text or "", "[^,]+") do
		local id, variant = string.match(token, "^([%w_]+):(%d+)$")

		if (id) then
			queue[#queue + 1] = {id = id, variant = tonumber(variant)}
		end
	end

	return queue
end

function SWS.SerializeQueue(queue)
	local parts = {}

	for _, item in ipairs(queue) do
		parts[#parts + 1] = item.id .. ":" .. item.variant
	end

	return table.concat(parts, ",")
end
