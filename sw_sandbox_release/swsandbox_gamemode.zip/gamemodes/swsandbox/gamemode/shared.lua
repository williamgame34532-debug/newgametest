--[[
	Star Wars Sandbox — основа (shared).
	Режим на базе Sandbox: игрок выбирает одну из четырёх сторон (Республика, КНС, Империя, Повстанцы),
	командует NPC своей стороны с высоты (RTS) и может вселиться в любого своего бойца.
	NPC — паки VJ Base «[VJ] Star Wars: Clone Wars Era SNPCs» и «Galactic Civil War SNPCs».
]]

DeriveGamemode("sandbox")

GM.Name = "Star Wars Sandbox"
GM.Author = "Star Wars Sandbox"
GM.Website = ""
GM.TeamBased = true

SWS = SWS or {}

-- режимы игрока: выбор стороны, командир (вид сверху), свободный (обычная песочница), вселение в бойца
SWS.MODE_MENU = 0
SWS.MODE_COMMANDER = 1
SWS.MODE_FREE = 2
SWS.MODE_POSSESS = 3

-- приказы
SWS.ORDER_MOVE = 1      -- идти и держать точку
SWS.ORDER_ATTACK = 2    -- атака с ходу: идти, по пути вступать в бой и преследовать
SWS.ORDER_HOLD = 3      -- держать текущую позицию
SWS.ORDER_FREE = 4      -- свободный бой: снять охрану
SWS.ORDER_DISMISS = 5   -- распустить (удалить)
SWS.ORDER_TARGET = 6    -- атаковать конкретную цель
SWS.ORDER_POSSESS = 7   -- вселиться в бойца

CreateConVar("sws_population", "60", {FCVAR_ARCHIVE, FCVAR_REPLICATED, FCVAR_NOTIFY}, "Лимит очков войск на одного командира")
CreateConVar("sws_spawn_batch", "10", {FCVAR_ARCHIVE, FCVAR_REPLICATED}, "Максимум юнитов за один спавн")
CreateConVar("sws_friendly_fire", "0", {FCVAR_ARCHIVE, FCVAR_REPLICATED}, "Огонь по своим среди игроков")

-- ИИ-командиры
CreateConVar("sws_ai", "1", {FCVAR_ARCHIVE, FCVAR_REPLICATED, FCVAR_NOTIFY}, "ИИ-командиры для сторон без игроков")
CreateConVar("sws_ai_max", "3", {FCVAR_ARCHIVE, FCVAR_REPLICATED}, "Сколько сторон может вести ИИ (режим auto)")
CreateConVar("sws_ai_population", "40", {FCVAR_ARCHIVE, FCVAR_REPLICATED}, "Лимит очков войск ИИ-командира")
CreateConVar("sws_ai_difficulty", "2", {FCVAR_ARCHIVE, FCVAR_REPLICATED}, "Сложность ИИ: 1 — лёгкий, 2 — средний, 3 — тяжёлый")

include("sh_factions.lua")
include("sh_units.lua")
include("sh_buildings.lua")
include("sh_loadouts.lua")

-- индексы юнитов: SWS.UnitIndex[фракция][id] = таблица юнита
SWS.UnitIndex = {}

for factionID, list in pairs(SWS.Units) do
	SWS.UnitIndex[factionID] = {}

	for order, unit in ipairs(list) do
		unit.order = order
		unit.size = unit.size or 1
		SWS.UnitIndex[factionID][unit.id] = unit
	end
end

for index, faction in ipairs(SWS.Factions) do
	faction.index = index
	SWS.FactionByID[faction.id] = faction

	team.SetUp(index, faction.name, faction.color, false)
end

function SWS.GetFaction(client)
	local index = IsValid(client) and client:GetNW2Int("SWS_Side", 0) or 0

	return SWS.Factions[index]
end

function SWS.GetMode(client)
	return IsValid(client) and client:GetNW2Int("SWS_Mode", SWS.MODE_MENU) or SWS.MODE_MENU
end

-- верхний регистр с кириллицей (string.upper знает только латиницу), с кэшем
local upperCache = {}

function SWS.Upper(text)
	text = tostring(text or "")

	local cached = upperCache[text]

	if (cached) then
		return cached
	end

	local chars = {}

	for _, code in utf8.codes(text) do
		if (code >= 0x430 and code <= 0x44F) then
			code = code - 0x20
		elseif (code == 0x451) then
			code = 0x401
		elseif (code >= 97 and code <= 122) then
			code = code - 32
		end

		chars[#chars + 1] = utf8.char(code)
	end

	cached = table.concat(chars)
	upperCache[text] = cached

	return cached
end

-- владелец юнита и его сторона
function SWS.GetUnitOwner(entity)
	return entity:GetNW2Entity("SWS_Owner")
end

function SWS.IsUnit(entity)
	return IsValid(entity) and entity:IsNPC() and entity:GetNW2Int("SWS_Side", 0) > 0
end

-- здоровье юнита: на клиенте Health() у NPC не передаётся, поэтому сервер дублирует его в NW2
function SWS.GetHealth(entity)
	if (SERVER) then
		return entity:Health()
	end

	return entity:GetNW2Int("SWS_HP", 0)
end

function SWS.GetMaxHealth(entity)
	if (SERVER) then
		return math.max(entity:GetMaxHealth(), 1)
	end

	return math.max(entity:GetNW2Int("SWS_MaxHP", 1), 1)
end

-- очки войск: сколько занимает юнит
function SWS.GetUnitCost(entity)
	return entity:GetNW2Int("SWS_Cost", 1)
end

-- лимит очков войск: у ИИ-командира свой
function SWS.GetPopulationLimit(owner)
	if (IsValid(owner) and owner:GetClass() == "sws_ai_commander") then
		return GetConVar("sws_ai_population"):GetInt()
	end

	return GetConVar("sws_population"):GetInt()
end

-- имя владельца здания / войск (игрок или ИИ)
function SWS.OwnerName(owner)
	if (!IsValid(owner)) then
		return "СТОРОНА"
	end

	if (owner:IsPlayer()) then
		return owner:Nick()
	end

	return owner.GetCommanderName and owner:GetCommanderName() or "ИИ"
end

-- сколько очков занято у игрока
function SWS.GetPopulation(client)
	local total = 0

	for _, entity in ipairs(ents.FindByClass("npc_*")) do
		if (SWS.GetUnitOwner(entity) == client and SWS.GetHealth(entity) > 0) then
			total = total + SWS.GetUnitCost(entity)
		end
	end

	return total
end

-- урон между игроками одной стороны
function GM:PlayerShouldTakeDamage(client, attacker)
	if (IsValid(attacker) and attacker:IsPlayer() and attacker != client and !GetConVar("sws_friendly_fire"):GetBool()
		and attacker:Team() == client:Team() and client:Team() >= 1 and client:Team() <= #SWS.Factions) then
		return false
	end

	return self.BaseClass.PlayerShouldTakeDamage(self, client, attacker)
end
