-- Сгенерировано tools/gen_factions.py из VJ-паков Star Wars (классы NPC и их оружие).
-- Юниты сторон: id, имя, роль (категория панели), уровень, описание и варианты (легион / местность).
-- Класс без варианта для выбранного легиона берётся из первого варианта.

SWS = SWS or {}
SWS.Units = {}

SWS.Units.republic = {
		{
			id = "trooper", name = "Клон-пехотинец", role = "Пехота", tier = 1,
			description = "Основа армии Республики: бластер DC-15A, выучка Камино.",
			size = 1,
			variants = {
				{variant = "Стандарт", class = "npc_vj_cwrep_clonetrooper", weapons = {"weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15s"}},
				{variant = "501-й легион", class = "npc_vj_cwrep_501st_clonetrooper", weapons = {"weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15s"}},
				{variant = "212-й батальон", class = "npc_vj_cwrep_212th_clonetrooper", weapons = {"weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15s"}},
				{variant = "327-й корпус", class = "npc_vj_cwrep_327th_clonetrooper", weapons = {"weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15s"}},
				{variant = "Шок-клоны", class = "npc_vj_cwrep_shock_clonetrooper", weapons = {"weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15s"}},
				{variant = "Фаза I", class = "npc_vj_cwrep_phase1_clonetrooper", weapons = {"weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15s"}},
				{variant = "2-я десантная", class = "npc_vj_cwrep_2nd_paratrooper", weapons = {"weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15s"}},
				{variant = "Галакт. морпехи", class = "npc_vj_cwrep_galactic_marine", weapons = {"weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15s"}},
			}
		},
		{
			id = "lieutenant", name = "Клон-лейтенант", role = "Пехота", tier = 1,
			description = "Командир отделения, держит строй и поднимает боевой дух.",
			size = 1,
			variants = {
				{variant = "Стандарт", class = "npc_vj_cwrep_clonetrooper_lieutenant", weapons = {"weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15s"}},
				{variant = "501-й легион", class = "npc_vj_cwrep_501st_clonetrooper_lieutenant", weapons = {"weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15s"}},
				{variant = "212-й батальон", class = "npc_vj_cwrep_212th_clonetrooper_lieutenant", weapons = {"weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15s"}},
				{variant = "327-й корпус", class = "npc_vj_cwrep_327th_clonetrooper_lieutenant", weapons = {"weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15s"}},
				{variant = "Шок-клоны", class = "npc_vj_cwrep_shock_clonetrooper_lieutenant", weapons = {"weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15s"}},
				{variant = "Фаза I", class = "npc_vj_cwrep_phase1_clonetrooper_lieutenant", weapons = {"weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15s"}},
				{variant = "2-я десантная", class = "npc_vj_cwrep_2nd_paratrooper_lieutenant", weapons = {"weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15s"}},
				{variant = "Галакт. морпехи", class = "npc_vj_cwrep_galactic_marine_lieutenant", weapons = {"weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15s"}},
			}
		},
		{
			id = "sharp", name = "Клон-снайпер", role = "Специалисты", tier = 1,
			description = "Снайперская винтовка DC-15x: бьёт издалека, медленно.",
			size = 1,
			variants = {
				{variant = "Стандарт", class = "npc_vj_cwrep_clonetrooper_sharp", weapons = {"weapon_vj_cw_dc-15x_sniperrifle"}},
				{variant = "501-й легион", class = "npc_vj_cwrep_501st_clonetrooper_sharp", weapons = {"weapon_vj_cw_dc-15x_sniperrifle"}},
				{variant = "212-й батальон", class = "npc_vj_cwrep_212th_clonetrooper_sharp", weapons = {"weapon_vj_cw_dc-15x_sniperrifle"}},
				{variant = "327-й корпус", class = "npc_vj_cwrep_327th_clonetrooper_sharp", weapons = {"weapon_vj_cw_dc-15x_sniperrifle"}},
				{variant = "Шок-клоны", class = "npc_vj_cwrep_shock_clonetrooper_sharp", weapons = {"weapon_vj_cw_dc-15x_sniperrifle"}},
				{variant = "Фаза I", class = "npc_vj_cwrep_phase1_clonetrooper_sharp", weapons = {"weapon_vj_cw_dc-15x_sniperrifle"}},
				{variant = "2-я десантная", class = "npc_vj_cwrep_2nd_paratrooper_sharp", weapons = {"weapon_vj_cw_dc-15x_sniperrifle"}},
				{variant = "Галакт. морпехи", class = "npc_vj_cwrep_galactic_marine_sharp", weapons = {"weapon_vj_cw_dc-15x_sniperrifle"}},
			}
		},
		{
			id = "rocketeer", name = "Клон-ракетчик", role = "Специалисты", tier = 1,
			description = "Ракетомёт PLX-1 против техники и укрытий.",
			size = 1,
			variants = {
				{variant = "Стандарт", class = "npc_vj_cwrep_clonetrooper_rocketeer", weapons = {"weapon_vj_cw_plx-1_rocketlauncher"}},
				{variant = "501-й легион", class = "npc_vj_cwrep_501st_clonetrooper_rocketeer", weapons = {"weapon_vj_cw_plx-1_rocketlauncher"}},
				{variant = "212-й батальон", class = "npc_vj_cwrep_212th_clonetrooper_rocketeer", weapons = {"weapon_vj_cw_plx-1_rocketlauncher"}},
				{variant = "327-й корпус", class = "npc_vj_cwrep_327th_clonetrooper_rocketeer", weapons = {"weapon_vj_cw_plx-1_rocketlauncher"}},
				{variant = "Шок-клоны", class = "npc_vj_cwrep_shock_clonetrooper_rocketeer", weapons = {"weapon_vj_cw_plx-1_rocketlauncher"}},
				{variant = "Фаза I", class = "npc_vj_cwrep_phase1_clonetrooper_rocketeer", weapons = {"weapon_vj_cw_plx-1_rocketlauncher"}},
				{variant = "2-я десантная", class = "npc_vj_cwrep_2nd_paratrooper_rocketeer", weapons = {"weapon_vj_cw_plx-1_rocketlauncher"}},
				{variant = "Галакт. морпехи", class = "npc_vj_cwrep_galactic_marine_rocketeer", weapons = {"weapon_vj_cw_plx-1_rocketlauncher"}},
			}
		},
		{
			id = "engineer", name = "Клон-инженер", role = "Специалисты", tier = 1,
			description = "Карабин DC-15S, работает на ближней дистанции.",
			size = 1,
			variants = {
				{variant = "Стандарт", class = "npc_vj_cwrep_clonetrooper_engineer", weapons = {"weapon_vj_cw_dc-15s"}},
				{variant = "501-й легион", class = "npc_vj_cwrep_501st_clonetrooper_engineer", weapons = {"weapon_vj_cw_dc-15s"}},
				{variant = "212-й батальон", class = "npc_vj_cwrep_212th_clonetrooper_engineer", weapons = {"weapon_vj_cw_dc-15s"}},
				{variant = "327-й корпус", class = "npc_vj_cwrep_327th_clonetrooper_engineer", weapons = {"weapon_vj_cw_dc-15s"}},
				{variant = "Шок-клоны", class = "npc_vj_cwrep_shock_clonetrooper_engineer", weapons = {"weapon_vj_cw_dc-15s"}},
				{variant = "Фаза I", class = "npc_vj_cwrep_phase1_clonetrooper_engineer", weapons = {"weapon_vj_cw_dc-15s"}},
				{variant = "2-я десантная", class = "npc_vj_cwrep_2nd_paratrooper_engineer", weapons = {"weapon_vj_cw_dc-15s"}},
			}
		},
		{
			id = "jet", name = "Реактивный клон", role = "Специалисты", tier = 1,
			description = "Реактивный ранец: прыгает через препятствия.",
			size = 1,
			variants = {
				{variant = "Стандарт", class = "npc_vj_cwrep_clonetrooper_jet", weapons = {"weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15s"}},
				{variant = "501-й легион", class = "npc_vj_cwrep_501st_clonetrooper_jet", weapons = {"weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15s"}},
				{variant = "212-й батальон", class = "npc_vj_cwrep_212th_clonetrooper_jet", weapons = {"weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15s"}},
				{variant = "327-й корпус", class = "npc_vj_cwrep_327th_clonetrooper_jet", weapons = {"weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15s"}},
				{variant = "Шок-клоны", class = "npc_vj_cwrep_shock_clonetrooper_jet", weapons = {"weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15s"}},
				{variant = "Фаза I", class = "npc_vj_cwrep_phase1_clonetrooper_jet", weapons = {"weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15s"}},
				{variant = "2-я десантная", class = "npc_vj_cwrep_2nd_paratrooper_jet", weapons = {"weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15s"}},
				{variant = "Галакт. морпехи", class = "npc_vj_cwrep_galactic_marine_jet", weapons = {"weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15s"}},
			}
		},
		{
			id = "heavy", name = "Тяжёлый клон", role = "Специалисты", tier = 1,
			description = "Пулемёт: подавляет огнём целые отряды.",
			size = 1,
			variants = {
				{variant = "Стандарт", class = "npc_vj_cwrep_clonetrooper_heavy", weapons = {}},
				{variant = "501-й легион", class = "npc_vj_cwrep_501st_clonetrooper_heavy", weapons = {}},
				{variant = "212-й батальон", class = "npc_vj_cwrep_212th_clonetrooper_heavy", weapons = {}},
				{variant = "327-й корпус", class = "npc_vj_cwrep_327th_clonetrooper_heavy", weapons = {}},
				{variant = "Шок-клоны", class = "npc_vj_cwrep_shock_clonetrooper_heavy", weapons = {}},
				{variant = "Фаза I", class = "npc_vj_cwrep_phase1_clonetrooper_heavy", weapons = {}},
				{variant = "2-я десантная", class = "npc_vj_cwrep_2nd_paratrooper_heavy", weapons = {}},
				{variant = "Галакт. морпехи", class = "npc_vj_cwrep_galactic_marine_heavy", weapons = {}},
			}
		},
		{
			id = "arc", name = "Клон ARC", role = "Элита", tier = 2,
			description = "Элитный разведчик-диверсант.",
			size = 1,
			variants = {
				{variant = "Стандарт", class = "npc_vj_cwrep_clonetrooper_arc", weapons = {"weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15s"}},
				{variant = "501-й легион", class = "npc_vj_cwrep_501st_clonetrooper_arc", weapons = {"weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15s"}},
				{variant = "212-й батальон", class = "npc_vj_cwrep_212th_clonetrooper_arc", weapons = {"weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15s"}},
				{variant = "Фаза I", class = "npc_vj_cwrep_phase1_clonetrooper_arc", weapons = {"weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15a", "weapon_vj_cw_dc-15s"}},
			}
		},
		{
			id = "commando", name = "Клон-коммандос", role = "Элита", tier = 2,
			description = "Броня Katarn и DC-17m. Отряд «Дельта» — по вариантам.",
			size = 1,
			variants = {
				{variant = "Стандарт", class = "npc_vj_cwrep_clone_commando", weapons = {}},
				{variant = "Дельта-38 Босс", class = "npc_vj_cwrep_deltasquad_boss", weapons = {}},
				{variant = "Дельта-40 Фиксер", class = "npc_vj_cwrep_deltasquad_fixer", weapons = {}},
				{variant = "Дельта-62 Скорч", class = "npc_vj_cwrep_deltasquad_scorch", weapons = {}},
				{variant = "Дельта-07 Сев", class = "npc_vj_cwrep_deltasquad_sev", weapons = {}},
			}
		},
		{
			id = "sentry", name = "Турель Республики", role = "Техника", tier = 2,
			description = "Стационарная турель: держит проход.",
			bVehicle = true,
			size = 1,
			variants = {
				{variant = nil, class = "npc_vj_cwrep_sentry_gun", weapons = {}},
			}
		},
		{
			id = "atxt", name = "AT-XT", role = "Техника", tier = 3,
			description = "Лёгкий шагоход поддержки.",
			bVehicle = true,
			size = 2,
			variants = {
				{variant = nil, class = "npc_vj_cwrep_atxt", weapons = {}},
			}
		},
		{
			id = "atte", name = "AT-TE", role = "Техника", tier = 4,
			description = "Шестиногий штурмовой шагоход. Медленный и почти неуязвимый.",
			bVehicle = true,
			size = 4,
			variants = {
				{variant = nil, class = "npc_vj_cwrep_atte", weapons = {}},
			}
		},
}

SWS.Units.cis = {
		{
			id = "b1", name = "Боевой дроид B1", role = "Пехота", tier = 1,
			description = "Дешёвый и многочисленный. Сила — в количестве.",
			size = 1,
			variants = {
				{variant = nil, class = "npc_vj_cwcis_battle_droid", weapons = {"weapon_vj_cw_e-5"}},
			}
		},
		{
			id = "b1cmd", name = "Командир B1", role = "Пехота", tier = 1,
			description = "Дроид-командир с жёлтой маркировкой.",
			size = 1,
			variants = {
				{variant = nil, class = "npc_vj_cwcis_battle_droid_commander", weapons = {"weapon_vj_cw_e-5"}},
			}
		},
		{
			id = "b1sniper", name = "Дроид-снайпер", role = "Специалисты", tier = 1,
			description = "Снайперская винтовка E-5s.",
			size = 1,
			variants = {
				{variant = nil, class = "npc_vj_cwcis_battle_droid_assassin", weapons = {"weapon_vj_cw_e-5s_sniperrifle"}},
			}
		},
		{
			id = "b1rocket", name = "Дроид-ракетчик", role = "Специалисты", tier = 1,
			description = "Ракетомёт E-60R против техники.",
			size = 1,
			variants = {
				{variant = nil, class = "npc_vj_cwcis_battle_droid_rocketeer", weapons = {"weapon_vj_cw_e-60r_rocketlauncher"}},
			}
		},
		{
			id = "b1eng", name = "Дроид-инженер", role = "Специалисты", tier = 1,
			description = "Ремонтник с бластером E-5.",
			size = 1,
			variants = {
				{variant = nil, class = "npc_vj_cwcis_battle_droid_engineer", weapons = {"weapon_vj_cw_e-5"}},
			}
		},
		{
			id = "b2", name = "Супердроид B2", role = "Элита", tier = 2,
			description = "Бронированный, со встроенными бластерами в руках.",
			size = 1,
			variants = {
				{variant = nil, class = "npc_vj_cwcis_super_battle_droid", weapons = {}},
			}
		},
		{
			id = "droideka", name = "Дроидека", role = "Элита", tier = 2,
			description = "Катится шаром, разворачивает щит и спаренные бластеры.",
			size = 1,
			variants = {
				{variant = nil, class = "npc_vj_cwcis_droideka", weapons = {}},
			}
		},
		{
			id = "magna", name = "МагнаСтраж", role = "Элита", tier = 2,
			description = "Телохранитель с электропосохом — смертелен вблизи.",
			size = 1,
			variants = {
				{variant = nil, class = "npc_vj_cwcis_magna_guard", weapons = {}},
			}
		},
		{
			id = "sentry", name = "Турель КНС", role = "Техника", tier = 2,
			description = "Стационарная турель Конфедерации.",
			bVehicle = true,
			size = 1,
			variants = {
				{variant = nil, class = "npc_vj_cwcis_sentry_gun", weapons = {}},
			}
		},
		{
			id = "dsd", name = "Карликовый паук", role = "Техника", tier = 3,
			description = "Дроид-паук DSD1 с бластерной пушкой.",
			bVehicle = true,
			size = 2,
			variants = {
				{variant = nil, class = "npc_vj_cwcis_dwarf_spider_droid", weapons = {}},
			}
		},
		{
			id = "adsd", name = "Улучшенный паук", role = "Техника", tier = 3,
			description = "Усиленная версия карликового паука.",
			bVehicle = true,
			size = 2,
			variants = {
				{variant = nil, class = "npc_vj_cwcis_advanced_dwarf_spider_droid", weapons = {}},
			}
		},
		{
			id = "hsd", name = "Самонаводящийся паук", role = "Техника", tier = 4,
			description = "OG-9: тяжёлая лучевая пушка, гроза шагоходов.",
			bVehicle = true,
			size = 4,
			variants = {
				{variant = nil, class = "npc_vj_cwcis_homing_spider_droid", weapons = {}},
			}
		},
}

SWS.Units.empire = {
		{
			id = "storm", name = "Штурмовик", role = "Пехота", tier = 1,
			description = "Солдат Империи с бластером E-11.",
			size = 1,
			variants = {
				{variant = "Стандарт", class = "npc_vj_glcwimp_stormtrooper", weapons = {"weapon_vj_glcw_e-11"}},
				{variant = "Пустыня", class = "npc_vj_glcwimp_stormtrooper_sand", weapons = {"weapon_vj_glcw_e-11"}},
				{variant = "Снег", class = "npc_vj_glcwimp_snowtrooper", weapons = {"weapon_vj_glcw_e-11"}},
				{variant = "Берег", class = "npc_vj_glcwimp_shoretrooper", weapons = {"weapon_vj_glcw_e-11"}},
				{variant = "Фаза III (клон)", class = "npc_vj_glcwimp_phase3_clonetrooper", weapons = {"weapon_vj_glcw_e-11"}},
				{variant = "Фаза III 501-й", class = "npc_vj_glcwimp_phase3_501st_clonetrooper", weapons = {"weapon_vj_glcw_e-11"}},
				{variant = "Фаза III 212-й", class = "npc_vj_glcwimp_phase3_212th_clonetrooper", weapons = {"weapon_vj_glcw_e-11"}},
				{variant = "Фаза III шок", class = "npc_vj_glcwimp_phase3_shock_clonetrooper", weapons = {"weapon_vj_glcw_e-11"}},
			}
		},
		{
			id = "captain", name = "Капитан штурмовиков", role = "Пехота", tier = 1,
			description = "Командир отделения с DLT-19.",
			size = 1,
			variants = {
				{variant = "Стандарт", class = "npc_vj_glcwimp_stormtrooper_captain", weapons = {"weapon_vj_glcw_dlt-19"}},
				{variant = "Пустыня", class = "npc_vj_glcwimp_stormtrooper_sand_captain", weapons = {"weapon_vj_glcw_dlt-19"}},
				{variant = "Снег", class = "npc_vj_glcwimp_snowtrooper_commander", weapons = {"weapon_vj_glcw_dlt-19"}},
				{variant = "Берег", class = "npc_vj_glcwimp_shoretrooper_captain", weapons = {"weapon_vj_glcw_dlt-19"}},
				{variant = "Фаза III (клон)", class = "npc_vj_glcwimp_phase3_clonetrooper_captain", weapons = {"weapon_vj_glcw_dlt-19"}},
				{variant = "Фаза III 501-й", class = "npc_vj_glcwimp_phase3_501st_clonetrooper_captain", weapons = {"weapon_vj_glcw_dlt-19"}},
				{variant = "Фаза III 212-й", class = "npc_vj_glcwimp_phase3_212th_clonetrooper_captain", weapons = {"weapon_vj_glcw_dlt-19"}},
				{variant = "Фаза III шок", class = "npc_vj_glcwimp_phase3_shock_clonetrooper_captain", weapons = {"weapon_vj_glcw_dlt-19"}},
			}
		},
		{
			id = "army", name = "Армейский солдат", role = "Пехота", tier = 1,
			description = "Пехота Имперской армии.",
			size = 1,
			variants = {
				{variant = nil, class = "npc_vj_glcwimp_army_trooper", weapons = {"weapon_vj_glcw_e-11"}},
			}
		},
		{
			id = "armycpt", name = "Капитан армии", role = "Пехота", tier = 1,
			description = "Командир армейского отделения.",
			size = 1,
			variants = {
				{variant = nil, class = "npc_vj_glcwimp_army_trooper_captain", weapons = {"weapon_vj_glcw_dlt-19"}},
			}
		},
		{
			id = "officer", name = "Имперский офицер", role = "Пехота", tier = 1,
			description = "Офицер в серой форме.",
			size = 1,
			variants = {
				{variant = nil, class = "npc_vj_glcwimp_officer", weapons = {"weapon_vj_glcw_e-11"}},
			}
		},
		{
			id = "scout", name = "Разведчик", role = "Специалисты", tier = 1,
			description = "Снайперская винтовка, лёгкая броня.",
			size = 1,
			variants = {
				{variant = "Стандарт", class = "npc_vj_glcwimp_stormtrooper_scout", weapons = {"weapon_vj_glcw_imperialsniper"}},
				{variant = "Пустыня", class = "npc_vj_glcwimp_stormtrooper_scout_sand", weapons = {"weapon_vj_glcw_imperialsniper"}},
				{variant = "Снег", class = "npc_vj_glcwimp_stormtrooper_scout_snow", weapons = {"weapon_vj_glcw_imperialsniper"}},
				{variant = "Прототип", class = "npc_vj_glcwimp_stormtrooper_scout_proto", weapons = {"weapon_vj_glcw_th22_sniperrifle"}},
				{variant = "Армия", class = "npc_vj_glcwimp_army_trooper_sniper", weapons = {"weapon_vj_glcw_imperialsniper"}},
			}
		},
		{
			id = "shock", name = "Шоктрупер", role = "Специалисты", tier = 1,
			description = "Ракетомёт против техники.",
			size = 1,
			variants = {
				{variant = "Стандарт", class = "npc_vj_glcwimp_stormtrooper_shock", weapons = {"weapon_vj_glcw_imperialrpg"}},
				{variant = "Пустыня", class = "npc_vj_glcwimp_stormtrooper_shock_sand", weapons = {"weapon_vj_glcw_imperialrpg"}},
				{variant = "Снег", class = "npc_vj_glcwimp_stormtrooper_shock_snow", weapons = {"weapon_vj_glcw_imperialrpg"}},
				{variant = "Армия", class = "npc_vj_glcwimp_army_trooper_rocketeer", weapons = {"weapon_vj_glcw_imperialrpg"}},
			}
		},
		{
			id = "incinerator", name = "Штурмовик-поджигатель", role = "Специалисты", tier = 1,
			description = "Огнемёт: выжигает укрытия.",
			size = 1,
			variants = {
				{variant = "Стандарт", class = "npc_vj_glcwimp_stormtrooper_incinerator", weapons = {}},
				{variant = "Пустыня", class = "npc_vj_glcwimp_stormtrooper_incinerator_sand", weapons = {}},
			}
		},
		{
			id = "engineer", name = "Имперский инженер", role = "Специалисты", tier = 1,
			description = "Инженер с бластером E-11.",
			size = 1,
			variants = {
				{variant = nil, class = "npc_vj_glcwimp_engineer", weapons = {"weapon_vj_glcw_e-11"}},
			}
		},
		{
			id = "jump", name = "Джамптрупер", role = "Специалисты", tier = 1,
			description = "Реактивный ранец, атака сверху.",
			size = 1,
			variants = {
				{variant = nil, class = "npc_vj_glcwimp_stormtrooper_jump", weapons = {}},
			}
		},
		{
			id = "heavy", name = "Тяжёлый штурмовик", role = "Специалисты", tier = 1,
			description = "Тяжёлое вооружение и броня.",
			size = 1,
			variants = {
				{variant = nil, class = "npc_vj_glcwimp_stormtrooper_heavy", weapons = {}},
			}
		},
		{
			id = "shadow", name = "Теневой штурмовик", role = "Элита", tier = 2,
			description = "Чёрная броня с маскировкой.",
			size = 1,
			variants = {
				{variant = nil, class = "npc_vj_glcwimp_stormtrooper_shadow", weapons = {"weapon_vj_glcw_e-11"}},
			}
		},
		{
			id = "navy", name = "Коммандо флота", role = "Элита", tier = 2,
			description = "Спецназ Имперского флота.",
			size = 1,
			variants = {
				{variant = "Боец", class = "npc_vj_glcwimp_navy_commando", weapons = {"weapon_vj_glcw_e-11"}},
				{variant = "Капитан", class = "npc_vj_glcwimp_navy_commando_captain", weapons = {"weapon_vj_glcw_dlt-19"}},
			}
		},
		{
			id = "death", name = "Штурмовик смерти", role = "Элита", tier = 2,
			description = "Элита разведки с E-11D.",
			size = 1,
			variants = {
				{variant = nil, class = "npc_vj_glcwimp_deathtrooper", weapons = {"weapon_vj_glcw_e-11d"}},
			}
		},
		{
			id = "dark", name = "Тёмный штурмовик", role = "Элита", tier = 3,
			description = "Боевой дроид проекта «Тёмный штурмовик».",
			size = 1,
			variants = {
				{variant = "Фаза III", class = "npc_vj_glcwimp_stormtrooper_dark", weapons = {"weapon_vj_glcw_darktroopergun"}},
				{variant = "Фаза 0", class = "npc_vj_glcwimp_stormtrooper_dark_zero", weapons = {"weapon_vj_glcw_imperial_arc_caster"}},
			}
		},
		{
			id = "commander", name = "Командир штурмовиков", role = "Элита", tier = 2,
			description = "Командир с оранжевым наплечником.",
			size = 1,
			variants = {
				{variant = nil, class = "npc_vj_glcwimp_stormtrooper_commander", weapons = {"weapon_vj_glcw_e-11"}},
			}
		},
		{
			id = "pilot", name = "Пилот TIE", role = "Пехота", tier = 1,
			description = "Пилот истребителя, в бою — с бластером.",
			size = 1,
			variants = {
				{variant = nil, class = "npc_vj_glcwimp_tie_fighter_pilot", weapons = {"weapon_vj_glcw_e-11"}},
			}
		},
		{
			id = "probe", name = "Зонд-дроид", role = "Техника", tier = 2,
			description = "Разведывательный дроид-зонд.",
			bVehicle = true,
			size = 1,
			variants = {
				{variant = nil, class = "npc_vj_glcwimp_probedroid", weapons = {}},
			}
		},
		{
			id = "sentry", name = "Имперская турель", role = "Техника", tier = 2,
			description = "Стационарная турель Империи.",
			bVehicle = true,
			size = 1,
			variants = {
				{variant = nil, class = "npc_vj_glcwimp_sentry_gun", weapons = {}},
			}
		},
		{
			id = "atst", name = "AT-ST", role = "Техника", tier = 3,
			description = "Двуногий разведывательный шагоход.",
			bVehicle = true,
			size = 2,
			variants = {
				{variant = nil, class = "npc_vj_glcwimp_atst", weapons = {}},
			}
		},
		{
			id = "atat", name = "AT-AT", role = "Техника", tier = 4,
			description = "Шагающий бронетранспорт. Огромный и смертоносный.",
			bVehicle = true,
			size = 6,
			variants = {
				{variant = nil, class = "npc_vj_glcwimp_atat", weapons = {}},
			}
		},
}

SWS.Units.rebels = {
		{
			id = "trooper", name = "Солдат Альянса", role = "Пехота", tier = 1,
			description = "Бластерная винтовка A280.",
			size = 1,
			variants = {
				{variant = "Город", class = "npc_vj_glcwreb_rebel_trooper", weapons = {"weapon_vj_glcw_a280", "weapon_vj_glcw_a280", "weapon_vj_glcw_dh-17"}},
				{variant = "Лес", class = "npc_vj_glcwreb_rebel_trooper_woodland", weapons = {"weapon_vj_glcw_a280", "weapon_vj_glcw_a280", "weapon_vj_glcw_dh-17"}},
				{variant = "Милиция Коты", class = "npc_vj_glcwk_kota_militia_trooper", weapons = {"weapon_vj_glcw_a280", "weapon_vj_glcw_a280", "weapon_vj_glcw_dh-17"}},
			}
		},
		{
			id = "fleet", name = "Флотский солдат", role = "Пехота", tier = 1,
			description = "Защитник кораблей Альянса с DH-17.",
			size = 1,
			variants = {
				{variant = nil, class = "npc_vj_glcwreb_rebel_fleet_trooper", weapons = {"weapon_vj_glcw_dh-17"}},
			}
		},
		{
			id = "sniper", name = "Снайпер Альянса", role = "Специалисты", tier = 1,
			description = "Дальнобойная винтовка.",
			size = 1,
			variants = {
				{variant = "Город", class = "npc_vj_glcwreb_rebel_trooper_sniper", weapons = {"weapon_vj_glcw_rebelsniper"}},
				{variant = "Лес", class = "npc_vj_glcwreb_rebel_trooper_sniper_woodland", weapons = {"weapon_vj_glcw_rebelsniper"}},
				{variant = "Милиция Коты", class = "npc_vj_glcwk_kota_militia_trooper_sniper", weapons = {"weapon_vj_glcw_rebelsniper"}},
			}
		},
		{
			id = "rocketeer", name = "Ракетчик Альянса", role = "Специалисты", tier = 1,
			description = "Ракетомёт против шагоходов.",
			size = 1,
			variants = {
				{variant = "Город", class = "npc_vj_glcwreb_rebel_trooper_rocketeer", weapons = {"weapon_vj_glcw_rebelrpg"}},
				{variant = "Лес", class = "npc_vj_glcwreb_rebel_trooper_rocketeer_woodland", weapons = {"weapon_vj_glcw_rebelrpg"}},
				{variant = "Милиция Коты", class = "npc_vj_glcwk_kota_militia_trooper_rocketeer", weapons = {"weapon_vj_glcw_rebelrpg"}},
			}
		},
		{
			id = "heavy", name = "Тяжёлый солдат", role = "Специалисты", tier = 1,
			description = "Тяжёлое оружие поддержки.",
			size = 1,
			variants = {
				{variant = "Город", class = "npc_vj_glcwreb_rebel_heavy_trooper", weapons = {}},
				{variant = "Лес", class = "npc_vj_glcwreb_rebel_heavy_trooper_woodland", weapons = {}},
				{variant = "Милиция Коты", class = "npc_vj_glcwk_kota_militia_heavy_trooper", weapons = {}},
			}
		},
		{
			id = "wookiee", name = "Вуки-воин", role = "Элита", tier = 2,
			description = "Арбалет-боукастер и сила вуки.",
			size = 1,
			variants = {
				{variant = nil, class = "npc_vj_glcwreb_wookiee", weapons = {"weapon_vj_glcw_bowcaster"}},
			}
		},
		{
			id = "t5b", name = "Танк T5B", role = "Техника", tier = 3,
			description = "Танк на воздушной подушке.",
			bVehicle = true,
			size = 3,
			variants = {
				{variant = nil, class = "npc_vj_glcwreb_t5btank", weapons = {}},
			}
		},
}
