--[[
	Выбор стороны в стиле Battlefront: четыре высокие карточки с артом, по две на эпоху
	(«Войны клонов» и «Гражданская война»). Карточка под курсором раздвигается, показывает
	описание, состав войск и кнопку «ВЫБРАТЬ». Фон — облёт карты камерой.
]]

local UI = SWS.UI

local PANEL = {}

function PANEL:Init()
	if (IsValid(SWS.sideMenu)) then
		SWS.sideMenu:Remove()
	end

	SWS.sideMenu = self

	self:SetSize(ScrW(), ScrH())
	self:SetPos(0, 0)
	self:MakePopup()
	self:SetAlpha(0)
	self:AlphaTo(255, 0.4)

	self.weights = {}
	self.cards = {}

	for index, faction in ipairs(SWS.Factions) do
		self.weights[index] = 1

		local card = self:Add("DButton")
		card:SetText("")
		card.faction = faction
		card.index = index
		card.hover = 0

		card.OnCursorEntered = function()
			UI.Sound("hover")
		end

		card.DoClick = function(this)
			UI.Sound("click")

			net.Start("SWS_ChooseSide")
				net.WriteUInt(this.index, 4)
			net.SendToServer()

			self:Close()
		end

		card.Paint = function(this, width, height)
			self:PaintCard(this, width, height)
		end

		self.cards[index] = card
	end

	-- назад (если сторона уже есть)
	self.back = self:Add("DButton")
	self.back:SetText("")
	self.back:SetSize(ScreenScale(60), ScreenScale(13))
	self.back.Paint = function(this, width, height)
		local hovered = this:IsHovered()
		local keyW = UI.Key("ESC", 0, height * 0.5 - ScreenScale(4), 255)

		draw.SimpleText("НАЗАД", "SWSLabel", keyW + ScreenScale(4), height * 0.5, Color(255, 255, 255, hovered and 255 or 190),
			TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	self.back.DoClick = function()
		UI.Sound("click")
		self:Close()
	end
end

function PANEL:Close()
	if (self.bClosing) then
		return
	end

	self.bClosing = true
	self:AlphaTo(0, 0.25, 0, function()
		if (IsValid(self)) then
			self:Remove()
		end
	end)
end

function PANEL:OnKeyCodePressed(key)
	if (key == KEY_ESCAPE or key == KEY_F2) and SWS.GetFaction(LocalPlayer()) then
		self:Close()
	end
end

function PANEL:Think()
	self.back:SetVisible(SWS.GetFaction(LocalPlayer()) != nil)

	-- карточка под курсором раздвигается
	local frameTime = FrameTime()
	local changed = false

	for index, card in ipairs(self.cards) do
		local target = card:IsHovered() and 1.45 or 1
		local weight = Lerp(math.min(frameTime * 10, 1), self.weights[index], target)

		if (math.abs(weight - self.weights[index]) > 0.0005) then
			changed = true
		end

		self.weights[index] = weight
		card.hover = math.Approach(card.hover, card:IsHovered() and 1 or 0, frameTime * 6)
	end

	if (changed or !self.bLaidOut) then
		self:LayoutCards()
	end
end

function PANEL:LayoutCards()
	self.bLaidOut = true

	local margin = ScreenScale(18)
	local gap = ScreenScale(4)
	local eraGap = ScreenScale(12)
	local top = ScreenScale(82)
	local height = ScrH() - top - ScreenScale(34)
	local available = ScrW() - margin * 2 - gap * 2 - eraGap
	local total = 0

	for _, weight in ipairs(self.weights) do
		total = total + weight
	end

	local x = margin

	for index, card in ipairs(self.cards) do
		local width = available * self.weights[index] / total

		card:SetPos(x, top)
		card:SetSize(width, height)

		x = x + width + (index == 2 and eraGap or gap)
	end

	self.back:SetPos(margin, ScrH() - ScreenScale(24))
end

function PANEL:PaintCard(card, width, height)
	local faction = card.faction
	local color = faction.color
	local hover = card.hover
	local art = UI.Material(faction.art, "smooth")

	-- арт «обложкой»
	if (!art:IsError()) then
		local artW, artH = art:Width(), art:Height()
		local scale = math.max(width / artW, height / artH) * (1.04 - hover * 0.04)
		local drawW, drawH = artW * scale, artH * scale

		-- панель сама обрезает рисование по своим границам
		surface.SetMaterial(art)
		surface.SetDrawColor(255, 255, 255, 170 + hover * 85)
		surface.DrawTexturedRect(width * 0.5 - drawW * 0.5, height * 0.5 - drawH * 0.5, drawW, drawH)
	else
		surface.SetDrawColor(color.r * 0.25, color.g * 0.25, color.b * 0.25, 255)
		surface.DrawRect(0, 0, width, height)

		local icon = UI.Material(faction.icon, "smooth")

		if (!icon:IsError()) then
			local size = math.min(width, height) * 0.5

			surface.SetMaterial(icon)
			surface.SetDrawColor(255, 255, 255, 40)
			surface.DrawTexturedRect(width * 0.5 - size * 0.5, height * 0.35 - size * 0.5, size, size)
		end
	end

	-- затемнение снизу и цвет стороны
	UI.Gradient(0, height * 0.35, width, height * 0.65, Color(0, 0, 0, 245), "up")
	UI.Gradient(0, height * 0.6, width, height * 0.4, Color(color.r, color.g, color.b, 50 + hover * 50), "up")

	-- рамка
	surface.SetDrawColor(255, 255, 255, 30 + hover * 200)
	surface.DrawOutlinedRect(0, 0, width, height, hover > 0.5 and 2 or 1)

	surface.SetDrawColor(color.r, color.g, color.b, 255)
	surface.DrawRect(0, height - 4, width, 4)

	local pad = ScreenScale(8)
	local y = height - ScreenScale(56) - hover * ScreenScale(40)

	-- эмблема пака и название
	local icon = UI.Material(faction.icon, "smooth")

	if (!icon:IsError()) then
		surface.SetMaterial(icon)
		surface.SetDrawColor(255, 255, 255, 230)
		surface.DrawTexturedRect(pad, y - ScreenScale(16), ScreenScale(12), ScreenScale(12))
	end

	UI.Spaced(faction.short, "SWSTitle", pad, y, UI.colors.text, 2)
	draw.SimpleText(UI.Fit(SWS.Upper(faction.name), "SWSSmall", width - pad * 2), "SWSSmall", pad, y + ScreenScale(21),
		Color(color.r, color.g, color.b))

	-- текущая сторона
	if (LocalPlayer():GetNW2Int("SWS_Side", 0) == card.index) then
		surface.SetFont("SWSTiny")

		local textW, textH = surface.GetTextSize("ТЕКУЩАЯ СТОРОНА")

		surface.SetDrawColor(255, 255, 255, 255)
		surface.DrawRect(pad, pad, textW + 12, textH + 6)

		draw.SimpleText("ТЕКУЩАЯ СТОРОНА", "SWSTiny", pad + 6, pad + 3, UI.colors.dark)
	end

	-- сторону ведёт ИИ-командир (можно играть вместе с ним)
	for _, commander in ipairs(ents.FindByClass("sws_ai_commander")) do
		if (commander:GetSide() == card.index) then
			surface.SetFont("SWSTiny")

			local textW, textH = surface.GetTextSize("ВЕДЁТ ИИ")
			local tagX = width - pad - textW - 12

			surface.SetDrawColor(color.r, color.g, color.b, 230)
			surface.DrawRect(tagX, pad, textW + 12, textH + 6)

			draw.SimpleText("ВЕДЁТ ИИ", "SWSTiny", tagX + 6, pad + 3, color_white)
			break
		end
	end

	-- раскрытая часть: описание, состав и кнопка
	if (hover > 0.02) then
		local alpha = 255 * hover
		local infoY = y + ScreenScale(31)

		draw.SimpleText(UI.Fit(faction.tagline, "SWSBody", width - pad * 2), "SWSBody", pad, infoY, Color(255, 255, 255, alpha * 0.85))

		local units = SWS.Units[faction.id] or {}
		local infantry, vehicles = 0, 0

		for _, unit in ipairs(units) do
			if (unit.bVehicle) then
				vehicles = vehicles + 1
			else
				infantry = infantry + 1
			end
		end

		local players = #team.GetPlayers(card.index)
		local stats = string.format("ПЕХОТА %d   ·   ТЕХНИКА %d   ·   ИГРОКОВ %d", infantry, vehicles, players)

		draw.SimpleText(stats, "SWSTiny", pad, infoY + ScreenScale(10), Color(color.r, color.g, color.b, alpha))

		-- кнопка «ВЫБРАТЬ» белой плашкой
		local buttonW, buttonH = math.min(width - pad * 2, ScreenScale(90)), ScreenScale(13)
		local buttonY = height - buttonH - ScreenScale(8)

		surface.SetDrawColor(255, 255, 255, alpha)
		surface.DrawRect(pad, buttonY, buttonW, buttonH)

		UI.Spaced("ВЫБРАТЬ", "SWSLabel", pad + buttonW * 0.5, buttonY + buttonH * 0.5, Color(14, 16, 20, alpha), 3,
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	else
		draw.SimpleText(faction.era, "SWSTiny", pad, height - ScreenScale(14), Color(255, 255, 255, 140))
	end
end

function PANEL:Paint(width, height)
	-- затемнение мира
	surface.SetDrawColor(4, 6, 9, 170)
	surface.DrawRect(0, 0, width, height)

	UI.Gradient(0, 0, width, height * 0.45, Color(0, 0, 0, 220), "down")

	local margin = ScreenScale(18)

	UI.Spaced("STAR WARS SANDBOX", "SWSHuge", margin, ScreenScale(12), UI.colors.text, 4)
	UI.Spaced("ВЫБЕРИТЕ СТОРОНУ", "SWSHeader", margin, ScreenScale(44), UI.colors.dim, 4)

	-- подписи эпох над парами карточек
	local first, third = self.cards[1], self.cards[3]

	if (IsValid(first) and IsValid(third)) then
		local eraY = first.y - ScreenScale(10)

		UI.Spaced("ВОЙНЫ КЛОНОВ", "SWSTab", first.x, eraY, Color(255, 255, 255, 200), 3, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		UI.Spaced("ГРАЖДАНСКАЯ ВОЙНА", "SWSTab", third.x, eraY, Color(255, 255, 255, 200), 3, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

		surface.SetDrawColor(255, 255, 255, 40)
		surface.DrawRect(first.x, eraY + ScreenScale(5), self.cards[2].x + self.cards[2]:GetWide() - first.x, 1)
		surface.DrawRect(third.x, eraY + ScreenScale(5), self.cards[4].x + self.cards[4]:GetWide() - third.x, 1)
	end

	draw.SimpleText("Командуйте войсками с высоты или вселяйтесь в любого бойца. F1 — управление.", "SWSBody",
		width - margin, height - ScreenScale(18), Color(255, 255, 255, 150), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
end

vgui.Register("SWSSideMenu", PANEL, "EditablePanel")

concommand.Add("sws_sidemenu", function()
	if (IsValid(SWS.sideMenu)) then
		SWS.sideMenu:Close()
		return
	end

	vgui.Create("SWSSideMenu")
end)

-- без стороны — меню открыто
hook.Add("Think", "SWS_SideMenuAuto", function()
	local client = LocalPlayer()

	if (!IsValid(client) or SWS.GetMode(client) != SWS.MODE_MENU or IsValid(SWS.sideMenu)) then
		return
	end

	if ((SWS.nextMenuTry or 0) > RealTime()) then
		return
	end

	SWS.nextMenuTry = RealTime() + 1
	vgui.Create("SWSSideMenu")
end)
