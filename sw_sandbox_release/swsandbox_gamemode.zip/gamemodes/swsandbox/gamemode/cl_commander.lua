--[[
	Режим командира (RTS): камера сверху, выделение войск, приказы, отряды 1–9, высадка юнитов.

	Камера: WASD / стрелки / курсор у края экрана — двигать, Q/E или зажатое колесо — поворот,
	колесо — высота, Shift — быстрее, Пробел — к выбранным.
	Войска: ЛКМ — выбрать (рамка — несколько, Shift — добавить, двойной клик — все такие же на экране),
	ПКМ — идти и держать точку (Ctrl+ПКМ — шагом), ПКМ по врагу — атаковать его,
	G, затем ПКМ — атака с ходу, H — держать позицию, X — свободный бой,
	Ctrl+1..9 — назначить отряд, 1..9 — выбрать отряд (дважды — камера к нему),
	F — вселиться в бойца, Delete — распустить, Esc — снять выбор / отменить высадку.
]]

SWS.Cmd = SWS.Cmd or {
	focus = nil,
	yaw = 0,
	pitch = 56,
	distance = 900,
	selection = {},
	squads = {},
	markers = {}
}

local Cmd = SWS.Cmd

local MIN_DISTANCE, MAX_DISTANCE = 220, 3200
local FOV = 72

function Cmd.IsActive()
	local mode = SWS.GetMode(LocalPlayer())

	return mode == SWS.MODE_COMMANDER
end

function Cmd.GetCameraAngles()
	return Angle(Cmd.pitch, Cmd.yaw, 0)
end

function Cmd.GetCameraOrigin()
	local focus = Cmd.focus or LocalPlayer():GetPos()
	local origin = focus - Cmd.GetCameraAngles():Forward() * Cmd.distance

	-- камера не проходит сквозь потолок и стены
	local trace = util.TraceLine({
		start = focus + Vector(0, 0, 24),
		endpos = origin,
		mask = MASK_SOLID_BRUSHONLY
	})

	if (trace.Hit) then
		origin = trace.HitPos + trace.HitNormal * 12
	end

	return origin
end

-- util.IsInWorld есть только на сервере: снаружи карты — сплошной «солид»
function Cmd.InWorld(position)
	return bit.band(util.PointContents(position), CONTENTS_SOLID) == 0
end

-- луч из камеры через точку экрана
function Cmd.TraceScreen(x, y, filterUnits)
	local origin = Cmd.lastOrigin or Cmd.GetCameraOrigin()
	local direction = gui.ScreenToVector(x, y)

	return util.TraceLine({
		start = origin,
		endpos = origin + direction * 60000,
		mask = filterUnits and MASK_SOLID_BRUSHONLY or MASK_SHOT,
		filter = LocalPlayer()
	})
end

-- свои войска (обновляется раз в 0.25 с)
Cmd.units = Cmd.units or {}

function Cmd.RefreshUnits()
	local client = LocalPlayer()
	local units = {}

	for _, entity in ipairs(ents.FindByClass("npc_*")) do
		if (entity:GetNW2Entity("SWS_Owner") == client and SWS.GetHealth(entity) > 0) then
			units[#units + 1] = entity
		end
	end

	Cmd.units = units

	local buildings = {}

	for _, entity in ipairs(ents.FindByClass("sws_building")) do
		if (entity:GetCommander() == client) then
			buildings[#buildings + 1] = entity
		end
	end

	Cmd.buildings = buildings

	if (IsValid(Cmd.building) == false) then
		Cmd.building = nil
	end

	-- чистим выбор и отряды от погибших
	for entity in pairs(Cmd.selection) do
		if (!IsValid(entity) or SWS.GetHealth(entity) <= 0) then
			Cmd.selection[entity] = nil
		end
	end

	for number, squad in pairs(Cmd.squads) do
		for index = #squad, 1, -1 do
			if (!IsValid(squad[index]) or SWS.GetHealth(squad[index]) <= 0) then
				table.remove(squad, index)
			end
		end

		if (#squad == 0) then
			Cmd.squads[number] = nil
		end
	end
end

function Cmd.GetSelected()
	local list = {}

	for entity in pairs(Cmd.selection) do
		if (IsValid(entity)) then
			list[#list + 1] = entity
		end
	end

	table.sort(list, function(a, b)
		return a:EntIndex() < b:EntIndex()
	end)

	return list
end

function Cmd.SetSelection(list, bAdd)
	if (!bAdd) then
		Cmd.selection = {}
	end

	for _, entity in ipairs(list) do
		if (IsValid(entity)) then
			Cmd.selection[entity] = true
		end
	end
end

function Cmd.CenterOn(list)
	if (#list == 0) then
		return
	end

	local center = Vector(0, 0, 0)

	for _, entity in ipairs(list) do
		center = center + entity:GetPos()
	end

	Cmd.focusTarget = center / #list
end

-- приказ выбранным
function Cmd.SendOrder(order, position, target, bRun)
	local list = Cmd.GetSelected()

	if (#list == 0) then
		return
	end

	net.Start("SWS_Order")
		net.WriteUInt(order, 3)
		net.WriteVector(position or vector_origin)
		net.WriteEntity(IsValid(target) and target or NULL)
		net.WriteBool(bRun != false)
		net.WriteUInt(math.min(#list, 255), 8)

		for index = 1, math.min(#list, 255) do
			net.WriteEntity(list[index])
		end
	net.SendToServer()

	SWS.UI.Sound("order")

	if (position and (order == SWS.ORDER_MOVE or order == SWS.ORDER_ATTACK)) then
		table.insert(Cmd.markers, {position = position, start = RealTime(), order = order})
	elseif (IsValid(target)) then
		table.insert(Cmd.markers, {entity = target, start = RealTime(), order = SWS.ORDER_TARGET})
	end
end

-- высадка: выбранный юнит следует за курсором, ЛКМ — поставить
function Cmd.StartPlacing(unit, variantIndex, count)
	Cmd.placing = {unit = unit, variant = variantIndex or 1, count = count or 1}
	SWS.UI.Sound("click")
end

-- постройка: здание следует за курсором, колесо — поворот, ЛКМ — поставить
function Cmd.StartBuilding(buildingType)
	Cmd.placing = nil
	Cmd.placingBuilding = {type = buildingType, yaw = (Cmd.yaw + 180) % 360}
	SWS.UI.Sound("click")
end

function Cmd.PlaceBuilding(position)
	local placing = Cmd.placingBuilding

	net.Start("SWS_Build")
		net.WriteString(placing.type)
		net.WriteVector(position)
		net.WriteFloat(placing.yaw)
	net.SendToServer()

	SWS.UI.Sound("spawn")

	if (!input.IsKeyDown(KEY_LSHIFT) and !input.IsKeyDown(KEY_RSHIFT)) then
		Cmd.placingBuilding = nil
	end
end

-- свои здания (обновляется вместе со списком войск)
Cmd.buildings = Cmd.buildings or {}

function Cmd.IsOwnBuilding(entity)
	return SWS.IsBuilding(entity) and entity:GetCommander() == LocalPlayer()
end

function Cmd.BuildingCommand(building, action, writer)
	net.Start("SWS_BuildingCmd")
		net.WriteEntity(building)
		net.WriteUInt(action, 3)

		if (writer) then
			writer()
		end
	net.SendToServer()
end

-- заказ юнита: в выбранное здание или в ближайшее подходящее; без зданий — высадка (если разрешена)
function Cmd.OrderUnit(unit, variantIndex, count)
	if (GetConVar("sws_free_landing"):GetBool()) then
		Cmd.StartPlacing(unit, variantIndex, count)
		return
	end

	local building = Cmd.building

	if (!IsValid(building) or !Cmd.IsOwnBuilding(building) or !SWS.BuildingProduces(building:GetBuildingType(), unit.role)) then
		building = nil

		local best, bestScore

		for _, entity in ipairs(Cmd.buildings) do
			if (IsValid(entity) and entity:IsBuilt() and SWS.BuildingProduces(entity:GetBuildingType(), unit.role)) then
				local score = #SWS.ParseQueue(entity:GetQueue()) * 1000 + entity:GetPos():Distance(Cmd.focus or entity:GetPos()) * 0.1

				if (!bestScore or score < bestScore) then
					best, bestScore = entity, score
				end
			end
		end

		building = best
	end

	if (!building) then
		local need = unit.role == "Техника" and "Завод техники" or "Казарму"

		SWS.UI.Notify("Сначала постройте " .. need .. " (вкладка «Здания»).", 2)
		return
	end

	Cmd.BuildingCommand(building, SWS.BUILDING_QUEUE, function()
		net.WriteString(unit.id)
		net.WriteUInt(variantIndex or 1, 5)
		net.WriteUInt(math.Clamp(count or 1, 1, 10), 5)
	end)

	SWS.UI.Sound("spawn")
end

function Cmd.Place(position)
	local placing = Cmd.placing

	if (!placing) then
		return
	end

	net.Start("SWS_Spawn")
		net.WriteString(placing.unit.id)
		net.WriteUInt(placing.variant, 5)
		net.WriteUInt(math.Clamp(placing.count, 1, 31), 5)
		net.WriteVector(position)
		net.WriteFloat(Cmd.yaw)
	net.SendToServer()

	SWS.UI.Sound("spawn")
	table.insert(Cmd.markers, {position = position, start = RealTime(), order = 0})

	-- Shift — продолжать высаживать
	if (!input.IsKeyDown(KEY_LSHIFT) and !input.IsKeyDown(KEY_RSHIFT)) then
		Cmd.placing = nil
	end
end

-- высаженные — сразу выбраны
net.Receive("SWS_Spawned", function()
	local count = net.ReadUInt(6)
	local indices = {}

	for _ = 1, count do
		indices[#indices + 1] = net.ReadUInt(13)
	end

	-- новые NPC доходят до клиента не сразу — несколько попыток
	local bAdd = input.IsKeyDown(KEY_LSHIFT)
	local tries = 0

	local function TrySelect()
		tries = tries + 1

		local list = {}

		for _, index in ipairs(indices) do
			local entity = Entity(index)

			if (IsValid(entity)) then
				list[#list + 1] = entity
			end
		end

		if (#list < #indices and tries < 10) then
			timer.Simple(0.15, TrySelect)
			return
		end

		Cmd.SetSelection(list, bAdd)
	end

	timer.Simple(0.1, TrySelect)
end)

-- юнит под курсором: прямое попадание или ближайший к курсору на экране
function Cmd.UnitAt(x, y, radius)
	local trace = Cmd.TraceScreen(x, y)

	if (IsValid(trace.Entity) and trace.Entity:IsNPC() and trace.Entity:GetNW2Entity("SWS_Owner") == LocalPlayer()) then
		return trace.Entity
	end

	local best, bestDistance = nil, (radius or 26) ^ 2

	for _, entity in ipairs(Cmd.units) do
		local screen = entity:WorldSpaceCenter():ToScreen()

		if (screen.visible) then
			local distance = (screen.x - x) ^ 2 + (screen.y - y) ^ 2

			if (distance < bestDistance) then
				best, bestDistance = entity, distance
			end
		end
	end

	return best
end

-- враг под курсором (чужой NPC или игрок другой стороны)
function Cmd.EnemyAt(x, y)
	local trace = Cmd.TraceScreen(x, y)
	local entity = trace.Entity

	if (!IsValid(entity)) then
		return nil
	end

	if (entity:IsNPC() and entity:GetNW2Int("SWS_Side", 0) != LocalPlayer():GetNW2Int("SWS_Side", 0)) then
		return entity
	end

	if (entity:IsPlayer() and entity:Team() != LocalPlayer():Team()) then
		return entity
	end
end

-- главный панель-перехватчик ввода командира (на весь экран, под HUD-панелями)
local PANEL = {}

function PANEL:Init()
	self:SetSize(ScrW(), ScrH())
	self:SetPos(0, 0)
	self:MakePopup()
	self:SetKeyboardInputEnabled(true)
	self:SetMouseInputEnabled(true)
	self:SetCursor("arrow")

	self.lastClick = 0

	if (SWS.BuildCommanderHUD) then
		SWS.BuildCommanderHUD(self)
	end
end

function PANEL:OnMousePressed(code)
	local x, y = self:CursorPos()

	if (code == MOUSE_LEFT) then
		if (Cmd.placingBuilding) then
			local trace = Cmd.TraceScreen(x, y, true)

			if (trace.Hit) then
				Cmd.PlaceBuilding(trace.HitPos)
			end

			return
		end

		if (Cmd.placing) then
			local trace = Cmd.TraceScreen(x, y, true)

			if (trace.Hit) then
				Cmd.Place(trace.HitPos)
			end

			return
		end

		self.dragStart = {x, y}
		self:MouseCapture(true)
	elseif (code == MOUSE_RIGHT) then
		if (Cmd.placing or Cmd.placingBuilding) then
			Cmd.placing = nil
			Cmd.placingBuilding = nil
			return
		end

		-- выбрано здание (и нет бойцов) — точка сбора; после G — сбор с атакой
		if (IsValid(Cmd.building) and Cmd.IsOwnBuilding(Cmd.building) and next(Cmd.selection) == nil) then
			local trace = Cmd.TraceScreen(x, y, true)

			if (trace.Hit) then
				local bAttack = Cmd.attackMove == true
				Cmd.attackMove = nil

				Cmd.BuildingCommand(Cmd.building, SWS.BUILDING_RALLY, function()
					net.WriteVector(trace.HitPos)
					net.WriteBool(bAttack)
				end)

				SWS.UI.Sound("order")
				table.insert(Cmd.markers, {position = trace.HitPos, start = RealTime(), order = bAttack and SWS.ORDER_ATTACK or SWS.ORDER_MOVE})
			end

			return
		end

		if (Cmd.attackMove) then
			Cmd.attackMove = nil

			local trace = Cmd.TraceScreen(x, y, true)

			if (trace.Hit) then
				Cmd.SendOrder(SWS.ORDER_ATTACK, trace.HitPos)
			end

			return
		end

		local enemy = Cmd.EnemyAt(x, y)

		if (enemy) then
			Cmd.SendOrder(SWS.ORDER_TARGET, nil, enemy)
			return
		end

		local trace = Cmd.TraceScreen(x, y, true)

		if (trace.Hit) then
			local bWalk = input.IsKeyDown(KEY_LCONTROL) or input.IsKeyDown(KEY_RCONTROL)
			Cmd.SendOrder(SWS.ORDER_MOVE, trace.HitPos, nil, !bWalk)
		end
	elseif (code == MOUSE_MIDDLE) then
		self.rotateStart = {x, Cmd.yaw}
		self:MouseCapture(true)
	end
end

function PANEL:OnMouseReleased(code)
	local x, y = self:CursorPos()

	if (code == MOUSE_MIDDLE) then
		self.rotateStart = nil
		self:MouseCapture(false)
		return
	end

	if (code != MOUSE_LEFT or !self.dragStart) then
		return
	end

	self:MouseCapture(false)

	local startX, startY = self.dragStart[1], self.dragStart[2]
	local bAdd = input.IsKeyDown(KEY_LSHIFT) or input.IsKeyDown(KEY_RSHIFT)

	self.dragStart = nil

	-- рамка
	if (math.abs(x - startX) > 6 or math.abs(y - startY) > 6) then
		local minX, maxX = math.min(x, startX), math.max(x, startX)
		local minY, maxY = math.min(y, startY), math.max(y, startY)
		local list = {}

		for _, entity in ipairs(Cmd.units) do
			local screen = entity:WorldSpaceCenter():ToScreen()

			if (screen.visible and screen.x >= minX and screen.x <= maxX and screen.y >= minY and screen.y <= maxY) then
				list[#list + 1] = entity
			end
		end

		Cmd.SetSelection(list, bAdd)

		if (#list > 0) then
			Cmd.building = nil
			SWS.UI.Sound("click")
		end

		return
	end

	-- клик
	local unit = Cmd.UnitAt(x, y)
	local now = RealTime()

	if (IsValid(unit) and now - self.lastClick < 0.35 and self.lastUnit == unit) then
		-- двойной клик: все такие же на экране
		local unitID = unit:GetNW2String("SWS_Unit")
		local list = {}

		for _, entity in ipairs(Cmd.units) do
			local screen = entity:WorldSpaceCenter():ToScreen()

			if (entity:GetNW2String("SWS_Unit") == unitID and screen.visible
				and screen.x > 0 and screen.x < ScrW() and screen.y > 0 and screen.y < ScrH()) then
				list[#list + 1] = entity
			end
		end

		Cmd.SetSelection(list, bAdd)
	elseif (!IsValid(unit) and SWS.IsBuilding(Cmd.TraceScreen(x, y).Entity)) then
		Cmd.building = Cmd.TraceScreen(x, y).Entity
		Cmd.selection = {}
		SWS.UI.Sound("click")
	elseif (IsValid(unit)) then
		Cmd.building = nil

		if (bAdd and Cmd.selection[unit]) then
			Cmd.selection[unit] = nil
		else
			Cmd.SetSelection({unit}, bAdd)
		end

		SWS.UI.Sound("click")
	elseif (!bAdd) then
		Cmd.selection = {}
		Cmd.building = nil
	end

	self.lastClick = now
	self.lastUnit = unit
end

function PANEL:OnMouseWheeled(delta)
	if (Cmd.placingBuilding) then
		Cmd.placingBuilding.yaw = (Cmd.placingBuilding.yaw + (delta > 0 and 15 or -15)) % 360
		return true
	end

	Cmd.distanceTarget = math.Clamp((Cmd.distanceTarget or Cmd.distance) * (delta > 0 and 0.85 or 1.18), MIN_DISTANCE, MAX_DISTANCE)
	return true
end

local squadKeys = {
	[KEY_1] = 1, [KEY_2] = 2, [KEY_3] = 3, [KEY_4] = 4, [KEY_5] = 5,
	[KEY_6] = 6, [KEY_7] = 7, [KEY_8] = 8, [KEY_9] = 9
}

function PANEL:OnKeyCodePressed(key)
	local bCtrl = input.IsKeyDown(KEY_LCONTROL) or input.IsKeyDown(KEY_RCONTROL)
	local squad = squadKeys[key]

	if (squad) then
		if (bCtrl) then
			local list = Cmd.GetSelected()

			Cmd.squads[squad] = #list > 0 and list or nil
			SWS.UI.Notify(#list > 0 and string.format("Отряд %d: %d бойцов", squad, #list) or ("Отряд " .. squad .. " распущен"))
		elseif (Cmd.squads[squad]) then
			local now = RealTime()

			Cmd.SetSelection(Cmd.squads[squad], input.IsKeyDown(KEY_LSHIFT))

			if (self.lastSquad == squad and now - (self.lastSquadTime or 0) < 0.4) then
				Cmd.CenterOn(Cmd.squads[squad])
			end

			self.lastSquad = squad
			self.lastSquadTime = now
			SWS.UI.Sound("click")
		end

		return
	end

	if (key == KEY_H) then
		Cmd.SendOrder(SWS.ORDER_HOLD)
	elseif (key == KEY_X) then
		Cmd.SendOrder(SWS.ORDER_FREE)
	elseif (key == KEY_G) then
		if (table.Count(Cmd.selection) > 0 or IsValid(Cmd.building)) then
			Cmd.attackMove = true
		end
	elseif (key == KEY_DELETE) then
		if (IsValid(Cmd.building) and Cmd.IsOwnBuilding(Cmd.building) and next(Cmd.selection) == nil) then
			Cmd.BuildingCommand(Cmd.building, SWS.BUILDING_DEMOLISH)
			Cmd.building = nil
		else
			Cmd.SendOrder(SWS.ORDER_DISMISS)
			Cmd.selection = {}
		end
	elseif (key == KEY_R) then
		if (IsValid(Cmd.building) and Cmd.IsOwnBuilding(Cmd.building)) then
			Cmd.BuildingCommand(Cmd.building, SWS.BUILDING_REPEAT)
			SWS.UI.Sound("click")
		end
	elseif (key == KEY_F) then
		local list = Cmd.GetSelected()

		if (#list > 0) then
			Cmd.SendOrder(SWS.ORDER_POSSESS)
		end
	elseif (key == KEY_SPACE) then
		Cmd.CenterOn(Cmd.GetSelected())
	elseif (key == KEY_ESCAPE) then
		Cmd.placing = nil
		Cmd.placingBuilding = nil
		Cmd.attackMove = nil
		Cmd.selection = {}
		Cmd.building = nil
	elseif (key == KEY_A and bCtrl) then
		Cmd.SetSelection(Cmd.units)
	elseif (key == KEY_ENTER) then
		chat.Open(1)
	elseif (key == KEY_F1) then
		SWS.showHelp = !SWS.showHelp
	elseif (key == KEY_F2) then
		RunConsoleCommand("sws_sidemenu")
	elseif (key == KEY_F3) then
		RunConsoleCommand("sws_togglemode")
	end
end

function PANEL:Think()
	if (!Cmd.IsActive() or IsValid(SWS.sideMenu) or IsValid(SWS.deployMenu)) then
		return
	end

	local frameTime = RealFrameTime()
	local x, y = self:CursorPos()
	local keyboardFocus = vgui.GetKeyboardFocus()
	local bTyping = IsValid(keyboardFocus) and keyboardFocus:GetClassName() == "TextEntry"

	-- после клика по кнопкам HUD клавиши снова слушает командир
	if (!bTyping and keyboardFocus != self) then
		self:RequestFocus()
	end

	-- кнопку отпустили над другой панелью (HUD) — OnMouseReleased сюда не пришёл
	if (self.rotateStart and !input.IsMouseDown(MOUSE_MIDDLE)) then
		self.rotateStart = nil
	end

	if (self.dragStart and !input.IsMouseDown(MOUSE_LEFT)) then
		self.dragStart = nil
	end

	-- поворот зажатым колесом
	if (self.rotateStart) then
		Cmd.yaw = self.rotateStart[2] - (x - self.rotateStart[1]) * 0.35
	end

	-- чат, консоль, меню игры или окно игры не в фокусе — камера стоит
	if (bTyping or Cmd.bChatOpen or gui.IsConsoleVisible() or gui.IsGameUIVisible() or !system.HasFocus()) then
		return
	end

	local speed = Cmd.distance * 1.1 * frameTime

	if (input.IsKeyDown(KEY_LSHIFT)) then
		speed = speed * 2.2
	end

	local angles = Angle(0, Cmd.yaw, 0)
	local forward, right = angles:Forward(), angles:Right()
	local move = Vector(0, 0, 0)
	-- прокрутка у края экрана: только если включена и курсор задержался у края (не «пролетел» мимо)
	local edge = 2
	local bEdgeX = x <= edge and -1 or (x >= ScrW() - edge - 1 and 1 or 0)
	local bEdgeY = y <= edge and -1 or (y >= ScrH() - edge - 1 and 1 or 0)
	local bInside = x >= 0 and y >= 0 and x < ScrW() and y < ScrH()

	if (bInside and (bEdgeX != 0 or bEdgeY != 0)) then
		self.edgeSince = self.edgeSince or RealTime()
	else
		self.edgeSince = nil
	end

	local bEdge = GetConVar("sws_edge_scroll"):GetBool() and self.edgeSince and RealTime() - self.edgeSince > 0.3

	if (!bEdge) then
		bEdgeX, bEdgeY = 0, 0
	end

	local bCtrl = input.IsKeyDown(KEY_LCONTROL) or input.IsKeyDown(KEY_RCONTROL)

	if (!bCtrl) then
		if (input.IsKeyDown(KEY_W) or input.IsKeyDown(KEY_UP) or bEdgeY < 0) then move = move + forward end
		if (input.IsKeyDown(KEY_S) or input.IsKeyDown(KEY_DOWN) or bEdgeY > 0) then move = move - forward end
		if (input.IsKeyDown(KEY_D) or input.IsKeyDown(KEY_RIGHT) or bEdgeX > 0) then move = move + right end
		if (input.IsKeyDown(KEY_A) or input.IsKeyDown(KEY_LEFT) or bEdgeX < 0) then move = move - right end
	end

	if (move:LengthSqr() > 0) then
		local focus = Cmd.focus + move:GetNormalized() * speed

		-- за пределы карты не уезжаем
		if (Cmd.InWorld(focus + Vector(0, 0, 48)) or !Cmd.InWorld(Cmd.focus + Vector(0, 0, 48))) then
			Cmd.focus = focus
		end

		Cmd.focusTarget = nil
	end

	if (bCtrl) then
		return
	end

	if (input.IsKeyDown(KEY_Q)) then
		Cmd.yaw = Cmd.yaw + 90 * frameTime
	elseif (input.IsKeyDown(KEY_E)) then
		Cmd.yaw = Cmd.yaw - 90 * frameTime
	end
end

function PANEL:Paint(width, height)
	-- рамка выделения
	if (self.dragStart) then
		local x, y = self:CursorPos()
		local minX, minY = math.min(x, self.dragStart[1]), math.min(y, self.dragStart[2])
		local w, h = math.abs(x - self.dragStart[1]), math.abs(y - self.dragStart[2])
		local faction = SWS.GetFaction(LocalPlayer())
		local color = faction and faction.color or color_white

		surface.SetDrawColor(color.r, color.g, color.b, 30)
		surface.DrawRect(minX, minY, w, h)

		surface.SetDrawColor(255, 255, 255, 200)
		surface.DrawOutlinedRect(minX, minY, w, h)

		SWS.UI.Corners(minX - 2, minY - 2, w + 4, h + 4, 8, color, 2)
	end

	if (SWS.PaintCommanderOverlay) then
		SWS.PaintCommanderOverlay(self, width, height)
	end
end

vgui.Register("SWSCommander", PANEL, "EditablePanel")

CreateClientConVar("sws_edge_scroll", "0", true, false, "Двигать камеру командира, когда курсор у края экрана")

hook.Add("StartChat", "SWS_CommanderChat", function()
	Cmd.bChatOpen = true
end)

hook.Add("FinishChat", "SWS_CommanderChat", function()
	Cmd.bChatOpen = false
end)

-- включение / выключение панели и плавная камера
hook.Add("Think", "SWS_Commander", function()
	local client = LocalPlayer()

	if (!IsValid(client)) then
		return
	end

	local bActive = Cmd.IsActive()

	if (bActive and !IsValid(Cmd.panel)) then
		if (!Cmd.focus) then
			Cmd.focus = client:GetPos()
			Cmd.yaw = client:EyeAngles().y
		end

		-- после вселения камера возвращается к месту, где был боец
		local focusAt = client:GetNW2Float("SWS_FocusAt", 0)

		if (focusAt > (Cmd.lastFocusAt or 0)) then
			Cmd.lastFocusAt = focusAt
			Cmd.focus = client:GetNW2Vector("SWS_FocusTo", Cmd.focus)
		end

		Cmd.panel = vgui.Create("SWSCommander")
	elseif (!bActive and IsValid(Cmd.panel)) then
		Cmd.panel:Remove()
		Cmd.placing = nil
		Cmd.placingBuilding = nil
		Cmd.attackMove = nil
	end

	if (!bActive) then
		return
	end

	local frameTime = RealFrameTime()

	-- плавный перелёт и высота
	if (Cmd.focusTarget) then
		Cmd.focus = LerpVector(math.min(frameTime * 6, 1), Cmd.focus, Cmd.focusTarget)

		if (Cmd.focus:DistToSqr(Cmd.focusTarget) < 16) then
			Cmd.focusTarget = nil
		end
	end

	Cmd.distance = Lerp(math.min(frameTime * 8, 1), Cmd.distance, Cmd.distanceTarget or Cmd.distance)

	-- фокус «прилипает» к земле
	local ground = util.TraceLine({
		start = Cmd.focus + Vector(0, 0, 160),
		endpos = Cmd.focus - Vector(0, 0, 4000),
		mask = MASK_SOLID_BRUSHONLY
	})

	if (ground.Hit and !ground.StartSolid and math.abs(ground.HitPos.z - Cmd.focus.z) < 1200) then
		Cmd.focus.z = Lerp(math.min(frameTime * 5, 1), Cmd.focus.z, ground.HitPos.z)
	end

	-- что бы ни случилось — без NaN и без ухода в бесконечность
	if (Cmd.focus.x != Cmd.focus.x or Cmd.focus.y != Cmd.focus.y or Cmd.focus.z != Cmd.focus.z) then
		Cmd.focus = client:GetPos()
		Cmd.focusTarget = nil
	end

	-- раз в 0.25 с — список своих войск; раз в 0.1 с — камера серверу
	local now = RealTime()

	if ((Cmd.nextRefresh or 0) < now) then
		Cmd.nextRefresh = now + 0.25
		Cmd.RefreshUnits()
	end

	if ((Cmd.nextSend or 0) < now) then
		Cmd.nextSend = now + 0.1

		net.Start("SWS_Camera")
			net.WriteVector(Cmd.focus)
			net.WriteVector(Cmd.lastOrigin or Cmd.focus)
		net.SendToServer()
	end
end)

hook.Add("CalcView", "SWS_CommanderView", function(client, origin, angles, fov)
	local mode = SWS.GetMode(client)

	if (mode != SWS.MODE_COMMANDER and mode != SWS.MODE_MENU) then
		return
	end

	-- в меню выбора стороны — медленный облёт
	if (mode == SWS.MODE_MENU) then
		Cmd.focus = Cmd.focus or client:GetPos()
		Cmd.yaw = Cmd.yaw + RealFrameTime() * 3
	end

	local view = {
		origin = Cmd.GetCameraOrigin(),
		angles = Cmd.GetCameraAngles(),
		fov = FOV,
		drawviewer = false,
		znear = 4
	}

	Cmd.lastOrigin = view.origin

	return view
end)

-- командир — без прицела, оружия и стандартного HUD
local hiddenHUD = {
	CHudCrosshair = true, CHudHealth = true, CHudBattery = true, CHudAmmo = true,
	CHudSecondaryAmmo = true, CHudWeaponSelection = true, CHudDamageIndicator = true
}

hook.Add("HUDShouldDraw", "SWS_CommanderHUD", function(name)
	local mode = SWS.GetMode(LocalPlayer())

	if ((mode == SWS.MODE_COMMANDER or mode == SWS.MODE_MENU) and hiddenHUD[name]) then
		return false
	end
end)

hook.Add("PreDrawViewModel", "SWS_CommanderViewModel", function()
	local mode = SWS.GetMode(LocalPlayer())

	if (mode == SWS.MODE_COMMANDER or mode == SWS.MODE_MENU) then
		return true
	end
end)

-- Q-меню песочницы — только в свободном режиме
hook.Add("SpawnMenuOpen", "SWS_SpawnMenu", function()
	if (SWS.GetMode(LocalPlayer()) != SWS.MODE_FREE) then
		return false
	end
end)

hook.Add("ContextMenuOpen", "SWS_ContextMenu", function()
	if (SWS.GetMode(LocalPlayer()) != SWS.MODE_FREE) then
		return false
	end
end)

concommand.Add("sws_togglemode", function()
	local mode = SWS.GetMode(LocalPlayer())

	if (!SWS.GetFaction(LocalPlayer())) then
		RunConsoleCommand("sws_sidemenu")
		return
	end

	-- из командования в бой — через экран высадки (база, класс, оружие)
	if (mode == SWS.MODE_COMMANDER) then
		RunConsoleCommand("sws_deploy")
		return
	end

	net.Start("SWS_SetMode")
		net.WriteUInt(SWS.MODE_COMMANDER, 2)
	net.SendToServer()
end)

-- Esc: сначала отменяет действия режима и закрывает экраны, и только потом открывает меню игры
hook.Add("OnPauseMenuShow", "SWS_Escape", function()
	local client = LocalPlayer()

	if (IsValid(SWS.deployMenu) and (client:Alive() or SWS.GetMode(client) != SWS.MODE_FREE)) then
		SWS.deployMenu:Close()
		return false
	end

	if (IsValid(SWS.sideMenu) and SWS.GetFaction(client)) then
		SWS.sideMenu:Close()
		return false
	end

	if (Cmd.IsActive() and (Cmd.placing or Cmd.placingBuilding or Cmd.attackMove or next(Cmd.selection) or IsValid(Cmd.building))) then
		Cmd.placing = nil
		Cmd.placingBuilding = nil
		Cmd.attackMove = nil
		Cmd.selection = {}
		Cmd.building = nil
		return false
	end
end)
