--[[
	Высадка игрока (как в Battlefront): точка — свой командный пост или казарма своей стороны
	(или стандартный спавн карты), класс и оружие из SWS.Loadouts.
]]

util.AddNetworkString("SWS_Deploy")
util.AddNetworkString("SWS_Kill")

CreateConVar("sws_sandbox_tools", "1", {FCVAR_ARCHIVE, FCVAR_REPLICATED}, "Выдавать физган и тулган в бою (это всё-таки песочница)")

-- годится ли здание как точка высадки для стороны
function SWS.IsDeployPoint(building, sideIndex)
	if (!SWS.IsBuilding(building) or !building:IsBuilt() or building:GetSide() != sideIndex) then
		return false
	end

	local buildingType = building:GetBuildingType()

	if (buildingType == "command") then
		return !building:GetContested()
	end

	return buildingType == "barracks"
end

-- свободное место вокруг точки высадки
local function FindSpot(building)
	local info = building:GetInfo()
	local center = building:GetPos()
	local base = math.max(info.maxs.x, info.maxs.y) + 50

	for attempt = 1, 16 do
		local angle = math.rad(math.random(0, 359))
		local distance = base + math.random(0, 120)
		local position = center + Vector(math.cos(angle) * distance, math.sin(angle) * distance, 0)

		local ground = util.TraceLine({
			start = position + Vector(0, 0, 96),
			endpos = position - Vector(0, 0, 256),
			mask = MASK_PLAYERSOLID_BRUSHONLY
		})

		if (ground.Hit and !ground.StartSolid) then
			local hull = util.TraceHull({
				start = ground.HitPos + Vector(0, 0, 4),
				endpos = ground.HitPos + Vector(0, 0, 4),
				mins = Vector(-16, -16, 0),
				maxs = Vector(16, 16, 72),
				mask = MASK_PLAYERSOLID
			})

			if (!hull.Hit) then
				return ground.HitPos + Vector(0, 0, 4), (ground.HitPos - center):Angle().y
			end
		end
	end
end

-- выдать снаряжение класса
function SWS.ApplyLoadout(client)
	local faction = SWS.GetFaction(client)
	local loadout = client.SWS_Loadout

	if (!faction or !loadout) then
		return false
	end

	local classInfo = SWS.Classes[loadout.class] or SWS.Classes[1]
	local set = SWS.Loadouts[faction.id] and SWS.Loadouts[faction.id][classInfo.id]

	if (!set) then
		return false
	end

	client:StripWeapons()

	local primary = SWS.ResolveWeapon(set.primary[loadout.primary] or set.primary[1])
	local secondary = SWS.ResolveWeapon(set.secondary[loadout.secondary] or set.secondary[1])
	local gadget = SWS.ResolveWeapon(set.gadget[loadout.gadget] or set.gadget[1])

	for _, class in ipairs({primary, secondary, gadget}) do
		if (class) then
			local weapon = client:Give(class)

			-- запас патронов: три магазина
			if (IsValid(weapon) and weapon:GetPrimaryAmmoType() >= 0) then
				client:GiveAmmo(math.max(weapon:GetMaxClip1(), 1) * 3, weapon:GetPrimaryAmmoType(), true)
			end
		end
	end

	if (GetConVar("sws_sandbox_tools"):GetBool()) then
		client:Give("weapon_physgun")
		client:Give("gmod_tool")
	end

	client:SetMaxHealth(classInfo.health)
	client:SetHealth(classInfo.health)
	client:SetArmor(classInfo.armor)
	client:SetWalkSpeed(200 * classInfo.speed)
	client:SetRunSpeed(360 * classInfo.speed)
	client:SetNW2Int("SWS_Class", loadout.class)

	if (primary) then
		client:SelectWeapon(primary)
	end

	return true
end

-- поставить на точку высадки
function SWS.ApplyDeployPoint(client)
	local point = client.SWS_DeployPoint
	client.SWS_DeployPoint = nil

	if (!IsValid(point) or !SWS.IsDeployPoint(point, client:GetNW2Int("SWS_Side", 0))) then
		return
	end

	local position, yaw = FindSpot(point)

	if (position) then
		client:SetPos(position)
		client:SetEyeAngles(Angle(0, yaw, 0))
	end
end

net.Receive("SWS_Deploy", function(length, client)
	local point = net.ReadEntity()
	local classIndex = net.ReadUInt(3)
	local primary = net.ReadUInt(3)
	local secondary = net.ReadUInt(3)
	local gadget = net.ReadUInt(3)

	local faction = SWS.GetFaction(client)

	if (!faction or (client.SWS_NextDeploy or 0) > CurTime()) then
		return
	end

	-- в бою живым высаживаться нельзя
	if (SWS.GetMode(client) == SWS.MODE_FREE and client:Alive()) then
		return
	end

	if (SWS.GetMode(client) == SWS.MODE_POSSESS) then
		return
	end

	-- после гибели — пауза
	if ((client.SWS_DeployReady or 0) > CurTime()) then
		SWS.Notify(client, "Высадка ещё не готова.", 1)
		return
	end

	client.SWS_NextDeploy = CurTime() + 1

	if (IsValid(point) and !SWS.IsDeployPoint(point, faction.index)) then
		SWS.Notify(client, "Эта точка недоступна.", 2)
		return
	end

	client.SWS_Loadout = {
		class = math.Clamp(classIndex, 1, #SWS.Classes),
		primary = math.max(primary, 1),
		secondary = math.max(secondary, 1),
		gadget = math.max(gadget, 1)
	}

	client.SWS_DeployPoint = IsValid(point) and point or nil

	client:SetNW2Int("SWS_Mode", SWS.MODE_FREE)
	client:KillSilent()
	client:Spawn()
end)

-- в бою после гибели — ждём выбора на экране высадки (не возрождаемся кликом)
hook.Add("PlayerDeath", "SWS_DeployTimer", function(client, inflictor, attacker)
	if (SWS.GetMode(client) == SWS.MODE_FREE) then
		client.SWS_DeployReady = CurTime() + 4
		client:SetNW2Float("SWS_DeployReady", client.SWS_DeployReady)
	end
end)

-- уведомление «враг уничтожен» игроку, который убил NPC
hook.Add("OnNPCKilled", "SWS_KillFeed", function(npc, attacker, inflictor)
	if (!IsValid(attacker) or !attacker:IsPlayer()) then
		return
	end

	local side = npc:GetNW2Int("SWS_Side", 0)
	local faction = SWS.Factions[side]
	local unit = faction and SWS.UnitIndex[faction.id] and SWS.UnitIndex[faction.id][npc:GetNW2String("SWS_Unit")]
	local name = unit and unit.name or (npc.PrintName or npc:GetClass())

	net.Start("SWS_Kill")
		net.WriteString(name)
		net.WriteBool(side == attacker:Team())
	net.Send(attacker)
end)

hook.Add("PlayerDeath", "SWS_KillFeedPlayers", function(victim, inflictor, attacker)
	if (IsValid(attacker) and attacker:IsPlayer() and attacker != victim) then
		net.Start("SWS_Kill")
			net.WriteString(victim:Nick())
			net.WriteBool(victim:Team() == attacker:Team())
		net.Send(attacker)
	end
end)
