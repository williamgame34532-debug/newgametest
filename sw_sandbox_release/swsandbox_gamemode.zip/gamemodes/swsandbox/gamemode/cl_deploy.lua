--[[
	Экран высадки в стиле Battlefront:
	- фон — живая камера, облетающая выбранную точку высадки;
	- слева классы (Штурмовик, Тяжёлый, Специалист, Офицер) со здоровьем, бронёй и скоростью;
	- снизу оружие: основное, пистолет, снаряжение — плитки с полосками урона, темпа и магазина;
	- справа точки высадки: свои командные посты и казармы, стандартная высадка;
	- «ВЫСАДИТЬСЯ» (Пробел), «КОМАНДОВАНИЕ» (F3), «СТОРОНА» (F2).
	Выбор запоминается между высадками.
]]

local UI = SWS.UI

SWS.DeployChoice = SWS.DeployChoice or {class = 1, primary = {}, secondary = {}, gadget = {}}

local function Faction()
	return SWS.GetFaction(LocalPlayer())
end

local function Accent()
	local faction = Faction()

	return faction and faction.color or color_white
end

-- доступные точки высадки
local function GetDeployPoints()
	local side = LocalPlayer():GetNW2Int("SWS_Side", 0)
	local points = {}

	for _, building in ipairs(ents.FindByClass("sws_building")) do
		if (building:GetSide() == side and building:IsBuilt()) then
			local buildingType = building:GetBuildingType()

			if (buildingType == "command" or buildingType == "barracks") then
				points[#points + 1] = building
			end
		end
	end

	table.sort(points, function(a, b)
		if (a:GetBuildingType() != b:GetBuildingType()) then
			return a:GetBuildingType() == "command"
		end

		return a:GetLetter() < b:GetLetter()
	end)

	return points
end

local PANEL = {}

function PANEL:Init()
	if (IsValid(SWS.deployMenu)) then
		SWS.deployMenu:Remove()
	end

	SWS.deployMenu = self

	self:SetSize(ScrW(), ScrH())
	self:SetPos(0, 0)
	self:MakePopup()
	self:SetAlpha(0)
	self:AlphaTo(255, 0.3)

	self.point = nil
	self.orbit = 0

	local margin = ScreenScale(14)

	-- классы слева
	self.classes = {}

	for index, classInfo in ipairs(SWS.Classes) do
		local button = self:Add("DButton")
		button:SetText("")
		button:SetSize(ScreenScale(118), ScreenScale(24))
		button:SetPos(margin, ScreenScale(58) + (index - 1) * ScreenScale(27))
		button.index = index
		button.classInfo = classInfo
		button.hover = 0

		button.Paint = function(this, width, height)
			self:PaintClass(this, width, height)
		end

		button.OnCursorEntered = function()
			UI.Sound("hover")
		end

		button.DoClick = function(this)
			SWS.DeployChoice.class = this.index
			UI.Sound("click")
			self:RebuildWeapons()
		end

		self.classes[index] = button
	end

	-- оружие снизу
	self.weaponRow = self:Add("Panel")
	self.weaponRow:SetPos(margin, ScrH() - ScreenScale(86))
	self.weaponRow:SetSize(ScrW() - margin * 2 - ScreenScale(130), ScreenScale(56))

	-- точки высадки справа
	self.pointList = self:Add("DScrollPanel")
	self.pointList:SetPos(ScrW() - margin - ScreenScale(118), ScreenScale(58))
	self.pointList:SetSize(ScreenScale(118), ScrH() - ScreenScale(58) - ScreenScale(110))
	self.pointList:GetVBar():SetWide(0)

	-- кнопки
	self.deploy = self:Add("DButton")
	self.deploy:SetText("")
	self.deploy:SetSize(ScreenScale(118), ScreenScale(22))
	self.deploy:SetPos(ScrW() - margin - ScreenScale(118), ScrH() - ScreenScale(22) - margin)
	self.deploy.Paint = function(this, width, height)
		local ready = self:GetReadyIn()
		local hovered = this:IsHovered() and ready <= 0
		local accent = Accent()

		surface.SetDrawColor(255, 255, 255, ready > 0 and 90 or 255)
		surface.DrawRect(0, 0, width, height)

		if (hovered) then
			surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
			surface.DrawRect(0, height - 4, width, 4)
		end

		local label = ready > 0 and string.format("ВЫСАДКА ЧЕРЕЗ %d", math.ceil(ready)) or "ВЫСАДИТЬСЯ"

		UI.Spaced(label, "SWSHeader", width * 0.5, height * 0.5, UI.colors.dark, 3, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

		if (ready <= 0) then
			UI.Key("ПРОБЕЛ", width - 6, -ScreenScale(10), 255, TEXT_ALIGN_RIGHT)
		end
	end
	self.deploy.DoClick = function()
		self:Deploy()
	end

	local function SmallButton(label, key, x, onClick)
		local button = self:Add("DButton")
		button:SetText("")

		surface.SetFont("SWSLabel")
		button:SetSize(surface.GetTextSize(label) + ScreenScale(22), ScreenScale(12))
		button:SetPos(x, ScrH() - ScreenScale(12) - margin)

		button.Paint = function(this, width, height)
			local keyW = UI.Key(key, 0, height * 0.5 - ScreenScale(4), 255)

			draw.SimpleText(label, "SWSLabel", keyW + ScreenScale(4), height * 0.5, Color(255, 255, 255, this:IsHovered() and 255 or 180),
				TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end

		button.DoClick = function()
			UI.Sound("click")
			onClick()
		end

		return button
	end

	local commandButton = SmallButton("КОМАНДОВАНИЕ", "F3", margin, function()
		self:Close()

		net.Start("SWS_SetMode")
			net.WriteUInt(SWS.MODE_COMMANDER, 2)
		net.SendToServer()
	end)

	SmallButton("СТОРОНА", "F2", margin + commandButton:GetWide() + ScreenScale(10), function()
		self:Close()
		RunConsoleCommand("sws_sidemenu")
	end)

	self:RebuildWeapons()
	self:RebuildPoints()
end

function PANEL:GetReadyIn()
	local client = LocalPlayer()

	if (client:Alive()) then
		return 0
	end

	return math.max(client:GetNW2Float("SWS_DeployReady", 0) - CurTime(), 0)
end

function PANEL:Close()
	if (self.bClosing) then
		return
	end

	self.bClosing = true
	self:AlphaTo(0, 0.2, 0, function()
		if (IsValid(self)) then
			self:Remove()
		end
	end)
end

function PANEL:Deploy()
	if (self:GetReadyIn() > 0) then
		UI.Sound("error")
		return
	end

	local faction = Faction()
	local choice = SWS.DeployChoice
	local classInfo = SWS.Classes[choice.class] or SWS.Classes[1]

	if (!faction) then
		return
	end

	local key = faction.id .. ":" .. classInfo.id

	net.Start("SWS_Deploy")
		net.WriteEntity(IsValid(self.point) and self.point or NULL)
		net.WriteUInt(choice.class, 3)
		net.WriteUInt(choice.primary[key] or 1, 3)
		net.WriteUInt(choice.secondary[key] or 1, 3)
		net.WriteUInt(choice.gadget[key] or 1, 3)
	net.SendToServer()

	UI.Sound("spawn")
	self:Close()
end

function PANEL:OnKeyCodePressed(key)
	if (key == KEY_SPACE or key == KEY_ENTER) then
		self:Deploy()
	elseif (key == KEY_F3) then
		self:Close()

		net.Start("SWS_SetMode")
			net.WriteUInt(SWS.MODE_COMMANDER, 2)
		net.SendToServer()
	elseif (key == KEY_F2) then
		self:Close()
		RunConsoleCommand("sws_sidemenu")
	elseif (key == KEY_ESCAPE and LocalPlayer():Alive()) then
		self:Close()
	elseif (key >= KEY_1 and key <= KEY_4) then
		SWS.DeployChoice.class = key - KEY_1 + 1
		self:RebuildWeapons()
		UI.Sound("click")
	end
end

-- плитки оружия: три секции
function PANEL:RebuildWeapons()
	self.weaponRow:Clear()

	local faction = Faction()

	if (!faction) then
		return
	end

	local classInfo = SWS.Classes[SWS.DeployChoice.class] or SWS.Classes[1]
	local set = SWS.Loadouts[faction.id] and SWS.Loadouts[faction.id][classInfo.id]

	if (!set) then
		return
	end

	local key = faction.id .. ":" .. classInfo.id
	local sections = {
		{title = "ОСНОВНОЕ", list = set.primary, store = "primary"},
		{title = "ПИСТОЛЕТ", list = set.secondary, store = "secondary"},
		{title = "СНАРЯЖЕНИЕ", list = set.gadget, store = "gadget"}
	}

	local x = 0
	local tileW = ScreenScale(62)
	local gap = ScreenScale(3)

	for _, section in ipairs(sections) do
		local header = self.weaponRow:Add("DLabel")
		header:SetText("")
		header:SetPos(x, 0)
		header:SetSize(tileW * #section.list + gap * (#section.list - 1), ScreenScale(10))
		header.Paint = function(this, width, height)
			UI.Spaced(section.title, "SWSTab", 0, height * 0.5, Color(255, 255, 255, 200), 2, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

			surface.SetDrawColor(255, 255, 255, 40)
			surface.DrawRect(0, height - 1, width, 1)
		end

		for index, entry in ipairs(section.list) do
			local class = SWS.ResolveWeapon(entry)
			local tile = self.weaponRow:Add("DButton")
			tile:SetText("")
			tile:SetPos(x, ScreenScale(13))
			tile:SetSize(tileW, ScreenScale(42))
			tile.hover = 0

			tile.Paint = function(this, width, height)
				local bSelected = (SWS.DeployChoice[section.store][key] or 1) == index
				local accent = Accent()

				this.hover = math.Approach(this.hover, this:IsHovered() and 1 or 0, FrameTime() * 8)

				if (bSelected) then
					surface.SetDrawColor(255, 255, 255, 240)
					surface.DrawRect(0, 0, width, height)
				else
					surface.SetDrawColor(10, 12, 16, 200 + this.hover * 40)
					surface.DrawRect(0, 0, width, height)

					surface.SetDrawColor(255, 255, 255, 40 + this.hover * 120)
					surface.DrawOutlinedRect(0, 0, width, height)
				end

				local textColor = bSelected and UI.colors.dark or UI.colors.text
				local pad = ScreenScale(4)

				draw.SimpleText(UI.Fit(SWS.Upper(entry.name), "SWSLabel", width - pad * 2), "SWSLabel", pad, pad, class and textColor or ColorAlpha(textColor, 90))

				if (!class) then
					draw.SimpleText("НЕ УСТАНОВЛЕНО", "SWSTiny", pad, pad + ScreenScale(9), UI.colors.danger)
					return
				end

				local stats = SWS.WeaponStats(class)

				if (!stats) then
					return
				end

				-- полоски характеристик
				local bars = {
					{"УРОН", math.Clamp(stats.damage / 120, 0.03, 1)},
					{"ТЕМП", math.Clamp(stats.rpm / 900, 0.03, 1)},
					{"МАГАЗИН", math.Clamp(stats.clip / 100, 0.03, 1)}
				}

				local barY = pad + ScreenScale(10)

				for _, bar in ipairs(bars) do
					draw.SimpleText(bar[1], "SWSTiny", pad, barY, ColorAlpha(textColor, 170))

					local barX = pad + ScreenScale(20)
					local barW = width - barX - pad

					surface.SetDrawColor(bSelected and Color(0, 0, 0, 40) or Color(255, 255, 255, 25))
					surface.DrawRect(barX, barY + 3, barW, 4)

					surface.SetDrawColor(bSelected and Color(accent.r * 0.7, accent.g * 0.7, accent.b * 0.7) or accent)
					surface.DrawRect(barX, barY + 3, barW * bar[2], 4)

					barY = barY + ScreenScale(7)
				end
			end

			tile.OnCursorEntered = function()
				UI.Sound("hover")
			end

			tile.DoClick = function()
				if (class) then
					SWS.DeployChoice[section.store][key] = index
					UI.Sound("click")
				else
					UI.Sound("error")
				end
			end

			x = x + tileW + gap
		end

		x = x + ScreenScale(10)
	end
end

function PANEL:RebuildPoints()
	self.pointList:Clear()

	local points = GetDeployPoints()
	local entries = {}

	for _, building in ipairs(points) do
		entries[#entries + 1] = building
	end

	entries[#entries + 1] = false -- стандартная высадка

	self.pointKey = #points

	-- точка по умолчанию: последний выбранный пост, иначе первый
	if (!IsValid(self.point) or !table.HasValue(points, self.point)) then
		self.point = points[1]
	end

	for _, building in ipairs(entries) do
		local row = self.pointList:Add("DButton")
		row:SetText("")
		row:Dock(TOP)
		row:DockMargin(0, 0, 0, 3)
		row:SetTall(ScreenScale(20))
		row.building = building

		row.Paint = function(this, width, height)
			local bSelected = (this.building or nil) == self.point
			local accent = Accent()
			local hovered = this:IsHovered()

			if (bSelected) then
				surface.SetDrawColor(255, 255, 255, 240)
				surface.DrawRect(0, 0, width, height)
			else
				surface.SetDrawColor(10, 12, 16, hovered and 235 or 190)
				surface.DrawRect(0, 0, width, height)

				surface.SetDrawColor(255, 255, 255, hovered and 160 or 40)
				surface.DrawOutlinedRect(0, 0, width, height)
			end

			local textColor = bSelected and UI.colors.dark or UI.colors.text
			local pad = ScreenScale(5)

			if (IsValid(this.building)) then
				local info = this.building:GetInfo()
				local badge = info.id == "command" and this.building:GetLetterText() or "К"

				surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
				surface.DrawRect(pad, height * 0.5 - ScreenScale(6), ScreenScale(12), ScreenScale(12))

				draw.SimpleText(badge, "SWSLabel", pad + ScreenScale(6), height * 0.5, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				draw.SimpleText(SWS.Upper(info.name), "SWSLabel", pad + ScreenScale(16), height * 0.36, textColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

				local distance = math.Round(LocalPlayer():GetPos():Distance(this.building:GetPos()) * 0.01905)
				local owner = this.building:GetCommander()
				local sub = SWS.OwnerName(owner) .. "  ·  " .. distance .. " М"

				draw.SimpleText(UI.Fit(sub, "SWSTiny", width - pad * 2 - ScreenScale(16)), "SWSTiny", pad + ScreenScale(16), height * 0.7,
					ColorAlpha(textColor, 170), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			else
				draw.SimpleText("СТАНДАРТНАЯ ВЫСАДКА", "SWSLabel", pad, height * 0.36, textColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText("ТОЧКА ПОЯВЛЕНИЯ КАРТЫ", "SWSTiny", pad, height * 0.7, ColorAlpha(textColor, 170), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end
		end

		row.OnCursorEntered = function()
			UI.Sound("hover")
		end

		row.DoClick = function(this)
			self.point = this.building or nil
			UI.Sound("click")
		end
	end
end

function PANEL:Think()
	-- точки появились / пропали — перестроить список
	if ((self.nextPoints or 0) < RealTime()) then
		self.nextPoints = RealTime() + 1

		local count = #GetDeployPoints()

		if (count != self.pointKey) then
			self:RebuildPoints()
		end
	end

	-- живой и в бою — экран не нужен
	if (LocalPlayer():Alive() and SWS.GetMode(LocalPlayer()) == SWS.MODE_FREE and !self.bManual) then
		self:Close()
	end
end

function PANEL:PaintClass(button, width, height)
	local classInfo = button.classInfo
	local bSelected = SWS.DeployChoice.class == button.index
	local accent = Accent()

	button.hover = math.Approach(button.hover, button:IsHovered() and 1 or 0, FrameTime() * 8)

	if (bSelected) then
		surface.SetDrawColor(255, 255, 255, 240)
		surface.DrawRect(0, 0, width, height)
	else
		surface.SetDrawColor(10, 12, 16, 190 + button.hover * 50)
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(255, 255, 255, 40 + button.hover * 140)
		surface.DrawOutlinedRect(0, 0, width, height)
	end

	local textColor = bSelected and UI.colors.dark or UI.colors.text
	local iconSize = height - ScreenScale(6)
	local icon = UI.Material("sws/c_" .. classInfo.icon .. ".png")

	if (!icon:IsError()) then
		surface.SetMaterial(icon)
		surface.SetDrawColor(bSelected and Color(accent.r * 0.8, accent.g * 0.8, accent.b * 0.8) or Color(255, 255, 255, 230))
		surface.DrawTexturedRect(ScreenScale(4), ScreenScale(3), iconSize, iconSize)
	end

	local textX = ScreenScale(6) + iconSize

	UI.Spaced(SWS.Upper(classInfo.name), "SWSHeader", textX, ScreenScale(2), textColor, 2)
	draw.SimpleText(string.format("ЗДОРОВЬЕ %d   БРОНЯ %d", classInfo.health, classInfo.armor), "SWSTiny", textX, height - ScreenScale(6),
		ColorAlpha(textColor, 170))

	draw.SimpleText(tostring(button.index), "SWSTiny", width - ScreenScale(4), ScreenScale(3), ColorAlpha(textColor, 120), TEXT_ALIGN_RIGHT)
end

-- живая камера над точкой высадки
function PANEL:GetPreviewTarget()
	if (IsValid(self.point)) then
		return self.point:GetPos()
	end

	local spawns = ents.FindByClass("info_player_start")

	if (#spawns > 0) then
		return spawns[1]:GetPos()
	end

	return LocalPlayer():GetPos()
end

function PANEL:Paint(width, height)
	self.orbit = self.orbit + FrameTime() * 6

	local target = self:GetPreviewTarget() + Vector(0, 0, 40)
	local angles = Angle(28, self.orbit, 0)
	local origin = target - angles:Forward() * 620

	local trace = util.TraceLine({start = target, endpos = origin, mask = MASK_SOLID_BRUSHONLY})

	if (trace.Hit) then
		origin = trace.HitPos + trace.HitNormal * 10
	end

	render.RenderView({
		origin = origin,
		angles = angles,
		x = 0, y = 0, w = width, h = height,
		fov = 70,
		drawviewmodel = false,
		drawhud = false,
		dopostprocess = true
	})

	-- затемнение по краям для читаемости
	UI.Gradient(0, 0, width * 0.35, height, Color(0, 0, 0, 200), "left")
	UI.Gradient(width * 0.65, 0, width * 0.35, height, Color(0, 0, 0, 200), "right")
	UI.Gradient(0, height * 0.6, width, height * 0.4, Color(0, 0, 0, 230), "up")
	UI.Gradient(0, 0, width, height * 0.2, Color(0, 0, 0, 200), "down")

	local margin = ScreenScale(14)
	local faction = Faction()
	local accent = Accent()

	UI.Spaced("ВЫСАДКА", "SWSTitle", margin, ScreenScale(12), UI.colors.text, 4)

	if (faction) then
		surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
		surface.DrawRect(margin, ScreenScale(40), ScreenScale(30), 2)

		UI.Spaced(faction.short .. "  ·  " .. faction.era, "SWSSmall", margin, ScreenScale(44), UI.colors.dim, 2)
	end

	UI.Spaced("ТОЧКА ВЫСАДКИ", "SWSTab", width - margin, ScreenScale(46), Color(255, 255, 255, 200), 2, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)

	-- метка цели в центре
	local center = target:ToScreen()

	if (center.visible) then
		UI.Corners(center.x - 30, center.y - 30, 60, 60, 12, Color(accent.r, accent.g, accent.b, 220), 2)
	end
end

vgui.Register("SWSDeployMenu", PANEL, "EditablePanel")

concommand.Add("sws_deploy", function()
	if (IsValid(SWS.deployMenu)) then
		SWS.deployMenu:Close()
		return
	end

	local panel = vgui.Create("SWSDeployMenu")
	panel.bManual = true
end)

-- погиб в бою — экран высадки
hook.Add("Think", "SWS_DeployAuto", function()
	local client = LocalPlayer()

	if (!IsValid(client) or SWS.GetMode(client) != SWS.MODE_FREE or client:Alive()) then
		return
	end

	if (IsValid(SWS.deployMenu) or IsValid(SWS.sideMenu)) then
		return
	end

	if ((SWS.nextDeployTry or 0) > RealTime()) then
		return
	end

	SWS.nextDeployTry = RealTime() + 1.5
	vgui.Create("SWSDeployMenu")
end)
