--[[
	HUD бойца в стиле Battlefront (в бою и при вселении):
	- слева внизу: класс (или боец, в которого вселились), здоровье полосой из делений, броня;
	- справа внизу: оружие — название, патроны в магазине крупно, запас; над ним слоты оружия с клавишами;
	- сверху по центру: командные посты A, B, C… цветом владельца и захват; внутри зоны — шкала захвата;
	- на экране — метки постов с расстоянием; справа — «враг уничтожен».
	Выбор оружия свой: 1–9 и колесо мыши.
]]

local UI = SWS.UI

local function Faction()
	return SWS.GetFaction(LocalPlayer())
end

local function Accent()
	local faction = Faction()

	return faction and faction.color or color_white
end

local function IsCombatMode()
	local mode = SWS.GetMode(LocalPlayer())

	return mode == SWS.MODE_FREE or mode == SWS.MODE_POSSESS
end

-- стандартный HUD в бою заменён своим
local hidden = {
	CHudHealth = true, CHudBattery = true, CHudAmmo = true, CHudSecondaryAmmo = true, CHudWeaponSelection = true
}

hook.Add("HUDShouldDraw", "SWS_PlayerHUD", function(name)
	if (hidden[name] and IsCombatMode() and SWS.GetFaction(LocalPlayer())) then
		return false
	end
end)

-- ===== выбор оружия =====
local selector = {shown = 0, index = 1}

local function GetWeaponList()
	local client = LocalPlayer()
	local list = client:GetWeapons()

	-- снаряжение класса первым, затем остальное по слотам
	local loadoutOrder = {}
	local faction = Faction()
	local classInfo = SWS.Classes[client:GetNW2Int("SWS_Class", 1)]
	local set = faction and classInfo and SWS.Loadouts[faction.id] and SWS.Loadouts[faction.id][classInfo.id]

	if (set) then
		local order = 1

		for _, section in ipairs({"primary", "secondary", "gadget"}) do
			for _, entry in ipairs(set[section]) do
				local class = SWS.ResolveWeapon(entry)

				if (class and !loadoutOrder[class]) then
					loadoutOrder[class] = order
				end
			end

			order = order + 1
		end
	end

	table.sort(list, function(a, b)
		local orderA = loadoutOrder[a:GetClass()] or (10 + a:GetSlot())
		local orderB = loadoutOrder[b:GetClass()] or (10 + b:GetSlot())

		if (orderA != orderB) then
			return orderA < orderB
		end

		return a:GetSlotPos() < b:GetSlotPos()
	end)

	return list
end

local function SelectIndex(index)
	local list = GetWeaponList()
	local weapon = list[index]

	if (IsValid(weapon) and weapon != LocalPlayer():GetActiveWeapon()) then
		input.SelectWeapon(weapon)
		surface.PlaySound("common/wpn_hudoff.wav")
	end

	selector.shown = RealTime()
	selector.index = math.Clamp(index, 1, math.max(#list, 1))
end

hook.Add("PlayerBindPress", "SWS_WeaponSelect", function(client, bind, bPressed)
	if (!bPressed or SWS.GetMode(client) != SWS.MODE_FREE or !client:Alive()) then
		return
	end

	-- физган с зажатым ПКМ крутит предмет колесом — не мешаем
	local active = client:GetActiveWeapon()

	if (IsValid(active) and active:GetClass() == "weapon_physgun" and client:KeyDown(IN_ATTACK)) then
		return
	end

	bind = string.lower(bind)

	local slot = string.match(bind, "^slot(%d)")

	if (slot) then
		SelectIndex(tonumber(slot))
		return true
	end

	if (string.find(bind, "invnext", 1, true) or string.find(bind, "invprev", 1, true)) then
		local list = GetWeaponList()
		local current = 1

		for index, weapon in ipairs(list) do
			if (weapon == active) then
				current = index
			end
		end

		local direction = string.find(bind, "invnext", 1, true) and 1 or -1

		SelectIndex((current - 1 + direction) % math.max(#list, 1) + 1)
		return true
	end
end)

-- ===== уведомления об убийствах =====
local kills = {}

net.Receive("SWS_Kill", function()
	table.insert(kills, 1, {name = net.ReadString(), bFriendly = net.ReadBool(), start = RealTime()})
	kills[5] = nil

	surface.PlaySound("buttons/lightswitch2.wav")
end)

-- ===== рисование =====
local function PaintHealth(client, x, y)
	local accent = Accent()
	local mode = SWS.GetMode(client)
	local health, maxHealth, armor, title

	if (mode == SWS.MODE_POSSESS) then
		local npc = client:GetNW2Entity("SWS_Possessed")

		if (!IsValid(npc)) then
			return
		end

		health, maxHealth, armor = SWS.GetHealth(npc), SWS.GetMaxHealth(npc), 0

		local faction = Faction()
		local unit = faction and SWS.UnitIndex[faction.id] and SWS.UnitIndex[faction.id][npc:GetNW2String("SWS_Unit")]

		title = unit and unit.name or "БОЕЦ"
	else
		health, maxHealth, armor = client:Health(), math.max(client:GetMaxHealth(), 1), client:Armor()

		local classInfo = SWS.Classes[client:GetNW2Int("SWS_Class", 1)]
		title = classInfo and classInfo.name or "БОЕЦ"
	end

	local width = ScreenScale(120)
	local fraction = math.Clamp(health / maxHealth, 0, 1)

	-- класс и сторона
	local classInfo = SWS.Classes[client:GetNW2Int("SWS_Class", 1)]
	local icon = classInfo and UI.Material("sws/c_" .. classInfo.icon .. ".png")
	local iconSize = ScreenScale(16)

	if (icon and !icon:IsError() and mode == SWS.MODE_FREE) then
		surface.SetMaterial(icon)
		surface.SetDrawColor(255, 255, 255, 230)
		surface.DrawTexturedRect(x, y - iconSize - ScreenScale(13), iconSize, iconSize)
	end

	local textX = (mode == SWS.MODE_FREE) and (x + iconSize + ScreenScale(4)) or x

	UI.Spaced(SWS.Upper(title), "SWSHeader", textX, y - ScreenScale(29), UI.colors.text, 2)

	local faction = Faction()

	if (faction) then
		draw.SimpleText(faction.short, "SWSTiny", textX, y - ScreenScale(15), accent)
	end

	-- здоровье: деления
	local segments = 10
	local gap = 3
	local segmentW = (width - gap * (segments - 1)) / segments
	local barH = ScreenScale(4)
	local filled = fraction * segments
	local lowPulse = fraction < 0.3 and (0.6 + math.sin(RealTime() * 8) * 0.4) or 1

	for i = 1, segments do
		local segX = x + (i - 1) * (segmentW + gap)

		surface.SetDrawColor(0, 0, 0, 150)
		surface.DrawRect(segX, y, segmentW, barH)

		local part = math.Clamp(filled - (i - 1), 0, 1)

		if (part > 0) then
			local color = fraction < 0.3 and UI.colors.danger or color_white

			surface.SetDrawColor(color.r, color.g, color.b, 255 * lowPulse)
			surface.DrawRect(segX, y, segmentW * part, barH)
		end
	end

	draw.SimpleText(tostring(math.max(health, 0)), "SWSNumber", x + width + ScreenScale(4), y + barH * 0.5, UI.colors.text,
		TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

	-- броня
	if (armor > 0) then
		local armorFraction = math.Clamp(armor / 100, 0, 1)

		surface.SetDrawColor(0, 0, 0, 150)
		surface.DrawRect(x, y + barH + 4, width, 2)

		surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
		surface.DrawRect(x, y + barH + 4, width * armorFraction, 2)
	end
end

local function PaintWeapon(client, right, y)
	local weapon = client:GetActiveWeapon()

	if (SWS.GetMode(client) == SWS.MODE_POSSESS) then
		local npc = client:GetNW2Entity("SWS_Possessed")
		weapon = IsValid(npc) and npc:GetActiveWeapon() or NULL
	end

	if (!IsValid(weapon)) then
		return
	end

	local name = SWS.Upper(language.GetPhrase(weapon:GetPrintName() or weapon:GetClass()))

	UI.Spaced(UI.Fit(name, "SWSHeader", ScreenScale(120)), "SWSHeader", right, y - ScreenScale(26), UI.colors.text, 2, TEXT_ALIGN_RIGHT)

	if (SWS.GetMode(client) != SWS.MODE_FREE) then
		return
	end

	local clip = weapon:Clip1()
	local ammoType = weapon:GetPrimaryAmmoType()
	local reserve = ammoType >= 0 and client:GetAmmoCount(ammoType) or 0

	if (clip < 0 and ammoType >= 0) then
		clip = reserve
		reserve = -1
	end

	if (clip >= 0) then
		local maxClip = math.max(weapon:GetMaxClip1(), 1)
		local low = clip / maxClip < 0.25

		local reserveText = reserve >= 0 and ("/ " .. reserve) or ""

		surface.SetFont("SWSSmall")
		local reserveW = surface.GetTextSize(reserveText)

		draw.SimpleText(reserveText, "SWSSmall", right, y + ScreenScale(2), UI.colors.dim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		draw.SimpleText(tostring(clip), "SWSTitle", right - reserveW - ScreenScale(4), y + ScreenScale(1),
			low and UI.colors.danger or UI.colors.text, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)

		-- магазин тонкой полосой
		local barW = ScreenScale(70)

		surface.SetDrawColor(0, 0, 0, 150)
		surface.DrawRect(right - barW, y + ScreenScale(10), barW, 3)

		surface.SetDrawColor(255, 255, 255, 230)
		surface.DrawRect(right - barW * math.Clamp(clip / maxClip, 0, 1), y + ScreenScale(10), barW * math.Clamp(clip / maxClip, 0, 1), 3)
	end
end

local function PaintSlots(client, right, y)
	local list = GetWeaponList()
	local active = client:GetActiveWeapon()
	local alpha = math.Clamp(1 - (RealTime() - selector.shown - 1.5) / 0.6, 0.35, 1)
	local x = right

	for index = #list, 1, -1 do
		local weapon = list[index]
		local name = UI.Fit(SWS.Upper(language.GetPhrase(weapon:GetPrintName() or weapon:GetClass())), "SWSTiny", ScreenScale(38))

		surface.SetFont("SWSTiny")

		local textW = surface.GetTextSize(name)
		local w, h = textW + ScreenScale(12), ScreenScale(9)
		local bActive = weapon == active

		x = x - w

		if (bActive) then
			surface.SetDrawColor(255, 255, 255, 240 * alpha)
			surface.DrawRect(x, y, w, h)
		else
			surface.SetDrawColor(10, 12, 16, 170 * alpha)
			surface.DrawRect(x, y, w, h)

			surface.SetDrawColor(255, 255, 255, 40 * alpha)
			surface.DrawOutlinedRect(x, y, w, h)
		end

		local color = bActive and UI.colors.dark or UI.colors.text

		draw.SimpleText(tostring(index), "SWSTiny", x + 4, y + h * 0.5, ColorAlpha(color, 140 * alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(name, "SWSTiny", x + ScreenScale(4) + 4, y + h * 0.5, ColorAlpha(color, 255 * alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

		x = x - 3
	end
end

-- командные посты сверху и шкала захвата
local function PaintPosts(client)
	local posts = {}

	for _, building in ipairs(ents.FindByClass("sws_building")) do
		if (building:GetBuildingType() == "command") then
			posts[#posts + 1] = building
		end
	end

	if (#posts == 0) then
		return
	end

	table.sort(posts, function(a, b)
		return a:GetLetter() < b:GetLetter()
	end)

	local size = ScreenScale(13)
	local gap = ScreenScale(4)
	local total = #posts * size + (#posts - 1) * gap
	local x = ScrW() * 0.5 - total * 0.5
	local y = ScreenScale(8)
	local mySide = client:GetNW2Int("SWS_Side", 0)
	local inside

	for _, post in ipairs(posts) do
		local faction = SWS.Factions[post:GetSide()]
		local color = faction and faction.color or Color(200, 204, 210)
		local captureFaction = SWS.Factions[post:GetCaptureSide()]

		surface.SetDrawColor(10, 12, 16, 200)
		surface.DrawRect(x, y, size, size)

		surface.SetDrawColor(color.r, color.g, color.b, faction and 255 or 120)
		surface.DrawOutlinedRect(x, y, size, size, 2)

		if (faction) then
			surface.SetDrawColor(color.r, color.g, color.b, 90)
			surface.DrawRect(x + 2, y + 2, size - 4, size - 4)
		end

		-- захват: полоса снизу цветом захватчика
		if (captureFaction or post:GetContested()) then
			local captureColor = post:GetContested() and UI.colors.danger or captureFaction.color
			local fraction = post:GetProgress() / 100

			surface.SetDrawColor(captureColor.r, captureColor.g, captureColor.b, 255)
			surface.DrawRect(x, y + size + 2, size * fraction, 3)
		end

		draw.SimpleText(post:GetLetterText(), "SWSHeader", x + size * 0.5, y + size * 0.5, post:GetSide() == mySide and UI.colors.text or color,
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

		local info = post:GetInfo()

		if (info and client:GetPos():DistToSqr(post:GetPos()) < info.captureRadius ^ 2) then
			inside = post
		end

		x = x + size + gap
	end

	-- внутри зоны
	if (inside) then
		local faction = SWS.Factions[inside:GetSide()]
		local captureFaction = SWS.Factions[inside:GetCaptureSide()]
		local w, h = ScreenScale(120), ScreenScale(16)
		local px, py = ScrW() * 0.5 - w * 0.5, ScreenScale(30)
		local text, color

		if (inside:GetContested()) then
			text, color = "ПОСТ " .. inside:GetLetterText() .. " ОСПАРИВАЕТСЯ", UI.colors.danger
		elseif (inside:GetSide() == mySide) then
			text, color = "ПОСТ " .. inside:GetLetterText() .. " УДЕРЖИВАЕТСЯ", Accent()
		elseif (captureFaction) then
			text, color = "ЗАХВАТ ПОСТА " .. inside:GetLetterText(), captureFaction.color
		else
			text, color = "ПОСТ " .. inside:GetLetterText() .. (faction and (": " .. faction.short) or ""), faction and faction.color or color_white
		end

		UI.Panel(px, py, w, h, 1)
		UI.Spaced(text, "SWSSmall", px + w * 0.5, py + ScreenScale(5), UI.colors.text, 2, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

		surface.SetDrawColor(255, 255, 255, 25)
		surface.DrawRect(px + 6, py + h - 7, w - 12, 3)

		surface.SetDrawColor(color.r, color.g, color.b, 255)
		surface.DrawRect(px + 6, py + h - 7, (w - 12) * inside:GetProgress() / 100, 3)
	end

	-- метки постов в мире
	for _, post in ipairs(posts) do
		if (post == inside) then
			continue
		end

		local screen = (post:GetPos() + Vector(0, 0, 160)):ToScreen()

		if (!screen.visible) then
			continue
		end

		local faction = SWS.Factions[post:GetSide()]
		local color = faction and faction.color or Color(200, 204, 210)
		local distance = math.Round(client:GetPos():Distance(post:GetPos()) * 0.01905)

		surface.SetDrawColor(10, 12, 16, 170)
		surface.DrawRect(screen.x - 12, screen.y - 12, 24, 24)

		surface.SetDrawColor(color)
		surface.DrawOutlinedRect(screen.x - 12, screen.y - 12, 24, 24, 2)

		draw.SimpleText(post:GetLetterText(), "SWSLabel", screen.x, screen.y, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(distance .. " М", "SWSTiny", screen.x, screen.y + 16, Color(255, 255, 255, 200), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	end
end

local function PaintKills()
	local now = RealTime()
	local x, y = ScrW() * 0.5, ScrH() * 0.62

	for index = #kills, 1, -1 do
		if (now - kills[index].start > 3) then
			table.remove(kills, index)
		end
	end

	for _, kill in ipairs(kills) do
		local age = now - kill.start
		local alpha = math.Clamp(math.min(age / 0.1, (3 - age) / 0.5), 0, 1) * 255
		local label = kill.bFriendly and "СВОЙ" or "ВРАГ УНИЧТОЖЕН"
		local color = kill.bFriendly and UI.colors.danger or color_white

		UI.Spaced(label, "SWSSmall", x, y, ColorAlpha(color, alpha), 2, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(SWS.Upper(kill.name), "SWSTiny", x, y + ScreenScale(7), Color(255, 255, 255, alpha * 0.7), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

		y = y + ScreenScale(16)
	end
end

hook.Add("HUDPaint", "SWS_PlayerHUD", function()
	local client = LocalPlayer()

	if (!IsCombatMode() or !SWS.GetFaction(client)) then
		return
	end

	PaintPosts(client)

	if (!client:Alive() and SWS.GetMode(client) == SWS.MODE_FREE) then
		return
	end

	local margin = ScreenScale(14)
	local bottom = ScrH() - margin - ScreenScale(4)

	PaintHealth(client, margin, bottom)
	PaintWeapon(client, ScrW() - margin, bottom)

	if (SWS.GetMode(client) == SWS.MODE_FREE) then
		PaintSlots(client, ScrW() - margin, bottom - ScreenScale(46))
	end

	PaintKills()
end)
