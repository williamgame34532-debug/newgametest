--[[
	Стороны конфликта. vjClass — класс отношений VJ Base (свои/чужие), icon — эмблема из VJ-пака,
	weapons — оружие игрока в свободном режиме (первое найденное: TFA Star Wars, затем Star Wars Weapons).
]]

SWS.FactionByID = SWS.FactionByID or {}

SWS.Factions = {
	{
		id = "republic",
		name = "Галактическая Республика",
		short = "РЕСПУБЛИКА",
		era = "ВОЙНЫ КЛОНОВ",
		tagline = "Армия клонов защищает Республику от сепаратистов.",
		color = Color(64, 140, 235),
		vjClass = "CLASS_GALACTIC_REPUBLIC",
		icon = "vgui/icons/galacticrepublic.png",
		art = "sws/side_republic.jpg",
		variantLabel = "ЛЕГИОН",
		weapons = {
			{"tfa_sw_blaster_dc15a_upgrade", "weapon_752_dc15a"},
			{"tfa_sw_blaster_dc17_upgrade", "weapon_752_dc17"}
		}
	},
	{
		id = "cis",
		name = "Конфедерация независимых систем",
		short = "СЕПАРАТИСТЫ",
		era = "ВОЙНЫ КЛОНОВ",
		tagline = "Бесконечные легионы дроидов против клонов.",
		color = Color(222, 120, 40),
		vjClass = "CLASS_CIS",
		icon = "vgui/icons/confederacyofindependentsystems.png",
		art = "sws/side_cis.jpg",
		variantLabel = "ВАРИАНТ",
		weapons = {
			{"tfa_sw_blaster_e5_upgrade", "weapon_752_e5"},
			{"tfa_sw_blaster_se14r_upgrade", "weapon_752_se14c"}
		}
	},
	{
		id = "empire",
		name = "Галактическая Империя",
		short = "ИМПЕРИЯ",
		era = "ГРАЖДАНСКАЯ ВОЙНА",
		tagline = "Порядок любой ценой. Штурмовики и шагоходы.",
		color = Color(206, 46, 46),
		vjClass = "CLASS_GALACTIC_EMPIRE",
		icon = "vgui/icons/galacticempire.png",
		art = "sws/side_empire.jpg",
		variantLabel = "МЕСТНОСТЬ",
		weapons = {
			{"tfa_sw_blaster_e11_upgrade", "weapon_752_e11"},
			{"tfa_sw_blaster_se14r_upgrade", "weapon_752_se14c"}
		}
	},
	{
		id = "rebels",
		name = "Альянс повстанцев",
		short = "ПОВСТАНЦЫ",
		era = "ГРАЖДАНСКАЯ ВОЙНА",
		tagline = "Надежда против Империи. Засады, вуки и танки T5B.",
		color = Color(236, 168, 40),
		vjClass = "CLASS_REBEL_ALLIANCE",
		icon = "vgui/icons/rebelalliance.png",
		art = "sws/side_rebels.jpg",
		variantLabel = "ОТРЯД",
		weapons = {
			{"tfa_sw_blaster_a280_upgrade", "weapon_752_dh17"},
			{"tfa_sw_blaster_dl44_upgrade", "weapon_752_dl44"}
		}
	}
}

-- категории панели юнитов в порядке показа
SWS.Roles = {"Пехота", "Специалисты", "Элита", "Техника"}
