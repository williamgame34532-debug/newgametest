--[[
	HUD командира в стиле Battlefront:
	- снизу панель войск: вкладки ролей (Пехота / Специалисты / Элита / Техника), карточки юнитов
	  с иконкой из VJ-пака, вариантом (легион / местность), ценой; справа — сколько высаживать;
	- над ней слева — выбранное отделение: состав, портреты со здоровьем, кнопки приказов;
	- справа — отряды 1–9; слева сверху — сторона и очки войск; сверху справа — режимы;
	- над головами — полоски здоровья, F1 — подсказка по управлению.
]]

local UI = SWS.UI
local Cmd = SWS.Cmd

local function Faction()
	return SWS.GetFaction(LocalPlayer())
end

local function Accent()
	local faction = Faction()

	return faction and faction.color or color_white
end

-- ===== карточка юнита =====
local CARD = {}

function CARD:Init()
	self:SetText("")
	self:SetCursor("hand")
	self.hover = 0
	self.variant = 1
end

function CARD:SetUnit(unit)
	self.unit = unit
	self.variant = math.Clamp(Cmd.variants and Cmd.variants[unit.id] or 1, 1, #unit.variants)
end

function CARD:GetVariant()
	return self.unit.variants[self.variant] or self.unit.variants[1]
end

function CARD:CycleVariant(direction)
	local count = #self.unit.variants

	if (count <= 1) then
		return
	end

	self.variant = (self.variant - 1 + direction) % count + 1

	Cmd.variants = Cmd.variants or {}
	Cmd.variants[self.unit.id] = self.variant

	if (Cmd.placing and Cmd.placing.unit == self.unit) then
		Cmd.placing.variant = self.variant
	end

	UI.Sound("hover")
end

function CARD:OnCursorEntered()
	UI.Sound("hover")
end

function CARD:OnMouseWheeled(delta)
	self:CycleVariant(delta > 0 and -1 or 1)
	return true
end

function CARD:DoClick()
	local x, y = self:CursorPos()
	local arrowZone = self:GetWide() * 0.22

	-- стрелки варианта внизу карточки
	if (#self.unit.variants > 1 and y > self:GetTall() * 0.72) then
		if (x < arrowZone) then
			self:CycleVariant(-1)
			return
		elseif (x > self:GetWide() - arrowZone) then
			self:CycleVariant(1)
			return
		end
	end

	Cmd.OrderUnit(self.unit, self.variant, Cmd.spawnCount or 1)
end

function CARD:DoRightClick()
	self:CycleVariant(1)
end

function CARD:Paint(width, height)
	local unit = self.unit
	local accent = Accent()
	local bPlacing = Cmd.placing and Cmd.placing.unit == unit
	local building = Cmd.building
	local bUnavailable = IsValid(building) and Cmd.IsOwnBuilding(building)
		and !SWS.BuildingProduces(building:GetBuildingType(), unit.role)

	self:SetAlpha(bUnavailable and 90 or 255)

	self.hover = math.Approach(self.hover, (self:IsHovered() or bPlacing) and 1 or 0, FrameTime() * 8)

	local lift = math.floor(self.hover * 4)

	-- фон и иконка
	surface.SetDrawColor(10, 12, 16, 220)
	surface.DrawRect(0, lift, width, height - lift)

	local iconSize = width - 8
	local variant = self:GetVariant()
	local icon = UI.UnitIcon(variant.class)

	UI.Gradient(0, lift, width, iconSize, Color(accent.r, accent.g, accent.b, 40 + self.hover * 40), "up")

	if (!icon:IsError()) then
		surface.SetMaterial(icon)
		surface.SetDrawColor(255, 255, 255, 200 + self.hover * 55)
		surface.DrawTexturedRect(4, 4 + lift, iconSize, iconSize)
	end

	-- уровень: точки сверху слева
	for i = 1, unit.tier or 1 do
		surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
		surface.DrawRect(6 + (i - 1) * 7, 6 + lift, 4, 4)
	end

	-- цена в очках
	draw.SimpleText("◆" .. unit.size, "SWSTiny", width - 6, 5 + lift, Color(255, 255, 255, 200), TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)

	-- название
	local nameY = iconSize + 6 + lift

	draw.SimpleText(UI.Fit(SWS.Upper(unit.name), "SWSSmall", width - 8), "SWSSmall", width * 0.5, nameY,
		UI.colors.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

	-- вариант
	if (#unit.variants > 1) then
		local label = SWS.Upper(variant.variant or "")
		local rowY = height - ScreenScale(5.5)

		draw.SimpleText(UI.Fit(label, "SWSTiny", width - ScreenScale(14)), "SWSTiny", width * 0.5, rowY, Color(accent.r, accent.g, accent.b),
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText("‹", "SWSLabel", 6, rowY, Color(255, 255, 255, 120 + self.hover * 135), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText("›", "SWSLabel", width - 6, rowY, Color(255, 255, 255, 120 + self.hover * 135), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	end

	-- рамка: при наведении белая, при высадке — заливка снизу
	surface.SetDrawColor(255, 255, 255, 30 + self.hover * 200)
	surface.DrawOutlinedRect(0, lift, width, height - lift, bPlacing and 2 or 1)

	if (bPlacing) then
		surface.SetDrawColor(255, 255, 255, 255)
		surface.DrawRect(0, height - 3, width, 3)
	end
end

vgui.Register("SWSUnitCard", CARD, "DButton")

-- ===== карточка здания =====
local BUILDCARD = {}

function BUILDCARD:Init()
	self:SetText("")
	self:SetCursor("hand")
	self.hover = 0
end

function BUILDCARD:OnCursorEntered()
	UI.Sound("hover")
end

function BUILDCARD:DoClick()
	Cmd.StartBuilding(self.info.id)
end

function BUILDCARD:Paint(width, height)
	local info = self.info
	local accent = Accent()
	local bPlacing = Cmd.placingBuilding and Cmd.placingBuilding.type == info.id

	self.hover = math.Approach(self.hover, (self:IsHovered() or bPlacing) and 1 or 0, FrameTime() * 8)

	local lift = math.floor(self.hover * 4)

	surface.SetDrawColor(10, 12, 16, 220)
	surface.DrawRect(0, lift, width, height - lift)

	local iconSize = width - 8

	UI.Gradient(0, lift, width, iconSize, Color(accent.r, accent.g, accent.b, 50 + self.hover * 50), "up")

	local icon = UI.Material("sws/b_" .. info.id .. ".png")

	if (!icon:IsError()) then
		surface.SetMaterial(icon)
		surface.SetDrawColor(255, 255, 255, 210 + self.hover * 45)
		surface.DrawTexturedRect(width * 0.18, 4 + lift + iconSize * 0.14, width * 0.64, width * 0.64)
	end

	local count = 0

	for _, entity in ipairs(Cmd.buildings) do
		if (IsValid(entity) and entity:GetBuildingType() == info.id) then
			count = count + 1
		end
	end

	local limit = GetConVar(info.limitConVar):GetInt()

	draw.SimpleText(count .. "/" .. limit, "SWSTiny", width - 6, 5 + lift, count >= limit and UI.colors.danger or Color(255, 255, 255, 200),
		TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)

	draw.SimpleText(UI.Fit(SWS.Upper(info.name), "SWSSmall", width - 8), "SWSSmall", width * 0.5, iconSize + 6 + lift,
		UI.colors.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

	local produces = info.produces and "ВОЙСКА" or "ВЫСАДКА И ЗАХВАТ"

	draw.SimpleText(produces, "SWSTiny", width * 0.5, height - ScreenScale(5.5), Color(accent.r, accent.g, accent.b),
		TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

	surface.SetDrawColor(255, 255, 255, 30 + self.hover * 200)
	surface.DrawOutlinedRect(0, lift, width, height - lift, bPlacing and 2 or 1)
end

vgui.Register("SWSBuildCard", BUILDCARD, "DButton")

-- ===== панель войск снизу =====
local BAR = {}

local BUILDINGS_TAB = "Здания"

function BAR:Init()
	self.role = BUILDINGS_TAB
	self.tabs = {}

	self.tabRow = self:Add("Panel")
	self.tabRow:Dock(TOP)
	self.tabRow:SetTall(ScreenScale(11))

	local tabNames = {BUILDINGS_TAB}

	for _, role in ipairs(SWS.Roles) do
		tabNames[#tabNames + 1] = role
	end

	for _, role in ipairs(tabNames) do
		local tab = self.tabRow:Add("DButton")
		tab:SetText("")
		tab:Dock(LEFT)
		tab:DockMargin(0, 0, ScreenScale(8), 0)
		tab.role = role

		surface.SetFont("SWSTab")
		tab:SetWide(surface.GetTextSize(SWS.Upper(role)) + ScreenScale(6))

		tab.Paint = function(this, width, height)
			local bActive = self.role == this.role
			local alpha = bActive and 255 or (this:IsHovered() and 220 or 140)

			UI.Spaced(SWS.Upper(this.role), "SWSTab", 0, height * 0.45, Color(255, 255, 255, alpha), 1, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

			if (bActive) then
				surface.SetDrawColor(255, 255, 255, 255)
				surface.DrawRect(0, height - 2, width - ScreenScale(6), 2)
			end
		end

		tab.DoClick = function(this)
			self.role = this.role
			self:Rebuild()
			UI.Sound("click")
		end

		self.tabs[#self.tabs + 1] = tab
	end

	-- сколько высаживать
	self.counter = self:Add("Panel")
	self.counter:Dock(RIGHT)
	self.counter:SetWide(ScreenScale(26))
	self.counter:DockMargin(ScreenScale(6), ScreenScale(2), 0, 0)

	for _, count in ipairs({1, 3, 5, 10}) do
		local button = self.counter:Add("DButton")
		button:SetText("")
		button:Dock(TOP)
		button:DockMargin(0, 0, 0, 3)
		button:SetTall(ScreenScale(12))
		button.count = count

		button.Paint = function(this, width, height)
			local bActive = (Cmd.spawnCount or 1) == this.count

			if (bActive) then
				surface.SetDrawColor(255, 255, 255, 255)
				surface.DrawRect(0, 0, width, height)
			else
				surface.SetDrawColor(10, 12, 16, this:IsHovered() and 240 or 200)
				surface.DrawRect(0, 0, width, height)

				surface.SetDrawColor(255, 255, 255, 40)
				surface.DrawOutlinedRect(0, 0, width, height)
			end

			draw.SimpleText("×" .. this.count, "SWSLabel", width * 0.5, height * 0.5,
				bActive and UI.colors.dark or UI.colors.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end

		button.DoClick = function(this)
			Cmd.spawnCount = this.count

			if (Cmd.placing) then
				Cmd.placing.count = this.count
			end

			UI.Sound("click")
		end
	end

	self.scroller = self:Add("DHorizontalScroller")
	self.scroller:Dock(FILL)
	self.scroller:DockMargin(0, ScreenScale(2), 0, 0)
	self.scroller:SetOverlap(-ScreenScale(3))

	self:Rebuild()
end

function BAR:Rebuild()
	local faction = Faction()

	self.scroller:Clear()
	self.factionID = faction and faction.id

	if (!faction) then
		return
	end

	local cardW = ScreenScale(46)

	if (self.role == BUILDINGS_TAB) then
		for _, buildingType in ipairs(SWS.BuildingOrder) do
			local card = vgui.Create("SWSBuildCard", self.scroller)
			card:SetWide(cardW)
			card.info = SWS.Buildings[buildingType]

			self.scroller:AddPanel(card)
		end

		return
	end

	for _, unit in ipairs(SWS.Units[faction.id] or {}) do
		if (unit.role == self.role) then
			local card = vgui.Create("SWSUnitCard", self.scroller)
			card:SetWide(cardW)
			card:SetUnit(unit)

			self.scroller:AddPanel(card)
		end
	end
end

function BAR:Think()
	local faction = Faction()

	if ((faction and faction.id) != self.factionID) then
		self:Rebuild()
	end

	-- выбрали казарму / завод — переключаемся на его войска
	local building = Cmd.building

	if (building != self.lastBuilding) then
		self.lastBuilding = building

		if (IsValid(building) and Cmd.IsOwnBuilding(building)) then
			local info = building:GetInfo()

			if (info and info.produces and !info.produces[self.role]) then
				for _, role in ipairs(SWS.Roles) do
					if (info.produces[role]) then
						self.role = role
						self:Rebuild()
						break
					end
				end
			end
		end
	end
end

function BAR:Paint(width, height)
	local tabH = self.tabRow:GetTall()

	UI.Gradient(-ScreenScale(12), tabH - 2, width + ScreenScale(24), height - tabH + ScreenScale(12), Color(0, 0, 0, 210), "up")

	surface.SetDrawColor(255, 255, 255, 40)
	surface.DrawRect(0, tabH, width, 1)
end

vgui.Register("SWSUnitBar", BAR, "Panel")

-- ===== выбранное отделение =====
local SELECTION = {}

local orderButtons = {
	{label = "АТАКА", key = "G", run = function() Cmd.attackMove = true end, tip = "ПКМ после — атака с ходу"},
	{label = "ДЕРЖАТЬ", key = "H", run = function() Cmd.SendOrder(SWS.ORDER_HOLD) end},
	{label = "СВОБОДНО", key = "X", run = function() Cmd.SendOrder(SWS.ORDER_FREE) end},
	{label = "ВСЕЛИТЬСЯ", key = "F", run = function() Cmd.SendOrder(SWS.ORDER_POSSESS) end},
	{label = "РАСПУСТИТЬ", key = "DEL", danger = true, run = function()
		Cmd.SendOrder(SWS.ORDER_DISMISS)
		Cmd.selection = {}
	end}
}

function SELECTION:Init()
	self.buttons = {}

	for _, info in ipairs(orderButtons) do
		local button = self:Add("DButton")
		button:SetText("")
		button.info = info

		button.Paint = function(this, width, height)
			local hovered = this:IsHovered()
			local color = info.danger and UI.colors.danger or color_white

			if (hovered) then
				surface.SetDrawColor(color.r, color.g, color.b, 255)
				surface.DrawRect(0, 0, width, height)
			else
				surface.SetDrawColor(255, 255, 255, 10)
				surface.DrawRect(0, 0, width, height)

				surface.SetDrawColor(255, 255, 255, 40)
				surface.DrawOutlinedRect(0, 0, width, height)
			end

			local textColor = hovered and (info.danger and color_white or UI.colors.dark) or UI.colors.text

			draw.SimpleText(info.label, "SWSTiny", width * 0.5, height * 0.38, textColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText(info.key, "SWSTiny", width * 0.5, height * 0.74, ColorAlpha(textColor, 150), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end

		button.OnCursorEntered = function()
			UI.Sound("hover")
		end

		button.DoClick = function()
			info.run()
			UI.Sound("click")
		end

		self.buttons[#self.buttons + 1] = button
	end
end

function SELECTION:PerformLayout(width, height)
	local gap = 3
	local count = #self.buttons
	local buttonW = (width - ScreenScale(8) - gap * (count - 1)) / count
	local buttonH = ScreenScale(13)

	for index, button in ipairs(self.buttons) do
		button:SetPos(ScreenScale(4) + (index - 1) * (buttonW + gap), height - buttonH - ScreenScale(4))
		button:SetSize(buttonW, buttonH)
	end
end

function SELECTION:Think()
	local bVisible = next(Cmd.selection) != nil and !IsValid(Cmd.building)

	if (self:IsVisible() != bVisible) then
		self:SetVisible(bVisible)
	end
end

function SELECTION:OnMousePressed(code)
	-- клик по портрету — выбрать только этого бойца
	local x, y = self:CursorPos()

	for _, slot in ipairs(self.slots or {}) do
		if (x >= slot.x and x <= slot.x + slot.size and y >= slot.y and y <= slot.y + slot.size and IsValid(slot.entity)) then
			if (code == MOUSE_LEFT) then
				Cmd.SetSelection({slot.entity})
				UI.Sound("click")
			elseif (code == MOUSE_RIGHT) then
				Cmd.CenterOn({slot.entity})
			end

			return
		end
	end
end

function SELECTION:Paint(width, height)
	local accent = Accent()
	local list = Cmd.GetSelected()
	local margin = ScreenScale(4)

	UI.Blur(self, 4)
	UI.Panel(0, 0, width, height, 1, accent)

	-- состав
	local counts, order = {}, {}

	for _, entity in ipairs(list) do
		local id = entity:GetNW2String("SWS_Unit")

		if (!counts[id]) then
			order[#order + 1] = id
		end

		counts[id] = (counts[id] or 0) + 1
	end

	local faction = Faction()
	local parts = {}

	for _, id in ipairs(order) do
		local unit = faction and SWS.UnitIndex[faction.id] and SWS.UnitIndex[faction.id][id]
		parts[#parts + 1] = counts[id] .. "× " .. (unit and unit.name or id)
	end

	UI.Spaced("ОТДЕЛЕНИЕ", "SWSHeader", margin, margin, UI.colors.text, 2)
	draw.SimpleText(tostring(#list), "SWSHeader", width - margin, margin, accent, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
	draw.SimpleText(UI.Fit(table.concat(parts, "   "), "SWSSmall", width - margin * 2), "SWSSmall", margin,
		margin + ScreenScale(11), UI.colors.dim)

	-- портреты
	local size = ScreenScale(15)
	local gap = 3
	local perRow = math.floor((width - margin * 2 + gap) / (size + gap))
	local startY = margin + ScreenScale(19)
	local rowsFit = math.floor((height - startY - ScreenScale(21) + gap) / (size + gap))

	self.slots = {}

	for index, entity in ipairs(list) do
		if (index > perRow * rowsFit) then
			draw.SimpleText("+" .. (#list - index + 1), "SWSSmall", width - margin, startY + rowsFit * (size + gap) - gap,
				UI.colors.dim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)
			break
		end

		local column = (index - 1) % perRow
		local row = math.floor((index - 1) / perRow)
		local x, y = margin + column * (size + gap), startY + row * (size + gap)

		surface.SetDrawColor(6, 8, 10, 230)
		surface.DrawRect(x, y, size, size)

		local icon = UI.UnitIcon(entity:GetClass())

		if (!icon:IsError()) then
			surface.SetMaterial(icon)
			surface.SetDrawColor(255, 255, 255, 255)
			surface.DrawTexturedRect(x + 1, y + 1, size - 2, size - 5)
		end

		local fraction = math.Clamp(SWS.GetHealth(entity) / SWS.GetMaxHealth(entity), 0, 1)
		local barColor = fraction < 0.35 and UI.colors.danger or (fraction < 0.7 and Color(240, 190, 60) or UI.colors.good)

		surface.SetDrawColor(0, 0, 0, 200)
		surface.DrawRect(x, y + size - 4, size, 4)

		surface.SetDrawColor(barColor)
		surface.DrawRect(x, y + size - 4, size * fraction, 4)

		surface.SetDrawColor(255, 255, 255, 30)
		surface.DrawOutlinedRect(x, y, size, size)

		self.slots[#self.slots + 1] = {x = x, y = y, size = size, entity = entity}
	end
end

vgui.Register("SWSSelectionPanel", SELECTION, "Panel")

-- ===== выбранное здание: очередь, повтор, точка сбора, снос =====
local BUILDING = {}

local buildingButtons = {
	{label = "НЕПРЕРЫВНО", key = "R", toggle = true, run = function(building) Cmd.BuildingCommand(building, SWS.BUILDING_REPEAT) end},
	{label = "СБОР С АТАКОЙ", key = "G", run = function() Cmd.attackMove = true end},
	{label = "СНЕСТИ", key = "DEL", danger = true, run = function(building)
		Cmd.BuildingCommand(building, SWS.BUILDING_DEMOLISH)
		Cmd.building = nil
	end}
}

function BUILDING:Init()
	self.buttons = {}

	for _, info in ipairs(buildingButtons) do
		local button = self:Add("DButton")
		button:SetText("")

		button.Paint = function(this, width, height)
			local building = Cmd.building
			local bActive = info.toggle and IsValid(building) and building:GetRepeat()
			local hovered = this:IsHovered()
			local color = info.danger and UI.colors.danger or color_white

			if (hovered or bActive) then
				surface.SetDrawColor(color.r, color.g, color.b, bActive and !hovered and 220 or 255)
				surface.DrawRect(0, 0, width, height)
			else
				surface.SetDrawColor(255, 255, 255, 10)
				surface.DrawRect(0, 0, width, height)

				surface.SetDrawColor(255, 255, 255, 40)
				surface.DrawOutlinedRect(0, 0, width, height)
			end

			local textColor = (hovered or bActive) and (info.danger and color_white or UI.colors.dark) or UI.colors.text

			draw.SimpleText(info.label, "SWSTiny", width * 0.5, height * 0.38, textColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText(info.key, "SWSTiny", width * 0.5, height * 0.74, ColorAlpha(textColor, 150), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end

		button.OnCursorEntered = function()
			UI.Sound("hover")
		end

		button.DoClick = function()
			if (IsValid(Cmd.building)) then
				info.run(Cmd.building)
				UI.Sound("click")
			end
		end

		self.buttons[#self.buttons + 1] = button
	end
end

function BUILDING:PerformLayout(width, height)
	local gap = 3
	local count = #self.buttons
	local buttonW = (width - ScreenScale(8) - gap * (count - 1)) / count
	local buttonH = ScreenScale(13)

	for index, button in ipairs(self.buttons) do
		button:SetPos(ScreenScale(4) + (index - 1) * (buttonW + gap), height - buttonH - ScreenScale(4))
		button:SetSize(buttonW, buttonH)
	end
end

function BUILDING:Think()
	local building = Cmd.building
	local bVisible = IsValid(building)

	if (self:IsVisible() != bVisible) then
		self:SetVisible(bVisible)
	end

	if (bVisible) then
		local bOwn = Cmd.IsOwnBuilding(building) and building:GetInfo() and building:GetInfo().produces != nil

		for _, button in ipairs(self.buttons) do
			button:SetVisible(Cmd.IsOwnBuilding(building) and (bOwn or button == self.buttons[#self.buttons]))
		end
	end
end

-- клик по ячейке очереди — отменить
function BUILDING:OnMousePressed(code)
	local x, y = self:CursorPos()

	for index, slot in ipairs(self.slots or {}) do
		if (x >= slot.x and x <= slot.x + slot.size and y >= slot.y and y <= slot.y + slot.size) then
			Cmd.BuildingCommand(Cmd.building, SWS.BUILDING_UNQUEUE, function()
				net.WriteUInt(index, 5)
			end)

			UI.Sound("click")
			return
		end
	end
end

function BUILDING:Paint(width, height)
	local building = Cmd.building

	if (!IsValid(building)) then
		return
	end

	local info = building:GetInfo()
	local faction = SWS.Factions[building:GetSide()]
	local accent = faction and faction.color or Color(200, 204, 210)
	local margin = ScreenScale(4)

	UI.Blur(self, 4)
	UI.Panel(0, 0, width, height, 1, accent)

	local title = SWS.Upper(info.name)

	if (info.id == "command") then
		title = title .. " " .. building:GetLetterText()
	end

	UI.Spaced(title, "SWSHeader", margin, margin, UI.colors.text, 2)
	draw.SimpleText(faction and faction.short or "НЕЙТРАЛЬНЫЙ", "SWSTiny", width - margin, margin + 2, accent, TEXT_ALIGN_RIGHT)

	local y = margin + ScreenScale(12)

	-- стройка / здоровье
	if (!building:IsBuilt()) then
		local fraction = building:GetBuildFraction()

		draw.SimpleText(string.format("СТРОИТСЯ... %d%%", fraction * 100), "SWSSmall", margin, y, UI.colors.dim)

		surface.SetDrawColor(255, 255, 255, 25)
		surface.DrawRect(margin, y + ScreenScale(7), width - margin * 2, 4)

		surface.SetDrawColor(120, 200, 255, 255)
		surface.DrawRect(margin, y + ScreenScale(7), (width - margin * 2) * fraction, 4)

		self.slots = {}
		return
	end

	if (info.health > 0) then
		local fraction = math.Clamp(building:GetHP() / math.max(building:GetMaxHP(), 1), 0, 1)

		draw.SimpleText(string.format("ПРОЧНОСТЬ %d / %d", building:GetHP(), building:GetMaxHP()), "SWSTiny", margin, y, UI.colors.dim)

		surface.SetDrawColor(255, 255, 255, 25)
		surface.DrawRect(margin, y + ScreenScale(5), width - margin * 2, 3)

		surface.SetDrawColor(fraction < 0.35 and UI.colors.danger or accent)
		surface.DrawRect(margin, y + ScreenScale(5), (width - margin * 2) * fraction, 3)
	else
		local capture = building:GetProgress()

		draw.SimpleText(building:GetContested() and "ПОСТ ОСПАРИВАЕТСЯ" or string.format("КОНТРОЛЬ %d%%", capture), "SWSTiny", margin, y,
			building:GetContested() and UI.colors.danger or UI.colors.dim)
	end

	y = y + ScreenScale(10)

	if (!info.produces) then
		draw.SimpleText(UI.Fit(info.description, "SWSSmall", width - margin * 2), "SWSSmall", margin, y, UI.colors.dim)
		self.slots = {}
		return
	end

	-- очередь
	local queue = SWS.ParseQueue(building:GetQueue())
	local size = ScreenScale(15)
	local gap = 3
	local perRow = math.floor((width - margin * 2 + gap) / (size + gap))
	local factionID = faction and faction.id

	self.slots = {}

	if (#queue == 0) then
		draw.SimpleText("ОЧЕРЕДЬ ПУСТА — ВЫБЕРИТЕ ВОЙСКА ВНИЗУ", "SWSSmall", margin, y + size * 0.5, UI.colors.dim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	for index, item in ipairs(queue) do
		if (index > perRow) then
			break
		end

		local unit = factionID and SWS.UnitIndex[factionID] and SWS.UnitIndex[factionID][item.id]
		local x = margin + (index - 1) * (size + gap)

		surface.SetDrawColor(6, 8, 10, 230)
		surface.DrawRect(x, y, size, size)

		if (unit) then
			local variant = unit.variants[item.variant] or unit.variants[1]
			local icon = UI.UnitIcon(variant.class)

			if (!icon:IsError()) then
				surface.SetMaterial(icon)
				surface.SetDrawColor(255, 255, 255, index == 1 and 255 or 150)
				surface.DrawTexturedRect(x + 1, y + 1, size - 2, size - 2)
			end
		end

		-- прогресс текущего
		if (index == 1 and building:GetProdEnd() > 0) then
			local fraction = math.Clamp((CurTime() - building:GetProdStart()) / math.max(building:GetProdEnd() - building:GetProdStart(), 0.01), 0, 1)

			surface.SetDrawColor(0, 0, 0, 160)
			surface.DrawRect(x, y + size * fraction, size, size * (1 - fraction))

			surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
			surface.DrawRect(x, y + size - 3, size * fraction, 3)
		end

		surface.SetDrawColor(255, 255, 255, index == 1 and 160 or 30)
		surface.DrawOutlinedRect(x, y, size, size)

		self.slots[index] = {x = x, y = y, size = size}
	end

	local statusY = y + size + 4
	local status

	if (building:GetBlocked()) then
		status = "ЛИМИТ ВОЙСК: ПРОИЗВОДСТВО ЖДЁТ"
	elseif (!building:GetHasRally()) then
		status = "ПКМ ПО ЗЕМЛЕ — ТОЧКА СБОРА"
	else
		status = building:GetRallyAttack() and "СБОР: АТАКА С ХОДУ  ·  ПКМ — ПЕРЕНЕСТИ" or "СБОР: ДЕРЖАТЬ ТОЧКУ  ·  ПКМ — ПЕРЕНЕСТИ"
	end

	draw.SimpleText(status, "SWSTiny", margin, statusY, building:GetBlocked() and UI.colors.danger or UI.colors.dim)
end

vgui.Register("SWSBuildingPanel", BUILDING, "Panel")

-- ===== отряды 1–9 справа =====
local SQUADS = {}

function SQUADS:Init()
	self.rows = {}

	for number = 1, 9 do
		local row = self:Add("DButton")
		row:SetText("")
		row:Dock(TOP)
		row:DockMargin(0, 0, 0, 3)
		row:SetTall(ScreenScale(12))
		row.number = number

		row.Paint = function(this, width, height)
			local squad = Cmd.squads[this.number]

			if (!squad) then
				return
			end

			local accent = Accent()
			local bSelected = true

			for _, entity in ipairs(squad) do
				if (!Cmd.selection[entity]) then
					bSelected = false
					break
				end
			end

			local health, maxHealth = 0, 0

			for _, entity in ipairs(squad) do
				if (IsValid(entity)) then
					health = health + SWS.GetHealth(entity)
					maxHealth = maxHealth + SWS.GetMaxHealth(entity)
				end
			end

			surface.SetDrawColor(10, 12, 16, (this:IsHovered() or bSelected) and 240 or 190)
			surface.DrawRect(0, 0, width, height)

			surface.SetDrawColor(bSelected and Color(255, 255, 255) or Color(accent.r, accent.g, accent.b))
			surface.DrawRect(0, 0, 3, height)

			draw.SimpleText(tostring(this.number), "SWSNumber", ScreenScale(5), height * 0.5, UI.colors.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText("ОТРЯД · " .. #squad, "SWSSmall", ScreenScale(14), height * 0.4, UI.colors.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

			local barX, barW = ScreenScale(14), width - ScreenScale(18)

			surface.SetDrawColor(255, 255, 255, 25)
			surface.DrawRect(barX, height * 0.72, barW, 3)

			surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
			surface.DrawRect(barX, height * 0.72, barW * math.Clamp(health / math.max(maxHealth, 1), 0, 1), 3)
		end

		row.DoClick = function(this)
			if (Cmd.squads[this.number]) then
				Cmd.SetSelection(Cmd.squads[this.number], input.IsKeyDown(KEY_LSHIFT))
				UI.Sound("click")
			end
		end

		row.DoDoubleClick = function(this)
			if (Cmd.squads[this.number]) then
				Cmd.CenterOn(Cmd.squads[this.number])
			end
		end

		self.rows[number] = row
	end
end

function SQUADS:Think()
	for number, row in ipairs(self.rows) do
		local bVisible = Cmd.squads[number] != nil

		if (row:IsVisible() != bVisible) then
			row:SetVisible(bVisible)
			self:InvalidateLayout()
		end
	end
end

vgui.Register("SWSSquads", SQUADS, "Panel")

-- ===== кнопки режимов сверху справа =====
local function TopButton(parent, label, key, onClick)
	local button = parent:Add("DButton")
	button:SetText("")
	button:Dock(RIGHT)
	button:DockMargin(ScreenScale(4), 0, 0, 0)

	surface.SetFont("SWSSmall")
	button:SetWide(surface.GetTextSize(label) + ScreenScale(16))

	button.Paint = function(this, width, height)
		local hovered = this:IsHovered()

		surface.SetDrawColor(10, 12, 16, hovered and 240 or 180)
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(255, 255, 255, hovered and 200 or 40)
		surface.DrawOutlinedRect(0, 0, width, height)

		local keyW = UI.Key(key, ScreenScale(3), height * 0.5 - ScreenScale(4), 255)

		draw.SimpleText(label, "SWSSmall", ScreenScale(3) + keyW + ScreenScale(3), height * 0.5, UI.colors.text,
			TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	button.OnCursorEntered = function()
		UI.Sound("hover")
	end

	button.DoClick = function()
		UI.Sound("click")
		onClick()
	end

	surface.SetFont("SWSKey")
	local keyW = surface.GetTextSize(key) + 10
	button:SetWide(button:GetWide() + keyW)

	return button
end

-- ===== сборка HUD на панели командира =====
function SWS.BuildCommanderHUD(panel)
	local margin = ScreenScale(10)
	-- панель войск — справа от панели отделения / здания, до правого края
	local barX = margin + ScreenScale(150) + ScreenScale(10)
	local barW = ScrW() - barX - margin

	panel.unitBar = panel:Add("SWSUnitBar")
	panel.unitBar:SetSize(barW, ScreenScale(78))
	panel.unitBar:SetPos(barX, ScrH() - ScreenScale(78) - margin)

	panel.selectionPanel = panel:Add("SWSSelectionPanel")
	panel.selectionPanel:SetSize(ScreenScale(150), ScreenScale(96))
	panel.selectionPanel:SetPos(margin, ScrH() - ScreenScale(96) - margin)
	panel.selectionPanel:SetVisible(false)

	panel.buildingPanel = panel:Add("SWSBuildingPanel")
	panel.buildingPanel:SetSize(ScreenScale(150), ScreenScale(76))
	panel.buildingPanel:SetPos(margin, ScrH() - ScreenScale(76) - margin)
	panel.buildingPanel:SetVisible(false)

	panel.squads = panel:Add("SWSSquads")
	panel.squads:SetSize(ScreenScale(62), ScreenScale(140))
	panel.squads:SetPos(ScrW() - ScreenScale(62) - margin, ScreenScale(60))

	panel.topButtons = panel:Add("Panel")
	panel.topButtons:SetSize(ScreenScale(300), ScreenScale(12))
	panel.topButtons:SetPos(ScrW() - ScreenScale(300) - margin, margin)

	TopButton(panel.topButtons, "ПОДСКАЗКА", "F1", function() SWS.showHelp = !SWS.showHelp end)
	TopButton(panel.topButtons, "СТОРОНА", "F2", function() RunConsoleCommand("sws_sidemenu") end)
	TopButton(panel.topButtons, "В БОЙ: ВЫСАДКА", "F3", function() RunConsoleCommand("sws_deploy") end)
end

-- ===== рисование поверх (вызывается из панели командира) =====
local helpLines = {
	{"WASD / края экрана", "двигать камеру"},
	{"Q / E, зажатое колесо", "повернуть камеру"},
	{"Колесо", "высота камеры"},
	{"ЛКМ / рамка", "выбрать бойцов (Shift — добавить)"},
	{"Двойной клик", "все такие же на экране"},
	{"ПКМ по земле", "идти и держать точку (Ctrl — шагом)"},
	{"ПКМ по врагу", "атаковать цель"},
	{"G, затем ПКМ", "атака с ходу"},
	{"H / X", "держать позицию / свободный бой"},
	{"Ctrl+1…9 / 1…9", "назначить / выбрать отряд"},
	{"F", "вселиться в бойца (End — выйти)"},
	{"Delete", "распустить выбранных"},
	{"Вкладка «Здания»", "построить пост, казарму, завод (колесо — поворот)"},
	{"Клик по зданию", "выбрать: карточки войск — в очередь"},
	{"ПКМ (выбрано здание)", "точка сбора новых бойцов (G — с атакой)"},
	{"R / Delete", "непрерывное производство / снести здание"},
	{"Колесо на карточке", "сменить вариант (легион / местность)"},
	{"Enter", "чат"}
}

local function PaintHelp(width, height)
	local w = ScreenScale(190)
	local lineH = ScreenScale(9)
	local h = ScreenScale(22) + #helpLines * lineH
	local x, y = width * 0.5 - w * 0.5, height * 0.18

	UI.Panel(x, y, w, h, 1, Accent())
	UI.Spaced("УПРАВЛЕНИЕ", "SWSHeader", x + ScreenScale(6), y + ScreenScale(5), UI.colors.text, 3)

	for index, line in ipairs(helpLines) do
		local lineY = y + ScreenScale(18) + (index - 1) * lineH

		draw.SimpleText(line[1], "SWSLabel", x + ScreenScale(6), lineY, UI.colors.text)
		draw.SimpleText(line[2], "SWSBody", x + ScreenScale(78), lineY, UI.colors.dim)
	end
end

function SWS.PaintCommanderOverlay(panel, width, height)
	local client = LocalPlayer()
	local faction = Faction()
	local accent = Accent()
	local margin = ScreenScale(10)

	-- полоски здоровья над своими
	local cursorX, cursorY = panel:CursorPos()

	for _, entity in ipairs(Cmd.units) do
		if (!IsValid(entity)) then
			continue
		end

		local fraction = math.Clamp(SWS.GetHealth(entity) / SWS.GetMaxHealth(entity), 0, 1)
		local bSelected = Cmd.selection[entity]

		if (!bSelected and fraction >= 1) then
			continue
		end

		local top = (entity:GetPos() + Vector(0, 0, entity:OBBMaxs().z + 8)):ToScreen()

		if (!top.visible) then
			continue
		end

		local barW = math.Clamp(ScreenScale(14) * (900 / math.max(Cmd.distance, 300)), ScreenScale(8), ScreenScale(22))
		local barColor = fraction < 0.35 and UI.colors.danger or (fraction < 0.7 and Color(240, 190, 60) or accent)

		surface.SetDrawColor(0, 0, 0, 180)
		surface.DrawRect(top.x - barW * 0.5 - 1, top.y - 1, barW + 2, 5)

		surface.SetDrawColor(barColor)
		surface.DrawRect(top.x - barW * 0.5, top.y, barW * fraction, 3)
	end

	-- здания: прочность (свои — при уроне или выборе), стройка
	for _, building in ipairs(ents.FindByClass("sws_building")) do
		local info = building:GetInfo()

		if (!info) then
			continue
		end

		local bSelected = Cmd.building == building
		local fraction = info.health > 0 and math.Clamp(building:GetHP() / math.max(building:GetMaxHP(), 1), 0, 1) or 1
		local bBuilding = !building:IsBuilt()

		if (!bSelected and !bBuilding and fraction >= 1) then
			continue
		end

		local top = (building:GetPos() + Vector(0, 0, info.maxs.z + 30)):ToScreen()

		if (!top.visible) then
			continue
		end

		local sideFaction = SWS.Factions[building:GetSide()]
		local color = sideFaction and sideFaction.color or Color(200, 204, 210)
		local barW = ScreenScale(36)

		if (bBuilding) then
			fraction = building:GetBuildFraction()
			color = Color(120, 200, 255)
		end

		surface.SetDrawColor(0, 0, 0, 180)
		surface.DrawRect(top.x - barW * 0.5 - 1, top.y - 1, barW + 2, 6)

		surface.SetDrawColor(color)
		surface.DrawRect(top.x - barW * 0.5, top.y, barW * fraction, 4)

		draw.SimpleText(SWS.Upper(info.name) .. (info.id == "command" and (" " .. building:GetLetterText()) or ""), "SWSTiny",
			top.x, top.y - 3, Color(255, 255, 255, 220), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
	end

	-- сторона и очки войск
	if (faction) then
		local population = 0

		for _, entity in ipairs(Cmd.units) do
			if (IsValid(entity)) then
				population = population + SWS.GetUnitCost(entity)
			end
		end

		local limit = GetConVar("sws_population"):GetInt()
		local x, y = margin, margin

		surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
		surface.DrawRect(x, y, 3, ScreenScale(26))

		UI.Spaced(faction.short, "SWSTitle", x + ScreenScale(5), y - ScreenScale(2), UI.colors.text, 2)
		UI.Spaced(faction.era .. "  ·  КОМАНДОВАНИЕ", "SWSSmall", x + ScreenScale(5), y + ScreenScale(15), UI.colors.dim, 1)

		local barY = y + ScreenScale(30)
		local barW = ScreenScale(90)

		draw.SimpleText("ОЧКИ ВОЙСК", "SWSTiny", x, barY, UI.colors.dim)
		draw.SimpleText(population .. " / " .. limit, "SWSTiny", x + barW, barY, UI.colors.text, TEXT_ALIGN_RIGHT)

		surface.SetDrawColor(255, 255, 255, 25)
		surface.DrawRect(x, barY + ScreenScale(6), barW, 4)

		surface.SetDrawColor(population >= limit and UI.colors.danger or accent)
		surface.DrawRect(x, barY + ScreenScale(6), barW * math.Clamp(population / math.max(limit, 1), 0, 1), 4)
	end

	-- подсказка у курсора
	local hint

	if (Cmd.placingBuilding) then
		local info = SWS.Buildings[Cmd.placingBuilding.type]
		hint = "СТРОИТЬ: " .. SWS.Upper(info.name) .. "   ·   ЛКМ — поставить, колесо — повернуть, ПКМ — отмена"
	elseif (Cmd.placing) then
		local variant = Cmd.placing.unit.variants[Cmd.placing.variant]
		hint = string.format("ВЫСАДКА: %s ×%d%s   ·   ЛКМ — поставить, Shift — ещё, ПКМ — отмена",
			SWS.Upper(Cmd.placing.unit.name), Cmd.placing.count, variant.variant and (" (" .. variant.variant .. ")") or "")
	elseif (Cmd.attackMove) then
		hint = "АТАКА С ХОДУ   ·   ПКМ — точка атаки"
	end

	if (hint and vgui.GetHoveredPanel() == panel) then
		surface.SetFont("SWSSmall")

		local textW, textH = surface.GetTextSize(hint)

		surface.SetDrawColor(0, 0, 0, 200)
		surface.DrawRect(cursorX + 18, cursorY + 14, textW + 12, textH + 6)

		surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
		surface.DrawRect(cursorX + 18, cursorY + 14, 2, textH + 6)

		draw.SimpleText(hint, "SWSSmall", cursorX + 24, cursorY + 17, UI.colors.text)
	end

	UI.PaintNotices(width * 0.5, ScreenScale(12))

	if (SWS.showHelp) then
		PaintHelp(width, height)
	elseif (!faction or #Cmd.units == 0) then
		draw.SimpleText("F1 — УПРАВЛЕНИЕ   ·   ПОСТРОЙТЕ КАЗАРМУ ВО ВКЛАДКЕ «ЗДАНИЯ» И ЗАКАЖИТЕ ВОЙСКА", "SWSSmall", width * 0.5,
			height - ScreenScale(96), Color(255, 255, 255, 170 + math.sin(RealTime() * 3) * 60), TEXT_ALIGN_CENTER)
	end
end

-- HUD вне режима командира: подсказки в бою и в свободном режиме
hook.Add("HUDPaint", "SWS_ModeHints", function()
	local client = LocalPlayer()
	local mode = SWS.GetMode(client)

	if (mode == SWS.MODE_POSSESS) then
		local text = "END / F3 — ВЕРНУТЬСЯ К КОМАНДОВАНИЮ   ·   H — ВИД ОТ 1-ГО / 3-ГО ЛИЦА"

		draw.SimpleText(text, "SWSSmall", ScrW() * 0.5 + 1, ScreenScale(52) + 1, Color(0, 0, 0, 200), TEXT_ALIGN_CENTER)
		draw.SimpleText(text, "SWSSmall", ScrW() * 0.5, ScreenScale(52), Color(255, 255, 255, 220), TEXT_ALIGN_CENTER)
	elseif (mode == SWS.MODE_FREE) then
		local faction = Faction()
		local x, y = ScrW() - ScreenScale(10), ScreenScale(10)

		if (faction) then
			UI.Spaced(faction.short, "SWSHeader", x, y, UI.colors.text, 2, TEXT_ALIGN_RIGHT)
		end

		draw.SimpleText("F3 — КОМАНДОВАНИЕ   ·   F2 — СТОРОНА", "SWSSmall", x, y + ScreenScale(12), Color(255, 255, 255, 180), TEXT_ALIGN_RIGHT)
		UI.PaintNotices(ScrW() * 0.5, ScreenScale(52))
	end
end)
