--[[
	Star Wars Sandbox — сервер.
]]

AddCSLuaFile("shared.lua")
AddCSLuaFile("sh_factions.lua")
AddCSLuaFile("sh_units.lua")
AddCSLuaFile("sh_buildings.lua")
AddCSLuaFile("sh_loadouts.lua")
AddCSLuaFile("cl_deploy.lua")
AddCSLuaFile("cl_playerhud.lua")
AddCSLuaFile("cl_fx.lua")
AddCSLuaFile("cl_init.lua")
AddCSLuaFile("cl_style.lua")
AddCSLuaFile("cl_sidemenu.lua")
AddCSLuaFile("cl_commander.lua")
AddCSLuaFile("cl_hud.lua")
AddCSLuaFile("cl_world.lua")

include("shared.lua")
include("sv_content.lua")
include("sv_player.lua")
include("sv_units.lua")
include("sv_buildings.lua")
include("sv_deploy.lua")
include("sv_ai.lua")
