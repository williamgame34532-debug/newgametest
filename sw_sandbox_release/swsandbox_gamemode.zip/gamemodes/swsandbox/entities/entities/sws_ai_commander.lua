--[[
	ИИ-командир: невидимый «владелец» зданий и войск стороны, которую ведёт компьютер.
	Логика — в gamemode/sv_ai.lua.
]]

AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "ИИ-командир"
ENT.Spawnable = false

function ENT:SetupDataTables()
	self:NetworkVar("Int", 0, "Side")
	self:NetworkVar("String", 0, "CommanderName")
end

function ENT:Initialize()
	self:SetNoDraw(true)
	self:DrawShadow(false)
	self:SetSolid(SOLID_NONE)
	self:SetMoveType(MOVETYPE_NONE)
end

-- имя и сторона нужны всем клиентам, где бы ни стоял командир
function ENT:UpdateTransmitState()
	return TRANSMIT_ALWAYS
end

function ENT:Draw()
end
