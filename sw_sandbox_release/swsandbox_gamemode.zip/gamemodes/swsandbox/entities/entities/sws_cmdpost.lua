--[[
	Нейтральный командный пост для меню спавна (Сущности → Star Wars Sandbox).
	Сам не создаётся — ставит обычное здание «командный пост» без стороны.
]]

AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Командный пост (нейтральный)"
ENT.Category = "Star Wars Sandbox"
ENT.Spawnable = true
ENT.AdminOnly = true

function ENT:SpawnFunction(client, trace, className)
	if (!trace.Hit) then
		return
	end

	local yaw = IsValid(client) and (client:EyeAngles().y + 180) or 0

	return SWS.CreateBuilding("command", trace.HitPos, yaw, 0, NULL, true)
end
