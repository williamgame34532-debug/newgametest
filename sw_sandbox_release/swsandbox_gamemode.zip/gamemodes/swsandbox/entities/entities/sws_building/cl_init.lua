--[[
	Здание — клиент: собирается из блоков PHX и деталей Combine (gamemode/sh_buildings.lua → parts),
	во время стройки «растёт» снизу вверх в голографической рамке, у командного поста — голограмма
	с буквой и кольцо зоны захвата цвета владельца.
]]

include("shared.lua")

local CUBE = "models/hunter/blocks/cube1x1x1.mdl"
local CUBE_SIZE = 47.45

local ringMaterial = Material("sws/ring.png", "smooth mips")
local ringDashMaterial = Material("sws/ring_dash.png", "smooth mips")
local beamMaterial = Material("sprites/physbeama")
local glowMaterial = Material("sprites/light_glow02_add")

-- одна клиентская модель на путь, переиспользуется для всех деталей
local models = {}

local function GetModel(path)
	local model = models[path]

	if (!IsValid(model)) then
		model = ClientsideModel(path, RENDERGROUP_OPAQUE)

		if (!IsValid(model)) then
			return nil
		end

		model:SetNoDraw(true)
		models[path] = model
	end

	return model
end

local NEUTRAL = Color(200, 204, 210)

function ENT:GetSideColor()
	local faction = SWS.Factions[self:GetSide()]

	return faction and faction.color or NEUTRAL
end

function ENT:Initialize()
	local info = self:GetInfo()

	if (info) then
		self:SetRenderBounds(info.mins - Vector(60, 60, 0), info.maxs + Vector(60, 60, 140))

		-- коллизия коробкой и на клиенте: иначе клик и трассировки камеры проходят сквозь здание
		self:PhysicsInitBox(info.mins, info.maxs)
		self:SetSolid(SOLID_VPHYSICS)
		self:EnableCustomCollisions(true)
		self:SetCollisionBounds(info.mins, info.maxs)
	end
end

function ENT:DrawPart(part, build, color)
	local position = self:GetPos()
	local angles = self:GetAngles()

	if (part.box) then
		local model = GetModel(CUBE)

		if (!model) then
			return
		end

		local offset = Vector(part.box[1], part.box[2], part.box[3] * build)
		offset:Rotate(angles)

		local scale = Matrix()
		scale:Scale(Vector(part.size[1] / CUBE_SIZE, part.size[2] / CUBE_SIZE, math.max(part.size[3] * build, 0.5) / CUBE_SIZE))

		model:SetPos(position + offset)
		model:SetAngles(angles)
		model:EnableMatrix("RenderMultiply", scale)
		model:SetMaterial(part.faction and "models/debug/debugwhite" or (part.material or "phoenix_storms/metalset_1-2"))

		if (part.faction) then
			render.SetColorModulation(color.r / 255, color.g / 255, color.b / 255)
		else
			local shade = part.shade or 1
			render.SetColorModulation(shade, shade, shade * 1.03)
		end

		model:SetupBones()
		model:DrawModel()
	elseif (part.model and build > 0.85) then
		local model = GetModel(part.model)

		if (!model) then
			return
		end

		local offset = Vector(part.pos[1], part.pos[2], part.pos[3])
		offset:Rotate(angles)

		model:SetPos(position + offset)
		model:SetAngles(angles + Angle(part.ang[1], part.ang[2], part.ang[3]))
		model:DisableMatrix("RenderMultiply")
		model:SetMaterial("")

		render.SetColorModulation(1, 1, 1)

		model:SetupBones()
		model:DrawModel()
	end
end

function ENT:Draw()
	local info = self:GetInfo()

	if (!info) then
		return
	end

	local build = self:GetBuildFraction()
	local color = self:GetSideColor()

	for _, part in ipairs(info.parts) do
		self:DrawPart(part, build, color)
	end

	render.SetColorModulation(1, 1, 1)
end

-- прозрачное: рамка стройки, кольца, голограммы
function ENT:DrawTranslucent()
	local info = self:GetInfo()

	if (!info) then
		return
	end

	local now = RealTime()
	local position = self:GetPos()
	local color = self:GetSideColor()
	local build = self:GetBuildFraction()
	local up = Vector(0, 0, 1)

	-- стройка: голографический каркас и бегущая полоса
	if (build < 1) then
		local mins, maxs = info.mins, info.maxs
		local height = maxs.z * build

		render.SetColorMaterial()
		render.DrawWireframeBox(position, self:GetAngles(), mins, maxs, Color(120, 200, 255, 120), true)
		render.DrawBox(position + up * height, self:GetAngles(), Vector(mins.x, mins.y, -1), Vector(maxs.x, maxs.y, 1),
			Color(120, 200, 255, 60 + math.sin(now * 8) * 30))

		if (math.random() < 0.08) then
			local effect = EffectData()
			effect:SetOrigin(position + Vector(math.Rand(mins.x, maxs.x), math.Rand(mins.y, maxs.y), height))
			effect:SetMagnitude(1)
			effect:SetScale(1)
			util.Effect("cball_bounce", effect)
		end
	end

	-- командный пост: кольцо зоны захвата, луч, буква
	if (info.id == "command") then
		local radius = info.captureRadius
		local capture = self:GetCaptureSide()
		local captureFaction = SWS.Factions[capture]
		local alpha = self:GetContested() and (120 + math.sin(now * 10) * 80) or 140

		if (!ringMaterial:IsError()) then
			render.SetMaterial(ringMaterial)
			render.DrawQuadEasy(position + up * 3, up, radius * 2, radius * 2, Color(color.r, color.g, color.b, alpha * 0.6), 0)

			render.SetMaterial(ringDashMaterial)
			render.DrawQuadEasy(position + up * 4, up, radius * 1.9, radius * 1.9, Color(color.r, color.g, color.b, alpha), now * 8 % 360)

			-- захват: второе кольцо цвета захватчика растёт с прогрессом
			if (captureFaction) then
				local fraction = self:GetProgress() / 100
				local captureColor = captureFaction.color

				render.SetMaterial(ringMaterial)
				render.DrawQuadEasy(position + up * 5, up, radius * 2 * math.max(fraction, 0.05), radius * 2 * math.max(fraction, 0.05),
					Color(captureColor.r, captureColor.g, captureColor.b, 220), 0)
			end
		end

		-- луч от мачты
		local top = position + up * 210

		render.SetMaterial(beamMaterial)
		render.DrawBeam(position + up * 20, top + up * 300, 18, now, now + 1, Color(color.r, color.g, color.b, 90))

		render.SetMaterial(glowMaterial)
		render.DrawSprite(top, 90 + math.sin(now * 3) * 12, 90 + math.sin(now * 3) * 12, Color(color.r, color.g, color.b, 200))

		-- буква к камере
		local eye = EyePos()
		local angles = (eye - top):Angle()
		angles = Angle(0, angles.y + 90, 90)

		cam.Start3D2D(top + up * 40, angles, 0.5)
			draw.SimpleText(self:GetLetterText(), "SWSHuge", 2, 2, Color(0, 0, 0, 160), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText(self:GetLetterText(), "SWSHuge", 0, 0, Color(color.r, color.g, color.b, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		cam.End3D2D()
	end
end
