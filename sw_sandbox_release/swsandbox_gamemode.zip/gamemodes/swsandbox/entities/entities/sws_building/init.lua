--[[
	Здание — сервер: постройка, производство с очередью и точкой сбора, захват командных постов, урон.
]]

AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")

local THINK_RATE = 0.25

function ENT:Initialize()
	local info = self:GetInfo()

	if (!info) then
		self:Remove()
		return
	end

	self:SetModel("models/hunter/blocks/cube1x1x1.mdl")
	self:PhysicsInitBox(info.mins, info.maxs)
	self:SetMoveType(MOVETYPE_NONE)
	self:SetSolid(SOLID_VPHYSICS)
	self:EnableCustomCollisions(true)
	self:SetCollisionBounds(info.mins, info.maxs)
	self:DrawShadow(false)

	local physics = self:GetPhysicsObject()

	if (IsValid(physics)) then
		physics:EnableMotion(false)
	end

	self:SetMaxHP(math.max(info.health, 1))
	self:SetHP(math.max(info.health, 1))

	if (self:GetBuiltAt() == 0) then
		self:SetBuiltAt(CurTime() + (self.SWS_Instant and 0 or info.buildTime))
	end

	if (self:GetSide() > 0 and info.id == "command") then
		self:SetProgress(100)
	end

	self.nextThink = 0
	self:EmitSound("ambient/machines/machine1_hit2.wav", 80, 90)
end

-- невидимая мишень VJ: вражеские NPC видят здание и стреляют по нему
function ENT:UpdateBullseye()
	local info = self:GetInfo()
	local faction = SWS.Factions[self:GetSide()]

	if (!faction or info.health <= 0 or !scripted_ents.GetStored("obj_vj_bullseye")) then
		if (IsValid(self.bullseye)) then
			self.bullseye:Remove()
		end

		return
	end

	if (!IsValid(self.bullseye)) then
		local bullseye = ents.Create("obj_vj_bullseye")
		bullseye.SolidMovementType = "Static"
		bullseye:SetModel("models/hunter/plates/plate.mdl")
		-- над крышей: NPC должны видеть мишень, а не упираться взглядом в стену
		bullseye:SetPos(self:GetPos() + Vector(0, 0, info.maxs.z + 16))
		bullseye:Spawn()
		bullseye:SetParent(self)
		bullseye:SetNoDraw(true)
		bullseye.SWS_Building = self

		self.bullseye = bullseye
		self:DeleteOnRemove(bullseye)
	end

	self.bullseye.VJ_NPC_Class = {faction.vjClass}
end

function ENT:Think()
	local now = CurTime()

	self:NextThink(now + THINK_RATE)

	if (now < self.nextThink) then
		return true
	end

	self.nextThink = now + THINK_RATE

	if (!self:IsBuilt()) then
		return true
	end

	if (!self.bBuiltOnce) then
		self.bBuiltOnce = true
		self:EmitSound("buttons/combine_button7.wav", 80, 100)
		self:UpdateBullseye()

		local owner = self:GetCommander()

		if (IsValid(owner)) then
			SWS.Notify(owner, self:GetInfo().name .. " построено.", 0)
		end
	end

	local info = self:GetInfo()

	if (info.id == "command") then
		self:ThinkCapture()
	elseif (info.produces) then
		self:ThinkProduction()
	end

	return true
end

-- ===== захват командного поста =====
function ENT:ThinkCapture()
	local info = self:GetInfo()
	local radius = info.captureRadius
	local position = self:GetPos()
	local counts = {}

	for _, client in ipairs(player.GetAll()) do
		local mode = SWS.GetMode(client)

		if (client:Alive() and mode == SWS.MODE_FREE and client:Team() >= 1 and client:Team() <= #SWS.Factions
			and client:GetPos():DistToSqr(position) < radius * radius) then
			counts[client:Team()] = (counts[client:Team()] or 0) + 1
		end
	end

	for _, npc in ipairs(ents.FindInSphere(position, radius)) do
		local side = npc:IsNPC() and npc:GetNW2Int("SWS_Side", 0) or 0

		if (side > 0 and npc:Health() > 0) then
			counts[side] = (counts[side] or 0) + 1
		end
	end

	local present = table.GetKeys(counts)
	local owner = self:GetSide()
	local progress = self:GetProgress()

	self:SetContested(#present > 1)

	if (#present != 1) then
		return
	end

	local side = present[1]
	local rate = 2.5 * math.min(counts[side], 4) -- за тик 0.25 с: один боец — ~10 с

	if (side == owner) then
		self:SetProgress(math.min(progress + rate, 100))
		self:SetCaptureSide(0)
		return
	end

	if (owner != 0) then
		-- сначала снимаем чужой флаг
		progress = progress - rate

		if (progress <= 0) then
			local oldFaction = SWS.Factions[owner]

			self:SetSide(0)
			self:SetProgress(0)
			self:SetCommander(NULL) -- пост больше не принадлежит строителю
			self:UpdateBullseye()

			SWS.Broadcast(string.format("Пост %s потерян: %s", self:GetLetterText(), oldFaction and oldFaction.short or ""), 1)
		else
			self:SetProgress(progress)
			self:SetCaptureSide(side)
		end

		return
	end

	-- нейтральный: поднимаем свой
	if (self:GetCaptureSide() != side) then
		self:SetCaptureSide(side)
		progress = 0
	end

	progress = progress + rate

	if (progress >= 100) then
		local faction = SWS.Factions[side]

		self:SetSide(side)
		self:SetProgress(100)
		self:SetCaptureSide(0)
		self:SetCommander(NULL)
		self:UpdateBullseye()
		self:EmitSound("buttons/combine_button5.wav", 90, 110)

		SWS.Broadcast(string.format("Пост %s захвачен: %s", self:GetLetterText(), faction.short), 0)
	else
		self:SetProgress(progress)
	end
end

-- ===== производство =====
function ENT:ThinkProduction()
	local queue = SWS.ParseQueue(self:GetQueue())
	local now = CurTime()
	local owner = self:GetCommander()
	local faction = SWS.Factions[self:GetSide()]

	if (#queue == 0 or !IsValid(owner) or !faction) then
		self:SetProdEnd(0)
		self:SetBlocked(false)
		return
	end

	local item = queue[1]
	local unit = SWS.UnitIndex[faction.id] and SWS.UnitIndex[faction.id][item.id]

	local variant = unit and (unit.variants[item.variant] or unit.variants[1])

	-- юнит неизвестен или NPC не установлен — убираем из очереди, чтобы она не застряла
	if (!unit or !scripted_ents.GetStored(variant.class)) then
		table.remove(queue, 1)
		self:SetQueue(SWS.SerializeQueue(queue))
		self:SetProdEnd(0)

		if (unit) then
			SWS.Notify(owner, "NPC «" .. unit.name .. "» не установлен на сервере — снят с очереди.", 2)
		end

		return
	end

	-- ещё не начали: ждём очков войск
	if (self:GetProdEnd() == 0) then
		local limit = SWS.GetPopulationLimit(owner)

		if (SWS.GetPopulation(owner) + unit.size > limit) then
			self:SetBlocked(true)
			return
		end

		self:SetBlocked(false)
		self:SetProdStart(now)
		self:SetProdEnd(now + SWS.GetUnitBuildTime(unit))
		return
	end

	if (now < self:GetProdEnd()) then
		return
	end

	-- готово: выпускаем и отправляем к точке сбора
	local yaw = self:GetAngles().y
	local spawned = SWS.SpawnUnits(owner, faction, unit, item.variant, 1, self:GetExitPos(unit.size), yaw)

	self:SetProdEnd(0)

	if (#spawned == 0) then
		-- выход загорожен: попробуем позже
		self.nextThink = now + 1
		return
	end

	self:EmitSound("doors/doorstop1.wav", 75, 120)

	if (self:GetHasRally()) then
		SWS.OrderGroup(spawned, self:GetRallyAttack() and SWS.ORDER_ATTACK or SWS.ORDER_MOVE, self:GetRally(), true)
	else
		-- без точки сбора — отходят от двери в сторону, освобождая выход
		local offset = self:GetForward() * (90 + unit.size * 20) + self:GetRight() * math.random(-120, 120)
		SWS.OrderGroup(spawned, SWS.ORDER_MOVE, self:GetExitPos(unit.size) + offset, false)
	end

	table.remove(queue, 1)

	if (self:GetRepeat()) then
		queue[#queue + 1] = item
	end

	self:SetQueue(SWS.SerializeQueue(queue))
end

-- ===== урон =====
function ENT:OnTakeDamage(damage)
	local info = self:GetInfo()

	if (!info or info.health <= 0 or self.bDestroyed) then
		return
	end

	local attacker = damage:GetAttacker()
	local side = self:GetSide()

	-- свои не ломают
	if (IsValid(attacker)) then
		if (attacker:IsPlayer() and attacker:Team() == side) then
			return
		end

		if (attacker:IsNPC() and attacker:GetNW2Int("SWS_Side", 0) == side) then
			return
		end
	end

	local hp = self:GetHP() - math.max(damage:GetDamage(), 0)

	self:SetHP(math.max(hp, 0))

	if (hp <= 0) then
		self:Destroy()
	end
end

function ENT:Destroy()
	self.bDestroyed = true

	local position = self:GetPos()
	local info = self:GetInfo()

	for i = 0, 4 do
		timer.Simple(i * 0.15, function()
			local effect = EffectData()
			effect:SetOrigin(position + Vector(math.Rand(-1, 1) * info.maxs.x, math.Rand(-1, 1) * info.maxs.y, math.Rand(0.2, 1) * info.maxs.z))
			util.Effect("Explosion", effect, true, true)
		end)
	end

	local owner = self:GetCommander()

	if (IsValid(owner)) then
		SWS.Notify(owner, info.name .. " уничтожено!", 2)
	end

	self:Remove()
end

-- урон по мишени VJ — зданию
hook.Add("EntityTakeDamage", "SWS_BullseyeDamage", function(target, damage)
	if (target.SWS_Building and IsValid(target.SWS_Building)) then
		target.SWS_Building:TakeDamageInfo(damage)
		return true
	end
end)
