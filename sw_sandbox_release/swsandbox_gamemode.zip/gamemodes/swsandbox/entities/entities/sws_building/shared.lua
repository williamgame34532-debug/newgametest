--[[
	Здание Star Wars Sandbox: командный пост, казарма или завод техники (см. gamemode/sh_buildings.lua).
]]

ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Здание"
ENT.Author = "Star Wars Sandbox"
ENT.Spawnable = false
ENT.RenderGroup = RENDERGROUP_BOTH

function ENT:SetupDataTables()
	self:NetworkVar("String", 0, "BuildingType")
	self:NetworkVar("String", 1, "Queue")

	self:NetworkVar("Int", 0, "Side")
	self:NetworkVar("Int", 1, "CaptureSide")
	self:NetworkVar("Int", 2, "Letter")
	self:NetworkVar("Int", 3, "HP")
	self:NetworkVar("Int", 4, "MaxHP")

	self:NetworkVar("Float", 0, "BuiltAt")
	self:NetworkVar("Float", 1, "ProdStart")
	self:NetworkVar("Float", 2, "ProdEnd")
	self:NetworkVar("Float", 3, "Progress")

	self:NetworkVar("Bool", 0, "Repeat")
	self:NetworkVar("Bool", 1, "Contested")
	self:NetworkVar("Bool", 2, "RallyAttack")
	self:NetworkVar("Bool", 3, "Blocked")
	self:NetworkVar("Bool", 4, "HasRally")

	self:NetworkVar("Vector", 0, "Rally")
	self:NetworkVar("Entity", 0, "Commander")
end

function ENT:GetInfo()
	return SWS.Buildings[self:GetBuildingType()]
end

function ENT:IsBuilt()
	return CurTime() >= self:GetBuiltAt()
end

-- 0..1: насколько достроено
function ENT:GetBuildFraction()
	local info = self:GetInfo()

	if (!info or self:IsBuilt()) then
		return 1
	end

	return math.Clamp(1 - (self:GetBuiltAt() - CurTime()) / info.buildTime, 0, 1)
end

function ENT:GetLetterText()
	local letter = self:GetLetter()

	return letter > 0 and string.char(64 + letter) or "?"
end

-- точка выхода бойцов перед фасадом (крупная техника — дальше от стены)
function ENT:GetExitPos(size)
	local info = self:GetInfo()
	local forward = self:GetForward()

	return self:GetPos() + forward * ((info and info.maxs.x or 100) + 14 * math.max(size or 1, 1) + 40)
end
