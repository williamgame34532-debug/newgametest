
--[[
	Enhanced Helix — loadout
	«Кукла» экипировки во вкладке инвентаря: сверху модель персонажа в рамке,
	под ней — СЕТКА СЛОТОВ с иконками надетых предметов (3D-иконка, подпись
	категории, красный ховер со «СНЯТЬ»), пустые ячейки-заглушки добивают
	сетку до ровных рядов. Клик по слоту — снять предмет (штатный EquipUn).
]]

local PLUGIN = PLUGIN

local function InventoryAction(action, itemID, invID)
	net.Start("ixInventoryAction")
		net.WriteString(action)
		net.WriteUInt(itemID, 32)
		net.WriteUInt(invID, 32)
		net.WriteTable({})
	net.SendToServer()
end

local function GetSlotLabel(item)
	if (item.outfitCategory) then
		return tostring(item.outfitCategory):utf8upper()
	elseif (item.weaponCategory) then
		return tostring(item.weaponCategory):utf8upper()
	elseif (item.isBag) then
		return "СУМКА"
	end

	return "ЭКИП."
end

-- слот экипировки (ячейка)
local PANEL = {}

function PANEL:Init()
	self:SetCursor("hand")
	self:SetMouseInputEnabled(true)

	self.icon = self:Add("SpawnIcon")
	self.icon:Dock(FILL)
	self.icon:DockMargin(3, 12, 3, 3)
	self.icon:SetMouseInputEnabled(false)
	self.icon:SetVisible(false)
end

function PANEL:SetItem(item)
	self.item = item

	if (item) then
		self.label = GetSlotLabel(item)

		self.icon:SetVisible(true)
		self.icon:SetModel(item:GetModel() or "models/props_junk/popcan01a.mdl", item:GetSkin() or 0)

		self:SetHelixTooltip(function(tooltip)
			ix.hud.PopulateItemTooltip(tooltip, item)
		end)
	else
		self.label = nil
		self.icon:SetVisible(false)
		self:SetTooltip(nil)
	end
end

function PANEL:OnMousePressed(code)
	if (code != MOUSE_LEFT or !self.item) then
		return
	end

	local item = self.item
	local info = item.functions and (item.functions.EquipUn or item.functions.Unequip)

	if (info) then
		item.player = LocalPlayer()

		if (!info.OnCanRun or info.OnCanRun(item) != false) then
			if (info.sound) then
				surface.PlaySound(info.sound)
			end

			LocalPlayer():EmitSound("Helix.Press")
			InventoryAction(item.functions.EquipUn and "EquipUn" or "Unequip", item:GetID(), item.invID)
		end

		item.player = nil
	end
end

function PANEL:Paint(width, height)
	local accent = ix.eui.styles.uprising.accent

	-- ячейка как в сетке инвентаря
	surface.SetDrawColor(ix.eui.colors.bg.r, ix.eui.colors.bg.g, ix.eui.colors.bg.b, 185)
	surface.DrawRect(1, 1, width - 2, height - 2)

	if (self.item) then
		if (self:IsHovered()) then
			surface.SetDrawColor(accent.r, accent.g, accent.b, 24)
			surface.DrawRect(1, 1, width - 2, height - 2)

			surface.SetDrawColor(accent.r, accent.g, accent.b, 220)
			surface.DrawOutlinedRect(1, 1, width - 2, height - 2)

			ix.eui.DrawCorners(1, 1, width - 2, height - 2, 6, ColorAlpha(accent, 255))
		else
			surface.SetDrawColor(ix.eui.colors.hairlineBright.r, ix.eui.colors.hairlineBright.g,
				ix.eui.colors.hairlineBright.b, 55)
			surface.DrawOutlinedRect(1, 1, width - 2, height - 2)
		end
	else
		surface.SetDrawColor(ix.eui.colors.hairline.r, ix.eui.colors.hairline.g,
			ix.eui.colors.hairline.b, 30)
		surface.DrawOutlinedRect(1, 1, width - 2, height - 2)

		surface.SetDrawColor(ix.eui.colors.hairline.r, ix.eui.colors.hairline.g,
			ix.eui.colors.hairline.b, 26)
		surface.DrawRect(width * 0.5 - 1, height * 0.5 - 1, 2, 2)
	end
end

function PANEL:PaintOver(width, height)
	if (self.item) then
		draw.SimpleText(self.label or "", "eixMonoSmallFont", 4, 2,
			ColorAlpha(ix.eui.colors.textDim, 220), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

		if (self:IsHovered()) then
			local accent = ix.eui.styles.uprising.accent

			surface.SetDrawColor(0, 0, 0, 170)
			surface.DrawRect(1, height - 16, width - 2, 15)

			draw.SimpleText("СНЯТЬ", "eixMonoSmallFont", width * 0.5, height - 8,
				accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
end

vgui.Register("eixLoadoutSlot", PANEL, "Panel")

-- сама кукла
PANEL = {}

function PANEL:Init()
	self:SetWide(math.max(ScrW() * 0.18, 300))

	self.model = self:Add("ixModelPanel")
	self.model:Dock(TOP)
	self.model:DockMargin(4, 4, 4, 0)
	self.model:SetTall(math.max(ScrH() * 0.3, 300))
	self.model:SetModel(LocalPlayer():GetModel(), LocalPlayer():GetSkin())
	self.model:SetFOV(50)
	self.model.PaintModel = self.model.Paint

	local header = self:Add("DLabel")
	header:Dock(TOP)
	header:DockMargin(8, 8, 8, 4)
	header:SetFont("eixMonoFont")
	header:SetTextColor(ix.eui.colors.textDim)
	header:SetText("// ЭКИПИРОВКА")
	header:SizeToContents()

	self.grid = self:Add("DIconLayout")
	self.grid:Dock(FILL)
	self.grid:DockMargin(8, 0, 8, 8)
	self.grid:SetSpaceX(4)
	self.grid:SetSpaceY(4)

	self.signature = ""
	self.nextThink = 0

	self:Rebuild()
end

function PANEL:GetEquippedItems()
	local character = LocalPlayer().GetCharacter and LocalPlayer():GetCharacter()
	local items = {}

	if (!character) then
		return items
	end

	local inventory = character:GetInventory()

	if (!inventory) then
		return items
	end

	for _, v in pairs(inventory:GetItems()) do
		if (v.GetData and v:GetData("equip", false)) then
			items[#items + 1] = v
		end
	end

	table.sort(items, function(a, b)
		return GetSlotLabel(a) < GetSlotLabel(b)
	end)

	return items
end

function PANEL:Rebuild()
	self.grid:Clear()

	local items = self:GetEquippedItems()
	local signature = ""

	-- размер ячейки: 3 в ряд
	local slotSize = math.floor((self:GetWide() - 16 - 8) / 3)

	-- добиваем пустыми до кратности 3, минимум 6 ячеек
	local total = math.max(6, math.ceil(#items / 3) * 3)

	if (total < #items) then
		total = math.ceil(#items / 3) * 3
	end

	for i = 1, total do
		local item = items[i]
		local slot = self.grid:Add("eixLoadoutSlot")
		slot:SetSize(slotSize, slotSize)
		slot:SetItem(item)

		if (item) then
			signature = signature .. item:GetID() .. ";"
		end
	end

	self.signature = signature
end

function PANEL:Think()
	if (CurTime() < self.nextThink) then
		return
	end

	self.nextThink = CurTime() + 0.75

	-- модель могла смениться (одежда меняет модель/бодигруппы)
	local model = LocalPlayer():GetModel()

	if (self.model:GetModel() != model) then
		self.model:SetModel(model, LocalPlayer():GetSkin())
	end

	local items = self:GetEquippedItems()
	local signature = ""

	for _, v in ipairs(items) do
		signature = signature .. v:GetID() .. ";"
	end

	if (signature != self.signature) then
		self:Rebuild()
	end
end

function PANEL:Paint(width, height)
	surface.SetDrawColor(ix.eui.colors.bg.r, ix.eui.colors.bg.g, ix.eui.colors.bg.b, 120)
	surface.DrawRect(0, 0, width, height)

	surface.SetDrawColor(ix.eui.colors.hairline)
	surface.DrawOutlinedRect(0, 0, width, height)

	ix.eui.DrawCorners(0, 0, width, height, 12)

	-- рамка вокруг модели
	local modelBottom = 4 + self.model:GetTall()

	surface.SetDrawColor(ix.eui.colors.hairline.r, ix.eui.colors.hairline.g,
		ix.eui.colors.hairline.b, 40)
	surface.DrawRect(4, modelBottom, width - 8, 1)
end

vgui.Register("eixLoadout", PANEL, "Panel")

-- встраиваемся во вкладку инвентаря (hook.Add — надёжнее диспатча плагин-хуков)
hook.Add("MenuSubpanelCreated", "eixLoadout", function(name, subpanel)
	if (PLUGIN.BuildLoadout) then
		PLUGIN:BuildLoadout(name, subpanel)
	end
end)

function PLUGIN:BuildLoadout(name, subpanel)
	if (name != "inv") then
		return
	end

	local canvas = ix.gui.menuInventoryContainer

	if (!IsValid(canvas)) then
		return
	end

	if (IsValid(ix.gui.eixLoadout)) then
		ix.gui.eixLoadout:Remove()
	end

	local panel = canvas:Add("eixLoadout")
	panel:SetTall(math.max(ScrH() * 0.58, 560))

	ix.gui.eixLoadout = panel
end
