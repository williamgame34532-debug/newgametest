local PLUGIN = PLUGIN

PLUGIN.name = "Loadout"
PLUGIN.author = "Enhanced Helix"
PLUGIN.description = "Панель экипировки во вкладке инвентаря: модель персонажа и слоты надетых предметов (одежда, оружие) с быстрым снятием — «кукла» в духе district/uprising."
