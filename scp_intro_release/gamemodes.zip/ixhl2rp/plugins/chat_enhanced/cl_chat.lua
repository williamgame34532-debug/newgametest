
local PLUGIN = PLUGIN

--[[
	Сообщения чата Зоны-19:
	- шрифт IBM Plex Sans (обычный и курсив для /me), отметки времени — JetBrains Mono;
	- иконка Tabler слева у каждого сообщения, окрашенная по типу чата;
	- выделение текста мышью по символам, в том числе через несколько сообщений
	  (зажать ЛКМ и тянуть), двойной клик — всё сообщение; выделенное копируется
	  в буфер при отпускании кнопки; ПКМ — меню копирования.
]]

ix.option.Add("chatIcons", ix.type.bool, true, {
	category = "chat"
})

-- цвет иконки по типу чата
PLUGIN.iconColors = {
	ic = Color(236, 236, 232),
	w = Color(150, 152, 156),
	y = Color(255, 150, 40),
	me = Color(255, 196, 37),
	it = Color(140, 190, 230),
	ooc = Color(110, 160, 230),
	looc = Color(90, 200, 200),
	pm = Color(230, 120, 190),
	radio = Color(110, 200, 110),
	radio_eavesdrop = Color(110, 200, 110),
	rad = Color(120, 220, 170),
	dispatch = Color(110, 170, 255),
	event = Color(214, 48, 48),
	broadcast = Color(255, 196, 37),
	roll = Color(170, 130, 230),
	connect = Color(90, 190, 110),
	disconnect = Color(214, 48, 48),
	notice = Color(255, 196, 37),
	request = Color(255, 150, 40),
	request_eavesdrop = Color(255, 150, 40),
	myclass = Color(236, 236, 232)
}

local iconMaterials = {}

local function GetChatIcon(class)
	class = tostring(class or "default")

	if (iconMaterials[class] == nil) then
		local material = Material("scp_ui/chat/" .. class .. ".png", "smooth mips")

		if (material:IsError()) then
			material = Material("scp_ui/chat/default.png", "smooth mips")
		end

		iconMaterials[class] = material
	end

	return iconMaterials[class]
end

-- шрифты сообщений: пересоздаём после GM:LoadFonts, иначе он перезапишет ixChatFont
local function CreateChatFonts()
	local scale = ix.option.Get("chatFontScale", 1)
	local size = math.max(ScreenScale(6.6), 16) * scale

	surface.CreateFont("ixChatFont", {
		font = "IBM Plex Sans",
		size = size,
		weight = 500,
		extended = true,
		antialias = true
	})

	surface.CreateFont("ixChatFontItalics", {
		font = "IBM Plex Sans",
		size = size,
		weight = 500,
		italic = true,
		extended = true,
		antialias = true
	})

	surface.CreateFont("z19ChatBold", {
		font = "IBM Plex Sans SmBld",
		size = size,
		weight = 600,
		extended = true,
		antialias = true
	})

	surface.CreateFont("z19ChatToast", {
		font = "JetBrains Mono",
		size = math.max(ScreenScale(4.6), 12),
		weight = 700,
		extended = true
	})
end

hook.Add("LoadFonts", "z19ChatFonts", function()
	timer.Simple(0, CreateChatFonts)
end)

-- выделение текста
local selection = {
	anchor = nil, -- {panel = ixChatMessage, index = число}
	focus = nil,
	bDragging = false,
	copiedAt = 0
}

PLUGIN.selection = selection

local function GetEntries()
	local chat = ix.gui.chat
	local tab = IsValid(chat) and chat.tabs and chat.tabs:GetActiveTab()

	return tab and tab.entries or {}
end

local function GetOrder(panel)
	for i, entry in ipairs(GetEntries()) do
		if (entry == panel) then
			return i
		end
	end

	return 0
end

local function ClearSelection()
	selection.anchor = nil
	selection.focus = nil
	selection.bDragging = false
end

-- начало и конец выделения в порядке сообщений
local function GetOrderedSelection()
	local a, b = selection.anchor, selection.focus

	if (!a or !b or !IsValid(a.panel) or !IsValid(b.panel)) then
		return
	end

	local orderA, orderB = GetOrder(a.panel), GetOrder(b.panel)

	if (orderA > orderB or (orderA == orderB and a.index > b.index)) then
		a, b = b, a
		orderA, orderB = orderB, orderA
	end

	return a, b, orderA, orderB
end

-- диапазон выделенных символов внутри одного сообщения [from, to)
local function GetPanelRange(panel)
	local first, last, orderFirst, orderLast = GetOrderedSelection()

	if (!first) then
		return
	end

	local order = GetOrder(panel)

	if (order < orderFirst or order > orderLast) then
		return
	end

	local from = (order == orderFirst) and first.index or 0
	local to = (order == orderLast) and last.index or panel.z19Length or 0

	if (to <= from) then
		return
	end

	return from, to
end

local function HasSelection()
	local first, last = GetOrderedSelection()

	return first and (first.panel != last.panel or first.index != last.index)
end

-- индекс текста сообщения: текстовые блоки разметки по порядку
local function BuildIndex(panel)
	local blocks = {}
	local length = 0

	if (panel.markup and panel.markup.blocks) then
		for _, block in ipairs(panel.markup.blocks) do
			if (block.text and !block.texture) then
				local count = block.text:utf8len()

				blocks[#blocks + 1] = {block = block, from = length, count = count}
				length = length + count
			end
		end
	end

	panel.z19Blocks = blocks
	panel.z19Length = length
end

-- размер иконки и отступ текста под неё
local function GetIconSize()
	surface.SetFont("ixChatFont")
	local _, height = surface.GetTextSize("Wj")

	return math.floor(height * 0.9)
end

local function GetInset()
	return ix.option.Get("chatIcons", true) and (GetIconSize() + 6) or 0
end

local function TextWidth(font, text)
	surface.SetFont(font)
	return (surface.GetTextSize(text))
end

-- какой символ под точкой (координаты внутри текста сообщения)
local function HitTest(panel, x, y)
	local blocks = panel.z19Blocks or {}

	if (#blocks == 0) then
		return 0
	end

	if (y < 0) then
		return 0
	end

	-- блоки строки, на которую указывает курсор (или последней строки)
	local row = {}
	local bestY

	for _, info in ipairs(blocks) do
		local block = info.block
		local top = block.offset.y
		local bottom = top + (block.height or 0)

		if (y >= top and y < bottom) then
			row[#row + 1] = info
		end

		if (!bestY or top > bestY) then
			bestY = top
		end
	end

	if (#row == 0) then
		return panel.z19Length or 0
	end

	for _, info in ipairs(row) do
		local block = info.block
		local left = block.offset.x

		if (x < left) then
			return info.from
		end

		local width = TextWidth(block.font, block.text)

		if (x <= left + width) then
			local previous = 0

			for i = 1, info.count do
				local current = TextWidth(block.font, block.text:utf8sub(1, i))

				if (x - left < (previous + current) * 0.5) then
					return info.from + i - 1
				end

				previous = current
			end

			return info.from + info.count
		end
	end

	local lastInfo = row[#row]
	return lastInfo.from + lastInfo.count
end

-- текст сообщения в диапазоне символов
local function GetPanelText(panel, from, to)
	local parts = {}
	local lastY

	from = from or 0
	to = to or panel.z19Length or 0

	for _, info in ipairs(panel.z19Blocks or {}) do
		local blockFrom = math.max(from, info.from)
		local blockTo = math.min(to, info.from + info.count)

		if (blockTo > blockFrom) then
			-- перенос строки внутри сообщения — пробел
			if (lastY and info.block.offset.y > lastY) then
				parts[#parts + 1] = " "
			end

			parts[#parts + 1] = info.block.text:utf8sub(blockFrom - info.from + 1, blockTo - info.from)
			lastY = info.block.offset.y
		end
	end

	return table.concat(parts)
end

local function GetSelectedText()
	local first, last, orderFirst, orderLast = GetOrderedSelection()

	if (!first) then
		return ""
	end

	local lines = {}
	local entries = GetEntries()

	for order = orderFirst, orderLast do
		local panel = entries[order]

		if (IsValid(panel)) then
			local from, to = GetPanelRange(panel)

			if (from) then
				lines[#lines + 1] = GetPanelText(panel, from, to)
			end
		end
	end

	return table.concat(lines, "\n")
end

local function CopyText(text)
	if (text and text != "") then
		SetClipboardText(text)
		selection.copiedAt = RealTime()

		if (ix.z19) then
			ix.z19.PlayUI("click")
		end
	end
end

-- патчим сообщения и чатбокс после загрузки плагина chatbox
local function PatchChat()
	local message = vgui.GetControlTable("ixChatMessage")
	local chatbox = vgui.GetControlTable("ixChatbox")

	if (!message or message.z19Patched) then
		return
	end

	message.z19Patched = true

	local function Reparse(panel, width)
		local drawText = panel.markup and panel.markup.onDrawText

		panel.markup = ix.markup.Parse(panel.text, math.max(width - GetInset(), 32))
		panel.markup.onDrawText = drawText
		panel.z19Width = width

		panel:SetTall(math.max(panel.markup:GetHeight(), GetIconSize()))
		BuildIndex(panel)
	end

	local oldSetMarkup = message.SetMarkup

	function message:SetMarkup(text)
		local class = CHAT_CLASS

		self.z19Class = class and class.uniqueID or "notice"
		self:SetCursor("beam")

		oldSetMarkup(self, text)
		Reparse(self, self:GetWide())
	end

	function message:PerformLayout(width, height)
		if (!self.markup or (IsValid(ix.gui.chat) and ix.gui.chat.bSizing) or self.z19Width == width) then
			return
		end

		Reparse(self, width)
	end

	function message:Paint(width, height)
		local newAlpha

		-- как в оригинале: прячем чат под важными меню
		if (IsValid(ix.gui.characterMenu)) then
			newAlpha = math.min(255 - ix.gui.characterMenu.currentAlpha, self.alpha)
		elseif (IsValid(ix.gui.menu)) then
			newAlpha = math.min(255 - ix.gui.menu.currentAlpha, self.alpha)
		elseif (ix.gui.chat:GetActive()) then
			newAlpha = math.max(ix.gui.chat.alpha, self.alpha)
		else
			newAlpha = self.alpha
		end

		if (newAlpha < 1) then
			return
		end

		local inset = GetInset()

		-- подсветка выделенного текста
		local from, to = GetPanelRange(self)

		if (from) then
			local accent = ix.eui.colors.accent

			surface.SetDrawColor(accent.r, accent.g, accent.b, 110 * (newAlpha / 255))

			for _, info in ipairs(self.z19Blocks or {}) do
				local blockFrom = math.max(from, info.from)
				local blockTo = math.min(to, info.from + info.count)

				if (blockTo > blockFrom) then
					local block = info.block
					local prefix = block.text:utf8sub(1, blockFrom - info.from)
					local selected = block.text:utf8sub(blockFrom - info.from + 1, blockTo - info.from)
					local x = inset + block.offset.x + TextWidth(block.font, prefix)

					surface.DrawRect(x, block.offset.y, TextWidth(block.font, selected), block.height or height)
				end
			end
		end

		-- иконка типа сообщения
		if (inset > 0) then
			local size = GetIconSize()
			local color = PLUGIN.iconColors[self.z19Class] or ix.eui.colors.text

			surface.SetMaterial(GetChatIcon(self.z19Class))
			surface.SetDrawColor(0, 0, 0, newAlpha * 0.8)
			surface.DrawTexturedRect(1, 2, size, size)
			surface.SetDrawColor(color.r, color.g, color.b, newAlpha)
			surface.DrawTexturedRect(0, 1, size, size)
		end

		self.markup:draw(inset, 0, nil, nil, newAlpha)
	end

	-- мышь: выделение и меню копирования (только когда чат открыт)
	local function ChatOpen()
		return IsValid(ix.gui.chat) and ix.gui.chat:GetActive()
	end

	local function LocalTextPos(panel)
		local x, y = panel:CursorPos()
		return x - GetInset(), y
	end

	function message:OnMousePressed(code)
		if (!ChatOpen()) then
			return
		end

		if (code == MOUSE_LEFT) then
			local x, y = LocalTextPos(self)
			local index = HitTest(self, x, y)

			selection.anchor = {panel = self, index = index}
			selection.focus = {panel = self, index = index}
			selection.bDragging = true

			self:MouseCapture(true)
		elseif (code == MOUSE_RIGHT) then
			local menu = DermaMenu()

			if (HasSelection()) then
				menu:AddOption("Копировать выделенное", function()
					CopyText(GetSelectedText())
				end):SetImage("icon16/page_copy.png")
			end

			menu:AddOption("Копировать сообщение", function()
				CopyText(GetPanelText(self))
			end):SetImage("icon16/page_white_copy.png")

			menu:AddOption("Копировать всю вкладку", function()
				local lines = {}

				for _, entry in ipairs(GetEntries()) do
					if (IsValid(entry)) then
						lines[#lines + 1] = GetPanelText(entry)
					end
				end

				CopyText(table.concat(lines, "\n"))
			end):SetImage("icon16/page_white_stack.png")

			menu:Open()
			menu:MakePopup()
		end
	end

	function message:OnMouseReleased(code)
		if (code != MOUSE_LEFT or !selection.bDragging) then
			return
		end

		selection.bDragging = false
		self:MouseCapture(false)

		if (HasSelection()) then
			CopyText(GetSelectedText())
		end

		-- вернуть фокус в поле ввода, чтобы можно было сразу печатать
		if (IsValid(ix.gui.chat) and IsValid(ix.gui.chat.entry)) then
			ix.gui.chat.entry:RequestFocus()
		end
	end

	function message:OnMouseDoublePressed(code)
		if (!ChatOpen() or code != MOUSE_LEFT) then
			return
		end

		selection.anchor = {panel = self, index = 0}
		selection.focus = {panel = self, index = self.z19Length or 0}
		selection.bDragging = false

		CopyText(GetPanelText(self))
	end

	-- плашка «скопировано» над полем ввода
	if (chatbox and !chatbox.z19Patched) then
		chatbox.z19Patched = true

		local oldPaintOver = chatbox.PaintOver

		function chatbox:PaintOver(width, height)
			if (oldPaintOver) then
				oldPaintOver(self, width, height)
			end

			local elapsed = RealTime() - selection.copiedAt

			if (elapsed < 1.6 and self:GetActive()) then
				local alpha = 255 * math.Clamp((1.6 - elapsed) / 0.4, 0, 1)
				local text = "СКОПИРОВАНО В БУФЕР"

				surface.SetFont("z19ChatToast")
				local textW, textH = surface.GetTextSize(text)
				local x, y = width - textW - 18, 6

				surface.SetDrawColor(ix.eui.colors.accent.r, ix.eui.colors.accent.g, ix.eui.colors.accent.b, alpha)
				surface.DrawRect(x - 6, y, textW + 12, textH + 4)

				draw.SimpleText(text, "z19ChatToast", x, y + 2, Color(18, 18, 20, alpha))
			end
		end
	end
end

hook.Add("InitializedPlugins", "z19ChatPatch", PatchChat)

-- перетаскивание выделения: ищем сообщение под курсором во вкладке
function PLUGIN:Think()
	if (!selection.anchor) then
		return
	end

	local chat = ix.gui.chat

	-- чат закрыли или вкладку сменили — снимаем выделение
	if (!IsValid(chat) or !chat:GetActive() or !IsValid(selection.anchor.panel)
		or GetOrder(selection.anchor.panel) == 0) then
		ClearSelection()
		return
	end

	if (!selection.bDragging) then
		return
	end

	if (!input.IsMouseDown(MOUSE_LEFT)) then
		selection.bDragging = false
		return
	end

	local mouseX, mouseY = gui.MousePos()
	local entries = GetEntries()
	local target, targetY
	local bestDistance = math.huge

	for _, entry in ipairs(entries) do
		if (IsValid(entry) and entry:IsVisible()) then
			local _, entryY = entry:LocalToScreen(0, 0)
			local distance = 0

			if (mouseY < entryY) then
				distance = entryY - mouseY
			elseif (mouseY > entryY + entry:GetTall()) then
				distance = mouseY - (entryY + entry:GetTall())
			end

			if (distance < bestDistance) then
				bestDistance = distance
				target = entry
				targetY = entryY
			end
		end
	end

	if (IsValid(target)) then
		local entryX = target:LocalToScreen(0, 0)

		selection.focus = {
			panel = target,
			index = HitTest(target, mouseX - entryX - GetInset(), mouseY - targetY)
		}
	end
end
