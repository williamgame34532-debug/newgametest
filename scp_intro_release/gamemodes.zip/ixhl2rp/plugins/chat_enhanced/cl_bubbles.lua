
local PLUGIN = PLUGIN

--[[
	Текст сообщения над головой игрока (кроме OOC, LOOC и ЛС — см. PLUGIN.noBubble).
	Видят только те, кому сообщение пришло (дальность чата учитывается сервером).
	До трёх последних сообщений столбиком, плавное появление и исчезновение.
]]

ix.option.Add("chatBubbles", ix.type.bool, true, {
	category = "chat"
})

local MAX_BUBBLES = 3
local MAX_DISTANCE = 700
local SCALE = 0.075
local MAX_WIDTH = 560

local bubbles = {}

local function CreateFonts()
	surface.CreateFont("z19BubbleFont", {
		font = "IBM Plex Sans",
		size = 34,
		weight = 500,
		extended = true,
		antialias = true
	})

	surface.CreateFont("z19BubbleItalic", {
		font = "IBM Plex Sans",
		size = 34,
		weight = 500,
		italic = true,
		extended = true,
		antialias = true
	})
end

CreateFonts()
hook.Add("LoadFonts", "z19BubbleFonts", CreateFonts)

-- перенос строк по ширине
local function WrapText(text, font, maxWidth)
	surface.SetFont(font)

	local lines = {}
	local line = ""

	for word in text:gmatch("%S+") do
		local candidate = line == "" and word or (line .. " " .. word)

		if (surface.GetTextSize(candidate) > maxWidth and line != "") then
			lines[#lines + 1] = line
			line = word
		else
			line = candidate
		end

		if (#lines >= 4) then
			break
		end
	end

	if (line != "" and #lines < 4) then
		lines[#lines + 1] = line
	elseif (#lines >= 4) then
		lines[4] = lines[4] .. "…"
	end

	return lines
end

function PLUGIN:MessageReceived(client, info)
	if (!IsValid(client) or !client:IsPlayer() or info.anonymous or self.noBubble[info.chatType]) then
		return
	end

	local text = string.Trim(tostring(info.text or ""))

	if (text == "") then
		return
	end

	local bItalic = info.chatType == "me" or info.chatType == "it"
	local font = bItalic and "z19BubbleItalic" or "z19BubbleFont"

	if (info.chatType == "me") then
		text = "* " .. text
	end

	local list = bubbles[client] or {}
	bubbles[client] = list

	list[#list + 1] = {
		lines = WrapText(text, font, MAX_WIDTH),
		font = font,
		class = info.chatType,
		start = RealTime(),
		duration = math.Clamp(4 + text:utf8len() / 14, 4, 12)
	}

	while (#list > MAX_BUBBLES) do
		table.remove(list, 1)
	end
end

local function GetHeadPosition(client)
	local bone = client:LookupBone("ValveBiped.Bip01_Head1")

	if (bone) then
		local position = client:GetBonePosition(bone)

		if (position) then
			return position + Vector(0, 0, 14)
		end
	end

	return client:EyePos() + Vector(0, 0, 12)
end

local iconMaterials = {}

local function GetIcon(class)
	if (iconMaterials[class] == nil) then
		local material = Material("scp_ui/chat/" .. tostring(class) .. ".png", "smooth mips")

		iconMaterials[class] = material:IsError() and Material("scp_ui/chat/default.png", "smooth mips") or material
	end

	return iconMaterials[class]
end

local function DrawBubble(bubble, y, alpha)
	surface.SetFont(bubble.font)

	local lineHeight = select(2, surface.GetTextSize("Wj"))
	local textWidth = 0

	for _, line in ipairs(bubble.lines) do
		textWidth = math.max(textWidth, (surface.GetTextSize(line)))
	end

	local iconSize = lineHeight
	local padding = 14
	local width = textWidth + iconSize + padding * 3
	local height = #bubble.lines * lineHeight + padding * 1.4
	local x = -width * 0.5
	local top = y - height

	local color = PLUGIN.iconColors and PLUGIN.iconColors[bubble.class] or ix.eui.colors.accent
	local eui = ix.eui

	surface.SetDrawColor(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, 215 * alpha)
	surface.DrawRect(x, top, width, height)

	surface.SetDrawColor(color.r, color.g, color.b, 255 * alpha)
	surface.DrawRect(x, top, 4, height)

	surface.SetMaterial(GetIcon(bubble.class))
	surface.SetDrawColor(color.r, color.g, color.b, 255 * alpha)
	surface.DrawTexturedRect(x + padding, top + padding * 0.7, iconSize, iconSize)

	for i, line in ipairs(bubble.lines) do
		draw.SimpleText(line, bubble.font, x + padding * 2 + iconSize, top + padding * 0.7 + (i - 1) * lineHeight,
			Color(eui.colors.text.r, eui.colors.text.g, eui.colors.text.b, 255 * alpha))
	end

	return height
end

function PLUGIN:PostDrawTranslucentRenderables(bDepth, bSkybox)
	if (bSkybox or !ix.option.Get("chatBubbles", true) or table.IsEmpty(bubbles)) then
		return
	end

	local localPlayer = LocalPlayer()
	local eyePos = EyePos()
	local now = RealTime()

	for client, list in pairs(bubbles) do
		if (!IsValid(client) or !client:Alive()) then
			bubbles[client] = nil
			continue
		end

		-- свои сообщения над собой — только в виде от третьего лица
		if (client == localPlayer and !client:ShouldDrawLocalPlayer()) then
			continue
		end

		local position = GetHeadPosition(client)

		if (position:DistToSqr(eyePos) > MAX_DISTANCE * MAX_DISTANCE or client:GetNoDraw()) then
			continue
		end

		local angles = (position - eyePos):Angle()
		angles = Angle(0, angles.y - 90, 90)

		cam.Start3D2D(position, angles, SCALE)
			local y = 0

			for i = #list, 1, -1 do
				local bubble = list[i]
				local age = now - bubble.start

				if (age > bubble.duration) then
					table.remove(list, i)
				else
					local alpha = math.Clamp(age / 0.25, 0, 1) * math.Clamp((bubble.duration - age) / 0.6, 0, 1)
					local rise = (1 - math.Clamp(age / 0.25, 0, 1)) * 20

					y = y - DrawBubble(bubble, y + rise, alpha) - 8
				end
			end
		cam.End3D2D()

		if (#list == 0) then
			bubbles[client] = nil
		end
	end
end
