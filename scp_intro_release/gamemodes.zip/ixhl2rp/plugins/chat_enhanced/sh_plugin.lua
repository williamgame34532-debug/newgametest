local PLUGIN = PLUGIN

PLUGIN.name = "Enhanced Chat (Зона-19)"
PLUGIN.author = "Enhanced Helix"
PLUGIN.description = "Сообщения чата в стиле Зоны-19: иконка у каждого типа сообщения, шрифт IBM Plex Sans, " ..
	"свободное выделение и копирование текста мышью, текст сообщения над головой игрока " ..
	"(кроме OOC, LOOC и ЛС), общая рация /rad."

-- типы чата, которые не показываются над головой
PLUGIN.noBubble = {
	ooc = true,
	looc = true,
	pm = true,
	connect = true,
	disconnect = true,
	notice = true,
	event = true,
	broadcast = true,
	dispatch = true
}

-- общая рация: /rad — слышат все игроки на сервере
ix.chat.Register("rad", {
	format = "[РАЦИЯ] %s: «%s»",
	color = Color(120, 220, 170),
	indicator = "chatRadioing",
	prefix = {"/rad", "/рация"},
	description = "Сообщение по общей рации — слышат все игроки",
	deadCanChat = false,
	CanHear = function(self, speaker, listener)
		return true
	end,
	OnChatAdd = function(self, speaker, text)
		local name = IsValid(speaker) and speaker:GetName() or "???"

		chat.AddText(self.color, string.format(self.format, name, text))
	end
})

if (CLIENT) then
	ix.lang.AddTable("russian", {
		chatRadioing = "Говорит по рации...",
		optChatIcons = "Иконки сообщений",
		optdChatIcons = "Показывать иконку типа сообщения слева от текста в чате.",
		optChatBubbles = "Текст над головой",
		optdChatBubbles = "Показывать текст сообщений над головами игроков (кроме OOC, LOOC и ЛС)."
	})

	ix.lang.AddTable("english", {
		chatRadioing = "Radioing...",
		optChatIcons = "Chat icons",
		optdChatIcons = "Show a chat type icon to the left of each message.",
		optChatBubbles = "Chat bubbles",
		optdChatBubbles = "Show messages above players' heads (except OOC, LOOC and PM)."
	})
end

ix.util.Include("cl_chat.lua")
ix.util.Include("cl_bubbles.lua")
