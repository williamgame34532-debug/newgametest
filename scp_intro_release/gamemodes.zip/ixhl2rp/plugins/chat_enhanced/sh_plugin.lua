local PLUGIN = PLUGIN

PLUGIN.name = "Enhanced Chat"
PLUGIN.author = "Enhanced Helix"
PLUGIN.description = "Улучшение сообщений чата: иконки icon16 по типу сообщения, чистый режим без фона у свёрнутого чата (фон рисуется только при активном вводе), опции в настройках."

if (CLIENT) then
	-- иконки по классам чата (пути icon16 из стандартной поставки GMod)
	PLUGIN.icons = {
		ic = "icon16/user_comment.png",
		w = "icon16/user_gray.png",
		whisper = "icon16/user_gray.png",
		y = "icon16/sound.png",
		yell = "icon16/sound.png",
		me = "icon16/status_online.png",
		it = "icon16/information.png",
		ooc = "icon16/world.png",
		looc = "icon16/comments.png",
		pm = "icon16/email.png",
		radio = "icon16/transmit.png",
		radio_yell = "icon16/transmit_add.png",
		radio_whisper = "icon16/transmit_blue.png",
		dispatch = "icon16/shield.png",
		event = "icon16/star.png",
		broadcast = "icon16/bell.png",
		roll = "icon16/bricks.png",
		connect = "icon16/user_add.png",
		disconnect = "icon16/user_delete.png",
		notice = "icon16/information.png"
	}

	-- кэш материалов
	local materials = {}

	local function GetIcon(class)
		local path = PLUGIN.icons[class]

		if (!path) then
			return
		end

		materials[path] = materials[path] or Material(path)
		return materials[path]
	end

	ix.option.Add("chatIcons", ix.type.bool, true, {
		category = "chat"
	})

	-- оборачиваем добавление сообщений: подставляем иконку класса первым сегментом.
	-- ixChatbox:AddLine нативно понимает IMaterial и превратит её в <img> в markup.
	hook.Add("InitializedPlugins", "eixChatEnhanced", function()
		local chatbox = vgui.GetControlTable("ixChatbox")

		if (!chatbox or chatbox.eixIconsPatched) then
			return
		end

		chatbox.eixIconsPatched = true

		local oldAddMessage = chatbox.AddMessage

		function chatbox:AddMessage(...)
			if (ix.option.Get("chatIcons", true)) then
				local class = CHAT_CLASS and CHAT_CLASS.uniqueID
				local icon = GetIcon(class)

				if (icon and !icon:IsError()) then
					return oldAddMessage(self, icon, ...)
				end
			end

			return oldAddMessage(self, ...)
		end
	end)
end
