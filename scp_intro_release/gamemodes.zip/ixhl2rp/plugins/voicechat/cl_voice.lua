
local PLUGIN = PLUGIN

--[[
	Голосовой чат «Зона-19» (клиент):
	- справа внизу карточки говорящих: аватар Steam с кольцом громкости, имя персонажа,
	  режим (шёпот / голос / крик / рация), расстояние и живая волна голоса;
	- над головой говорящего — значок микрофона или рации с расходящимися кольцами;
	- во время разговора колёсико мыши меняет дальность голоса (или команда z19_voicemode),
	  при смене — плашка с режимом снизу по центру;
	- у рации щелчки начала и конца передачи (SCP: Containment Breach).
	Стандартные панели голоса GMod отключены.
]]

ix.option.Add("voiceMode", ix.type.array, PLUGIN.defaultMode, {
	category = "voice",
	populate = function()
		local entries = {}

		for index, mode in ipairs(PLUGIN.modes) do
			entries[index] = mode.bRadio and (mode.name .. " (слышат все)")
				or string.format("%s (%d%%)", mode.name, math.Round(mode.range * 100))
		end

		return entries
	end,
	OnChanged = function(oldValue, value)
		PLUGIN:SendMode(value)
	end
})

ix.option.Add("voiceHUD", ix.type.bool, true, {
	category = "voice"
})

ix.option.Add("voiceIcons", ix.type.bool, true, {
	category = "voice"
})

local function CreateFonts()
	local function font(name, face, size, weight, minimum)
		surface.CreateFont(name, {
			font = face,
			size = math.max(math.Round(ScreenScale(size)), minimum or 12),
			weight = weight,
			extended = true,
			antialias = true
		})
	end

	font("z19VoiceName", "Zone19 Sans Bold", 7, 700, 16)
	font("z19VoiceMode", "JetBrains Mono", 4.4, 700, 11)
	font("z19VoiceToast", "Zone19 Sans Bold", 8, 700, 18)
end

CreateFonts()
hook.Add("LoadFonts", "z19VoiceFonts", CreateFonts)

local icons = {}

local function GetIcon(name)
	if (!icons[name]) then
		icons[name] = Material("scp_ui/voice/" .. name .. ".png", "smooth mips")
	end

	return icons[name]
end

local HISTORY = 28

PLUGIN.speakers = PLUGIN.speakers or {}

-- режим локального игрока: из настройки, рацию сервер мог выключить
function PLUGIN:SendMode(index)
	index = tonumber(index) or self.defaultMode

	if (!self.modes[index]) then
		return
	end

	net.Start("z19VoiceMode")
		net.WriteUInt(index, 3)
	net.SendToServer()
end

function PLUGIN:CycleMode(direction)
	local index = tonumber(ix.option.Get("voiceMode", self.defaultMode)) or self.defaultMode
	local count = #self.modes

	for _ = 1, count do
		index = (index - 1 + direction) % count + 1

		if (!self.modes[index].bRadio or ix.config.Get("voiceRadio", true)) then
			break
		end
	end

	ix.option.Set("voiceMode", index)

	self.toast = {mode = index, start = RealTime()}
	surface.PlaySound("scp_voice/mode.ogg")
end

concommand.Add("z19_voicemode", function(client, command, arguments)
	local index = tonumber(arguments[1] or "")

	if (index and PLUGIN.modes[index]) then
		ix.option.Set("voiceMode", index)
		PLUGIN.toast = {mode = index, start = RealTime()}
		surface.PlaySound("scp_voice/mode.ogg")
	else
		PLUGIN:CycleMode(1)
	end
end)

-- сервер должен знать режим после входа и смены персонажа
function PLUGIN:CharacterLoaded()
	timer.Simple(0.5, function()
		self:SendMode(ix.option.Get("voiceMode", self.defaultMode))
	end)
end

function PLUGIN:InitPostEntity()
	timer.Simple(2, function()
		self:SendMode(ix.option.Get("voiceMode", self.defaultMode))
	end)
end

-- колёсико во время разговора меняет дальность (раньше выбора оружия)
local function HandleVoiceBind(bind, bPressed)
	if (!bPressed or !PLUGIN.bLocalSpeaking) then
		return
	end

	bind = bind:lower()

	if (bind:find("invnext", 1, true)) then
		PLUGIN:CycleMode(1)
		return true
	elseif (bind:find("invprev", 1, true)) then
		PLUGIN:CycleMode(-1)
		return true
	end
end

function PLUGIN:PlayerBindPress(client, bind, bPressed)
	return HandleVoiceBind(bind, bPressed)
end

-- выбор оружия (wepselect) тоже слушает колёсико: ставим нашу проверку перед ним,
-- порядок вызова хуков плагинов Helix не определён
local wrappedBinds = setmetatable({}, {__mode = "k"})

function PLUGIN:InitializedPlugins()
	local cache = HOOKS_CACHE and HOOKS_CACHE["PlayerBindPress"]

	if (!cache) then
		return
	end

	for plugin, callback in pairs(cache) do
		if (plugin != self and !wrappedBinds[callback]) then
			local wrapped = function(this, client, bind, bPressed)
				if (HandleVoiceBind(bind, bPressed)) then
					return true
				end

				return callback(this, client, bind, bPressed)
			end

			wrappedBinds[wrapped] = true
			cache[plugin] = wrapped
		end
	end
end

-- стандартные панели голоса GMod не нужны
function PLUGIN:PlayerStartVoice(client)
	if (!IsValid(client)) then
		return true
	end

	local data = self.speakers[client] or {}

	data.start = RealTime()
	data.ended = nil
	data.history = data.history or {}
	data.alpha = data.alpha or 0
	data.mode = select(2, self:GetMode(client))

	self.speakers[client] = data

	if (client == LocalPlayer()) then
		self.bLocalSpeaking = true
	end

	if (self:GetMode(client).bRadio) then
		surface.PlaySound("scp_voice/radio_on.ogg")
	end

	return true
end

function PLUGIN:PlayerEndVoice(client)
	if (!IsValid(client)) then
		return true
	end

	local data = self.speakers[client]

	if (data and !data.ended) then
		data.ended = RealTime()

		if (self.modes[data.mode] and self.modes[data.mode].bRadio) then
			surface.PlaySound("scp_voice/radio_off.ogg")
		end
	end

	if (client == LocalPlayer()) then
		self.bLocalSpeaking = false
	end

	return true
end

-- аватары — панели, рисуются вручную внутри карточек
local function GetAvatar(data, client)
	if (!IsValid(data.avatar)) then
		data.avatar = vgui.Create("AvatarImage")
		data.avatar:SetPaintedManually(true)
		data.avatar:SetPlayer(client, 64)
	end

	return data.avatar
end

local function GetSpeakerName(client)
	if (client == LocalPlayer()) then
		local character = client:GetCharacter()

		return character and character:GetName() or client:Name()
	end

	return hook.Run("GetCharacterName", client, "ic") or client:Name()
end

function PLUGIN:Think()
	local now = RealTime()

	for client, data in pairs(self.speakers) do
		if (!IsValid(client)) then
			if (IsValid(data.avatar)) then
				data.avatar:Remove()
			end

			self.speakers[client] = nil
			continue
		end

		-- волна голоса: история громкости
		if ((data.nextSample or 0) < now) then
			data.nextSample = now + 0.04

			table.insert(data.history, 1, data.ended and 0 or client:VoiceVolume())
			data.history[HISTORY + 1] = nil
		end

		data.mode = select(2, self:GetMode(client))
		data.alpha = math.Approach(data.alpha, data.ended and 0 or 1, FrameTime() * (data.ended and 3 or 6))

		if (data.ended and data.alpha <= 0) then
			if (IsValid(data.avatar)) then
				data.avatar:Remove()
			end

			self.speakers[client] = nil
		end
	end
end

-- обрезать строку под ширину с многоточием
local function FitText(text, font, maxWidth)
	surface.SetFont(font)

	if (surface.GetTextSize(text) <= maxWidth) then
		return text
	end

	local length = utf8.len(text) or #text

	while (length > 1) do
		length = length - 1

		local result = text:utf8sub(1, length) .. "…"

		if (surface.GetTextSize(result) <= maxWidth) then
			return result
		end
	end

	return text
end

local function DrawWave(history, x, y, width, height, color, alpha)
	local count = #history
	local gap = 2
	local barW = math.max((width - gap * (HISTORY - 1)) / HISTORY, 1)

	for i = 1, HISTORY do
		local value = history[i] or 0
		local barH = math.max(height * math.min(value * 2.2, 1), 2)
		local barX = x + width - i * (barW + gap) + gap

		surface.SetDrawColor(color.r, color.g, color.b, alpha * (i <= count and 1 or 0.3) * (1 - (i - 1) / HISTORY * 0.6))
		surface.DrawRect(barX, y + height * 0.5 - barH * 0.5, barW, barH)
	end
end

function PLUGIN:PaintSpeaker(client, data, x, y, width, height)
	local eui = ix.eui
	local mode = self.modes[data.mode] or self.modes[self.defaultMode]
	local color = mode.color
	local alpha = data.alpha * 255
	local volume = data.ended and 0 or client:VoiceVolume()
	local bLocal = client == LocalPlayer()
	local margin = math.floor(height * 0.16)

	-- карточка
	surface.SetDrawColor(eui.colors.panel.r, eui.colors.panel.g, eui.colors.panel.b, 235 * data.alpha)
	surface.DrawRect(x, y, width, height)

	eui.DrawGradientH(x, y, width * 0.6, height, ColorAlpha(color, 26 * data.alpha))

	surface.SetDrawColor(color.r, color.g, color.b, alpha)
	surface.DrawRect(x, y, 3, height)

	-- помехи рации
	if (mode.bRadio) then
		surface.SetDrawColor(color.r, color.g, color.b, 26 * data.alpha)

		for _ = 1, 10 do
			surface.DrawRect(x + math.random(0, width), y + math.random(0, height), math.random(4, 22), 1)
		end
	end

	-- аватар с кольцом громкости
	local avatarSize = height - margin * 2
	local avatarX, avatarY = x + margin + 3, y + margin
	local avatar = GetAvatar(data, client)

	avatar:SetPos(avatarX, avatarY)
	avatar:SetSize(avatarSize, avatarSize)
	avatar:SetAlpha(alpha)
	avatar:PaintManual()

	local ring = math.Clamp(volume * 3, 0, 1)

	surface.SetDrawColor(color.r, color.g, color.b, alpha * (0.35 + ring * 0.65))
	surface.DrawOutlinedRect(avatarX - 1 - ring * 2, avatarY - 1 - ring * 2, avatarSize + 2 + ring * 4,
		avatarSize + 2 + ring * 4, 1 + math.floor(ring * 2))

	-- имя и режим
	local textX = avatarX + avatarSize + margin + 2
	local waveW = width * 0.26
	local name = FitText(GetSpeakerName(client), "z19VoiceName", x + width - waveW - margin * 2 - textX)

	draw.SimpleText(name, "z19VoiceName", textX, y + height * 0.36, ColorAlpha(eui.colors.text, alpha),
		TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

	local iconSize = math.floor(height * 0.24)
	local infoY = y + height * 0.72

	surface.SetMaterial(GetIcon(mode.icon))
	surface.SetDrawColor(color.r, color.g, color.b, alpha)
	surface.DrawTexturedRect(textX, infoY - iconSize * 0.5, iconSize, iconSize)

	local info = mode.name:utf8upper()

	if (!ix.config.Get("allowVoice", false)) then
		info = "ГОЛОС ОТКЛЮЧЁН НА СЕРВЕРЕ"
	elseif (bLocal) then
		info = info .. "  ·  ВЫ В ЭФИРЕ"
	elseif (mode.bRadio) then
		info = info .. "  ·  КАНАЛ 19.1"
	else
		local meters = LocalPlayer():GetPos():Distance(client:GetPos()) * 0.01905
		info = string.format("%s  ·  %d М", info, math.Round(meters))
	end

	draw.SimpleText(info, "z19VoiceMode", textX + iconSize + 5, infoY, ColorAlpha(color, alpha),
		TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

	-- волна
	DrawWave(data.history, x + width - waveW - margin, y + margin, waveW, height * 0.42, color, alpha)

	surface.SetDrawColor(eui.colors.hairline.r, eui.colors.hairline.g, eui.colors.hairline.b,
		eui.colors.hairline.a * data.alpha)
	surface.DrawOutlinedRect(x, y, width, height)
end

-- плашка режима при смене дальности
function PLUGIN:PaintToast()
	local toast = self.toast

	if (!toast) then
		return
	end

	local time = RealTime() - toast.start
	local duration = 1.6

	if (time > duration) then
		self.toast = nil
		return
	end

	local eui = ix.eui
	local mode = self.modes[toast.mode] or self.modes[self.defaultMode]
	local color = mode.color
	local fade = math.min(time / 0.12, 1) * math.min((duration - time) / 0.3, 1)
	local alpha = 255 * fade

	local text = "ДАЛЬНОСТЬ ГОЛОСА:  " .. mode.name:utf8upper()

	surface.SetFont("z19VoiceToast")
	local textW, textH = surface.GetTextSize(text)
	local iconSize = textH
	local boxW = textW + iconSize + ScreenScale(18)
	local boxH = textH + ScreenScale(10)
	local x = ScrW() * 0.5 - boxW * 0.5
	local y = ScrH() * 0.78 - boxH * 0.5 + (1 - fade) * 10

	surface.SetDrawColor(eui.colors.panel.r, eui.colors.panel.g, eui.colors.panel.b, 240 * fade)
	surface.DrawRect(x, y, boxW, boxH)

	surface.SetDrawColor(color.r, color.g, color.b, alpha)
	surface.DrawRect(x, y, boxW, 2)

	surface.SetMaterial(GetIcon(mode.icon))
	surface.DrawTexturedRect(x + ScreenScale(6), y + ScreenScale(3), iconSize, iconSize)

	draw.SimpleText(text, "z19VoiceToast", x + ScreenScale(6) + iconSize + ScreenScale(5), y + ScreenScale(3),
		ColorAlpha(eui.colors.text, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

	-- шкала дальности: по сегменту на режим
	local segments = #self.modes
	local segmentW = (boxW - ScreenScale(12) - (segments - 1) * 3) / segments

	for i = 1, segments do
		local bActive = i <= toast.mode

		surface.SetDrawColor(color.r, color.g, color.b, (bActive and 230 or 30) * fade)
		surface.DrawRect(x + ScreenScale(6) + (i - 1) * (segmentW + 3), y + boxH - ScreenScale(3), segmentW, 3)
	end
end

function PLUGIN:HUDPaint()
	self:PaintToast()

	if (!ix.option.Get("voiceHUD", true)) then
		return
	end

	local width = math.max(ScreenScale(118), 280)
	local height = math.max(ScreenScale(19), 46)
	local x = ScrW() - width - ScreenScale(8)
	local y = ScrH() * 0.8 - height
	local gap = ScreenScale(3)

	-- свой голос — всегда нижней карточкой
	local list = {}

	for client, data in pairs(self.speakers) do
		if (IsValid(client)) then
			list[#list + 1] = {client, data}
		end
	end

	table.sort(list, function(a, b)
		local aLocal, bLocal = a[1] == LocalPlayer(), b[1] == LocalPlayer()

		if (aLocal != bLocal) then
			return aLocal
		end

		return a[2].start < b[2].start
	end)

	for _, entry in ipairs(list) do
		local data = entry[2]
		local slide = (1 - data.alpha) * ScreenScale(20)

		self:PaintSpeaker(entry[1], data, x + slide, y, width, height)

		y = y - (height + gap) * math.min(data.alpha * 1.5, 1)

		if (y < ScrH() * 0.3) then
			break
		end
	end
end

-- значок над головой говорящего
local function GetHeadPosition(client)
	local bone = client:LookupBone("ValveBiped.Bip01_Head1")

	if (bone) then
		local position = client:GetBonePosition(bone)

		if (position and position != client:GetPos()) then
			return position + Vector(0, 0, 9)
		end
	end

	return client:EyePos() + Vector(0, 0, 6)
end

function PLUGIN:PostDrawTranslucentRenderables(bDepth, bSkybox)
	if (bSkybox or !ix.option.Get("voiceIcons", true)) then
		return
	end

	local localPlayer = LocalPlayer()
	local eyePos = EyePos()
	local angle = Angle(0, EyeAngles().y - 90, 90)

	for client, data in pairs(self.speakers) do
		if (!IsValid(client) or !client:Alive() or client:GetNoDraw() or data.alpha <= 0) then
			continue
		end

		if (client == localPlayer and !localPlayer:ShouldDrawLocalPlayer()) then
			continue
		end

		local position = GetHeadPosition(client)
		local distance = eyePos:Distance(position)

		if (distance > 900) then
			continue
		end

		local mode = self.modes[data.mode] or self.modes[self.defaultMode]
		local color = mode.color
		local alpha = data.alpha * 255 * math.Clamp((900 - distance) / 200, 0, 1)
		local volume = data.ended and 0 or client:VoiceVolume()
		local pulse = (RealTime() * 1.4) % 1

		cam.Start3D2D(position, angle, 0.06)
			-- расходящиеся кольца
			surface.SetDrawColor(color.r, color.g, color.b, alpha * (1 - pulse) * 0.6)
			surface.DrawOutlinedRect(-60 - pulse * 40, -60 - pulse * 40, 120 + pulse * 80, 120 + pulse * 80, 3)

			local size = 120 + volume * 60

			surface.SetDrawColor(ix.eui.colors.bg.r, ix.eui.colors.bg.g, ix.eui.colors.bg.b, alpha * 0.85)
			surface.DrawRect(-60, -60, 120, 120)

			surface.SetDrawColor(color.r, color.g, color.b, alpha)
			surface.DrawOutlinedRect(-60, -60, 120, 120, 3)

			surface.SetMaterial(GetIcon(mode.icon))
			surface.DrawTexturedRect(-size * 0.35, -size * 0.35, size * 0.7, size * 0.7)
		cam.End3D2D()
	end
end
