local PLUGIN = PLUGIN

PLUGIN.name = "Голосовой чат (Зона-19)"
PLUGIN.author = "Enhanced Helix"
PLUGIN.description = "Голосовой чат в стиле Зоны-19: карточки говорящих с волной голоса, дальность голоса " ..
	"(шёпот / голос / крик / рация на весь сервер), значок над головой говорящего, щелчки рации из SCP: CB."

-- режимы дальности: range — множитель настройки voiceDistance, bRadio — слышат все игроки
PLUGIN.modes = {
	{id = "whisper", name = "Шёпот", range = 0.3, icon = "whisper", color = Color(150, 172, 196)},
	{id = "normal", name = "Голос", range = 1, icon = "normal", color = Color(255, 196, 37)},
	{id = "yell", name = "Крик", range = 2, icon = "yell", color = Color(232, 104, 54)},
	{id = "radio", name = "Рация", range = 0, icon = "radio", color = Color(120, 220, 170), bRadio = true}
}

PLUGIN.defaultMode = 2

ix.config.Add("voiceRadio", true, "Режим «Рация» в голосовом чате: голос слышат все игроки на сервере.", nil, {
	category = "Голосовой чат"
})

function PLUGIN:GetMode(client)
	local index = IsValid(client) and client:GetNetVar("voiceMode", self.defaultMode) or self.defaultMode
	local mode = self.modes[index] or self.modes[self.defaultMode]

	-- рацию могли выключить в настройках сервера
	if (mode.bRadio and !ix.config.Get("voiceRadio", true)) then
		return self.modes[self.defaultMode], self.defaultMode
	end

	return mode, index
end

if (SERVER) then
	util.AddNetworkString("z19VoiceMode")

	net.Receive("z19VoiceMode", function(length, client)
		local index = net.ReadUInt(3)

		if (!PLUGIN.modes[index] or (client.z19NextVoiceMode or 0) > CurTime()) then
			return
		end

		client.z19NextVoiceMode = CurTime() + 0.15
		client:SetNetVar("voiceMode", index)
	end)

	-- кто кого слышит: дальность по режиму говорящего, рация — все, 2D
	function PLUGIN:PlayerCanHearPlayersVoice(listener, speaker)
		if (!ix.config.Get("allowVoice", false) or !IsValid(speaker) or !speaker:Alive()) then
			return false
		end

		local mode = self:GetMode(speaker)

		if (mode.bRadio) then
			return true, false
		end

		local range = ix.config.Get("voiceDistance", 600) * mode.range

		return listener:EyePos():DistToSqr(speaker:EyePos()) < range * range, true
	end
end

if (CLIENT) then
	ix.lang.AddTable("russian", {
		voice = "Голосовой чат",
		optVoiceMode = "Дальность голоса",
		optdVoiceMode = "Как далеко слышно ваш голос. Во время разговора режим меняется колёсиком мыши " ..
			"(или командой z19_voicemode).",
		optVoiceHUD = "Карточки говорящих",
		optdVoiceHUD = "Показывать справа внизу, кто сейчас говорит.",
		optVoiceIcons = "Значок над головой",
		optdVoiceIcons = "Показывать значок микрофона или рации над головой говорящего."
	})

	ix.lang.AddTable("english", {
		voice = "Voice chat",
		optVoiceMode = "Voice range",
		optdVoiceMode = "How far your voice carries. While talking, scroll the mouse wheel to change it " ..
			"(or use the z19_voicemode command).",
		optVoiceHUD = "Speaker cards",
		optdVoiceHUD = "Show who is talking in the bottom right corner.",
		optVoiceIcons = "Icon above head",
		optdVoiceIcons = "Show a microphone or radio icon above the speaker's head."
	})
end

ix.util.Include("cl_voice.lua")
