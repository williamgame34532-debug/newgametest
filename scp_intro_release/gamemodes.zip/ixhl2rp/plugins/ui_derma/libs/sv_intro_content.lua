
--[[
	Enhanced Helix — ui_derma
	Раздача контента клиентам (FastDL / загрузка с сервера): интро, меню персонажей и шрифты.
	Сам контент лежит в отдельном аддоне scp_intro_content.
	Если контент выложен в Workshop — замените это на resource.AddWorkshop("<id>").
]]

local folders = {
	{"materials/scp_intro/", "*"},
	{"materials/scp_menu/", "*"},
	{"sound/scp_intro/", "*"},
	{"sound/scp_menu/", "*"},
	{"resource/fonts/", "Zone19Sans-*.ttf"},
	{"resource/fonts/", "JetBrainsMono-*.ttf"}
}

for _, folder in ipairs(folders) do
	local files = file.Find(folder[1] .. folder[2], "GAME")

	for _, name in ipairs(files or {}) do
		resource.AddSingleFile(folder[1] .. name)
	end
end
