
--[[
	Enhanced Helix — ui_derma
	Раздача контента вступительной заставки клиентам (FastDL / загрузка с сервера).
	Сам контент лежит в отдельном аддоне scp_intro_content (materials/scp_intro, sound/scp_intro).
	Если контент выложен в Workshop — замените это на resource.AddWorkshop("<id>").
]]

local files = {
	"materials/scp_intro/s1_siren_off.jpg",
	"materials/scp_intro/s1_siren_on.jpg",
	"materials/scp_intro/s2_legs.jpg",
	"materials/scp_intro/s3_helmets.jpg",
	"materials/scp_intro/s4_scp106.jpg",
	"materials/scp_intro/s5_gate.jpg",
	"materials/scp_intro/s5_gate_closed.jpg",
	"materials/scp_intro/logo.png",
	"materials/scp_intro/glow.png",

	"sound/scp_intro/siren_loop.ogg",
	"sound/scp_intro/pa_breach.ogg",
	"sound/scp_intro/run_squad.ogg",
	"sound/scp_intro/breath.ogg",
	"sound/scp_intro/radio_squelch.ogg",
	"sound/scp_intro/sting_horror.ogg",
	"sound/scp_intro/scp106_music.ogg",
	"sound/scp_intro/scp106_decay.ogg",
	"sound/scp_intro/scp106_corrosion.ogg",
	"sound/scp_intro/scp106_laugh.ogg",
	"sound/scp_intro/scp106_abduct.ogg",
	"sound/scp_intro/bodyfall.ogg",
	"sound/scp_intro/gate_open.ogg",
	"sound/scp_intro/mtf_announce.ogg",
	"sound/scp_intro/mtf_march.ogg",
	"sound/scp_intro/sting_logo.ogg"
}

for _, path in ipairs(files) do
	resource.AddSingleFile(path)
end
