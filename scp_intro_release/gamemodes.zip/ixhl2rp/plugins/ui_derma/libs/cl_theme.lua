
--[[
	Enhanced Helix — ui_derma
	Тема "Enhanced": графит + циан, тонкие волосяные линии, угловые скобки,
	сканлайны и моноширинные технические подписи.
	Референсы: district (флэт-терминалы), c8 (комбайн-голография),
	genesis (кинематографичный минимализм), resilence (чистая типографика).
]]

ix.eui = ix.eui or {}
local eui = ix.eui

eui.colors = {
	bg = Color(6, 10, 14),                     -- глубокий фон
	panel = Color(11, 17, 23, 242),            -- основная панель
	panelLight = Color(18, 27, 35, 242),       -- приподнятая панель / ховер
	hairline = Color(140, 190, 210, 22),       -- волосяная линия
	hairlineBright = Color(140, 220, 240, 70), -- яркая волосяная линия / скобки
	text = Color(228, 238, 242),
	textDim = Color(145, 168, 178),
	accent = Color(0, 198, 224),               -- циан Альянса
	danger = Color(232, 66, 78)
}

-- единая точка получения акцента: хочешь цвет сервера — верни ix.config.Get("color")
function eui.GetAccent()
	return eui.colors.accent
end

-- шрифты
local function CreateFonts()
	surface.CreateFont("eixTitleFont", {
		font = "Roboto Th",
		size = math.max(ScreenScale(26), 40),
		weight = 100,
		extended = true
	})

	surface.CreateFont("eixSubTitleFont", {
		font = "Roboto Th",
		size = math.max(ScreenScale(10), 20),
		weight = 100,
		extended = true
	})

	surface.CreateFont("eixMonoFont", {
		font = "Consolas",
		size = math.max(ScreenScale(6), 15),
		weight = 400,
		extended = true
	})

	surface.CreateFont("eixMonoSmallFont", {
		font = "Consolas",
		size = math.max(ScreenScale(5), 12),
		weight = 400,
		extended = true
	})

	surface.CreateFont("eixGhostFont", {
		font = "Roboto Th",
		size = math.max(ScreenScale(80), 128),
		weight = 100,
		extended = true
	})
end

CreateFonts()
hook.Add("LoadFonts", "eixThemeFonts", CreateFonts)

-- страховка: шрифт колеса оружия (лечит [ERROR] 'ixWeaponSelectFont' isn't a valid font,
-- если стоковый LoadFonts плагина wepselect не успел отработать)
local function CreateFallbackFonts()
	if (not pcall(surface.SetFont, "ixWeaponSelectFont")) then
		surface.CreateFont("ixWeaponSelectFont", {
			font = "Roboto",
			size = ScreenScale(16),
			extended = true,
			weight = 1000
		})
	end
end

CreateFallbackFonts()
hook.Add("LoadFonts", "eixFallbackFonts", CreateFallbackFonts)
hook.Add("InitPostEntity", "eixFallbackFonts", CreateFallbackFonts)

-- хелперы отрисовки
function eui.DrawPanel(x, y, w, h, color, border)
	surface.SetDrawColor(color or eui.colors.panel)
	surface.DrawRect(x, y, w, h)

	surface.SetDrawColor(border or eui.colors.hairline)
	surface.DrawOutlinedRect(x, y, w, h)
end

-- угловые скобки в стиле комбайн-голографии (c8)
function eui.DrawCorners(x, y, w, h, len, color, thickness)
	len = len or 8
	thickness = thickness or 1

	surface.SetDrawColor(color or eui.colors.hairlineBright)

	surface.DrawRect(x, y, len, thickness)
	surface.DrawRect(x, y, thickness, len)

	surface.DrawRect(x + w - len, y, len, thickness)
	surface.DrawRect(x + w - thickness, y, thickness, len)

	surface.DrawRect(x, y + h - thickness, len, thickness)
	surface.DrawRect(x, y + h - len, thickness, len)

	surface.DrawRect(x + w - len, y + h - thickness, len, thickness)
	surface.DrawRect(x + w - thickness, y + h - len, thickness, len)
end

-- лёгкие сканлайны (CRT-налёт, как терминалы c8/genesis)
function eui.DrawScanlines(x, y, w, h, alpha, gap)
	gap = gap or 4

	surface.SetDrawColor(0, 0, 0, alpha or 10)

	for i = y, y + h, gap do
		surface.DrawRect(x, i, w, 1)
	end
end

function eui.DrawAccentBar(x, y, h, color, width)
	color = color or eui.GetAccent()

	surface.SetDrawColor(color.r, color.g, color.b, 255)
	surface.DrawRect(x, y, width or 2, h)
end

-- панель со срезанными углами (верхний левый + нижний правый) — фирменная форма Enhanced
function eui.DrawCutPanel(x, y, w, h, cut, color, border)
	cut = cut or 8

	local points = {
		{x = x + cut, y = y},
		{x = x + w, y = y},
		{x = x + w, y = y + h - cut},
		{x = x + w - cut, y = y + h},
		{x = x, y = y + h},
		{x = x, y = y + cut}
	}

	draw.NoTexture()
	surface.SetDrawColor(color or eui.colors.panel)
	surface.DrawPoly(points)

	surface.SetDrawColor(border or eui.colors.hairline)

	for i = 1, #points do
		local a = points[i]
		local b = points[i % #points + 1]

		surface.DrawLine(a.x, a.y, b.x, b.y)
	end
end

-- крупный призрачный текст на фоне (номера шагов, литеры разделов)
function eui.DrawGhostText(text, x, y, alpha, alignX, alignY)
	draw.SimpleText(text, "eixGhostFont", x, y,
		ColorAlpha(eui.GetAccent(), alpha or 14),
		alignX or TEXT_ALIGN_RIGHT, alignY or TEXT_ALIGN_BOTTOM)
end

-- залитый уголок (маркер редкости, resonance)
function eui.DrawCornerTriangle(x, y, size, color)
	draw.NoTexture()
	surface.SetDrawColor(color.r, color.g, color.b, color.a or 255)
	surface.DrawPoly({
		{x = x, y = y},
		{x = x + size, y = y},
		{x = x, y = y + size}
	})
end

-- переопределение скина "helix" — глобальный рестайл рамок, тултипов, меню и кнопок
local skin = derma.GetNamedSkin and derma.GetNamedSkin("helix") or (derma.SkinList or {}).helix

if (skin) then
	local gradient = surface.GetTextureID("vgui/gradient-d")

	skin.Colours.Info = Color(90, 200, 235)
	skin.Colours.Error = eui.colors.danger
	skin.Colours.MenuLabel = eui.colors.text
	skin.Colours.DarkerBackground = Color(6, 10, 14, 160)

	-- плоская заливка с ярким левым маркером вместо градиента (district)
	function skin:DrawImportantBackground(x, y, width, height, color)
		color = color or eui.GetAccent()

		surface.SetDrawColor(color.r, color.g, color.b, math.min(color.a or 255, 90))
		surface.DrawRect(x, y, width, height)

		surface.SetDrawColor(color.r, color.g, color.b, 255)
		surface.DrawRect(x, y, 3, height)
	end

	function skin:PaintFrame(panel)
		local width, height = panel:GetWide(), panel:GetTall()

		if (not panel.bNoBackgroundBlur) then
			ix.util.DrawBlur(panel, 10)
		end

		surface.SetDrawColor(eui.colors.panel)
		surface.DrawRect(0, 0, width, height)

		if (panel:GetTitle() ~= "" or panel.btnClose:IsVisible()) then
			surface.SetDrawColor(eui.colors.panelLight)
			surface.DrawRect(0, 0, width, 24)

			surface.SetDrawColor(eui.GetAccent())
			surface.DrawRect(0, 23, width, 1)

			if (panel.bHighlighted) then
				self:DrawImportantBackground(0, 0, width, 24, ColorAlpha(color_white, 22))
			end
		end

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)

		eui.DrawCorners(0, 0, width, height, 10)
	end

	function skin:PaintBaseFrame(panel, width, height)
		if (not panel.bNoBackgroundBlur) then
			ix.util.DrawBlur(panel, 10)
		end

		surface.SetDrawColor(eui.colors.panel)
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)

		eui.DrawCorners(0, 0, width, height, 10)
	end

	function skin:PaintMenuBackground(panel, width, height, alphaFraction)
		alphaFraction = alphaFraction or 1

		surface.SetDrawColor(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, alphaFraction * 235)
		surface.SetTexture(gradient)
		surface.DrawTexturedRect(0, 0, width, height)

		ix.util.DrawBlur(panel, alphaFraction * 15, nil, 200)

		eui.DrawScanlines(0, 0, width, height, alphaFraction * 8, 4)
	end

	function skin:PaintPlaceholderPanel(panel, width, height)
		surface.SetDrawColor(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, 120)
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)

		eui.DrawCorners(0, 0, width, height, 12)
	end

	function skin:PaintTooltipBackground(panel, width, height)
		ix.util.DrawBlur(panel, 1)

		surface.SetDrawColor(eui.colors.panel)
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)

		local accent = eui.GetAccent()

		surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
		surface.DrawRect(0, 0, width, 1)

		eui.DrawCorners(0, 0, width, height, 6, ColorAlpha(accent, 130))
	end

	function skin:PaintEntityInfoBackground(panel, width, height)
		self:PaintTooltipBackground(panel, width, height)
	end

	function skin:PaintButton(panel)
		if (panel.m_bBackground) then
			local width, height = panel:GetWide(), panel:GetTall()
			local fillAlpha = 200
			local border = eui.colors.hairline

			if (panel:GetDisabled()) then
				fillAlpha = 80
			elseif (panel.Depressed) then
				fillAlpha = 255
				border = eui.GetAccent()
			elseif (panel.Hovered) then
				fillAlpha = 235
				border = eui.colors.hairlineBright
			end

			if (panel:GetParent() and panel:GetParent():GetName() == "DListView_Column") then
				surface.SetDrawColor(eui.colors.panelLight)
				surface.DrawRect(0, 0, width, height)
			end

			surface.SetDrawColor(eui.colors.panelLight.r, eui.colors.panelLight.g, eui.colors.panelLight.b, fillAlpha)
			surface.DrawRect(0, 0, width, height)

			surface.SetDrawColor(border)
			surface.DrawOutlinedRect(0, 0, width, height)
		end
	end

	function skin:PaintCharacterCreateBackground(panel, width, height)
		surface.SetDrawColor(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, 255)
		surface.SetTexture(gradient)
		surface.DrawTexturedRect(0, 0, width, height)

		eui.DrawScanlines(0, 0, width, height, 8, 4)
	end

	function skin:PaintCharacterLoadBackground(panel, width, height)
		surface.SetDrawColor(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, panel:GetBackgroundFraction() * 255)
		surface.SetTexture(gradient)
		surface.DrawTexturedRect(0, 0, width, height)
	end

	function skin:PaintListRow(panel, width, height)
		surface.SetDrawColor(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, 170)
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(eui.colors.hairline.r, eui.colors.hairline.g, eui.colors.hairline.b, 12)
		surface.DrawRect(0, height - 1, width, 1)
	end

	function skin:PaintSettingsRowBackground(panel, width, height)
		if (panel:GetBackgroundIndex() == 0) then
			surface.SetDrawColor(eui.colors.panelLight.r, eui.colors.panelLight.g, eui.colors.panelLight.b, 60)
			surface.DrawRect(0, 0, width, height)
		end

		if (panel:GetShowReset()) then
			surface.SetDrawColor(self.Colours.Warning)
			surface.DrawRect(0, 0, 2, height)
		end
	end

	function skin:PaintMenu(panel, width, height)
		ix.util.DrawBlur(panel)

		surface.SetDrawColor(eui.colors.panel)
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)
	end

	function skin:PaintScrollBarGrip(panel, width, height)
		local parent = panel:GetParent()
		local upButtonHeight = parent.btnUp:GetTall()
		local downButtonHeight = parent.btnDown:GetTall()
		local accent = eui.GetAccent()

		DisableClipping(true)
			surface.SetDrawColor(eui.colors.panelLight.r, eui.colors.panelLight.g, eui.colors.panelLight.b, 220)
			surface.DrawRect(4, -upButtonHeight, width - 8, height + upButtonHeight + downButtonHeight)

			surface.SetDrawColor(accent.r, accent.g, accent.b, 90)
			surface.DrawRect(4, -upButtonHeight, 1, height + upButtonHeight + downButtonHeight)
		DisableClipping(false)
	end

	local gradientUp = surface.GetTextureID("vgui/gradient-u")

	function skin:PaintCategoryPanel(panel, text, color)
		text = text or ""
		color = color or eui.GetAccent()

		surface.SetFont(self.fontCategory)

		local textHeight = select(2, surface.GetTextSize(text)) + 8
		local width, height = panel:GetSize()

		-- тело
		surface.SetDrawColor(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, 150)
		surface.DrawRect(0, textHeight, width, height - textHeight)

		-- заголовок: приподнятая панель + подмес цвета фракции + левый маркер
		surface.SetDrawColor(eui.colors.panelLight)
		surface.DrawRect(0, 0, width, textHeight)

		surface.SetDrawColor(color.r, color.g, color.b, 35)
		surface.DrawRect(0, 0, width, textHeight)

		surface.SetDrawColor(color.r, color.g, color.b, 255)
		surface.DrawRect(0, 0, 4, textHeight)

		surface.SetDrawColor(color.r, color.g, color.b, 160)
		surface.DrawRect(0, textHeight - 1, width, 1)

		surface.SetTextColor(eui.colors.text)
		surface.SetTextPos(12, 4)
		surface.DrawText(text)

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)

		eui.DrawCorners(0, 0, width, height, 8)

		return 1, textHeight, 1, 1
	end

	function skin:PaintInventorySlot(panel, width, height)
		-- resonance: глубокие ячейки с видимым зазором, лёгким глянцем и точкой в центре
		surface.SetDrawColor(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, 175)
		surface.DrawRect(2, 2, width - 4, height - 4)

		surface.SetDrawColor(255, 255, 255, 4)
		surface.SetTexture(gradient)
		surface.DrawTexturedRect(2, 2, width - 4, (height - 4) * 0.5)

		surface.SetDrawColor(eui.colors.hairline.r, eui.colors.hairline.g, eui.colors.hairline.b, 28)
		surface.DrawOutlinedRect(2, 2, width - 4, height - 4)

		surface.SetDrawColor(eui.colors.hairline.r, eui.colors.hairline.g, eui.colors.hairline.b, 22)
		surface.DrawRect(width * 0.5 - 1, height * 0.5 - 1, 2, 2)
	end

	function skin:PaintSegmentedProgressBackground(panel, width, height)
		surface.SetDrawColor(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, 210)
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawRect(0, 0, width, 1)
	end

	function skin:PaintSegmentedProgress(panel, width, height)
		local font = panel:GetFont() or self.fontSegmentedProgress
		local barColor = panel:GetBarColor() or eui.GetAccent()
		local segments = panel:GetSegments()
		local count = #segments

		if (count == 0) then
			return
		end

		local fraction = panel:GetFraction()
		local segmentHalfWidth = width / count * 0.5

		-- мягкая заливка пройденного и жёсткая линия прогресса сверху
		surface.SetDrawColor(barColor.r, barColor.g, barColor.b, 25)
		surface.DrawRect(0, 0, fraction * width, height)

		surface.SetDrawColor(barColor.r, barColor.g, barColor.b, 255)
		surface.DrawRect(0, 0, fraction * width, 2)

		for i = 1, count do
			local x = (i - 1) / count * width

			if (i > 1) then
				surface.SetDrawColor(eui.colors.hairline)
				surface.DrawRect(x, 0, 1, height)
			end

			local bDone = (i / count) <= (fraction + 0.001)
			local textColor = bDone and eui.colors.text or eui.colors.textDim

			draw.SimpleText(string.format("%02d // %s", i, tostring(segments[i])), font,
				x + segmentHalfWidth, height * 0.5,
				textColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	function skin:PaintHelixSlider(panel, width, height)
		surface.SetDrawColor(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, 200)
		surface.DrawRect(0, 0, width, height)

		local accent = eui.GetAccent()

		surface.SetDrawColor(accent.r, accent.g, accent.b, 60)
		surface.DrawRect(0, 0, panel:GetVisualFraction() * width, height)

		surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
		surface.DrawRect(math.max(panel:GetVisualFraction() * width - 2, 0), 0, 2, height)

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)
	end

	function skin:PaintCharacterTransitionOverlay(panel, x, y, width, height, color)
		color = color or panel.overlayColor or eui.GetAccent()

		surface.SetDrawColor(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, 255)
		surface.DrawRect(x, y, width, height)

		eui.DrawScanlines(x, y, width, height, 20, 4)

		surface.SetDrawColor(color.r, color.g, color.b, 255)
		surface.DrawRect(x, y, width, 1)
		surface.DrawRect(x, y + height - 2, width, 2)
	end

	function skin:PaintComboDownArrow(panel, width, height)
		surface.SetFont("ixIconsSmall")

		local textWidth, textHeight = surface.GetTextSize("r")
		local alpha = (panel.ComboBox:IsMenuOpen() or panel.ComboBox.Hovered) and 220 or 110
		local accent = eui.GetAccent()

		surface.SetTextColor(ColorAlpha(accent, alpha))
		surface.SetTextPos(width * 0.5 - textWidth * 0.5, height * 0.5 - textHeight * 0.5)
		surface.DrawText("r")
	end

	function skin:PaintChatboxTabButton(panel, width, height)
		if (panel:GetActive()) then
			surface.SetDrawColor(eui.colors.panelLight)
			surface.DrawRect(0, 0, width, height)

			local accent = eui.GetAccent()

			surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
			surface.DrawRect(0, height - 2, width, 2)
		else
			surface.SetDrawColor(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, 140)
			surface.DrawRect(0, 0, width, height)

			if (panel:GetUnread()) then
				surface.SetDrawColor(ColorAlpha(self.Colours.Warning, Lerp(panel.unreadAlpha, 0, 120)))
				surface.SetTexture(gradient)
				surface.DrawTexturedRect(0, 0, width, height - 1)
			end
		end

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawRect(width - 1, 0, 1, height)
	end

	function skin:PaintChatboxTabs(panel, width, height, alpha)
		alpha = alpha or 255

		surface.SetDrawColor(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, 120 * (alpha / 255))
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawRect(0, height - 1, width, 1)
	end

	function skin:PaintChatboxBackground(panel, width, height)
		-- фон и рамка — только при активном чате; свернутый чат = чистые плавающие сообщения
		if (not panel:GetActive()) then
			return
		end

		ix.util.DrawBlur(panel, 10)

		surface.SetDrawColor(eui.colors.panel.r, eui.colors.panel.g, eui.colors.panel.b, 210)
		surface.DrawRect(0, 0, width, height)

		if (panel:GetActive()) then
			local accent = eui.GetAccent()

			surface.SetDrawColor(ColorAlpha(accent, 25))
			surface.SetTexture(gradientUp)
			surface.DrawTexturedRect(0, panel.tabs.buttons:GetTall(), width, height * 0.25)
		end

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)

		eui.DrawCorners(0, 0, width, height, 8)
	end

	function skin:PaintChatboxEntry(panel, width, height)
		surface.SetDrawColor(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, 170)
		surface.DrawRect(0, 0, width, height)

		local accent = eui.GetAccent()

		surface.SetDrawColor(accent.r, accent.g, accent.b, 220)
		surface.DrawRect(0, 0, 2, height)

		panel:DrawTextEntryText(eui.colors.text, accent, eui.colors.text)

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)
	end

	function skin:DrawChatboxPreviewBox(x, y, text, color)
		color = color or eui.GetAccent()

		local textWidth, textHeight = surface.GetTextSize(text)
		local width, height = textWidth + 10, textHeight + 8

		surface.SetDrawColor(eui.colors.panelLight)
		surface.DrawRect(x, y, width, height)

		surface.SetDrawColor(color.r, color.g, color.b, 255)
		surface.DrawRect(x, y, 3, height)

		surface.SetTextColor(eui.colors.text)
		surface.SetTextPos(x + 3 + (width - 3) * 0.5 - textWidth * 0.5, y + height * 0.5 - textHeight * 0.5)
		surface.DrawText(text)

		surface.SetDrawColor(ColorAlpha(color, 180))
		surface.DrawOutlinedRect(x, y, width, height)

		return width
	end

	function skin:DrawChatboxPrefixBox(panel, width, height)
		local color = panel:GetBackgroundColor()

		surface.SetDrawColor(color.r, color.g, color.b, 45)
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(color.r, color.g, color.b, 255)
		surface.DrawRect(0, 0, 3, height)

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)
	end

	function skin:PaintChatboxAutocompleteEntry(panel, width, height)
		if (panel.highlightAlpha > 0) then
			self:DrawImportantBackground(0, 0, width, height, ColorAlpha(eui.GetAccent(), panel.highlightAlpha * 66))
		end

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawRect(0, height - 1, width, 1)
	end

	function skin:PaintInfoBar(panel, width, height, color)
		surface.SetDrawColor(color.r, color.g, color.b, 235)
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(255, 255, 255, 20)
		surface.DrawRect(0, 0, width, 1)
	end

	function skin:PaintInfoBarBackground(panel, width, height)
		surface.SetDrawColor(eui.colors.panelLight.r, eui.colors.panelLight.g, eui.colors.panelLight.b, 90)
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)

		panel.bar:PaintManual()

		DisableClipping(true)
			panel.label:PaintManual()
		DisableClipping(false)
	end

	function skin:PaintDeathScreenBackground(panel, width, height, progress)
		surface.SetDrawColor(0, 0, 0, (progress / 0.3) * 255)
		surface.DrawRect(0, 0, width, height)

		if (progress > 0.3) then
			eui.DrawScanlines(0, 0, width, height, 14, 4)

			local danger = eui.colors.danger

			surface.SetDrawColor(danger.r, danger.g, danger.b, 90 * math.min((progress - 0.3) / 0.7, 1))
			surface.DrawRect(0, height * 0.5, width, 1)
		end
	end

	-- строки настроек: акцентный маркер при наведении (c8)
	local oldSettingsRow = skin.PaintSettingsRowBackground

	function skin:PaintSettingsRowBackground(panel, width, height)
		if (oldSettingsRow) then
			oldSettingsRow(self, panel, width, height)
		end

		if (panel:IsHovered()) then
			local accent = eui.GetAccent()

			surface.SetDrawColor(accent.r, accent.g, accent.b, 14)
			surface.DrawRect(0, 0, width, height)

			surface.SetDrawColor(accent.r, accent.g, accent.b, 220)
			surface.DrawRect(0, 0, 2, height)
		end
	end

	-- тёмные стандартные поля ввода и выпадающие списки
	function skin:PaintTextEntry(panel, width, height)
		surface.SetDrawColor(eui.colors.panelLight.r, eui.colors.panelLight.g, eui.colors.panelLight.b, 230)
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)

		panel:DrawTextEntryText(eui.colors.text, eui.GetAccent(), eui.colors.text)
	end

	function skin:PaintComboBox(panel, width, height)
		surface.SetDrawColor(eui.colors.panelLight.r, eui.colors.panelLight.g, eui.colors.panelLight.b, 230)
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(panel:IsHovered() and eui.colors.hairlineBright or eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)
	end

	derma.RefreshSkins()
end
