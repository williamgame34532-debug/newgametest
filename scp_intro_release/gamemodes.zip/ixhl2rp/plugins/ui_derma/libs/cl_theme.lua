
--[[
	Enhanced Helix — ui_derma
	Тема «Зона-19»: терминал Фонда SCP — графит, янтарный акцент (как в меню персонажей),
	красный для опасности, тонкие линии, угловые скобки, моноширинные технические подписи.
	Шрифты: Zone19 Sans (на основе Jost*) и JetBrains Mono из контент-аддона.
]]

ix.eui = ix.eui or {}
local eui = ix.eui

eui.colors = {
	bg = Color(11, 12, 14),                    -- глубокий фон
	panel = Color(19, 20, 23, 242),            -- основная панель
	panelLight = Color(30, 32, 36, 242),       -- приподнятая панель / ховер
	hairline = Color(255, 255, 255, 20),       -- волосяная линия
	hairlineBright = Color(255, 196, 37, 90),  -- яркая линия / скобки (янтарь)
	text = Color(236, 236, 232),
	textDim = Color(146, 148, 152),
	accent = Color(255, 196, 37),              -- янтарь Фонда
	danger = Color(214, 48, 48)
}

-- единая точка получения акцента: хочешь цвет сервера — верни ix.config.Get("color")
function eui.GetAccent()
	return eui.colors.accent
end

-- свои градиенты (контент scp_menu): grad_bottom — непрозрачен снизу, grad_left — слева
local gradientBottom = Material("scp_menu/grad_bottom.png", "smooth")
local gradientLeft = Material("scp_menu/grad_left.png", "smooth")

-- вертикальный градиент: bTop — непрозрачен сверху
function eui.DrawGradientV(x, y, w, h, color, bTop)
	surface.SetMaterial(gradientBottom)
	surface.SetDrawColor(color)

	if (bTop) then
		surface.DrawTexturedRectUV(x, y, w, h, 0, 1, 1, 0)
	else
		surface.DrawTexturedRect(x, y, w, h)
	end
end

-- горизонтальный градиент: bRight — непрозрачен справа
function eui.DrawGradientH(x, y, w, h, color, bRight)
	surface.SetMaterial(gradientLeft)
	surface.SetDrawColor(color)

	if (bRight) then
		surface.DrawTexturedRectUV(x, y, w, h, 1, 0, 0, 1)
	else
		surface.DrawTexturedRect(x, y, w, h)
	end
end

-- жёлто-чёрная полоса «опасность» (фирменная деталь Зоны-19): тайловая текстура, без ножниц
local hazard = Material("scp_menu/hazard.png", "smooth noclamp")

function eui.DrawHazard(x, y, w, h, alpha)
	surface.SetMaterial(hazard)
	surface.SetDrawColor(255, 255, 255, alpha or 255)
	surface.DrawTexturedRectUV(x, y, w, h, 0, 0, w / math.max(h * 2, 1), 0.5)
end

-- шрифты
local function CreateFonts()
	surface.CreateFont("eixTitleFont", {
		font = "Zone19 Sans Bold",
		size = math.max(ScreenScale(22), 36),
		weight = 700,
		extended = true
	})

	surface.CreateFont("eixSubTitleFont", {
		font = "Zone19 Sans Semi",
		size = math.max(ScreenScale(9), 18),
		weight = 600,
		extended = true
	})

	surface.CreateFont("eixMonoFont", {
		font = "JetBrains Mono",
		size = math.max(ScreenScale(5.5), 14),
		weight = 400,
		extended = true
	})

	surface.CreateFont("eixMonoSmallFont", {
		font = "JetBrains Mono",
		size = math.max(ScreenScale(4.6), 12),
		weight = 400,
		extended = true
	})

	surface.CreateFont("eixGhostFont", {
		font = "Zone19 Sans Black",
		size = math.max(ScreenScale(80), 128),
		weight = 900,
		extended = true
	})
end

-- шрифты ядра Helix: пересоздаём ПОСЛЕ GM:LoadFonts (он вызывается после хуков и перезаписал бы наши)
local function OverrideHelixFonts()
	local function font(name, face, size, weight, extra)
		local data = {font = face, size = size, weight = weight, extended = true, antialias = true}

		if (extra) then
			table.Merge(data, extra)
		end

		surface.CreateFont(name, data)
	end

	local sans, semi, medium, bold, book = "Zone19 Sans Book", "Zone19 Sans Semi", "Zone19 Sans Medium",
		"Zone19 Sans Bold", "Zone19 Sans Book"
	local mono = "JetBrains Mono"

	font("ix3D2DFont", bold, 128, 700)
	font("ix3D2DMediumFont", bold, 48, 700)
	font("ix3D2DSmallFont", semi, 24, 600)
	font("ixTitleFont", bold, ScreenScale(24), 700)
	font("ixSubTitleFont", semi, ScreenScale(13), 600)
	font("ixMenuMiniFont", book, math.max(ScreenScale(4), 18), 400)
	font("ixMenuButtonFont", semi, ScreenScale(11), 600)
	font("ixMenuButtonFontSmall", semi, ScreenScale(8), 600)
	font("ixMenuButtonFontThick", bold, ScreenScale(11), 700)
	font("ixMenuButtonLabelFont", semi, 24, 600)
	font("ixMenuButtonHugeFont", medium, ScreenScale(18), 500)
	font("ixToolTipText", medium, 20, 500)
	font("ixMonoSmallFont", mono, 12, 700)
	font("ixMonoMediumFont", mono, 22, 700)
	font("ixBigFont", bold, 36, 700)
	font("ixMediumFont", bold, 25, 700)
	font("ixNoticeFont", medium, math.max(ScreenScale(7), 18), 500)
	font("ixMediumLightFont", sans, 25, 400)
	font("ixMediumLightBlurFont", sans, 25, 400, {blursize = 4})
	font("ixGenericFont", semi, 20, 600)
	font("ixSmallTitleFont", semi, math.max(ScreenScale(11), 22), 600)
	font("ixMinimalTitleFont", bold, math.max(ScreenScale(8), 22), 700)
	font("ixSmallFont", sans, math.max(ScreenScale(6), 17), 400)
	font("ixItemDescFont", sans, math.max(ScreenScale(6), 17), 400)
	font("ixSmallBoldFont", bold, math.max(ScreenScale(7.5), 19), 700)
	font("ixItemBoldFont", bold, math.max(ScreenScale(7.5), 19), 700)

	hook.Run("Z19FontsOverridden")
end

eui.OverrideHelixFonts = OverrideHelixFonts

hook.Add("LoadFonts", "eixHelixFontOverride", function()
	timer.Simple(0, OverrideHelixFonts)
end)

CreateFonts()
hook.Add("LoadFonts", "eixThemeFonts", CreateFonts)

-- страховка: шрифт колеса оружия (лечит [ERROR] 'ixWeaponSelectFont' isn't a valid font,
-- если стоковый LoadFonts плагина wepselect не успел отработать)
local function CreateFallbackFonts()
	if (not pcall(surface.SetFont, "ixWeaponSelectFont")) then
		surface.CreateFont("ixWeaponSelectFont", {
			font = "Roboto",
			size = ScreenScale(16),
			extended = true,
			weight = 1000
		})
	end
end

CreateFallbackFonts()
hook.Add("LoadFonts", "eixFallbackFonts", CreateFallbackFonts)
hook.Add("InitPostEntity", "eixFallbackFonts", CreateFallbackFonts)

-- хелперы отрисовки
function eui.DrawPanel(x, y, w, h, color, border)
	surface.SetDrawColor(color or eui.colors.panel)
	surface.DrawRect(x, y, w, h)

	surface.SetDrawColor(border or eui.colors.hairline)
	surface.DrawOutlinedRect(x, y, w, h)
end

-- угловые скобки в стиле комбайн-голографии (c8)
function eui.DrawCorners(x, y, w, h, len, color, thickness)
	len = len or 8
	thickness = thickness or 1

	surface.SetDrawColor(color or eui.colors.hairlineBright)

	surface.DrawRect(x, y, len, thickness)
	surface.DrawRect(x, y, thickness, len)

	surface.DrawRect(x + w - len, y, len, thickness)
	surface.DrawRect(x + w - thickness, y, thickness, len)

	surface.DrawRect(x, y + h - thickness, len, thickness)
	surface.DrawRect(x, y + h - len, thickness, len)

	surface.DrawRect(x + w - len, y + h - thickness, len, thickness)
	surface.DrawRect(x + w - thickness, y + h - len, thickness, len)
end

-- лёгкие сканлайны (CRT-налёт, как терминалы c8/genesis)
function eui.DrawScanlines(x, y, w, h, alpha, gap)
	gap = gap or 4

	surface.SetDrawColor(0, 0, 0, alpha or 10)

	for i = y, y + h, gap do
		surface.DrawRect(x, i, w, 1)
	end
end

function eui.DrawAccentBar(x, y, h, color, width)
	color = color or eui.GetAccent()

	surface.SetDrawColor(color.r, color.g, color.b, 255)
	surface.DrawRect(x, y, width or 2, h)
end

-- панель со срезанными углами (верхний левый + нижний правый) — фирменная форма Enhanced
function eui.DrawCutPanel(x, y, w, h, cut, color, border)
	cut = cut or 8

	local points = {
		{x = x + cut, y = y},
		{x = x + w, y = y},
		{x = x + w, y = y + h - cut},
		{x = x + w - cut, y = y + h},
		{x = x, y = y + h},
		{x = x, y = y + cut}
	}

	draw.NoTexture()
	surface.SetDrawColor(color or eui.colors.panel)
	surface.DrawPoly(points)

	surface.SetDrawColor(border or eui.colors.hairline)

	for i = 1, #points do
		local a = points[i]
		local b = points[i % #points + 1]

		surface.DrawLine(a.x, a.y, b.x, b.y)
	end
end

-- крупный призрачный текст на фоне (номера шагов, литеры разделов)
function eui.DrawGhostText(text, x, y, alpha, alignX, alignY)
	draw.SimpleText(text, "eixGhostFont", x, y,
		ColorAlpha(eui.GetAccent(), alpha or 14),
		alignX or TEXT_ALIGN_RIGHT, alignY or TEXT_ALIGN_BOTTOM)
end

-- залитый уголок (маркер редкости, resonance)
function eui.DrawCornerTriangle(x, y, size, color)
	draw.NoTexture()
	surface.SetDrawColor(color.r, color.g, color.b, color.a or 255)
	surface.DrawPoly({
		{x = x, y = y},
		{x = x + size, y = y},
		{x = x, y = y + size}
	})
end

-- переопределение скина "helix" — глобальный рестайл рамок, тултипов, меню и кнопок
local skin = derma.GetNamedSkin and derma.GetNamedSkin("helix") or (derma.SkinList or {}).helix

if (skin) then

	skin.Colours.Info = Color(255, 196, 37)
	skin.Colours.Success = Color(70, 170, 100)
	skin.Colours.Warning = Color(255, 150, 40)
	skin.Colours.Error = eui.colors.danger
	skin.Colours.MenuLabel = eui.colors.text
	skin.Colours.DarkerBackground = Color(6, 10, 14, 160)

	-- плоская заливка с ярким левым маркером вместо градиента (district)
	function skin:DrawImportantBackground(x, y, width, height, color)
		color = color or eui.GetAccent()

		surface.SetDrawColor(color.r, color.g, color.b, math.min(color.a or 255, 90))
		surface.DrawRect(x, y, width, height)

		surface.SetDrawColor(color.r, color.g, color.b, 255)
		surface.DrawRect(x, y, 3, height)
	end

	function skin:PaintFrame(panel)
		local width, height = panel:GetWide(), panel:GetTall()

		if (not panel.bNoBackgroundBlur) then
			ix.util.DrawBlur(panel, 10)
		end

		surface.SetDrawColor(eui.colors.panel)
		surface.DrawRect(0, 0, width, height)

		if (panel:GetTitle() ~= "" or panel.btnClose:IsVisible()) then
			surface.SetDrawColor(eui.colors.panelLight)
			surface.DrawRect(0, 0, width, 24)

			surface.SetDrawColor(eui.GetAccent())
			surface.DrawRect(0, 23, width, 1)

			if (panel.bHighlighted) then
				self:DrawImportantBackground(0, 0, width, 24, ColorAlpha(color_white, 22))
			end
		end

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)

		eui.DrawCorners(0, 0, width, height, 10)
	end

	function skin:PaintBaseFrame(panel, width, height)
		if (not panel.bNoBackgroundBlur) then
			ix.util.DrawBlur(panel, 10)
		end

		surface.SetDrawColor(eui.colors.panel)
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)

		eui.DrawCorners(0, 0, width, height, 10)
	end

	function skin:PaintMenuBackground(panel, width, height, alphaFraction)
		alphaFraction = alphaFraction or 1

		ix.util.DrawBlur(panel, alphaFraction * 15, nil, 200)

		surface.SetDrawColor(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, alphaFraction * 200)
		surface.DrawRect(0, 0, width, height)

		eui.DrawGradientV(0, height * 0.55, width, height * 0.45,
			Color(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, alphaFraction * 120))

		eui.DrawScanlines(0, 0, width, height, alphaFraction * 6, 4)
	end

	function skin:PaintPlaceholderPanel(panel, width, height)
		surface.SetDrawColor(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, 120)
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)

		eui.DrawCorners(0, 0, width, height, 12)
	end

	function skin:PaintTooltipBackground(panel, width, height)
		ix.util.DrawBlur(panel, 1)

		surface.SetDrawColor(eui.colors.panel.r, eui.colors.panel.g, eui.colors.panel.b, 245)
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)

		local accent = eui.GetAccent()

		-- янтарная линия сверху и короткая полоса «опасность» в правом верхнем углу
		surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
		surface.DrawRect(0, 0, width, 2)

		local hazardW = math.min(width * 0.25, 48)
		eui.DrawHazard(width - hazardW, 2, hazardW, 4, 220)

		eui.DrawCorners(0, 0, width, height, 6, ColorAlpha(accent, 130))
	end

	function skin:PaintEntityInfoBackground(panel, width, height)
		self:PaintTooltipBackground(panel, width, height)
	end

	function skin:PaintButton(panel)
		if (panel.m_bBackground) then
			local width, height = panel:GetWide(), panel:GetTall()
			local fillAlpha = 200
			local border = eui.colors.hairline

			if (panel:GetDisabled()) then
				fillAlpha = 80
			elseif (panel.Depressed) then
				fillAlpha = 255
				border = eui.GetAccent()
			elseif (panel.Hovered) then
				fillAlpha = 235
				border = eui.colors.hairlineBright
			end

			if (panel:GetParent() and panel:GetParent():GetName() == "DListView_Column") then
				surface.SetDrawColor(eui.colors.panelLight)
				surface.DrawRect(0, 0, width, height)
			end

			surface.SetDrawColor(eui.colors.panelLight.r, eui.colors.panelLight.g, eui.colors.panelLight.b, fillAlpha)
			surface.DrawRect(0, 0, width, height)

			surface.SetDrawColor(border)
			surface.DrawOutlinedRect(0, 0, width, height)
		end
	end

	function skin:PaintCharacterCreateBackground(panel, width, height)
		surface.SetDrawColor(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, 255)
		surface.DrawRect(0, 0, width, height)

		eui.DrawScanlines(0, 0, width, height, 8, 4)
	end

	function skin:PaintCharacterLoadBackground(panel, width, height)
		surface.SetDrawColor(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, panel:GetBackgroundFraction() * 255)
		surface.DrawRect(0, 0, width, height)
	end

	function skin:PaintListRow(panel, width, height)
		surface.SetDrawColor(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, 170)
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(eui.colors.hairline.r, eui.colors.hairline.g, eui.colors.hairline.b, 12)
		surface.DrawRect(0, height - 1, width, 1)
	end

	function skin:PaintSettingsRowBackground(panel, width, height)
		if (panel:GetBackgroundIndex() == 0) then
			surface.SetDrawColor(eui.colors.panelLight.r, eui.colors.panelLight.g, eui.colors.panelLight.b, 60)
			surface.DrawRect(0, 0, width, height)
		end

		if (panel:GetShowReset()) then
			surface.SetDrawColor(self.Colours.Warning)
			surface.DrawRect(0, 0, 2, height)
		end
	end

	function skin:PaintMenu(panel, width, height)
		ix.util.DrawBlur(panel)

		surface.SetDrawColor(eui.colors.panel)
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)
	end

	function skin:PaintScrollBarGrip(panel, width, height)
		local parent = panel:GetParent()
		local upButtonHeight = parent.btnUp:GetTall()
		local downButtonHeight = parent.btnDown:GetTall()
		local accent = eui.GetAccent()

		DisableClipping(true)
			surface.SetDrawColor(eui.colors.panelLight.r, eui.colors.panelLight.g, eui.colors.panelLight.b, 220)
			surface.DrawRect(4, -upButtonHeight, width - 8, height + upButtonHeight + downButtonHeight)

			surface.SetDrawColor(accent.r, accent.g, accent.b, 90)
			surface.DrawRect(4, -upButtonHeight, 1, height + upButtonHeight + downButtonHeight)
		DisableClipping(false)
	end

	function skin:PaintCategoryPanel(panel, text, color)
		text = text or ""
		color = color or eui.GetAccent()

		surface.SetFont(self.fontCategory)

		local textHeight = select(2, surface.GetTextSize(text)) + 8
		local width, height = panel:GetSize()

		-- тело
		surface.SetDrawColor(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, 150)
		surface.DrawRect(0, textHeight, width, height - textHeight)

		-- заголовок: приподнятая панель + подмес цвета фракции + левый маркер
		surface.SetDrawColor(eui.colors.panelLight)
		surface.DrawRect(0, 0, width, textHeight)

		surface.SetDrawColor(color.r, color.g, color.b, 35)
		surface.DrawRect(0, 0, width, textHeight)

		surface.SetDrawColor(color.r, color.g, color.b, 255)
		surface.DrawRect(0, 0, 4, textHeight)

		surface.SetDrawColor(color.r, color.g, color.b, 160)
		surface.DrawRect(0, textHeight - 1, width, 1)

		surface.SetTextColor(eui.colors.text)
		surface.SetTextPos(12, 4)
		surface.DrawText(text)

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)

		eui.DrawCorners(0, 0, width, height, 8)

		return 1, textHeight, 1, 1
	end

	function skin:PaintInventorySlot(panel, width, height)
		-- resonance: глубокие ячейки с видимым зазором, лёгким глянцем и точкой в центре
		surface.SetDrawColor(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, 175)
		surface.DrawRect(2, 2, width - 4, height - 4)

		eui.DrawGradientV(2, 2, width - 4, (height - 4) * 0.5, Color(255, 255, 255, 5), true)

		surface.SetDrawColor(eui.colors.hairline.r, eui.colors.hairline.g, eui.colors.hairline.b, 28)
		surface.DrawOutlinedRect(2, 2, width - 4, height - 4)

		surface.SetDrawColor(eui.colors.hairline.r, eui.colors.hairline.g, eui.colors.hairline.b, 22)
		surface.DrawRect(width * 0.5 - 1, height * 0.5 - 1, 2, 2)
	end

	function skin:PaintSegmentedProgressBackground(panel, width, height)
		surface.SetDrawColor(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, 210)
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawRect(0, 0, width, 1)
	end

	function skin:PaintSegmentedProgress(panel, width, height)
		local font = panel:GetFont() or self.fontSegmentedProgress
		local barColor = panel:GetBarColor() or eui.GetAccent()
		local segments = panel:GetSegments()
		local count = #segments

		if (count == 0) then
			return
		end

		local fraction = panel:GetFraction()
		local segmentHalfWidth = width / count * 0.5

		-- мягкая заливка пройденного и жёсткая линия прогресса сверху
		surface.SetDrawColor(barColor.r, barColor.g, barColor.b, 25)
		surface.DrawRect(0, 0, fraction * width, height)

		surface.SetDrawColor(barColor.r, barColor.g, barColor.b, 255)
		surface.DrawRect(0, 0, fraction * width, 2)

		for i = 1, count do
			local x = (i - 1) / count * width

			if (i > 1) then
				surface.SetDrawColor(eui.colors.hairline)
				surface.DrawRect(x, 0, 1, height)
			end

			local bDone = (i / count) <= (fraction + 0.001)
			local textColor = bDone and eui.colors.text or eui.colors.textDim

			draw.SimpleText(string.format("%02d // %s", i, tostring(segments[i])), font,
				x + segmentHalfWidth, height * 0.5,
				textColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end

	function skin:PaintHelixSlider(panel, width, height)
		surface.SetDrawColor(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, 200)
		surface.DrawRect(0, 0, width, height)

		local accent = eui.GetAccent()

		surface.SetDrawColor(accent.r, accent.g, accent.b, 60)
		surface.DrawRect(0, 0, panel:GetVisualFraction() * width, height)

		surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
		surface.DrawRect(math.max(panel:GetVisualFraction() * width - 2, 0), 0, 2, height)

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)
	end

	function skin:PaintCharacterTransitionOverlay(panel, x, y, width, height, color)
		color = color or panel.overlayColor or eui.GetAccent()

		surface.SetDrawColor(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, 255)
		surface.DrawRect(x, y, width, height)

		eui.DrawScanlines(x, y, width, height, 20, 4)

		surface.SetDrawColor(color.r, color.g, color.b, 255)
		surface.DrawRect(x, y, width, 1)
		surface.DrawRect(x, y + height - 2, width, 2)
	end

	function skin:PaintComboDownArrow(panel, width, height)
		surface.SetFont("ixIconsSmall")

		local textWidth, textHeight = surface.GetTextSize("r")
		local alpha = (panel.ComboBox:IsMenuOpen() or panel.ComboBox.Hovered) and 220 or 110
		local accent = eui.GetAccent()

		surface.SetTextColor(ColorAlpha(accent, alpha))
		surface.SetTextPos(width * 0.5 - textWidth * 0.5, height * 0.5 - textHeight * 0.5)
		surface.DrawText("r")
	end

	function skin:PaintChatboxTabButton(panel, width, height)
		if (panel:GetActive()) then
			surface.SetDrawColor(eui.colors.panelLight)
			surface.DrawRect(0, 0, width, height)

			local accent = eui.GetAccent()

			surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
			surface.DrawRect(0, height - 2, width, 2)
		else
			surface.SetDrawColor(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, 140)
			surface.DrawRect(0, 0, width, height)

			if (panel:GetUnread()) then
				eui.DrawGradientV(0, 0, width, height - 1, ColorAlpha(eui.colors.accent, Lerp(panel.unreadAlpha, 0, 120)))
			end
		end

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawRect(width - 1, 0, 1, height)
	end

	function skin:PaintChatboxTabs(panel, width, height, alpha)
		alpha = alpha or 255

		surface.SetDrawColor(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, 120 * (alpha / 255))
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawRect(0, height - 1, width, 1)
	end

	function skin:PaintChatboxBackground(panel, width, height)
		-- фон и рамка — только при активном чате; свернутый чат = чистые плавающие сообщения
		if (not panel:GetActive()) then
			return
		end

		ix.util.DrawBlur(panel, 10)

		surface.SetDrawColor(eui.colors.panel.r, eui.colors.panel.g, eui.colors.panel.b, 225)
		surface.DrawRect(0, 0, width, height)

		local accent = eui.GetAccent()
		local tabsHeight = panel.tabs and panel.tabs.buttons and panel.tabs.buttons:GetTall() or 0

		eui.DrawGradientV(0, tabsHeight, width, height * 0.25, ColorAlpha(accent, 14), true)

		-- янтарная линия сверху и полоса «опасность» в правом верхнем углу
		surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
		surface.DrawRect(0, 0, width, 2)

		local hazardW = math.min(width * 0.18, 90)
		eui.DrawHazard(width - hazardW, 2, hazardW, 5, 230)

		draw.SimpleText("КАНАЛ СВЯЗИ  //  ЗОНА-19", "eixMonoSmallFont", width - hazardW - 8, 3,
			ColorAlpha(eui.colors.textDim, 160), TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)

		eui.DrawCorners(0, 0, width, height, 8, ColorAlpha(accent, 120))
	end

	function skin:PaintChatboxEntry(panel, width, height)
		surface.SetDrawColor(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, 200)
		surface.DrawRect(0, 0, width, height)

		local accent = eui.GetAccent()

		surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
		surface.DrawRect(0, 0, 3, height)

		surface.SetDrawColor(accent.r, accent.g, accent.b, panel:HasFocus() and 160 or 50)
		surface.DrawRect(3, height - 1, width - 3, 1)

		panel:DrawTextEntryText(eui.colors.text, ColorAlpha(accent, 120), accent)

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)
	end

	function skin:DrawChatboxPreviewBox(x, y, text, color)
		color = color or eui.GetAccent()

		local textWidth, textHeight = surface.GetTextSize(text)
		local width, height = textWidth + 10, textHeight + 8

		surface.SetDrawColor(eui.colors.panelLight)
		surface.DrawRect(x, y, width, height)

		surface.SetDrawColor(color.r, color.g, color.b, 255)
		surface.DrawRect(x, y, 3, height)

		surface.SetTextColor(eui.colors.text)
		surface.SetTextPos(x + 3 + (width - 3) * 0.5 - textWidth * 0.5, y + height * 0.5 - textHeight * 0.5)
		surface.DrawText(text)

		surface.SetDrawColor(ColorAlpha(color, 180))
		surface.DrawOutlinedRect(x, y, width, height)

		return width
	end

	function skin:DrawChatboxPrefixBox(panel, width, height)
		local color = panel:GetBackgroundColor()

		surface.SetDrawColor(color.r, color.g, color.b, 45)
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(color.r, color.g, color.b, 255)
		surface.DrawRect(0, 0, 3, height)

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)
	end

	function skin:PaintChatboxAutocompleteEntry(panel, width, height)
		if (panel.highlightAlpha > 0) then
			self:DrawImportantBackground(0, 0, width, height, ColorAlpha(eui.GetAccent(), panel.highlightAlpha * 66))
		end

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawRect(0, height - 1, width, 1)
	end

	function skin:PaintInfoBar(panel, width, height, color)
		surface.SetDrawColor(color.r, color.g, color.b, 235)
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(255, 255, 255, 20)
		surface.DrawRect(0, 0, width, 1)
	end

	function skin:PaintInfoBarBackground(panel, width, height)
		surface.SetDrawColor(eui.colors.panelLight.r, eui.colors.panelLight.g, eui.colors.panelLight.b, 90)
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)

		panel.bar:PaintManual()

		DisableClipping(true)
			panel.label:PaintManual()
		DisableClipping(false)
	end

	function skin:PaintDeathScreenBackground(panel, width, height, progress)
		surface.SetDrawColor(0, 0, 0, (progress / 0.3) * 255)
		surface.DrawRect(0, 0, width, height)

		if (progress > 0.3) then
			eui.DrawScanlines(0, 0, width, height, 14, 4)

			local danger = eui.colors.danger

			surface.SetDrawColor(danger.r, danger.g, danger.b, 90 * math.min((progress - 0.3) / 0.7, 1))
			surface.DrawRect(0, height * 0.5, width, 1)
		end
	end

	-- строки настроек: акцентный маркер при наведении (c8)
	local oldSettingsRow = skin.PaintSettingsRowBackground

	function skin:PaintSettingsRowBackground(panel, width, height)
		if (oldSettingsRow) then
			oldSettingsRow(self, panel, width, height)
		end

		if (panel:IsHovered()) then
			local accent = eui.GetAccent()

			surface.SetDrawColor(accent.r, accent.g, accent.b, 14)
			surface.DrawRect(0, 0, width, height)

			surface.SetDrawColor(accent.r, accent.g, accent.b, 220)
			surface.DrawRect(0, 0, 2, height)
		end
	end

	-- тёмные стандартные поля ввода и выпадающие списки
	function skin:PaintTextEntry(panel, width, height)
		surface.SetDrawColor(eui.colors.panelLight.r, eui.colors.panelLight.g, eui.colors.panelLight.b, 230)
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)

		panel:DrawTextEntryText(eui.colors.text, eui.GetAccent(), eui.colors.text)
	end

	function skin:PaintComboBox(panel, width, height)
		surface.SetDrawColor(eui.colors.panelLight.r, eui.colors.panelLight.g, eui.colors.panelLight.b, 230)
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(panel:IsHovered() and eui.colors.hairlineBright or eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)
	end

	derma.RefreshSkins()
end
