
--[[
	Enhanced Helix — ui_derma
	Палитры визуальных стилей проектов-референсов. Каждая панель фреймворка
	тянет свой стиль: resilence (монохром), singularity (оранж),
	uprising (красный), resonance (тёмно-красный + редкость), autonomous (циан).
]]

ix.eui = ix.eui or {}

ix.eui.styles = {
	resilence = {
		accent = Color(225, 231, 236),      -- монохромный светлый
		dim = Color(120, 128, 134)
	},
	singularity = {
		accent = Color(235, 122, 40),       -- оранжевый из мастера создания
		teal = Color(0, 190, 210)           -- бирюза терминалов
	},
	uprising = {
		accent = Color(212, 44, 56),        -- фирменный красный
		dim = Color(120, 40, 46)
	},
	resonance = {
		accent = Color(198, 40, 52),        -- тёмно-красный
		rarity = {                          -- цвета редкости предметов
			common = Color(140, 160, 170),
			uncommon = Color(90, 180, 110),
			rare = Color(80, 140, 220),
			epic = Color(160, 90, 220),
			mythic = Color(198, 40, 52),
			gold = Color(220, 170, 60)
		}
	},
	autonomous = {
		accent = Color(0, 190, 230)         -- нейви-циан
	}
}

local function CreateFonts()
	surface.CreateFont("eixGiantFont", {
		font = "Roboto Th",
		size = math.max(ScreenScale(52), 84),
		weight = 100,
		extended = true
	})

	surface.CreateFont("eixCardFont", {
		font = "Roboto Th",
		size = math.max(ScreenScale(14), 26),
		weight = 200,
		extended = true
	})
end

CreateFonts()
hook.Add("LoadFonts", "eixStyleFonts", CreateFonts)
