
--[[
	Enhanced Helix — ui_derma
	Палитры стилей панелей. Имена исторические, цвета приведены к стилю Зоны-19:
	resilence (монохром), singularity/autonomous (янтарь), uprising/resonance (красный + редкость).
]]

ix.eui = ix.eui or {}

-- все стили сведены к палитре Зоны-19: янтарь, светлый монохром и красный «опасность»
ix.eui.styles = {
	resilence = {
		accent = Color(236, 236, 232),      -- светлый монохром
		dim = Color(130, 132, 136)
	},
	singularity = {
		accent = Color(255, 196, 37),       -- янтарь Фонда
		teal = Color(120, 170, 200)         -- холодный акцент терминалов
	},
	uprising = {
		accent = Color(214, 48, 48),        -- красный «опасность»
		dim = Color(110, 36, 36)
	},
	resonance = {
		accent = Color(214, 48, 48),
		rarity = {                          -- цвета редкости предметов
			common = Color(150, 152, 156),
			uncommon = Color(90, 180, 110),
			rare = Color(80, 140, 220),
			epic = Color(160, 90, 220),
			mythic = Color(214, 48, 48),
			gold = Color(255, 196, 37)
		}
	},
	autonomous = {
		accent = Color(255, 196, 37)
	}
}

local function CreateFonts()
	surface.CreateFont("eixGiantFont", {
		font = "Zone19 Sans Black",
		size = math.max(ScreenScale(52), 84),
		weight = 900,
		extended = true
	})

	surface.CreateFont("eixCardFont", {
		font = "Zone19 Sans Semi",
		size = math.max(ScreenScale(12), 24),
		weight = 600,
		extended = true
	})
end

CreateFonts()
hook.Add("LoadFonts", "eixStyleFonts", CreateFonts)
