
--[[
	Enhanced Helix — ui_derma
	Общий стиль меню персонажей «Зона-19»: шрифты (Zone19 Sans — на основе Jost*, JetBrains Mono),
	цвета, рисованные арты в карточках, частицы «обратного дождя» и кнопка с материалом.
	Шрифты и материалы лежат в контент-аддоне scp_intro_content (resource/fonts, materials/scp_menu).
]]

ix.z19 = ix.z19 or {}

local z19 = ix.z19

z19.colors = {
	white = Color(246, 246, 244),
	paper = Color(236, 236, 233),
	ink = Color(18, 18, 20),
	inkSoft = Color(70, 72, 76),
	inkDim = Color(130, 132, 136),
	line = Color(18, 18, 20, 40),
	accent = Color(255, 196, 37), -- жёлтый акцент, как подсветка вкладок в Battlefront
	danger = Color(200, 40, 40)
}

local function CreateFonts()
	local function font(name, face, size, weight, extra)
		local data = {
			font = face,
			size = math.max(math.Round(ScreenScale(size)), 12),
			weight = weight,
			extended = true,
			antialias = true
		}

		if (extra) then
			table.Merge(data, extra)
		end

		surface.CreateFont(name, data)
	end

	font("z19Huge", "Zone19 Sans Bold", 30, 700)
	font("z19Title", "Zone19 Sans Bold", 18, 700)
	font("z19CardTitle", "Zone19 Sans Bold", 16, 700)
	font("z19CardTitleMid", "Zone19 Sans Bold", 13, 700)
	font("z19CardTitleSmall", "Zone19 Sans Bold", 11, 700)
	font("z19CardSub", "Zone19 Sans Semi", 5.2, 600)
	font("z19Tab", "Zone19 Sans Book", 9, 400)
	font("z19Label", "Zone19 Sans Semi", 6.2, 600)
	font("z19Body", "Zone19 Sans Book", 7, 400)
	font("z19BodySmall", "Zone19 Sans Book", 5.8, 400)
	font("z19Entry", "Zone19 Sans Medium", 11, 500)
	font("z19EntrySmall", "Zone19 Sans Book", 7, 400)
	font("z19Button", "Zone19 Sans Bold", 9.5, 700)
	font("z19ButtonSmall", "Zone19 Sans Semi", 6.5, 600)
	font("z19Arrow", "Zone19 Sans Book", 34, 400)
	font("z19Mono", "JetBrains Mono", 5, 400)
	font("z19MonoBold", "JetBrains Mono", 5.5, 700)
end

CreateFonts()
hook.Add("LoadFonts", "z19MenuFonts", CreateFonts)

local materials = {}

function z19.GetMaterial(path)
	if (!materials[path]) then
		materials[path] = Material(path, "smooth")
	end

	return materials[path]
end

-- свои градиенты (белые, альфа задаёт форму): grad_bottom — непрозрачен снизу, grad_left — непрозрачен слева
local gradientBottom = z19.GetMaterial("scp_menu/grad_bottom.png")
local gradientLeft = z19.GetMaterial("scp_menu/grad_left.png")

z19.gradientBottom = gradientBottom
z19.gradientLeft = gradientLeft

-- нарисовать картинку 16:9 внутри прямоугольника «с обрезкой» (cover), с наездом zoom и сдвигом
function z19.DrawCover(material, x, y, width, height, zoom, alpha, offsetX, offsetY, aspect)
	if (!material or material:IsError() or width <= 0 or height <= 0) then
		return
	end

	aspect = aspect or (16 / 9)
	zoom = zoom or 1

	local rectAspect = width / height
	local u, v = 1, 1

	if (rectAspect > aspect) then
		v = aspect / rectAspect
	else
		u = rectAspect / aspect
	end

	u, v = u / zoom, v / zoom

	local cu = 0.5 + (offsetX or 0) * (1 - u) * 0.5
	local cv = 0.5 + (offsetY or 0) * (1 - v) * 0.5

	surface.SetMaterial(material)
	surface.SetDrawColor(255, 255, 255, alpha or 255)
	surface.DrawTexturedRectUV(x, y, width, height, cu - u * 0.5, cv - v * 0.5, cu + u * 0.5, cv + v * 0.5)
end

-- тень под карточкой
function z19.DrawShadow(x, y, width, height, strength)
	strength = strength or 1

	for i = 1, 6 do
		surface.SetDrawColor(0, 0, 0, 10 * strength)
		surface.DrawRect(x - i, y - i + 3, width + i * 2, height + i * 2)
	end
end

-- навести камеру ixModelPanel на модель: focus — доля высоты модели, куда смотрит камера,
-- visible — какую долю высоты модели уместить по вертикали (1.1 — во весь рост, 0.5 — по пояс)
function z19.FrameModel(panel, focus, visible)
	local entity = IsValid(panel) and panel.Entity

	if (!IsValid(entity)) then
		return
	end

	local mins, maxs = entity:GetRenderBounds()
	local modelHeight = math.max(maxs.z - mins.z, 1)
	local target = Vector(0, 0, mins.z + modelHeight * focus)

	-- FOV в Source задан для 4:3 по горизонтали, вертикальный угол от пропорций панели не зависит
	local verticalFOV = 2 * math.atan(math.tan(math.rad(panel:GetFOV()) * 0.5) * 0.75)
	local distance = (modelHeight * visible * 0.5) / math.tan(verticalFOV * 0.5)

	-- ixModelPanel разворачивает модель на 45°, поэтому камера стоит на диагонали лицом к ней
	panel:SetLookAt(target)
	panel:SetCamPos(target + Vector(1, 1, 0):GetNormalized() * distance)
end

-- частицы «обратного дождя»: чёрные штрихи летят снизу вверх
local PARTICLES = {}
PARTICLES.__index = PARTICLES

function z19.CreateParticles(count, color)
	local object = setmetatable({list = {}, color = color or z19.colors.ink}, PARTICLES)

	for i = 1, count do
		object.list[i] = object:Spawn({}, true)
	end

	return object
end

function PARTICLES:Spawn(particle, bAnywhere)
	particle.x = math.Rand(0, 1)
	particle.y = bAnywhere and math.Rand(0, 1.1) or math.Rand(1.02, 1.2)
	particle.depth = math.Rand(0.15, 1)
	particle.speed = Lerp(particle.depth, 0.05, 0.32)
	particle.length = Lerp(particle.depth, 0.01, 0.07) * math.Rand(0.6, 1.4)
	particle.width = particle.depth > 0.85 and 2 or 1
	particle.alpha = Lerp(particle.depth, 25, 150)
	particle.drift = math.Rand(-0.004, 0.004)

	return particle
end

function PARTICLES:Draw(width, height, alpha)
	local frameTime = math.min(FrameTime(), 0.1)
	local color = self.color

	alpha = alpha or 1

	for _, particle in ipairs(self.list) do
		particle.y = particle.y - particle.speed * frameTime
		particle.x = particle.x + particle.drift * frameTime

		if (particle.y + particle.length < -0.02) then
			self:Spawn(particle)
		end

		local x = particle.x * width
		local y = particle.y * height
		local length = particle.length * height

		-- штрих с затухающим хвостом
		surface.SetDrawColor(color.r, color.g, color.b, particle.alpha * alpha)
		surface.DrawRect(x, y, particle.width, length * 0.35)

		surface.SetDrawColor(color.r, color.g, color.b, particle.alpha * alpha * 0.45)
		surface.DrawRect(x, y + length * 0.35, particle.width, length * 0.65)
	end
end

-- белый фон экранов создания/загрузки: бумажный градиент + частицы
function z19.PaintWhiteBackground(panel, width, height, alpha)
	alpha = alpha or 255

	surface.SetDrawColor(z19.colors.white.r, z19.colors.white.g, z19.colors.white.b, alpha)
	surface.DrawRect(0, 0, width, height)

	surface.SetMaterial(gradientBottom)
	surface.SetDrawColor(z19.colors.paper.r, z19.colors.paper.g, z19.colors.paper.b, alpha)
	surface.DrawTexturedRect(0, height * 0.45, width, height * 0.55)

	panel.z19Particles = panel.z19Particles or z19.CreateParticles(140)
	panel.z19Particles:Draw(width, height, alpha / 255)
end

-- текст с разрядкой (для заголовков капсом)
function z19.DrawSpaced(text, font, x, y, spacing, color, alignX)
	surface.SetFont(font)

	local glyphs = {}
	local total = 0

	for _, code in utf8.codes(text) do
		local glyph = utf8.char(code)
		local glyphW = surface.GetTextSize(glyph)

		glyphs[#glyphs + 1] = {glyph, glyphW}
		total = total + glyphW + spacing
	end

	total = total - spacing

	if (alignX == TEXT_ALIGN_CENTER) then
		x = x - total * 0.5
	elseif (alignX == TEXT_ALIGN_RIGHT) then
		x = x - total
	end

	surface.SetTextColor(color)

	for _, data in ipairs(glyphs) do
		surface.SetTextPos(x, y)
		surface.DrawText(data[1])
		x = x + data[2] + spacing
	end

	return total
end

-- кнопка с материалом (ИГРАТЬ / ВЫБРАТЬ)
local BUTTON = {}

AccessorFunc(BUTTON, "label", "Label", FORCE_STRING)
AccessorFunc(BUTTON, "sublabel", "Sublabel", FORCE_STRING)

function BUTTON:Init()
	self:SetText("")
	self:SetCursor("hand")

	self.label = ""
	self.hover = 0
	self.press = 0
end

function BUTTON:OnCursorEntered()
	LocalPlayer():EmitSound("Helix.Rollover")
end

function BUTTON:OnMousePressed(code)
	if (self:GetDisabled()) then
		return
	end

	self.press = 1
	LocalPlayer():EmitSound("Helix.Press")

	baseclass.Get("DButton").OnMousePressed(self, code)
end

function BUTTON:Paint(width, height)
	local frameTime = FrameTime()
	local disabled = self:GetDisabled()

	self.hover = math.Approach(self.hover, (self:IsHovered() and !disabled) and 1 or 0, frameTime * 6)
	self.press = math.Approach(self.press, 0, frameTime * 4)

	local normal = z19.GetMaterial("scp_menu/button_play.png")
	local hover = z19.GetMaterial("scp_menu/button_play_hover.png")
	local alpha = disabled and 110 or 255

	if (!normal:IsError()) then
		surface.SetMaterial(normal)
		surface.SetDrawColor(255, 255, 255, alpha)
		surface.DrawTexturedRect(0, 0, width, height)
	else
		surface.SetDrawColor(z19.colors.ink.r, z19.colors.ink.g, z19.colors.ink.b, alpha)
		surface.DrawRect(0, 0, width, height)
	end

	if (self.hover > 0 and !hover:IsError()) then
		surface.SetMaterial(hover)
		surface.SetDrawColor(255, 255, 255, self.hover * 255)
		surface.DrawTexturedRect(0, 0, width, height)
	end

	-- вспышка нажатия
	if (self.press > 0) then
		surface.SetDrawColor(255, 255, 255, self.press * 60)
		surface.DrawRect(0, 0, width, height)
	end

	local textColor = Color(
		Lerp(self.hover, 246, 18), Lerp(self.hover, 246, 18), Lerp(self.hover, 244, 20), alpha
	)

	local textX = width * 0.56

	draw.SimpleText(self.label, "z19Button", textX, height * (self.sublabel and 0.42 or 0.5),
		textColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

	if (self.sublabel) then
		draw.SimpleText(self.sublabel, "z19Mono", textX, height * 0.74,
			ColorAlpha(textColor, alpha * 0.7), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
end

vgui.Register("z19MaterialButton", BUTTON, "DButton")

-- простая текстовая кнопка («← НАЗАД», «УДАЛИТЬ»)
local TEXTBUTTON = {}

AccessorFunc(TEXTBUTTON, "label", "Label", FORCE_STRING)
AccessorFunc(TEXTBUTTON, "color", "Color")
AccessorFunc(TEXTBUTTON, "font", "LabelFont", FORCE_STRING)

function TEXTBUTTON:Init()
	self:SetText("")
	self:SetCursor("hand")

	self.label = ""
	self.font = "z19ButtonSmall"
	self.color = z19.colors.ink
	self.hover = 0
	self.bOutlined = false
end

function TEXTBUTTON:SetOutlined(bValue)
	self.bOutlined = bValue
end

function TEXTBUTTON:SizeToLabel(paddingX, paddingY)
	surface.SetFont(self.font)

	local width, height = surface.GetTextSize(self.label)
	self:SetSize(width + (paddingX or 24) * 2, height + (paddingY or 10) * 2)
end

function TEXTBUTTON:OnCursorEntered()
	LocalPlayer():EmitSound("Helix.Rollover")
end

function TEXTBUTTON:OnMousePressed(code)
	if (self:GetDisabled()) then
		return
	end

	LocalPlayer():EmitSound("Helix.Press")
	baseclass.Get("DButton").OnMousePressed(self, code)
end

function TEXTBUTTON:Paint(width, height)
	local bActive = (self:IsHovered() or self.bSelected) and !self:GetDisabled()
	self.hover = math.Approach(self.hover, bActive and 1 or 0, FrameTime() * 6)

	local color = self.color
	local alpha = self:GetDisabled() and 90 or 255

	if (self.bOutlined) then
		surface.SetDrawColor(255, 255, 255, 230)
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(color.r, color.g, color.b, alpha)
		surface.DrawOutlinedRect(0, 0, width, height, 2)

		if (self.hover > 0) then
			surface.SetDrawColor(color.r, color.g, color.b, self.hover * alpha)
			surface.DrawRect(0, 0, width, height)
		end

		local inverse = Lerp(self.hover, 0, 1)
		local textColor = Color(
			Lerp(inverse, color.r, 246), Lerp(inverse, color.g, 246), Lerp(inverse, color.b, 244), alpha
		)

		draw.SimpleText(self.label, self.font, width * 0.5, height * 0.5, textColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	else
		draw.SimpleText(self.label, self.font, width * 0.5, height * 0.5, ColorAlpha(color, alpha * (0.7 + self.hover * 0.3)),
			TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

		surface.SetFont(self.font)
		local textW = surface.GetTextSize(self.label)

		surface.SetDrawColor(z19.colors.accent.r, z19.colors.accent.g, z19.colors.accent.b, alpha)
		surface.DrawRect(width * 0.5 - textW * 0.5, height - 3, textW * self.hover, 3)
	end
end

vgui.Register("z19TextButton", TEXTBUTTON, "DButton")

-- поле ввода на белом фоне: крупный текст и толстая линия снизу
DEFINE_BASECLASS("DTextEntry")
local ENTRY = {}

AccessorFunc(ENTRY, "backgroundColor", "BackgroundColor")

function ENTRY:Init()
	self:SetPaintBackground(false)
	self:SetTextColor(z19.colors.ink)
	self:SetCursorColor(z19.colors.ink)
	self:SetHighlightColor(ColorAlpha(z19.colors.accent, 160))
	self:SetFont("z19Entry")

	self.focus = 0
end

function ENTRY:SetFont(font)
	surface.SetFont(font)
	local _, height = surface.GetTextSize("W@Й")

	self:SetTall(height + 14)
	BaseClass.SetFont(self, font)
end

function ENTRY:Paint(width, height)
	self.focus = math.Approach(self.focus, self:HasFocus() and 1 or 0, FrameTime() * 6)

	surface.SetDrawColor(255, 255, 255, 200 + self.focus * 55)
	surface.DrawRect(0, 0, width, height)

	surface.SetDrawColor(z19.colors.line)
	surface.DrawOutlinedRect(0, 0, width, height)

	surface.SetDrawColor(z19.colors.ink.r, z19.colors.ink.g, z19.colors.ink.b, 255)
	surface.DrawRect(0, height - 2, width, 2)

	surface.SetDrawColor(z19.colors.accent.r, z19.colors.accent.g, z19.colors.accent.b, 255)
	surface.DrawRect(0, height - 3, width * self.focus, 3)

	if (self:GetValue() == "" and self.placeholderText and !self:HasFocus()) then
		draw.SimpleText(self.placeholderText, "z19EntrySmall", 8, self:IsMultiline() and 8 or height * 0.5,
			z19.colors.inkDim, TEXT_ALIGN_LEFT, self:IsMultiline() and TEXT_ALIGN_TOP or TEXT_ALIGN_CENTER)
	end

	BaseClass.Paint(self, width, height)
end

function ENTRY:SetPlaceholder(text)
	self.placeholderText = text
end

vgui.Register("z19TextEntry", ENTRY, "DTextEntry")
