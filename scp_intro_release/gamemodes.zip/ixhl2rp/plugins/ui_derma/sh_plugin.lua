local PLUGIN = PLUGIN

PLUGIN.name = "Enhanced UI (Derma)"
PLUGIN.author = "Enhanced Helix"
PLUGIN.description = "Визуальный рестайл фреймворка в стиле Зоны-19: тема «графит + янтарь» (волосяные линии, угловые скобки, сканлайны, моно-подписи), рестайл меню персонажей, создания и загрузки персонажа, вкладочного меню, кнопок, тултипов, скорборда, инвентаря и нотисов; глобальный скин: рамки, контекстные меню, чатбокс, категории, прогресс, слайдеры, скроллбары, экран смерти."

if (CLIENT) then
	ix.lang.AddTable("russian", {
		optDeployAnimation = "Анимация входа персонажа",
		optdDeployAnimation = "Показывать заставку идентификации при загрузке персонажа."
	})

	ix.lang.AddTable("english", {
		optDeployAnimation = "Character deploy animation",
		optdDeployAnimation = "Show the identification sequence when a character is loaded."
	})
end
