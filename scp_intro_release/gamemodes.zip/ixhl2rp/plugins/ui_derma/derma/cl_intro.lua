
--[[
	Enhanced Helix — ui_derma
	Вступительная заставка «Зона-19»: нарисованные кадры, раскадровка по времени,
	звуки из SCP: Containment Breach (CC BY-SA 3.0).

	Кадры:
		1. Сирена тяжёлой зоны содержания (мигающий красный свет)
		2. Ноги бегущих сотрудников СБ
		3. Шлемы сотрудников СБ крупным планом
		4. SCP-106 утаскивает одного из трёх сотрудников
		5. Открываются гермоворота выхода «А», входит МОГ Эпсилон-11
		6. Эмблема Фонда, затемнение

	Материалы и звуки лежат в отдельном контент-аддоне (materials/scp_intro, sound/scp_intro).
	Пропуск: [ПРОБЕЛ] или кнопка в правом нижнем углу.
]]

DEFINE_BASECLASS("EditablePanel")

local MATERIAL_PATH = "scp_intro/"
local SOUND_PATH = "sound/scp_intro/"

local FADE_OUT_TIME = 1.6 -- затухание в самом конце / при пропуске
local INTRO_LENGTH = 44.5 -- когда начинается финальное затухание

local gradientUp = Material("vgui/gradient-u")
local gradientLeft = Material("vgui/gradient-l")
local gradientRight = Material("vgui/gradient-r")

local function CreateFonts()
	surface.CreateFont("scpIntroTitle", {
		font = "Zone19 Sans Bold",
		size = math.min(math.max(ScreenScale(34), 48), 128),
		weight = 900,
		extended = true
	})

	surface.CreateFont("scpIntroSubtitle", {
		font = "Zone19 Sans Medium",
		size = math.max(ScreenScale(7.5), 16),
		weight = 500,
		extended = true
	})

	surface.CreateFont("scpIntroCaption", {
		font = "Zone19 Sans Bold",
		size = math.max(ScreenScale(9.5), 20),
		weight = 700,
		extended = true
	})

	surface.CreateFont("scpIntroCaptionShadow", {
		font = "Zone19 Sans Bold",
		size = math.max(ScreenScale(9.5), 20),
		weight = 700,
		blursize = 4,
		extended = true
	})

	surface.CreateFont("scpIntroMotto", {
		font = "Zone19 Sans Book",
		size = math.max(ScreenScale(9), 18),
		weight = 300,
		extended = true
	})

	surface.CreateFont("scpIntroKey", {
		font = "Zone19 Sans Bold",
		size = math.max(ScreenScale(5.5), 13),
		weight = 800,
		extended = true
	})

	surface.CreateFont("scpIntroSkip", {
		font = "Zone19 Sans Medium",
		size = math.max(ScreenScale(6.5), 15),
		weight = 500,
		extended = true
	})
end

CreateFonts()
hook.Add("LoadFonts", "scpIntroFonts", CreateFonts)

local materials = {}

local function GetMaterial(name)
	if (!materials[name]) then
		materials[name] = Material(MATERIAL_PATH .. name, "smooth noclamp")
	end

	return materials[name]
end

-- плавные функции
local function Clamp01(x)
	return math.Clamp(x, 0, 1)
end

local function Smooth(x)
	x = Clamp01(x)
	return x * x * (3 - 2 * x)
end

local function EaseOut(x)
	x = Clamp01(x)
	return 1 - (1 - x) ^ 3
end

local function EaseInOut(x)
	x = Clamp01(x)
	return x < 0.5 and 4 * x * x * x or 1 - (-2 * x + 2) ^ 3 / 2
end

-- окно видимости: появление за fadeIn, исчезание за fadeOut
local function Window(t, length, fadeIn, fadeOut)
	return Clamp01(t / fadeIn) * Clamp01((length - t) / fadeOut)
end

-- нарисовать материал «на весь экран» (cover) с наездом камеры и смещением
local function DrawCover(material, width, height, zoom, panX, panY, alpha, rotation)
	if (!material or material:IsError()) then
		return
	end

	local scale = math.max(width / 16, height / 9) * (zoom or 1)
	local drawW, drawH = 16 * scale, 9 * scale
	local x = width * 0.5 + (panX or 0) * width
	local y = height * 0.5 + (panY or 0) * height

	surface.SetMaterial(material)
	surface.SetDrawColor(255, 255, 255, alpha or 255)
	surface.DrawTexturedRectRotated(x, y, drawW, drawH, rotation or 0)

	return x - drawW * 0.5, y - drawH * 0.5, drawW, drawH
end

local function DrawGlow(x, y, size, color, alpha)
	local material = GetMaterial("glow.png")

	if (material:IsError()) then
		return
	end

	render.OverrideBlend(true, BLEND_SRC_ALPHA, BLEND_ONE, BLENDFUNC_ADD)
		surface.SetMaterial(material)
		surface.SetDrawColor(color.r, color.g, color.b, alpha)
		surface.DrawTexturedRect(x - size * 0.5, y - size * 0.5, size, size)
	render.OverrideBlend(false)
end

-- субтитры по кадрам (время от начала интро)
local captions = {
	{1.6, 7.6, "Нарушение условий содержания. Объекты класса «Кетер» покинули свои камеры."},
	{8.6, 13.2, "Служба безопасности Фонда поднята по тревоге."},
	{14.0, 18.6, "Им приказано удержать коридор тяжёлой зоны любой ценой."},
	{19.8, 26.4, "Но есть угрозы, которые невозможно остановить пулями."},
	{28.0, 35.0, "К выходу «А» прибыла МОГ Эпсилон-11 «Девятихвостая лиса»."}
}

-- звуки: {время, файл, громкость, ключ, зациклить}
local soundEvents = {
	{0.0, "siren_loop.ogg", 0.55, "siren", true},
	{1.2, "pa_breach.ogg", 0.9, "pa"},
	{8.0, "run_squad.ogg", 1.0, "run"},
	{13.5, "breath.ogg", 0.8, "breath"},
	{13.7, "radio_squelch.ogg", 0.6},
	{16.2, "radio_squelch.ogg", 0.6},
	{18.4, "sting_horror.ogg", 0.8, "sting"},
	{19.0, "scp106_music.ogg", 0.5, "music106"},
	{19.0, "scp106_decay.ogg", 0.45, "decay"},
	{19.3, "scp106_corrosion.ogg", 1.0},
	{20.2, "scp106_laugh.ogg", 1.0},
	{21.3, "scp106_abduct.ogg", 1.0},
	{24.6, "bodyfall.ogg", 0.7},
	{27.0, "gate_open.ogg", 1.0, "gate"},
	{27.8, "mtf_announce.ogg", 0.95, "announce"},
	{29.0, "mtf_march.ogg", 0.9, "march"},
	{35.5, "sting_logo.ogg", 1.0, "logo"}
}

-- изменения громкости: {время, ключ, целевая громкость, длительность}
local volumeEvents = {
	{8.0, "siren", 0.3, 1.0},
	{18.5, "pa", 0, 1.2},
	{19.0, "siren", 0.15, 1.0},
	{26.0, "music106", 0, 2.0},
	{26.0, "decay", 0, 1.5},
	{27.5, "siren", 0, 1.5},
	{42.5, "announce", 0, 2.0}
}

-- раскадровка: {начало, длительность, функция отрисовки}
local scenes = {}
local PANEL = {}

-- 1. Сирена
scenes[1] = {0, 8.0, function(self, w, h, t, alpha)
	local blink = Smooth((math.sin(t * math.pi * 2 * 0.75 - math.pi * 0.5) + 1) * 0.5 * 1.6 - 0.3)
	local zoom = 1.12 - EaseOut(t / 8) * 0.08

	local x, y, drawW, drawH = DrawCover(GetMaterial("s1_siren_off.jpg"), w, h, zoom, 0, 0, alpha)
	DrawCover(GetMaterial("s1_siren_on.jpg"), w, h, zoom, 0, 0, alpha * blink)

	-- красная заливка от сирены
	surface.SetDrawColor(255, 20, 10, alpha * blink * 0.3)
	surface.DrawRect(0, 0, w, h)

	-- свечение привязано к лампе на кадре (с учётом наезда камеры)
	if (x) then
		DrawGlow(x + drawW * self.sirenX, y + drawH * self.sirenY, h * 1.4, Color(255, 40, 20), alpha * blink * 0.9)
	end

	-- заголовок
	local titleAlpha = alpha * Smooth((t - 0.8) / 1.2)

	draw.SimpleText("ЗОНА-19", "scpIntroTitle", w * 0.07 + 3, h * 0.17 + 3, Color(0, 0, 0, titleAlpha * 0.6))
	draw.SimpleText("ЗОНА-19", "scpIntroTitle", w * 0.07, h * 0.17, Color(235, 235, 235, titleAlpha))

	surface.SetFont("scpIntroTitle")
	local _, titleH = surface.GetTextSize("ЗОНА-19")
	local subtitleAlpha = alpha * Smooth((t - 1.6) / 1.0)

	surface.SetDrawColor(200, 30, 30, subtitleAlpha)
	surface.DrawRect(w * 0.07, h * 0.17 + titleH + 4, w * 0.18 * EaseOut((t - 1.4) / 1.2), 3)

	draw.SimpleText("ТЯЖЁЛАЯ ЗОНА СОДЕРЖАНИЯ  ·  03:47  ·  КОД «ЧЁРНЫЙ»", "scpIntroSubtitle",
		w * 0.07, h * 0.17 + titleH + 14, Color(220, 210, 210, subtitleAlpha))
end}

-- 2. Ноги сотрудников СБ
scenes[2] = {8.0, 5.5, function(self, w, h, t, alpha)
	-- камера трясётся в такт бегу
	local bob = math.abs(math.sin(t * math.pi * 3.2)) * 0.006
	local sway = math.sin(t * math.pi * 1.6) * 0.004

	DrawCover(GetMaterial("s2_legs.jpg"), w, h, 1.14 - t * 0.012, -0.02 + t * 0.006 + sway, -bob, alpha)
	self:DrawAlarmPulse(w, h, t, alpha * 0.6)
end}

-- 3. Шлемы
scenes[3] = {13.5, 5.5, function(self, w, h, t, alpha)
	local breathe = math.sin(t * math.pi * 0.9) * 0.004

	DrawCover(GetMaterial("s3_helmets.jpg"), w, h, 1.04 + EaseInOut(t / 5.5) * 0.08 + breathe, 0, 0, alpha)
	self:DrawAlarmPulse(w, h, t, alpha * 0.7)
end}

-- 4. SCP-106
scenes[4] = {19.0, 8.0, function(self, w, h, t, alpha)
	-- рывок и тряска в момент захвата
	local grab = Clamp01((t - 2.2) / 0.15) * Clamp01((4.5 - t) / 1.5)
	local shake = grab * 0.012
	local shakeX = (math.Rand(-1, 1)) * shake
	local shakeY = (math.Rand(-1, 1)) * shake
	local zoom = 1.06 + EaseOut(t / 8) * 0.1 + grab * 0.03

	-- мигающий свет фонаря
	local flicker = 1

	if (t < 2.4 or (t > 4.5 and t < 5.5)) then
		flicker = math.random() > 0.12 and 1 or 0.35
	end

	DrawCover(GetMaterial("s4_scp106.jpg"), w, h, zoom, shakeX, shakeY, alpha * flicker)

	-- красная вспышка при захвате
	surface.SetDrawColor(140, 0, 0, alpha * grab * 0.35 * (0.6 + math.sin(t * 40) * 0.4))
	surface.DrawRect(0, 0, w, h)

	-- тьма карманного измерения поднимается снизу и поглощает кадр
	local swallow = EaseInOut((t - 5.4) / 2.4)

	if (swallow > 0) then
		surface.SetDrawColor(10, 6, 4, alpha * swallow)
		surface.SetMaterial(gradientUp)
		surface.DrawTexturedRect(0, h * (1 - swallow * 1.6), w, h * 0.6)
		surface.DrawRect(0, h * (1 - swallow * 1.6) + h * 0.6 - 1, w, h)
	end
end}

-- 5. Гермоворота выхода «А»
scenes[5] = {27.0, 8.5, function(self, w, h, t, alpha)
	local open = EaseInOut((t - 0.4) / 5.2)
	local zoom = 1.12 - EaseOut(t / 8.5) * 0.08

	-- за воротами: свет и входящая МОГ
	local x, y, drawW, drawH = DrawCover(GetMaterial("s5_gate.jpg"), w, h, zoom, 0, 0, alpha)

	-- створки закрытых ворот разъезжаются в стороны
	local closed = GetMaterial("s5_gate_closed.jpg")

	if (x and !closed:IsError() and open < 1) then
		local slide = drawW * 0.5 * open

		surface.SetMaterial(closed)
		surface.SetDrawColor(255, 255, 255, alpha)
		surface.DrawTexturedRectUV(x - slide, y, drawW * 0.5, drawH, 0, 0, 0.5, 1)
		surface.DrawTexturedRectUV(x + drawW * 0.5 + slide, y, drawW * 0.5, drawH, 0.5, 0, 1, 1)

		-- свет бьёт из щели
		local gapAlpha = alpha * Clamp01(open * 6) * (1 - open * 0.6)

		surface.SetDrawColor(220, 235, 255, gapAlpha)
		surface.SetMaterial(gradientRight)
		surface.DrawTexturedRect(x + drawW * 0.5 - slide - w * 0.06, y, w * 0.06, drawH)
		surface.SetMaterial(gradientLeft)
		surface.DrawTexturedRect(x + drawW * 0.5 + slide, y, w * 0.06, drawH)
	end

	-- вспышка открытия
	DrawGlow(w * 0.5, h * 0.45, h * 2.2, Color(200, 225, 255), alpha * Clamp01(open * 3) * (1 - open) * 0.9)

	self:DrawSnow(w, h, t, alpha * Clamp01(open * 2))
end}

-- 6. Эмблема Фонда
scenes[6] = {35.5, INTRO_LENGTH + FADE_OUT_TIME - 35.5, function(self, w, h, t, alpha)
	surface.SetDrawColor(4, 5, 7, alpha)
	surface.DrawRect(0, 0, w, h)

	local appear = EaseOut(t / 2.2)
	local size = h * 0.42 * (1.25 - appear * 0.25)
	local rotation = (1 - appear) * 60
	local logo = GetMaterial("logo.png")
	local cx, cy = w * 0.5, h * 0.43

	-- пульсирующее свечение за эмблемой
	local pulse = 0.5 + math.sin(t * 2.2) * 0.15
	DrawGlow(cx, cy, size * 2.6, Color(180, 190, 200), alpha * appear * pulse * 0.35)

	if (!logo:IsError()) then
		surface.SetMaterial(logo)

		-- «эхо» эмблемы при появлении
		surface.SetDrawColor(220, 225, 230, alpha * appear * (1 - appear) * 0.6)
		surface.DrawTexturedRectRotated(cx, cy, size * (1 + (1 - appear) * 0.5), size * (1 + (1 - appear) * 0.5), -rotation)

		surface.SetDrawColor(235, 238, 240, alpha * appear)
		surface.DrawTexturedRectRotated(cx, cy, size, size, rotation)
	end

	-- блик, проходящий по эмблеме
	local sweep = Clamp01((t - 2.0) / 1.2)

	if (sweep > 0 and sweep < 1) then
		render.SetScissorRect(cx - size * 0.5, cy - size * 0.5, cx + size * 0.5, cy + size * 0.5, true)
			surface.SetDrawColor(255, 255, 255, alpha * 0.35 * math.sin(sweep * math.pi))
			surface.SetMaterial(gradientRight)
			surface.DrawTexturedRect(cx - size + sweep * size * 2 - size * 0.15, cy - size * 0.5, size * 0.15, size)
			surface.SetMaterial(gradientLeft)
			surface.DrawTexturedRect(cx - size + sweep * size * 2, cy - size * 0.5, size * 0.15, size)
		render.SetScissorRect(0, 0, 0, 0, false)
	end

	-- название и девиз
	local textAlpha = alpha * Smooth((t - 1.6) / 1.2)
	local spacing = (1 - EaseOut((t - 1.6) / 2.5)) * 18

	self:DrawSpacedText("ФОНД SCP", "scpIntroTitle", cx, cy + size * 0.5 + h * 0.035, spacing + 6,
		Color(235, 235, 235, textAlpha))

	draw.SimpleText("ОБЕЗОПАСИТЬ.  УДЕРЖАТЬ.  СОХРАНИТЬ.", "scpIntroMotto", cx, cy + size * 0.5 + h * 0.155,
		Color(170, 175, 180, alpha * Smooth((t - 2.8) / 1.4)), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end}

function PANEL:Init()
	if (IsValid(ix.gui.intro)) then
		ix.gui.intro:Remove(true)
	end

	ix.gui.intro = self

	self:SetSize(ScrW(), ScrH())
	self:SetPos(0, 0)
	self:SetZPos(99999)
	self:MakePopup()

	self.channels = {}
	self.volumes = {}
	self.fades = {}
	self.firedSounds = {}
	self.firedVolumes = {}
	self.particles = {}
	self.master = 1
	self.skipAlpha = 0

	-- положение лампы сирены на кадре 1 (доли картинки) — для красного свечения
	self.sirenX = 0.845
	self.sirenY = 0.735

	-- прогреваем материалы, чтобы не было подвисаний посреди интро
	for _, name in ipairs({"s1_siren_off.jpg", "s1_siren_on.jpg", "s2_legs.jpg", "s3_helmets.jpg", "s4_scp106.jpg",
		"s5_gate.jpg", "s5_gate_closed.jpg", "logo.png", "glow.png"}) do
		GetMaterial(name)
	end

	self:CreateSkipButton()
end

function PANEL:CreateSkipButton()
	local button = self:Add("DButton")
	button:SetText("")
	button:SetCursor("hand")
	button.hover = 0

	button.Paint = function(this, width, height)
		local alpha = self.skipAlpha * 255
		this.hover = math.Approach(this.hover, this:IsHovered() and 1 or 0, FrameTime() * 6)

		surface.SetFont("scpIntroKey")
		local keyW, keyH = surface.GetTextSize("ПРОБЕЛ")
		keyW, keyH = keyW + 22, keyH + 10

		local keyX, keyY = 0, (height - keyH) * 0.5

		-- клавиша
		surface.SetDrawColor(20, 22, 26, alpha * (0.75 + this.hover * 0.25))
		surface.DrawRect(keyX, keyY, keyW, keyH)
		surface.SetDrawColor(220, 225, 230, alpha * (0.55 + this.hover * 0.45))
		surface.DrawOutlinedRect(keyX, keyY, keyW, keyH)
		surface.DrawRect(keyX + 2, keyY + keyH - 3, keyW - 4, 1)

		draw.SimpleText("ПРОБЕЛ", "scpIntroKey", keyX + keyW * 0.5, keyY + keyH * 0.5 - 1,
			Color(235, 238, 240, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

		draw.SimpleText("Пропустить", "scpIntroSkip", keyX + keyW + 12, height * 0.5,
			Color(220 + this.hover * 35, 225 + this.hover * 30, 230 + this.hover * 25, alpha * (0.75 + this.hover * 0.25)),
			TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	button.DoClick = function()
		if (self.skipAlpha > 0.1) then
			self:Skip()
		end
	end

	surface.SetFont("scpIntroKey")
	local keyW = surface.GetTextSize("ПРОБЕЛ") + 22
	surface.SetFont("scpIntroSkip")
	local labelW, labelH = surface.GetTextSize("Пропустить")

	button:SetSize(keyW + 12 + labelW + 4, math.max(labelH, 24) + 16)
	button:SetPos(ScrW() - button:GetWide() - ScreenScale(14), ScrH() - button:GetTall() - ScreenScale(8))

	self.skipButton = button
end

-- @todo h a c k
function PANEL:Think()
	if (!self.bStarted) then
		if (IsValid(LocalPlayer())) then
			self.bStarted = true
			self:BeginIntro()
		end

		return
	end

	if (!self.startTime) then
		return
	end

	local time = self:GetTime()

	-- звуки по раскадровке
	for index, event in ipairs(soundEvents) do
		if (!self.firedSounds[index] and time >= event[1] and !self.bClosing) then
			self.firedSounds[index] = true
			self:PlaySound(event[2], event[3], event[4], event[5])
		end
	end

	for index, event in ipairs(volumeEvents) do
		if (!self.firedVolumes[index] and time >= event[1]) then
			self.firedVolumes[index] = true
			self:FadeSound(event[2], event[3], event[4])
		end
	end

	-- плавная громкость
	local now = SysTime()

	for key, channel in pairs(self.channels) do
		if (IsValid(channel)) then
			local fade = self.fades[key]
			local volume = self.volumes[key] or 1

			if (fade) then
				local fraction = Clamp01((now - fade.start) / fade.duration)
				volume = Lerp(fraction, fade.from, fade.to)
				self.volumes[key] = volume

				if (fraction >= 1) then
					self.fades[key] = nil

					if (volume <= 0) then
						channel:Stop()
					end
				end
			end

			channel:SetVolume(volume * self.master)
		end
	end

	self.skipAlpha = math.Approach(self.skipAlpha, (time > 0.8 and !self.bClosing) and 1 or 0, FrameTime() * 2)

	-- конец интро
	if (time >= INTRO_LENGTH and !self.bClosing) then
		self:Close()
	end

	if (self.bClosing) then
		self.master = 1 - Clamp01((SysTime() - self.closeStart) / FADE_OUT_TIME)

		if (self.master <= 0) then
			self:Remove(true)
		end
	end
end

function PANEL:GetTime()
	return self.startTime and (SysTime() - self.startTime) or 0
end

function PANEL:BeginIntro()
	-- something could have errored on startup and invalidated all options, so we'll be extra careful with setting the option
	-- because if it errors here, the sound will play each tick and proceed to hurt ears
	local bLoaded = false

	if (ix and ix.option and ix.option.Set) then
		local bSuccess, _ = pcall(ix.option.Set, "showIntro", false)
		bLoaded = bSuccess
	end

	if (!bLoaded) then
		self:Remove(true)

		if (ix and ix.gui and IsValid(ix.gui.characterMenu)) then
			ix.gui.characterMenu:Remove()
		end

		ErrorNoHalt(
			"[Helix] Something has errored and prevented the framework from loading correctly - check your console for errors!\n")

		return
	end

	self:MoveToFront()
	self:RequestFocus()

	-- небольшая пауза в темноте перед первым кадром
	timer.Create("ixIntroStart", 0.6, 1, function()
		if (IsValid(self)) then
			self.startTime = SysTime()
		end
	end)
end

function PANEL:PlaySound(name, volume, key, bLoop)
	key = key or (name .. SysTime())

	sound.PlayFile(SOUND_PATH .. name, "noplay noblock", function(channel)
		if (!IsValid(channel)) then
			return
		end

		if (!IsValid(self) or self.bClosing) then
			channel:Stop()
			return
		end

		channel:SetVolume(volume * self.master)
		channel:EnableLooping(bLoop and true or false)
		channel:Play()

		if (IsValid(self.channels[key])) then
			self.channels[key]:Stop()
		end

		self.channels[key] = channel
		self.volumes[key] = volume
	end)
end

function PANEL:FadeSound(key, target, duration)
	local channel = self.channels[key]

	if (IsValid(channel)) then
		self.fades[key] = {
			from = self.volumes[key] or 1,
			to = target,
			start = SysTime(),
			duration = duration
		}
	end
end

-- отголосок тревоги в кадрах после сирены
function PANEL:DrawAlarmPulse(width, height, time, alpha)
	local blink = Smooth((math.sin((time + 8) * math.pi * 2 * 0.75 - math.pi * 0.5) + 1) * 0.5 * 1.6 - 0.3)

	surface.SetDrawColor(255, 10, 0, alpha * blink * 0.22)
	surface.DrawRect(0, 0, width, height)
end

function PANEL:DrawSnow(width, height, time, alpha)
	if (alpha <= 0) then
		return
	end

	local count = 140

	if (#self.particles == 0) then
		for i = 1, count do
			self.particles[i] = {
				x = math.Rand(0, 1),
				y = math.Rand(0, 1),
				z = math.Rand(0.3, 1),
				speed = math.Rand(0.15, 0.45),
				phase = math.Rand(0, math.pi * 2)
			}
		end
	end

	local frameTime = FrameTime()

	for _, particle in ipairs(self.particles) do
		-- снег летит из ворот на камеру
		particle.y = particle.y + particle.speed * frameTime * 0.6
		particle.x = particle.x + (particle.x - 0.5) * frameTime * particle.z * 0.5 + math.sin(time + particle.phase) * frameTime * 0.02

		if (particle.y > 1.05 or particle.x < -0.05 or particle.x > 1.05) then
			particle.x = math.Rand(0.35, 0.65)
			particle.y = math.Rand(0.2, 0.6)
		end

		local size = math.max(1, particle.z * ScreenScale(1.6))

		surface.SetDrawColor(230, 240, 255, alpha * particle.z * 0.8)
		surface.DrawRect(particle.x * width, particle.y * height, size, size * 1.4)
	end
end

function PANEL:DrawSpacedText(text, font, x, y, spacing, color)
	surface.SetFont(font)

	local characters = {}
	local total = 0

	for _, code in utf8.codes(text) do
		local character = utf8.char(code)
		local charW = surface.GetTextSize(character)

		characters[#characters + 1] = {character, charW}
		total = total + charW + spacing
	end

	total = total - spacing

	local cursor = x - total * 0.5

	surface.SetTextColor(color)

	for _, data in ipairs(characters) do
		surface.SetTextPos(cursor, y)
		surface.DrawText(data[1])
		cursor = cursor + data[2] + spacing
	end
end

function PANEL:DrawCaption(width, height, time, alpha)
	for _, caption in ipairs(captions) do
		local start, finish, text = caption[1], caption[2], caption[3]

		if (time >= start and time <= finish) then
			local captionAlpha = alpha * Window(time - start, finish - start, 0.35, 0.5)

			-- печатающийся текст
			local length = utf8.len(text) or #text
			local shown = math.min(length, math.floor((time - start) * 42))
			local cut = utf8.offset(text, shown + 1)
			local visible = cut and text:sub(1, cut - 1) or text

			local x, y = width * 0.5, height * 0.86

			draw.SimpleText(text, "scpIntroCaptionShadow", x, y, Color(0, 0, 0, captionAlpha * 0.9 * (shown / length)),
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

			-- выравниваем по полной строке, чтобы текст не «ехал»
			surface.SetFont("scpIntroCaption")
			local fullW, fullH = surface.GetTextSize(text)

			surface.SetTextColor(240, 240, 240, captionAlpha)
			surface.SetTextPos(x - fullW * 0.5, y - fullH * 0.5)
			surface.DrawText(visible)
		end
	end
end

function PANEL:Paint(width, height)
	surface.SetDrawColor(0, 0, 0, 255)
	surface.DrawRect(0, 0, width, height)

	local time = self:GetTime()

	if (!self.startTime) then
		return
	end

	for _, scene in ipairs(scenes) do
		local start, length, drawScene = scene[1], scene[2], scene[3]
		local t = time - start

		if (t >= 0 and t <= length) then
			local alpha = 255 * Window(t, length, 0.45, 0.35)
			drawScene(self, width, height, t, alpha)
		end
	end

	self:DrawCaption(width, height, time, 255)
end

function PANEL:PaintOver(width, height)
	-- при закрытии весь экран интро плавно исчезает, открывая меню персонажей
	if (self.bClosing) then
		self:SetAlpha(255 * self.master)
	end
end

function PANEL:OnKeyCodePressed(key)
	if (key == KEY_SPACE and self.skipAlpha > 0.1) then
		self:Skip()
	end
end

function PANEL:Skip()
	self:Close()
end

function PANEL:Close()
	if (self.bClosing) then
		return
	end

	self.bClosing = true
	self.closeStart = SysTime()

	self:SetMouseInputEnabled(false)
	self:SetKeyboardInputEnabled(false)
end

function PANEL:OnRemove()
	timer.Remove("ixIntroStart")

	for _, channel in pairs(self.channels or {}) do
		if (IsValid(channel)) then
			channel:Stop()
		end
	end

	if (IsValid(ix.gui.characterMenu)) then
		ix.gui.characterMenu:PlayMusic()
	end
end

function PANEL:Remove(bForce)
	if (bForce) then
		BaseClass.Remove(self)
		return
	end

	self:Close()
end

vgui.Register("ixIntro", PANEL, "EditablePanel")
