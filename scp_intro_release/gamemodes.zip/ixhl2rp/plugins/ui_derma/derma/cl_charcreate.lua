
--[[
	Enhanced Helix — ui_derma
	Создание бойца (ixCharMenuNew) на одном экране: белый фон с «обратным дождём»,
	слева сверху — «Введите имя» и «Введите описание», под ними у края — навыки,
	по центру справа стоит модель, у правого края — фракция и выбор модели,
	справа снизу — кнопка «Играть» с материалом.
	Payload, хуки переменных персонажа, валидация и сетевые сообщения — как в оригинале.
]]

local z19 = ix.z19

-- переменные, у которых на этом экране свои виджеты; остальные (из плагинов) выводятся под описанием
local CUSTOM_VARS = {
	name = true,
	description = true,
	model = true,
	attributes = true
}

-- закрепить порядок докинга: при равных ZPos GMod раскладывает Dock по z-порядку,
-- а клик по элементу поднимает его наверх — блоки начинали «съезжать» друг под друга
local function LockDockOrder(panel)
	for i, child in ipairs(panel:GetChildren()) do
		child:SetZPos(i)
	end
end

-- строка навыка: название, сегменты значения, кнопки «−» и «+»
local SKILL = {}

function SKILL:Init()
	self:SetTall(ScreenScale(13))
	self.value = 0
	self.maximum = 10

	-- порядок докинга по ZPos: «+» у самого края, «−» левее
	self.minus = self:Add("z19TextButton")
	self.minus:SetLabel("−")
	self.minus:SetLabelFont("z19ButtonSmall")
	self.minus:SetOutlined(true)
	self.minus:Dock(RIGHT)
	self.minus:SetZPos(1)
	self.minus.DoClick = function()
		self:Change(-1)
	end

	self.plus = self:Add("z19TextButton")
	self.plus:SetLabel("+")
	self.plus:SetLabelFont("z19ButtonSmall")
	self.plus:SetOutlined(true)
	self.plus:Dock(RIGHT)
	self.minus:DockMargin(0, 0, ScreenScale(2), 0)
	self.plus:SetZPos(0)
	self.plus.DoClick = function()
		self:Change(1)
	end
end

function SKILL:PerformLayout(width, height)
	self.minus:SetWide(height)
	self.plus:SetWide(height)
end

function SKILL:SetSkill(name, maximum, bReadOnly)
	self.name = name
	self.maximum = maximum
	self.bReadOnly = bReadOnly

	self.minus:SetDisabled(bReadOnly)
	self.plus:SetDisabled(bReadOnly)
end

function SKILL:Change(difference)
	if (self.bReadOnly) then
		return
	end

	local newValue = self.value + difference

	if (newValue < 0 or newValue > self.maximum) then
		return
	end

	if (self.OnChanged and self:OnChanged(difference) == false) then
		return
	end

	self.value = newValue
end

function SKILL:Paint(width, height)
	local buttonsW = height * 2 + ScreenScale(4)
	local nameW = width * 0.38

	draw.SimpleText(self.name or "", "z19Body", 0, height * 0.5, z19.colors.ink, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

	-- сегменты
	local valueW = ScreenScale(8)
	local barX = nameW
	local barW = width - nameW - buttonsW - valueW
	local count = math.max(self.maximum, 1)
	local gap = 2
	local segmentW = (barW - gap * (count - 1)) / count
	local segmentH = height * 0.36
	local segmentY = height * 0.5 - segmentH * 0.5

	for i = 1, count do
		local x = barX + (i - 1) * (segmentW + gap)

		if (i <= self.value) then
			surface.SetDrawColor(z19.colors.ink)
		else
			surface.SetDrawColor(z19.colors.line)
		end

		surface.DrawRect(x, segmentY, segmentW, segmentH)
	end

	draw.SimpleText(tostring(self.value), "z19MonoBold", width - buttonsW - ScreenScale(2), height * 0.5,
		z19.colors.inkSoft, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
end

vgui.Register("z19SkillRow", SKILL, "Panel")

-- экран создания
DEFINE_BASECLASS("ixCharMenuPanel")
local PANEL = {}

function PANEL:Init()
	local parent = self:GetParent()
	local width, height = parent:GetSize()
	local padding = ScreenScale(22)

	self:ResetPayload(true)

	self.factionButtons = {}
	self.repopulatePanels = {}
	self.modelIcons = {}

	-- назад
	self.backButton = vgui.Create("z19TextButton", self)
	self.backButton:SetLabel("‹  НАЗАД")
	self.backButton:SizeToLabel()
	self.backButton:SetPos(width - padding - self.backButton:GetWide(), padding)
	self.backButton.DoClick = function()
		parent:ReturnToMain("play")
	end

	-- левая колонка: имя, описание, доп. поля, навыки
	local columnW = width * 0.3
	local columnY = padding + ScreenScale(30)

	self.leftColumn = vgui.Create("Panel", self)
	self.leftColumn:SetPos(padding, columnY)
	self.leftColumn:SetSize(columnW, height - columnY - padding)

	self.nameLabel = self:AddLabel("ВВЕДИТЕ ИМЯ")

	self.nameEntry = self.leftColumn:Add("z19TextEntry")
	self.nameEntry:Dock(TOP)
	self.nameEntry:SetPlaceholder("Имя и фамилия бойца")
	self.nameEntry:SetUpdateOnType(true)
	self.nameEntry.OnValueChange = function(this, text)
		self.payload:Set("name", text)
	end

	self.descriptionLabel = self:AddLabel("ВВЕДИТЕ ОПИСАНИЕ")

	self.descriptionEntry = self.leftColumn:Add("z19TextEntry")
	self.descriptionEntry:Dock(TOP)
	self.descriptionEntry:SetUpdateOnType(true)
	self.descriptionEntry.OnValueChange = function(this, text)
		self.payload:Set("description", text)
	end
	self:StyleDescription()

	-- поля переменных из плагинов
	self.extraContainer = self.leftColumn:Add("Panel")
	self.extraContainer:Dock(TOP)
	self.extraContainer:SetTall(0)

	-- навыки
	self.skillsLabel = self:AddLabel("НАВЫКИ")

	self.skillsPoints = self.leftColumn:Add("DLabel")
	self.skillsPoints:SetFont("z19Mono")
	self.skillsPoints:SetTextColor(z19.colors.inkSoft)
	self.skillsPoints:Dock(TOP)
	self.skillsPoints:DockMargin(0, 0, 0, ScreenScale(3))

	self.skillsList = self.leftColumn:Add("Panel")
	self.skillsList:Dock(TOP)

	LockDockOrder(self.leftColumn)

	-- модель по центру справа
	self.model = vgui.Create("ixModelPanel", self)
	self.model:SetPos(width * 0.36, 0)
	self.model:SetSize(width * 0.38, height)
	self.model:SetModel("models/error.mdl")
	self.model:SetFOV(30)
	self.model.PaintModel = self.model.Paint

	-- правая колонка: фракция и выбор модели
	local rightW = width * 0.19
	local rightX = width - padding - rightW

	self.factionLabel = vgui.Create("DLabel", self)
	self.factionLabel:SetFont("z19Label")
	self.factionLabel:SetTextColor(z19.colors.ink)
	self.factionLabel:SetText("ФРАКЦИЯ")
	self.factionLabel:SizeToContents()
	self.factionLabel:SetPos(rightX, padding + ScreenScale(30))

	self.factionList = vgui.Create("Panel", self)
	self.factionList:SetPos(rightX, padding + ScreenScale(30) + self.factionLabel:GetTall() + ScreenScale(3))
	self.factionList:SetWide(rightW)

	self.modelLabel = vgui.Create("DLabel", self)
	self.modelLabel:SetFont("z19Label")
	self.modelLabel:SetTextColor(z19.colors.ink)
	self.modelLabel:SetText("ВЫБОР МОДЕЛИ")
	self.modelLabel:SizeToContents()

	self.modelScroll = vgui.Create("DScrollPanel", self)
	self.modelScroll:SetWide(rightW)
	self.modelScroll:GetVBar():SetWide(4)
	self.modelScroll.Paint = function(this, panelWidth, panelHeight)
		surface.SetDrawColor(255, 255, 255, 170)
		surface.DrawRect(0, 0, panelWidth, panelHeight)

		surface.SetDrawColor(z19.colors.line)
		surface.DrawOutlinedRect(0, 0, panelWidth, panelHeight)
	end

	self.modelLayout = self.modelScroll:Add("DIconLayout")
	self.modelLayout:Dock(FILL)
	self.modelLayout:DockMargin(4, 4, 4, 4)
	self.modelLayout:SetSpaceX(4)
	self.modelLayout:SetSpaceY(4)

	-- кнопка «Играть»
	self.playButton = vgui.Create("z19MaterialButton", self)
	self.playButton:SetLabel("ИГРАТЬ")
	self.playButton:SetSublabel("СОЗДАТЬ БОЙЦА")
	self.playButton:SetSize(rightW, ScreenScale(30))
	self.playButton:SetPos(rightX, height - padding - self.playButton:GetTall())
	self.playButton.DoClick = function()
		self:SendPayload()
	end

	-- выбор модели занимает место между фракциями и кнопкой
	local modelBottom = self.playButton.y - ScreenScale(8)
	local modelTop = height * 0.42

	self.modelLabel:SetPos(rightX, modelTop)
	self.modelScroll:SetPos(rightX, modelTop + self.modelLabel:GetTall() + ScreenScale(3))
	self.modelScroll:SetTall(modelBottom - self.modelScroll.y)

	-- модель в превью следует за выбором
	self:AddPayloadHook("model", function(value)
		local faction = ix.faction.indices[self.payload.faction]

		if (!faction) then
			return
		end

		local model = faction:GetModels(LocalPlayer())[value]

		if (istable(model)) then
			self.model:SetModel(model[1], model[2] or 0, model[3])
		elseif (model) then
			self.model:SetModel(model)
		end

		-- во весь рост, чуть выше пояса в центре
		z19.FrameModel(self.model, 0.5, 1.08)
	end)

	-- ответ сервера на создание
	net.Receive("ixCharacterAuthed", function()
		timer.Remove("ixCharacterCreateTimeout")
		self.awaitingResponse = false

		local id = net.ReadUInt(32)
		local indices = net.ReadUInt(6)
		local charList = {}

		for _ = 1, indices do
			charList[#charList + 1] = net.ReadUInt(32)
		end

		ix.characters = charList

		if (!IsValid(self) or !IsValid(parent)) then
			return
		end

		parent.mainPanel:UpdateLoadButton()

		if (LocalPlayer():GetCharacter()) then
			parent:ReturnToMain("play")
			parent:ShowNotice(2, L("charCreated"))
		elseif (id) then
			self.bMenuShouldClose = true

			-- сразу заходим новым бойцом: затемнение, затем выбор персонажа
			parent:Transition(function()
				net.Start("ixCharacterChoose")
					net.WriteUInt(id, 32)
				net.SendToServer()
			end)
		else
			parent:ReturnToMain("play")
		end
	end)

	net.Receive("ixCharacterAuthFailed", function()
		timer.Remove("ixCharacterCreateTimeout")
		self.awaitingResponse = false

		local fault = net.ReadString()
		local args = net.ReadTable()

		-- остаёмся на экране, чтобы игрок исправил данные
		self:RestorePayload()
		parent:ShowNotice(3, L(fault, unpack(args)))
	end)
end

function PANEL:AddLabel(text)
	local label = self.leftColumn:Add("DLabel")
	label:SetFont("z19Label")
	label:SetTextColor(z19.colors.ink)
	label:SetText(text)
	label:SizeToContents()
	label:Dock(TOP)
	label:DockMargin(0, ScreenScale(7), 0, ScreenScale(2))

	return label
end

function PANEL:StyleDescription()
	self.descriptionEntry:SetMultiline(true)
	self.descriptionEntry:SetFont("z19EntrySmall")
	self.descriptionEntry:SetTall(ScreenScale(46))
	self.descriptionEntry:SetPlaceholder("Внешность, особые приметы, история службы…")
end

function PANEL:SendPayload()
	if (self.awaitingResponse or !self:VerifyProgression()) then
		return
	end

	self.awaitingResponse = true

	timer.Create("ixCharacterCreateTimeout", 10, 1, function()
		if (IsValid(self) and self.awaitingResponse) then
			self.awaitingResponse = false
			self:RestorePayload()
			self:GetParent():ShowNotice(3, L("unknownError"))
		end
	end)

	-- копия значений на случай отказа сервера
	self.lastPayload = table.Copy(self.payload)
	self.payload:Prepare()

	net.Start("ixCharacterCreate")
	net.WriteUInt(table.Count(self.payload), 8)

	for k, v in pairs(self.payload) do
		net.WriteString(k)
		net.WriteType(v)
	end

	net.SendToServer()
end

-- вернуть payload с методами после неудачной отправки (Prepare их удаляет)
function PANEL:RestorePayload()
	local values = self.lastPayload or {}

	self:ResetPayload()

	for k, v in pairs(values) do
		if (!isfunction(v)) then
			self.payload[k] = v
		end
	end
end

function PANEL:OnSlideUp()
	self:ResetPayload()
	self:Populate()
end

function PANEL:OnSlideDown()
end

function PANEL:ResetPayload(bWithHooks)
	if (bWithHooks) then
		self.hooks = {}
	end

	self.payload = {}

	function self.payload.Set(payload, key, value)
		self:SetPayload(key, value)
	end

	function self.payload.AddHook(payload, key, callback)
		self:AddPayloadHook(key, callback)
	end

	function self.payload.Prepare(payload)
		self.payload.Set = nil
		self.payload.AddHook = nil
		self.payload.Prepare = nil
	end
end

function PANEL:SetPayload(key, value)
	self.payload[key] = value
	self:RunPayloadHook(key, value)
end

function PANEL:AddPayloadHook(key, callback)
	if (!self.hooks[key]) then
		self.hooks[key] = {}
	end

	self.hooks[key][#self.hooks[key] + 1] = callback
end

function PANEL:RunPayloadHook(key, value)
	local hooks = self.hooks[key] or {}

	for _, v in ipairs(hooks) do
		v(value)
	end
end

-- совместимость с плагинами, которые ищут контейнер категории
function PANEL:GetContainerPanel(name)
	return self.extraContainer
end

function PANEL:AttachCleanup(panel)
	self.repopulatePanels[#self.repopulatePanels + 1] = panel
end

function PANEL:Populate()
	-- фракции
	for _, v in ipairs(self.factionButtons) do
		if (IsValid(v)) then
			v:Remove()
		end
	end

	self.factionButtons = {}

	local defaultFaction
	local factions = {}

	for _, v in SortedPairs(ix.faction.teams) do
		if (ix.faction.HasWhitelist(v.index)) then
			factions[#factions + 1] = v

			-- первая доступная фракция, но фракция по умолчанию важнее
			if (!defaultFaction or v.isDefault) then
				defaultFaction = v.index
			end
		end
	end

	local buttonH = ScreenScale(13)

	for i, v in ipairs(factions) do
		local button = self.factionList:Add("z19TextButton")
		button:SetLabel(L(v.name):utf8upper())
		button:SetOutlined(true)
		button:Dock(TOP)
		button:SetZPos(i)
		button:DockMargin(0, 0, 0, ScreenScale(2))
		button:SetTall(buttonH)
		button.faction = v.index
		button.DoClick = function(this)
			self:SelectFaction(this.faction)
		end

		self.factionButtons[#self.factionButtons + 1] = button
	end

	self.factionList:SetTall(#factions * (buttonH + ScreenScale(2)))

	-- одна фракция — блок выбора не нужен
	local bShowFactions = #factions > 1
	self.factionLabel:SetVisible(bShowFactions)
	self.factionList:SetVisible(bShowFactions)

	-- навыки
	self:BuildSkills()

	if (defaultFaction) then
		self:SelectFaction(self.lastFaction and ix.faction.HasWhitelist(self.lastFaction) and self.lastFaction
			or defaultFaction)
	end
end

function PANEL:SelectFaction(index)
	local faction = ix.faction.indices[index]

	if (!faction) then
		return
	end

	self.lastFaction = index
	self.payload:Set("faction", index)

	for _, button in ipairs(self.factionButtons) do
		local bSelected = button.faction == index

		button:SetColor(bSelected and z19.colors.ink or z19.colors.inkDim)
		button.bSelected = bSelected
	end

	-- имя: значение по умолчанию от схемы (например, номер для Альянса)
	local nameVar = ix.char.vars.name

	self.nameEntry:SetDisabled(false)
	self.nameEntry:SetEditable(true)

	-- имя, подставленное прошлой фракцией, не переносим в новую
	if (self.bNameDefaulted) then
		self.nameEntry:SetText("")
	end

	local defaultName = hook.Run("GetDefaultCharacterName", LocalPlayer(), index)
	self.bNameDefaulted = defaultName != nil

	if (nameVar and nameVar.OnPostSetup) then
		nameVar:OnPostSetup(self.nameEntry, self.payload)
	end

	self.payload:Set("name", self.nameEntry:GetValue())

	local descriptionVar = ix.char.vars.description

	if (descriptionVar and descriptionVar.OnPostSetup) then
		descriptionVar:OnPostSetup(self.descriptionEntry, self.payload)
		self:StyleDescription()
	end

	self.payload:Set("description", self.descriptionEntry:GetValue())

	-- модели фракции
	local models = faction:GetModels(LocalPlayer())

	self:BuildModelPicker(models)
	self.payload:Set("model", math.random(1, #models))

	self:BuildExtraVars()
end

function PANEL:BuildModelPicker(models)
	self.modelLayout:Clear()
	self.modelIcons = {}

	local columns = 3
	local iconW = math.floor((self.modelScroll:GetWide() - 8 - (columns - 1) * 4 - 6) / columns)
	local iconH = iconW -- SpawnIcon рендерит квадратную иконку: другая высота растягивает модель

	for k, v in SortedPairs(models) do
		local icon = self.modelLayout:Add("SpawnIcon")
		icon:SetSize(iconW, iconH)
		icon:InvalidateLayout(true)
		icon.DoClick = function()
			self.payload:Set("model", k)
			z19.PlayUI("click")
		end
		icon.OnCursorEntered = function()
			z19.PlayUI("hover")
		end
		icon.PaintOver = function(this, w, h)
			if (self.payload.model == k) then
				surface.SetDrawColor(z19.colors.accent)
				surface.DrawOutlinedRect(0, 0, w, h, 3)
			elseif (this:IsHovered()) then
				surface.SetDrawColor(z19.colors.ink)
				surface.DrawOutlinedRect(0, 0, w, h, 1)
			end
		end

		if (isstring(v)) then
			icon:SetModel(v)
		else
			icon:SetModel(v[1], v[2] or 0, v[3])
		end

		self.modelIcons[k] = icon
	end

	local bShowModels = table.Count(models) > 1
	self.modelLabel:SetVisible(bShowModels)
	self.modelScroll:SetVisible(bShowModels)
end

function PANEL:BuildSkills()
	self.skillsList:Clear()

	local attributesVar = ix.char.vars.attributes
	local bShow = attributesVar and (!attributesVar.ShouldDisplay or attributesVar:ShouldDisplay(self.skillsList, self.payload) != false)
	local maximum = hook.Run("GetDefaultAttributePoints", LocalPlayer(), self.payload) or 10

	if (!bShow or maximum < 1) then
		self.skillsLabel:SetVisible(false)
		self.skillsPoints:SetVisible(false)
		self.skillsList:SetVisible(false)
		return
	end

	self.skillsLabel:SetVisible(true)
	self.skillsPoints:SetVisible(true)
	self.skillsList:SetVisible(true)

	local total = 0
	local rowH = ScreenScale(13)
	local count = 0

	self.payload.attributes = {}

	local function UpdatePoints()
		self.skillsPoints:SetText(string.format("ОСТАЛОСЬ ОЧКОВ: %d / %d", maximum - total, maximum))
		self.skillsPoints:SizeToContents()
	end

	for k, v in SortedPairsByMemberValue(ix.attributes.list, "name") do
		self.payload.attributes[k] = 0

		local row = self.skillsList:Add("z19SkillRow")
		row:Dock(TOP)
		row:SetZPos(count)
		row:DockMargin(0, 0, 0, ScreenScale(2))
		row:SetTall(rowH)
		row:SetSkill(L(v.name), maximum, v.noStartBonus)
		row.OnChanged = function(this, difference)
			if ((total + difference) > maximum or (total + difference) < 0) then
				return false
			end

			total = total + difference
			self.payload.attributes[k] = self.payload.attributes[k] + difference
			UpdatePoints()
		end

		count = count + 1
	end

	self.skillsList:SetTall(count * (rowH + ScreenScale(2)))
	UpdatePoints()
end

-- переменные персонажа из плагинов: свой OnDisplay или текстовое поле
function PANEL:BuildExtraVars()
	for i = 1, #self.repopulatePanels do
		if (IsValid(self.repopulatePanels[i])) then
			self.repopulatePanels[i]:Remove()
		end
	end

	self.repopulatePanels = {}

	local container = self.extraContainer
	local totalHeight = 0
	local zPos = 0

	for k, v in SortedPairsByMemberValue(ix.char.vars, "index") do
		if (v.bNoDisplay or k == "__SortedIndex" or CUSTOM_VARS[k]) then
			continue
		end

		if (v.ShouldDisplay and v:ShouldDisplay(container, self.payload) == false) then
			continue
		end

		local panel

		if (v.OnDisplay) then
			panel = v:OnDisplay(container, self.payload)
		elseif (isstring(v.default)) then
			panel = container:Add("z19TextEntry")
			panel:SetFont("z19EntrySmall")
			panel:SetUpdateOnType(true)
			panel.OnValueChange = function(this, text)
				self.payload:Set(k, text)
			end
		end

		if (IsValid(panel)) then
			local label = container:Add("DLabel")
			label:SetFont("z19Label")
			label:SetTextColor(z19.colors.ink)
			label:SetText(L(k):utf8upper())
			label:SizeToContents()
			label:Dock(TOP)
			label:DockMargin(0, ScreenScale(7), 0, ScreenScale(2))

			panel:Dock(TOP)

			-- подпись создаётся после поля, поэтому порядок задаём явно
			label:SetZPos(zPos)
			panel:SetZPos(zPos + 1)
			zPos = zPos + 2

			self:AttachCleanup(label)
			self:AttachCleanup(panel)

			if (v.OnPostSetup) then
				v:OnPostSetup(panel, self.payload)
			end

			panel:InvalidateLayout(true)
			totalHeight = totalHeight + label:GetTall() + ScreenScale(9) + panel:GetTall()
		end
	end

	container:SetTall(totalHeight)
end

function PANEL:VerifyProgression(name)
	for k, v in SortedPairsByMemberValue(ix.char.vars, "index") do
		if (name ~= nil and (v.category or "description") != name) then
			continue
		end

		local value = self.payload[k]

		if (!v.bNoDisplay or v.OnValidate) then
			if (v.OnValidate) then
				local result = {v:OnValidate(value, self.payload, LocalPlayer())}

				if (result[1] == false) then
					self:GetParent():ShowNotice(3, L(unpack(result, 2)))
					return false
				end
			end

			self.payload[k] = value
		end
	end

	return true
end

function PANEL:Paint(width, height)
	z19.PaintWhiteBackground(self, width, height)

	local padding = ScreenScale(22)

	-- эмблема-водяной знак за моделью
	local logo = z19.GetMaterial("scp_intro/logo.png")

	if (!logo:IsError()) then
		local size = height * 0.62

		surface.SetMaterial(logo)
		surface.SetDrawColor(255, 255, 255, 14)
		surface.DrawTexturedRect(width * 0.55 - size * 0.5, height * 0.5 - size * 0.5, size, size)
	end

	-- заголовок экрана
	draw.SimpleText("СОЗДАНИЕ БОЙЦА", "z19Title", padding, padding - ScreenScale(3), z19.colors.ink)

	surface.SetDrawColor(z19.colors.accent)
	surface.DrawRect(padding, padding + ScreenScale(19), ScreenScale(26), 3)

	-- фракция под моделью
	local faction = ix.faction.indices[self.payload.faction or 0]

	if (faction) then
		z19.DrawSpaced(L(faction.name):utf8upper(), "z19Mono", width * 0.55, height - padding, 4,
			z19.colors.inkSoft, TEXT_ALIGN_CENTER)
	end

	BaseClass.Paint(self, width, height)
end

vgui.Register("ixCharMenuNew", PANEL, "ixCharMenuPanel")
