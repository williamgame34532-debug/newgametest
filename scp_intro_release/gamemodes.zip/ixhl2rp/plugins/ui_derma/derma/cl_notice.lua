
--[[
	Enhanced Helix — ui_derma
	Рестайл всплывающих нотисов: тёмная панель вместо полупрозрачной
	чёрной, левый цветовой маркер (циан — инфо, красный — ошибка),
	полоса длительности снизу. Логика ховера/анимаций сохранена.
]]

local noticeTable = vgui.GetControlTable("ixNotice")

if (noticeTable) then
	function noticeTable:Paint(width, height)
		if (self.outAnimation < 1) then
			local x, y = self:LocalToScreen(0, 0)
			render.SetScissorRect(x, y, x + self:GetWide(), y + (self:GetTall() * self.outAnimation), true)
		end

		local x, y = self:LocalToScreen(0, 0)
		local mouseX, mouseY = gui.MousePos()

		if (mouseX >= x and mouseX <= x + width and
			mouseY >= y and mouseY <= y + height) then
			if (not self.bHovered) then
				self.bHovered = true
				self:OnMouseHover()
			end
		elseif (self.bHovered) then
			self.bHovered = false
			self:OnMouseLeave()
		end

		ix.util.DrawBlur(self)

		local accent = self.bError and ix.eui.colors.danger or ix.eui.GetAccent()

		if (self.errorAnimation > 0) then
			local color = ix.eui.colors.danger

			surface.SetDrawColor(
				color.r * self.errorAnimation,
				color.g * self.errorAnimation,
				color.b * self.errorAnimation,
				self.errorAnimation * 200 + ((1 - self.errorAnimation) * 210)
			)
		else
			surface.SetDrawColor(ix.eui.colors.panel.r, ix.eui.colors.panel.g, ix.eui.colors.panel.b, 210)
		end

		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
		surface.DrawRect(0, 0, 3, height)

		surface.SetDrawColor(ix.eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)

		surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
		surface.DrawRect(0, height - 1, width * self.duration, 1)
	end
end
