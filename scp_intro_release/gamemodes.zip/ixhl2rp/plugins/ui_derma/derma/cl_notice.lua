
--[[
	Enhanced Helix — ui_derma
	Всплывающие уведомления (ixNotice) в стиле Зоны-19: тёмная плашка, слева цветная полоса
	и иконка типа (янтарная «i» — инфо, красный «!» — ошибка), текст выровнен влево,
	снизу полоса оставшегося времени. Логика ховера/анимаций Helix сохранена.
]]

local noticeTable = vgui.GetControlTable("ixNotice")

if (noticeTable) then
	local infoIcon = Material("scp_ui/chat/info.png", "smooth mips")
	local errorIcon = Material("scp_ui/chat/error.png", "smooth mips")

	local function GetIconSpace(panel)
		surface.SetFont(panel:GetFont() or "ixNoticeFont")
		local _, textHeight = surface.GetTextSize("Wj")

		return math.floor(textHeight * 1.1) + panel.padding
	end

	local oldInit = noticeTable.Init

	function noticeTable:Init()
		oldInit(self)

		self:SetContentAlignment(4)
		self:SetExpensiveShadow(0)
	end

	-- место под иконку слева
	function noticeTable:SizeToContents()
		local iconSpace = GetIconSpace(self)
		local contentWidth, contentHeight = self:GetContentSize()

		contentWidth = contentWidth + self.padding * 3 + iconSpace
		contentHeight = contentHeight + self.padding * 2

		local manager = ix.gui.notices
		local maxWidth = math.min(IsValid(manager) and (manager:GetWide() - manager:GetPadding() * 2) or ScrW(),
			contentWidth)

		self:SetTextInset(self.padding * 2 + iconSpace, 0)

		if (contentWidth > maxWidth) then
			self:SetWide(maxWidth)
			self:SetWrap(true)
			self:SizeToContentsY()
		else
			self:SetSize(contentWidth, contentHeight)
		end
	end

	function noticeTable:Paint(width, height)
		if (self.outAnimation < 1) then
			local x, y = self:LocalToScreen(0, 0)
			render.SetScissorRect(x, y, x + self:GetWide(), y + (self:GetTall() * self.outAnimation), true)
		end

		local x, y = self:LocalToScreen(0, 0)
		local mouseX, mouseY = gui.MousePos()

		if (mouseX >= x and mouseX <= x + width and
			mouseY >= y and mouseY <= y + height) then
			if (not self.bHovered) then
				self.bHovered = true
				self:OnMouseHover()
			end
		elseif (self.bHovered) then
			self.bHovered = false
			self:OnMouseLeave()
		end

		ix.util.DrawBlur(self)

		local eui = ix.eui
		local accent = self.bError and eui.colors.danger or eui.colors.accent

		surface.SetDrawColor(eui.colors.panel.r, eui.colors.panel.g, eui.colors.panel.b, 230)
		surface.DrawRect(0, 0, width, height)

		-- вспышка ошибки
		if (self.errorAnimation > 0) then
			local danger = eui.colors.danger

			surface.SetDrawColor(danger.r, danger.g, danger.b, self.errorAnimation * 160)
			surface.DrawRect(0, 0, width, height)
		end

		surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
		surface.DrawRect(0, 0, 3, height)

		-- иконка типа
		local iconSize = GetIconSpace(self) - self.padding

		surface.SetMaterial(self.bError and errorIcon or infoIcon)
		surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
		surface.DrawTexturedRect(self.padding + 3, height * 0.5 - iconSize * 0.5, iconSize, iconSize)

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)

		-- оставшееся время
		surface.SetDrawColor(accent.r, accent.g, accent.b, 200)
		surface.DrawRect(3, height - 2, (width - 3) * self.duration, 2)
	end
end

-- полоса уведомлений (ixNoticeBar) — для плагинов, которые ей пользуются
local noticeBarTable = vgui.GetControlTable("ixNoticeBar")

if (noticeBarTable) then
	local typeColors = {
		Color(255, 196, 37), -- инфо
		Color(70, 170, 100), -- успех
		Color(214, 48, 48) -- ошибка
	}

	function noticeBarTable:Paint(width, height)
		local eui = ix.eui
		local color = typeColors[self.type] or typeColors[1]

		surface.SetDrawColor(eui.colors.panel.r, eui.colors.panel.g, eui.colors.panel.b, 240)
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(color.r, color.g, color.b, 255)
		surface.DrawRect(0, 0, 4, height)
		surface.DrawRect(0, height - 2, width, 2)

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)
	end
end
