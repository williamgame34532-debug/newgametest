
--[[
	Enhanced Helix — ui_derma
	Анимация загрузки персонажа «Зона-19» (хук CharacterLoaded):
	1) терминал Фонда печатает идентификацию сотрудника (имя, подразделение, допуск),
	   рядом вращается эмблема, снизу заполняется шкала проверки;
	2) штамп «ДОСТУП РАЗРЕШЁН»;
	3) экран раскрывается как гермоворота — половины разъезжаются, в щели янтарный свет.
	Ввод не блокирует, длится ~4.5 с, отключается опцией «Анимация входа персонажа».
]]

ix.option.Add("deployAnimation", ix.type.bool, true, {
	category = "appearance"
})

local DURATION = 4.6
local OPEN_START = 3.4

local function CreateFonts()
	surface.CreateFont("z19DeployMono", {
		font = "JetBrains Mono",
		size = math.max(ScreenScale(6.5), 16),
		weight = 400,
		extended = true
	})

	surface.CreateFont("z19DeployMonoBold", {
		font = "JetBrains Mono",
		size = math.max(ScreenScale(6.5), 16),
		weight = 700,
		extended = true
	})

	surface.CreateFont("z19DeployName", {
		font = "Zone19 Sans Bold",
		size = math.max(ScreenScale(22), 40),
		weight = 700,
		extended = true
	})

	surface.CreateFont("z19DeployStamp", {
		font = "Zone19 Sans Black",
		size = math.max(ScreenScale(16), 34),
		weight = 900,
		extended = true
	})
end

CreateFonts()
hook.Add("LoadFonts", "z19DeployFonts", CreateFonts)

local function Clamp01(x)
	return math.Clamp(x, 0, 1)
end

local function EaseInOut(x)
	x = Clamp01(x)
	return x < 0.5 and 4 * x * x * x or 1 - (-2 * x + 2) ^ 3 / 2
end

local PANEL = {}

function PANEL:Init()
	if (IsValid(ix.gui.deploy)) then
		ix.gui.deploy:Remove()
	end

	ix.gui.deploy = self

	self:SetSize(ScrW(), ScrH())
	self:SetPos(0, 0)
	self:MakePopup()
	self:SetMouseInputEnabled(false)
	self:SetKeyboardInputEnabled(false)

	self.start = RealTime()
	self.sounds = {}
end

function PANEL:SetCharacter(character)
	local faction = ix.faction.indices[character:GetFaction()]

	self.name = character:GetName()
	self.faction = faction and L(faction.name):utf8upper() or "—"
	self.factionColor = faction and faction.color or ix.eui.colors.accent
	self.id = string.format("%05d", character:GetID() % 100000)

	self.lines = {
		{"ФОНД SCP  //  ЗОНА-19  //  ТЕРМИНАЛ КПП-А", ix.eui.colors.textDim},
		{"ИДЕНТИФИКАЦИЯ СОТРУДНИКА .............. ОК", ix.eui.colors.text},
		{"ЛИЧНЫЙ НОМЕР: " .. self.id, ix.eui.colors.text},
		{"ПОДРАЗДЕЛЕНИЕ: " .. self.faction, self.factionColor},
		{"БИОМЕТРИЯ .............................. ОК", ix.eui.colors.text},
		{"ДОПУСК ПОДТВЕРЖДЁН", ix.eui.colors.accent}
	}
end

function PANEL:PlayOnce(key, name)
	if (!self.sounds[key]) then
		self.sounds[key] = true

		if (ix.z19) then
			ix.z19.PlayUI(name)
		end
	end
end

function PANEL:Think()
	local t = RealTime() - self.start

	if (t > 0.05) then
		self:PlayOnce("start", "transition")
	end

	if (t > 2.45) then
		self:PlayOnce("stamp", "notice")
	end

	if (t > OPEN_START) then
		self:PlayOnce("open", "transition")
	end

	if (t >= DURATION) then
		self:Remove()
	end
end

function PANEL:PaintTerminal(width, height, t, alpha)
	local eui = ix.eui
	local accent = eui.colors.accent
	local leftX = width * 0.36
	local topY = height * 0.33

	-- эмблема слева от текста
	local logo = ix.z19 and ix.z19.GetMaterial("scp_intro/logo.png")
	local logoSize = height * 0.26

	if (logo and !logo:IsError()) then
		surface.SetMaterial(logo)
		surface.SetDrawColor(255, 255, 255, alpha * 0.9)
		surface.DrawTexturedRectRotated(width * 0.24, height * 0.46, logoSize, logoSize, -t * 12)
	end

	-- имя сотрудника
	draw.SimpleText(self.name or "", "z19DeployName", leftX, topY - ScreenScale(4),
		ColorAlpha(eui.colors.text, alpha * Clamp01((t - 0.25) / 0.4)), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)

	surface.SetDrawColor(accent.r, accent.g, accent.b, alpha)
	surface.DrawRect(leftX, topY, ScreenScale(60) * Clamp01((t - 0.2) / 0.6), 3)

	-- строки терминала печатаются по очереди
	local lineHeight = ScreenScale(11)

	for i, line in ipairs(self.lines or {}) do
		local lineStart = 0.35 + (i - 1) * 0.3
		local shown = math.floor((t - lineStart) * 70)

		if (shown > 0) then
			local text = line[1]
			local cut = utf8.offset(text, shown + 1)
			local visible = cut and text:sub(1, cut - 1) or text
			local bDone = !cut

			draw.SimpleText(visible .. ((!bDone and math.floor(t * 8) % 2 == 0) and "_" or ""),
				i == #self.lines and "z19DeployMonoBold" or "z19DeployMono",
				leftX, topY + ScreenScale(8) + (i - 1) * lineHeight, ColorAlpha(line[2], alpha))
		end
	end

	-- шкала проверки
	local barY = topY + ScreenScale(8) + #(self.lines or {}) * lineHeight + ScreenScale(6)
	local barW = width * 0.4
	local progress = Clamp01((t - 0.3) / 2.0)

	surface.SetDrawColor(255, 255, 255, alpha * 0.08)
	surface.DrawRect(leftX, barY, barW, 6)

	surface.SetDrawColor(accent.r, accent.g, accent.b, alpha)
	surface.DrawRect(leftX, barY, barW * progress, 6)

	draw.SimpleText(string.format("%03d%%", math.floor(progress * 100)), "z19DeployMono", leftX + barW + 10, barY + 3,
		ColorAlpha(eui.colors.textDim, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

	-- штамп «ДОСТУП РАЗРЕШЁН»
	local stamp = Clamp01((t - 2.45) / 0.18)

	if (stamp > 0) then
		local scale = 1 + (1 - stamp) * 0.6
		local text = "ДОСТУП РАЗРЕШЁН"

		surface.SetFont("z19DeployStamp")
		local textW, textH = surface.GetTextSize(text)
		local boxW, boxH = (textW + ScreenScale(16)) * scale, (textH + ScreenScale(6)) * scale
		local cx, cy = width * 0.5, height * 0.78

		surface.SetDrawColor(accent.r, accent.g, accent.b, alpha * stamp)
		surface.DrawOutlinedRect(cx - boxW * 0.5, cy - boxH * 0.5, boxW, boxH, 3)

		local matrix = Matrix()
		matrix:Translate(Vector(cx, cy, 0))
		matrix:Scale(Vector(scale, scale, 1))
		matrix:Translate(Vector(-cx, -cy, 0))

		cam.PushModelMatrix(matrix, true)
			draw.SimpleText(text, "z19DeployStamp", cx, cy, ColorAlpha(accent, alpha * stamp),
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		cam.PopModelMatrix()
	end
end

function PANEL:Paint(width, height)
	local eui = ix.eui
	local t = RealTime() - self.start
	local open = EaseInOut((t - OPEN_START) / (DURATION - OPEN_START - 0.1))

	-- две половины «гермоворот»
	local half = height * 0.5
	local shift = half * open
	local topH = half - shift
	local bottomY = half + shift

	if (topH > 0) then
		surface.SetDrawColor(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, 255)
		surface.DrawRect(0, 0, width, topH)
		surface.DrawRect(0, bottomY, width, height - bottomY)

		eui.DrawScanlines(0, 0, width, topH, 14, 4)
		eui.DrawScanlines(0, bottomY, width, height - bottomY, 14, 4)

		-- полосы «опасность» по краям створок — только когда ворота начали открываться,
		-- иначе стык проходит прямо через текст терминала
		if (open > 0) then
			local hazardH = ScreenScale(5)

			eui.DrawHazard(0, topH - hazardH, width, hazardH, 255)
			eui.DrawHazard(0, bottomY, width, hazardH, 255)
		end

		-- свет в щели
		if (open > 0) then
			local accent = eui.colors.accent
			local glow = math.sin(open * math.pi)

			surface.SetDrawColor(accent.r, accent.g, accent.b, 200 * glow)
			surface.DrawRect(0, topH, width, 2)
			surface.DrawRect(0, bottomY - 2, width, 2)
		end
	end

	-- терминал виден до раскрытия
	local terminalAlpha = 255 * Clamp01(t / 0.25) * (1 - Clamp01((t - OPEN_START + 0.1) / 0.25))

	if (terminalAlpha > 0) then
		self:PaintTerminal(width, height, t, terminalAlpha)
	end
end

vgui.Register("z19DeployOverlay", PANEL, "EditablePanel")

hook.Add("CharacterLoaded", "z19DeployAnimation", function(character)
	if (!ix.option.Get("deployAnimation", true) or !character) then
		return
	end

	local panel = vgui.Create("z19DeployOverlay")
	panel:SetCharacter(character)
end)
