
--[[
	Enhanced Helix — ui_derma
	Заголовки сабпанелей (создание персонажа, загрузка и т.д.):
	тонкий Roboto Thin светлым текстом вместо цветного жирного заголовка.
]]

local panelTable = vgui.GetControlTable("ixSubpanel")

if (panelTable) then
	local oldSetTitle = panelTable.SetTitle

	function panelTable:SetTitle(text, bNoTranslation, bNoUpper)
		oldSetTitle(self, text, bNoTranslation, bNoUpper)

		if (IsValid(self.title)) then
			self.title:SetFont("eixTitleFont")
			self.title:SetTextColor(ix.eui.colors.text)
			self.title:SizeToContents()
		end
	end
end
