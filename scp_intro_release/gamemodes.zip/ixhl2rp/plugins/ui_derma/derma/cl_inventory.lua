
--[[
	Enhanced Helix — ui_derma
	Рестайл инвентаря: тёмные ячейки с волосяными рамками и угловыми засечками
	(слоты — через скин), подсветка предмета цианом при наведении.
	Логика оригинала сохранена.
]]

local RECEIVER_NAME = "ixInventoryItem"

-- The queue for the rendered icons.
ICON_RENDER_QUEUE = ICON_RENDER_QUEUE or {}

-- To make making inventory variant, This must be followed up.
local function RenderNewIcon(panel, itemTable)
	local model = itemTable:GetModel()

	-- re-render icons
	if ((itemTable.iconCam and !ICON_RENDER_QUEUE[string.lower(model)]) or itemTable.forceRender) then
		local iconCam = itemTable.iconCam
		iconCam = {
			cam_pos = iconCam.pos,
			cam_ang = iconCam.ang,
			cam_fov = iconCam.fov,
		}
		ICON_RENDER_QUEUE[string.lower(model)] = true

		panel.Icon:RebuildSpawnIconEx(
			iconCam
		)
	end
end

local function InventoryAction(action, itemID, invID, data)
	net.Start("ixInventoryAction")
		net.WriteString(action)
		net.WriteUInt(itemID, 32)
		net.WriteUInt(invID, 32)
		net.WriteTable(data or {})
	net.SendToServer()
end

local PANEL = {}

AccessorFunc(PANEL, "itemTable", "ItemTable")
AccessorFunc(PANEL, "inventoryID", "InventoryID")

function PANEL:Init()
	self:Droppable(RECEIVER_NAME)
end

function PANEL:OnMousePressed(code)
	if (code == MOUSE_LEFT and self:IsDraggable()) then
		self:MouseCapture(true)
		self:DragMousePress(code)

		self.clickX, self.clickY = input.GetCursorPos()
	elseif (code == MOUSE_RIGHT and self.DoRightClick) then
		self:DoRightClick()
	end
end

function PANEL:OnMouseReleased(code)
	-- move the item into the world if we're dropping on something that doesn't handle inventory item drops
	if (!dragndrop.m_ReceiverSlot or dragndrop.m_ReceiverSlot.Name != RECEIVER_NAME) then
		self:OnDrop(dragndrop.IsDragging())
	end

	self:DragMouseRelease(code)
	self:SetZPos(99)
	self:MouseCapture(false)
end

function PANEL:DoRightClick()
	local itemTable = self.itemTable
	local inventory = self.inventoryID

	if (itemTable and inventory) then
		itemTable.player = LocalPlayer()

		local menu = DermaMenu()
		local override = hook.Run("CreateItemInteractionMenu", self, menu, itemTable)

		if (override == true) then
			if (menu.Remove) then
				menu:Remove()
			end

			return
		end

		for k, v in SortedPairs(itemTable.functions) do
			if (k == "drop" or k == "combine" or (v.OnCanRun and v.OnCanRun(itemTable) == false)) then
				continue
			end

			-- is Multi-Option Function
			if (v.isMulti) then
				local subMenu, subMenuOption = menu:AddSubMenu(L(v.name or k), function()
					itemTable.player = LocalPlayer()
						local send = true

						if (v.OnClick) then
							send = v.OnClick(itemTable)
						end

						if (v.sound) then
							surface.PlaySound(v.sound)
						end

						if (send != false) then
							InventoryAction(k, itemTable.id, inventory)
						end
					itemTable.player = nil
				end)
				subMenuOption:SetImage(v.icon or "icon16/brick.png")

				if (v.multiOptions) then
					local options = isfunction(v.multiOptions) and v.multiOptions(itemTable, LocalPlayer()) or v.multiOptions

					for _, sub in pairs(options) do
						subMenu:AddOption(L(sub.name or "subOption"), function()
							itemTable.player = LocalPlayer()
								local send = true

								if (sub.OnClick) then
									send = sub.OnClick(itemTable)
								end

								if (sub.sound) then
									surface.PlaySound(sub.sound)
								end

								if (send != false) then
									InventoryAction(k, itemTable.id, inventory, sub.data)
								end
							itemTable.player = nil
						end)
					end
				end
			else
				menu:AddOption(L(v.name or k), function()
					itemTable.player = LocalPlayer()
						local send = true

						if (v.OnClick) then
							send = v.OnClick(itemTable)
						end

						if (v.sound) then
							surface.PlaySound(v.sound)
						end

						if (send != false) then
							InventoryAction(k, itemTable.id, inventory)
						end
					itemTable.player = nil
				end):SetImage(v.icon or "icon16/brick.png")
			end
		end

		-- we want drop to show up as the last option
		local info = itemTable.functions.drop

		if (info and info.OnCanRun and info.OnCanRun(itemTable) != false) then
			menu:AddOption(L(info.name or "drop"), function()
				itemTable.player = LocalPlayer()
					local send = true

					if (info.OnClick) then
						send = info.OnClick(itemTable)
					end

					if (info.sound) then
						surface.PlaySound(info.sound)
					end

					if (send != false) then
						InventoryAction("drop", itemTable.id, inventory)
					end
				itemTable.player = nil
			end):SetImage(info.icon or "icon16/brick.png")
		end

		menu:Open()
		itemTable.player = nil
	end
end

function PANEL:OnDrop(bDragging, inventoryPanel, inventory, gridX, gridY)
	local item = self.itemTable

	if (!item or !bDragging) then
		return
	end

	if (!IsValid(inventoryPanel)) then
		local inventoryID = self.inventoryID

		if (inventoryID) then
			InventoryAction("drop", item.id, inventoryID, {})
		end
	elseif (inventoryPanel:IsAllEmpty(gridX, gridY, item.width, item.height, self)) then
		local oldX, oldY = self.gridX, self.gridY

		if (oldX != gridX or oldY != gridY or self.inventoryID != inventoryPanel.invID) then
			self:Move(gridX, gridY, inventoryPanel)
		end
	elseif (inventoryPanel.combineItem) then
		local combineItem = inventoryPanel.combineItem
		local inventoryID = combineItem.invID

		if (inventoryID) then
			combineItem.player = LocalPlayer()
				if (combineItem.functions.combine.sound) then
					surface.PlaySound(combineItem.functions.combine.sound)
				end

				InventoryAction("combine", combineItem.id, inventoryID, {item.id})
			combineItem.player = nil
		end
	end
end

function PANEL:Move(newX, newY, givenInventory, bNoSend)
	local iconSize = givenInventory.iconSize
	local oldX, oldY = self.gridX, self.gridY
	local oldParent = self:GetParent()

	if (givenInventory:OnTransfer(oldX, oldY, newX, newY, oldParent, bNoSend) == false) then
		return
	end

	local x = (newX - 1) * iconSize + 4
	local y = (newY - 1) * iconSize + givenInventory:GetPadding(2)

	self.gridX = newX
	self.gridY = newY

	self:SetParent(givenInventory)
	self:SetPos(x, y)

	if (self.slots) then
		for _, v in ipairs(self.slots) do
			if (IsValid(v) and v.item == self) then
				v.item = nil
			end
		end
	end

	self.slots = {}

	for currentX = 1, self.gridW do
		for currentY = 1, self.gridH do
			local slot = givenInventory.slots[self.gridX + currentX - 1][self.gridY + currentY - 1]

			slot.item = self
			self.slots[#self.slots + 1] = slot
		end
	end
end

function PANEL:PaintOver(width, height)
	local itemTable = self.itemTable

	if (itemTable and itemTable.PaintOver) then
		itemTable.PaintOver(self, itemTable, width, height)
	end
end

function PANEL:ExtraPaint(width, height)
end

function PANEL:Paint(width, height)
	surface.SetDrawColor(ix.eui.colors.panelLight.r, ix.eui.colors.panelLight.g, ix.eui.colors.panelLight.b, 230)
	surface.DrawRect(1, 1, width - 2, height - 2)

	ix.eui.DrawGradientV(1, 1, width - 2, (height - 2) * 0.6, Color(255, 255, 255, 6), true)

	local itemTable = self.itemTable
	local rarity = itemTable and (itemTable.rarity and ix.eui.styles.resonance.rarity[itemTable.rarity]
		or itemTable.rarityColor)

	if (self.Hovered) then
		-- янтарная подсветка с угловыми засечками
		local accent = ix.eui.colors.accent

		surface.SetDrawColor(accent.r, accent.g, accent.b, 22)
		surface.DrawRect(1, 1, width - 2, height - 2)

		surface.SetDrawColor(accent.r, accent.g, accent.b, 210)
		surface.DrawOutlinedRect(1, 1, width - 2, height - 2)

		ix.eui.DrawCorners(1, 1, width - 2, height - 2, 6, ColorAlpha(accent, 255))
	elseif (rarity) then
		-- resonance: постоянная рамка цвета редкости
		-- (ITEM.rarity = "common/uncommon/rare/epic/mythic/gold" или ITEM.rarityColor = Color(...))
		surface.SetDrawColor(rarity.r, rarity.g, rarity.b, 190)
		surface.DrawOutlinedRect(1, 1, width - 2, height - 2)

		ix.eui.DrawCornerTriangle(1, 1, 12, ColorAlpha(rarity, 255))
	else
		surface.SetDrawColor(ix.eui.colors.hairline)
		surface.DrawOutlinedRect(1, 1, width - 2, height - 2)
	end

	self:ExtraPaint(width, height)

	-- маркер повёрнутого предмета (плагин itemrotate)
	if (itemTable and itemTable.GetData and itemTable:GetData("rotated", false)) then
		draw.SimpleText("R", "eixMonoSmallFont", width - 5, height - 3,
			ColorAlpha(ix.eui.colors.accent, 230), TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)
	end
end

vgui.Register("ixItemIcon", PANEL, "SpawnIcon")

PANEL = {}
DEFINE_BASECLASS("DFrame")

AccessorFunc(PANEL, "iconSize", "IconSize", FORCE_NUMBER)
AccessorFunc(PANEL, "bHighlighted", "Highlighted", FORCE_BOOL)

function PANEL:Init()
	self:SetIconSize(64)
	self:ShowCloseButton(false)
	self:SetDraggable(true)
	self:SetSizable(true)
	self:SetTitle(L"inv")
	self:Receiver(RECEIVER_NAME, self.ReceiveDrop)

	self.btnMinim:SetVisible(false)
	self.btnMinim:SetMouseInputEnabled(false)
	self.btnMaxim:SetVisible(false)
	self.btnMaxim:SetMouseInputEnabled(false)

	self.panels = {}
end

function PANEL:GetPadding(index)
	return select(index, self:GetDockPadding())
end

function PANEL:SetTitle(text)
	if (text == nil) then
		self.oldPadding = {self:GetDockPadding()}

		self.lblTitle:SetText("")
		self.lblTitle:SetVisible(false)

		self:DockPadding(5, 5, 5, 5)
	else
		if (self.oldPadding) then
			self:DockPadding(unpack(self.oldPadding))
			self.oldPadding = nil
		end

		BaseClass.SetTitle(self, text)
	end
end

function PANEL:FitParent(invWidth, invHeight)
	local parent = self:GetParent()

	if (!IsValid(parent)) then
		return
	end

	local width, height = parent:GetSize()
	local padding = 4
	local iconSize

	if (invWidth > invHeight) then
		iconSize = (width - padding * 2) / invWidth
	elseif (invHeight > invWidth) then
		iconSize = (height - padding * 2) / invHeight
	else
		-- we use height because the titlebar will make it more tall than it is wide
		iconSize = (height - padding * 2) / invHeight - 4
	end

	self:SetSize(iconSize * invWidth + padding * 2, iconSize * invHeight + padding * 2)
	self:SetIconSize(iconSize)
end

function PANEL:OnRemove()
	if (self.childPanels) then
		for _, v in ipairs(self.childPanels) do
			if (v != self) then
				v:Remove()
			end
		end
	end
end

function PANEL:ViewOnly()
	self.viewOnly = true

	for _, icon in pairs(self.panels) do
		icon.OnMousePressed = nil
		icon.OnMouseReleased = nil
		icon.doRightClick = nil
	end
end

function PANEL:SetInventory(inventory, bFitParent)
	if (inventory.slots) then
		local invWidth, invHeight = inventory:GetSize()
		self.invID = inventory:GetID()

		if (IsValid(ix.gui.inv1) and ix.gui.inv1.childPanels and inventory != LocalPlayer():GetCharacter():GetInventory()) then
			self:SetIconSize(ix.gui.inv1:GetIconSize())
			self:SetPaintedManually(true)
			self.bNoBackgroundBlur = true

			ix.gui.inv1.childPanels[#ix.gui.inv1.childPanels + 1] = self
		elseif (bFitParent) then
			self:FitParent(invWidth, invHeight)
		else
			self:SetSize(self.iconSize, self.iconSize)
		end

		self:SetGridSize(invWidth, invHeight)

		for x, items in pairs(inventory.slots) do
			for y, data in pairs(items) do
				if (!data.id) then continue end

				local item = ix.item.instances[data.id]

				if (item and !IsValid(self.panels[item.id])) then
					local icon = self:AddIcon(item:GetModel() or "models/props_junk/popcan01a.mdl",
						x, y, item.width, item.height, item:GetSkin())

					if (IsValid(icon)) then
						icon:SetHelixTooltip(function(tooltip)
							ix.hud.PopulateItemTooltip(tooltip, item)
						end)

						self.panels[item.id] = icon
					end
				end
			end
		end
	end
end

function PANEL:SetGridSize(w, h)
	local iconSize = self.iconSize
	local newWidth = w * iconSize + 8
	local newHeight = h * iconSize + self:GetPadding(2) + self:GetPadding(4)

	self.gridW = w
	self.gridH = h

	self:SetSize(newWidth, newHeight)
	self:SetMinWidth(newWidth)
	self:SetMinHeight(newHeight)
	self:BuildSlots()
end

function PANEL:PerformLayout(width, height)
	BaseClass.PerformLayout(self, width, height)

	if (self.Sizing and self.gridW and self.gridH) then
		local newWidth = (width - 8) / self.gridW
		local newHeight = (height - self:GetPadding(2) + self:GetPadding(4)) / self.gridH

		self:SetIconSize((newWidth + newHeight) / 2)
		self:RebuildItems()
	end
end

function PANEL:BuildSlots()
	local iconSize = self.iconSize

	self.slots = self.slots or {}

	for _, v in ipairs(self.slots) do
		for _, v2 in ipairs(v) do
			v2:Remove()
		end
	end

	self.slots = {}

	for x = 1, self.gridW do
		self.slots[x] = {}

		for y = 1, self.gridH do
			local slot = self:Add("DPanel")
			slot:SetZPos(-999)
			slot.gridX = x
			slot.gridY = y
			slot:SetPos((x - 1) * iconSize + 4, (y - 1) * iconSize + self:GetPadding(2))
			slot:SetSize(iconSize, iconSize)
			slot.Paint = function(panel, width, height)
				derma.SkinFunc("PaintInventorySlot", panel, width, height)
			end

			self.slots[x][y] = slot
		end
	end
end

function PANEL:RebuildItems()
	local iconSize = self.iconSize

	for x = 1, self.gridW do
		for y = 1, self.gridH do
			local slot = self.slots[x][y]

			slot:SetPos((x - 1) * iconSize + 4, (y - 1) * iconSize + self:GetPadding(2))
			slot:SetSize(iconSize, iconSize)
		end
	end

	for _, v in pairs(self.panels) do
		if (IsValid(v)) then
			v:SetPos(self.slots[v.gridX][v.gridY]:GetPos())
			v:SetSize(v.gridW * iconSize, v.gridH * iconSize)
		end
	end
end

function PANEL:PaintDragPreview(width, height, mouseX, mouseY, itemPanel)
	local iconSize = self.iconSize
	local item = itemPanel:GetItemTable()

	if (item) then
		local inventory = ix.item.inventories[self.invID]
		local dropX = math.ceil((mouseX - 4 - (itemPanel.gridW - 1) * 32) / iconSize)
		local dropY = math.ceil((mouseY - self:GetPadding(2) - (itemPanel.gridH - 1) * 32) / iconSize)

		local hoveredPanel = vgui.GetHoveredPanel()

		if (IsValid(hoveredPanel) and hoveredPanel != itemPanel and hoveredPanel.GetItemTable) then
			local hoveredItem = hoveredPanel:GetItemTable()

			if (hoveredItem) then
				local info = hoveredItem.functions.combine

				if (info and info.OnCanRun and info.OnCanRun(hoveredItem, {item.id}) != false) then
					surface.SetDrawColor(ColorAlpha(derma.GetColor("Info", self, Color(200, 0, 0)), 20))
					surface.DrawRect(
						hoveredPanel.x,
						hoveredPanel.y,
						hoveredPanel:GetWide(),
						hoveredPanel:GetTall()
					)

					self.combineItem = hoveredItem

					return
				end
			end
		end

		self.combineItem = nil

		-- don't draw grid if we're dragging it out of bounds
		if (inventory) then
			local invWidth, invHeight = inventory:GetSize()

			if (dropX < 1 or dropY < 1 or
				dropX + itemPanel.gridW - 1 > invWidth or
				dropY + itemPanel.gridH - 1 > invHeight) then
				return
			end
		end

		local bEmpty = true

		for x = 0, itemPanel.gridW - 1 do
			for y = 0, itemPanel.gridH - 1 do
				local x2 = dropX + x
				local y2 = dropY + y

				bEmpty = self:IsEmpty(x2, y2, itemPanel)

				if (!bEmpty) then
					-- no need to iterate further since we know something is blocking the hovered grid cells, break through both loops
					goto finish
				end
			end
		end

		::finish::
		local previewColor = ColorAlpha(derma.GetColor(bEmpty and "Success" or "Error", self, Color(200, 0, 0)), 20)

		surface.SetDrawColor(previewColor)
		surface.DrawRect(
			(dropX - 1) * iconSize + 4,
			(dropY - 1) * iconSize + self:GetPadding(2),
			itemPanel:GetWide(),
			itemPanel:GetTall()
		)
	end
end

function PANEL:PaintOver(width, height)
	local panel = self.previewPanel

	if (IsValid(panel)) then
		local itemPanel = (dragndrop.GetDroppable() or {})[1]

		if (IsValid(itemPanel)) then
			self:PaintDragPreview(width, height, self.previewX, self.previewY, itemPanel)
		end
	end

	self.previewPanel = nil

	-- янтарные угловые скобки и счётчик занятости под сеткой
	local accent = ix.eui.colors.accent

	ix.eui.DrawCorners(0, 0, width, height, 10, ColorAlpha(accent, 130))

	if (self.gridW and self.gridH) then
		local total = self.gridW * self.gridH
		local used = 0

		for _, v in pairs(self.panels) do
			if (IsValid(v)) then
				used = used + (v.gridW or 1) * (v.gridH or 1)
			end
		end

		DisableClipping(true)
			draw.SimpleText(string.format("// ЗАНЯТО %d / %d", used, total), "eixMonoSmallFont",
				width - 2, height + 3,
				ColorAlpha(accent, 200), TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)

			surface.SetDrawColor(accent.r, accent.g, accent.b, 90)
			surface.DrawRect(0, height + 1, width * math.min(used / total, 1), 1)
		DisableClipping(false)
	end
end

function PANEL:IsEmpty(x, y, this)
	return (self.slots[x] and self.slots[x][y]) and (!IsValid(self.slots[x][y].item) or self.slots[x][y].item == this)
end

function PANEL:IsAllEmpty(x, y, width, height, this)
	for x2 = 0, width - 1 do
		for y2 = 0, height - 1 do
			if (!self:IsEmpty(x + x2, y + y2, this)) then
				return false
			end
		end
	end

	return true
end

function PANEL:OnTransfer(oldX, oldY, x, y, oldInventory, noSend)
	local inventories = ix.item.inventories
	local inventory = inventories[oldInventory.invID]
	local inventory2 = inventories[self.invID]
	local item

	if (inventory) then
		item = inventory:GetItemAt(oldX, oldY)

		if (!item) then
			return false
		end

		if (hook.Run("CanTransferItem", item, inventories[oldInventory.invID], inventories[self.invID]) == false) then
			return false, "notAllowed"
		end

		if (item.CanTransfer and
			item:CanTransfer(inventory, inventory != inventory2 and inventory2 or nil) == false) then
			return false
		end
	end

	if (!noSend) then
		net.Start("ixInventoryMove")
			net.WriteUInt(oldX, 6)
			net.WriteUInt(oldY, 6)
			net.WriteUInt(x, 6)
			net.WriteUInt(y, 6)
			net.WriteUInt(oldInventory.invID, 32)
			net.WriteUInt(self != oldInventory and self.invID or oldInventory.invID, 32)
		net.SendToServer()
	end

	if (inventory) then
		inventory.slots[oldX][oldY] = nil
	end

	if (item and inventory2) then
		inventory2.slots[x] = inventory2.slots[x] or {}
		inventory2.slots[x][y] = item
	end
end

function PANEL:AddIcon(model, x, y, w, h, skin)
	local iconSize = self.iconSize

	w = w or 1
	h = h or 1

	if (self.slots[x] and self.slots[x][y]) then
		local panel = self:Add("ixItemIcon")
		panel:SetSize(w * iconSize, h * iconSize)
		panel:SetZPos(999)
		panel:InvalidateLayout(true)
		panel:SetModel(model, skin)
		panel:SetPos(self.slots[x][y]:GetPos())
		panel.gridX = x
		panel.gridY = y
		panel.gridW = w
		panel.gridH = h

		local inventory = ix.item.inventories[self.invID]

		if (!inventory) then
			return
		end

		local itemTable = inventory:GetItemAt(panel.gridX, panel.gridY)

		panel:SetInventoryID(inventory:GetID())
		panel:SetItemTable(itemTable)

		if (self.panels[itemTable:GetID()]) then
			self.panels[itemTable:GetID()]:Remove()
		end

		if (itemTable.exRender) then
			panel.Icon:SetVisible(false)
			panel.ExtraPaint = function(this, panelX, panelY)
				local exIcon = ikon:GetIcon(itemTable.uniqueID)
				if (exIcon) then
					surface.SetMaterial(exIcon)
					surface.SetDrawColor(color_white)
					surface.DrawTexturedRect(0, 0, panelX, panelY)
				else
					ikon:renderIcon(
						itemTable.uniqueID,
						itemTable.width,
						itemTable.height,
						itemTable:GetModel(),
						itemTable.iconCam
					)
				end
			end
		else
			-- yeah..
			RenderNewIcon(panel, itemTable)
		end

		panel.slots = {}

		for i = 0, w - 1 do
			for i2 = 0, h - 1 do
				local slot = self.slots[x + i] and self.slots[x + i][y + i2]

				if (IsValid(slot)) then
					slot.item = panel
					panel.slots[#panel.slots + 1] = slot
				else
					for _, v in ipairs(panel.slots) do
						v.item = nil
					end

					panel:Remove()

					return
				end
			end
		end

		return panel
	end
end

function PANEL:ReceiveDrop(panels, bDropped, menuIndex, x, y)
	local panel = panels[1]

	if (!IsValid(panel)) then
		self.previewPanel = nil
		return
	end

	if (bDropped) then
		local inventory = ix.item.inventories[self.invID]

		if (inventory and panel.OnDrop) then
			local dropX = math.ceil((x - 4 - (panel.gridW - 1) * 32) / self.iconSize)
			local dropY = math.ceil((y - self:GetPadding(2) - (panel.gridH - 1) * 32) / self.iconSize)

			panel:OnDrop(true, self, inventory, dropX, dropY)
		end

		self.previewPanel = nil
	else
		self.previewPanel = panel
		self.previewX = x
		self.previewY = y
	end
end

vgui.Register("ixInventory", PANEL, "DFrame")

hook.Add("CreateMenuButtons", "ixInventory", function(tabs)
	if (hook.Run("CanPlayerViewInventory") == false) then
		return
	end

	tabs["inv"] = {
		bDefault = true,
		Create = function(info, container)
			-- правая колонка: сведения о предмете под курсором
			local details = container:Add("z19ItemDetails")
			details:Dock(RIGHT)
			details:SetWide(math.max(container:GetWide() * 0.26, 300))
			details:DockMargin(ScreenScale(6), 0, 0, 0)

			local canvas = container:Add("DTileLayout")
			local canvasLayout = canvas.PerformLayout
			canvas.PerformLayout = nil -- we'll layout after we add the panels instead of each time one is added
			canvas:SetBorder(0)
			canvas:SetSpaceX(2)
			canvas:SetSpaceY(2)
			canvas:Dock(FILL)

			ix.gui.menuInventoryContainer = canvas

			local panel = canvas:Add("ixInventory")
			panel:SetPos(0, 0)
			panel:SetDraggable(false)
			panel:SetSizable(false)
			panel:SetTitle(nil)
			-- resonance: крупная сетка — размер ячейки от высоты экрана
			panel:SetIconSize(math.Round(math.max(ScrH() * 0.088, 84)))
			panel.bNoBackgroundBlur = true
			panel.childPanels = {}

			local inventory = LocalPlayer():GetCharacter():GetInventory()

			if (inventory) then
				panel:SetInventory(inventory)
			end

			ix.gui.inv1 = panel

			if (ix.option.Get("openBags", true)) then
				for _, v in pairs(inventory:GetItems()) do
					if (!v.isBag) then
						continue
					end

					v.functions.View.OnClick(v)
				end
			end

			canvas.PerformLayout = canvasLayout
			canvas:Layout()
		end
	}
end)

hook.Add("PostRenderVGUI", "ixInvHelper", function()
	local pnl = ix.gui.inv1

	hook.Run("PostDrawInventory", pnl)
end)

-- колонка «Сведения о предмете»: предмет под курсором (модель, название, описание, размер),
-- баланс персонажа и заполненность инвентаря
local DETAILS = {}

function DETAILS:Init()
	self.model = self:Add("DModelPanel")
	self.model:SetVisible(false)
	self.model:SetMouseInputEnabled(false)
	self.model:SetFOV(30)
	self.model.LayoutEntity = function(this, entity)
		entity:SetAngles(Angle(0, RealTime() * 30 % 360, 0))
	end

	self.description = self:Add("DLabel")
	self.description:SetFont("ixItemDescFont")
	self.description:SetTextColor(ix.eui.colors.textDim)
	self.description:SetWrap(true)
	self.description:SetContentAlignment(7)
	self.description:SetText("")
end

function DETAILS:PerformLayout(width, height)
	local header = ScreenScale(14)

	self.model:SetPos(1, header)
	self.model:SetSize(width - 2, height * 0.38)

	self.description:SetPos(ScreenScale(6), header + height * 0.38 + ScreenScale(30))
	self.description:SetSize(width - ScreenScale(12), height * 0.28)
end

function DETAILS:SetItem(itemTable)
	if (self.item == itemTable) then
		return
	end

	self.item = itemTable

	if (!itemTable) then
		self.model:SetVisible(false)
		self.description:SetText("")
		return
	end

	self.model:SetVisible(true)
	self.model:SetModel(itemTable:GetModel())

	if (IsValid(self.model.Entity) and itemTable.GetSkin) then
		self.model.Entity:SetSkin(itemTable:GetSkin() or 0)
	end

	-- камера: предмет целиком в кадре
	local entity = self.model.Entity

	if (IsValid(entity)) then
		local mins, maxs = entity:GetRenderBounds()
		local size = math.max(maxs.x - mins.x, maxs.y - mins.y, maxs.z - mins.z)
		local center = (mins + maxs) * 0.5

		self.model:SetLookAt(center)
		self.model:SetCamPos(center + Vector(1, 1, 0.6):GetNormalized() * size * 1.9)
	end

	local description = itemTable.GetDescription and itemTable:GetDescription() or itemTable.description or ""
	self.description:SetText(L(description))
end

function DETAILS:Think()
	-- предмет под курсором: иконка в любой открытой сетке
	local hovered = vgui.GetHoveredPanel()

	if (IsValid(hovered) and hovered.itemTable and hovered.gridX) then
		self:SetItem(hovered.itemTable)
	end
end

function DETAILS:Paint(width, height)
	local eui = ix.eui
	local header = ScreenScale(14)

	surface.SetDrawColor(eui.colors.panel)
	surface.DrawRect(0, 0, width, height)

	surface.SetDrawColor(eui.colors.hairline)
	surface.DrawOutlinedRect(0, 0, width, height)

	-- шапка
	surface.SetDrawColor(eui.colors.panelLight)
	surface.DrawRect(0, 0, width, header)

	surface.SetDrawColor(eui.colors.accent)
	surface.DrawRect(0, 0, 3, header)

	draw.SimpleText("СВЕДЕНИЯ О ПРЕДМЕТЕ", "eixSubTitleFont", ScreenScale(6), header * 0.5, eui.colors.text,
		TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

	-- подложка под модель
	local modelY, modelH = header, height * 0.38

	eui.DrawGradientV(1, modelY, width - 2, modelH, Color(255, 255, 255, 6))
	eui.DrawCorners(ScreenScale(4), modelY + ScreenScale(4), width - ScreenScale(8), modelH - ScreenScale(8), 10,
		ColorAlpha(eui.colors.accent, 90))

	local item = self.item
	local infoY = modelY + modelH + ScreenScale(4)

	if (item) then
		draw.SimpleText(L(item.GetName and item:GetName() or item.name or ""):utf8upper(), "ixItemBoldFont",
			ScreenScale(6), infoY, eui.colors.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

		local category = item.category and L(item.category) or ""
		local info = string.format("РАЗМЕР %d×%d   ·   %s", item.width or 1, item.height or 1, category:utf8upper())

		draw.SimpleText(info, "eixMonoSmallFont", ScreenScale(6), infoY + ScreenScale(13), eui.colors.accent,
			TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	else
		draw.SimpleText("НАВЕДИТЕ НА ПРЕДМЕТ", "eixMonoSmallFont", width * 0.5, modelY + modelH * 0.5,
			eui.colors.textDim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	-- низ: баланс и заполненность
	local footerY = height - ScreenScale(30)

	surface.SetDrawColor(eui.colors.hairline)
	surface.DrawRect(ScreenScale(6), footerY, width - ScreenScale(12), 1)

	local character = LocalPlayer():GetCharacter()

	if (character) then
		draw.SimpleText("БАЛАНС", "eixMonoSmallFont", ScreenScale(6), footerY + ScreenScale(4), eui.colors.textDim,
			TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
		draw.SimpleText(ix.currency.Get(character:GetMoney()), "ixItemBoldFont", width - ScreenScale(6),
			footerY + ScreenScale(2), eui.colors.text, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)

		local inventory = character:GetInventory()

		if (inventory) then
			local gridW, gridH = inventory:GetSize()
			local total = math.max(gridW * gridH, 1)
			local used = 0

			for _, v in pairs(inventory:GetItems(true)) do
				used = used + (v.width or 1) * (v.height or 1)
			end

			local barY = footerY + ScreenScale(17)
			local barW = width - ScreenScale(12)
			local fraction = math.min(used / total, 1)

			draw.SimpleText(string.format("ЗАПОЛНЕНО %d / %d", used, total), "eixMonoSmallFont", ScreenScale(6), barY,
				eui.colors.textDim, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

			surface.SetDrawColor(255, 255, 255, 14)
			surface.DrawRect(ScreenScale(6), barY + ScreenScale(7), barW, 4)

			local barColor = fraction > 0.85 and eui.colors.danger or eui.colors.accent

			surface.SetDrawColor(barColor)
			surface.DrawRect(ScreenScale(6), barY + ScreenScale(7), barW * fraction, 4)
		end
	end
end

vgui.Register("z19ItemDetails", DETAILS, "Panel")
