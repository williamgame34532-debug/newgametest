
--[[
	Enhanced Helix — ui_derma
	Инвентарь «Зона-19» — склад личных вещей сотрудника Фонда:
	- центр: «чертёж» контейнера — сетка с перекрестьями и координатной линейкой (A1, B2...),
	  панель поиска и фильтр по категориям, внизу посегментная шкала занятых ячеек;
	- предметы — карточки: цветная метка категории, название на нижней плашке,
	  при наведении бегущая линия сканера, выбранный предмет в янтарной рамке;
	- справа «досье объекта»: вращающаяся модель в окне сканера, название, метки,
	  описание и кнопки действий предмета (Использовать, Надеть, Выбросить...).
	ЛКМ — выбрать предмет, ПКМ — меню действий, перетаскивание — как в Helix.
	Логика сетки, переноса и объединения предметов — из оригинала Helix.
]]

local RECEIVER_NAME = "ixInventoryItem"

-- The queue for the rendered icons.
ICON_RENDER_QUEUE = ICON_RENDER_QUEUE or {}

local function CreateFonts()
	local function font(name, face, size, weight, minimum)
		surface.CreateFont(name, {
			font = face,
			size = math.max(math.Round(ScreenScale(size)), minimum or 12),
			weight = weight,
			extended = true,
			antialias = true
		})
	end

	font("z19InvTitle", "Zone19 Sans Bold", 10, 700, 20)
	font("z19InvName", "Zone19 Sans Bold", 8.5, 700, 18)
	font("z19InvLabel", "Zone19 Sans Semi", 5.6, 600, 13)
	font("z19InvBody", "IBM Plex Sans", 5.8, 400, 14)
	font("z19InvMono", "JetBrains Mono", 4.6, 400, 11)
	font("z19InvMonoBold", "JetBrains Mono", 4.8, 700, 12)
	font("z19InvTiny", "JetBrains Mono", 3.9, 700, 10)
end

CreateFonts()
hook.Add("LoadFonts", "z19InventoryFonts", CreateFonts)

local icons = {}

local function GetIcon(name)
	if (!icons[name]) then
		icons[name] = Material("scp_ui/inv/" .. name .. ".png", "smooth mips")
	end

	return icons[name]
end

-- цвет метки категории: стабильный цвет из палитры по названию категории
local categoryPalette = {
	Color(255, 196, 37),
	Color(86, 182, 194),
	Color(214, 72, 62),
	Color(120, 200, 120),
	Color(160, 132, 220),
	Color(232, 132, 54),
	Color(110, 150, 230),
	Color(200, 200, 196)
}

local function GetCategoryColor(item)
	local category = item and item.category or "misc"

	return categoryPalette[(tonumber(util.CRC(category)) or 0) % #categoryPalette + 1]
end

local function GetItemName(item)
	return L(item.GetName and item:GetName() or item.name or "")
end

-- фильтр склада: строка поиска и выбранная категория (общий для всех сеток)
ix.gui.invFilter = ix.gui.invFilter or {}

local function ItemMatchesFilter(item)
	local filter = ix.gui.invFilter

	if (!item or (!filter.text and !filter.category)) then
		return true
	end

	if (filter.category and item.category != filter.category) then
		return false
	end

	if (filter.text) then
		local name = GetItemName(item):utf8lower()

		if (!name:find(filter.text, 1, true)) then
			return false
		end
	end

	return true
end

-- выбранный предмет (ЛКМ по карточке)
local function SelectItem(item)
	local id = item and item.id

	if (ix.gui.invSelected != id) then
		ix.gui.invSelected = id

		if (id and ix.z19) then
			ix.z19.PlayUI("item")
		end
	end
end

-- To make making inventory variant, This must be followed up.
local function RenderNewIcon(panel, itemTable)
	local model = itemTable:GetModel()

	-- re-render icons
	if ((itemTable.iconCam and !ICON_RENDER_QUEUE[string.lower(model)]) or itemTable.forceRender) then
		local iconCam = itemTable.iconCam
		iconCam = {
			cam_pos = iconCam.pos,
			cam_ang = iconCam.ang,
			cam_fov = iconCam.fov,
		}
		ICON_RENDER_QUEUE[string.lower(model)] = true

		panel.Icon:RebuildSpawnIconEx(
			iconCam
		)
	end
end

local function InventoryAction(action, itemID, invID, data)
	net.Start("ixInventoryAction")
		net.WriteString(action)
		net.WriteUInt(itemID, 32)
		net.WriteUInt(invID, 32)
		net.WriteTable(data or {})
	net.SendToServer()
end

-- выполнить функцию предмета так же, как пункт меню Helix (OnClick, звук, отправка на сервер)
local function RunItemFunction(itemTable, inventoryID, key, info, data)
	itemTable.player = LocalPlayer()
		local send = true

		if (info.OnClick) then
			send = info.OnClick(itemTable)
		end

		if (info.sound) then
			surface.PlaySound(info.sound)
		end

		if (send != false) then
			InventoryAction(key, itemTable.id, inventoryID, data)
		end
	itemTable.player = nil
end

-- доступные действия предмета: {key, info}, «выбросить» всегда последним
local function GetItemActions(itemTable)
	local actions = {}

	itemTable.player = LocalPlayer()

	for k, v in SortedPairs(itemTable.functions or {}) do
		if (k == "drop" or k == "combine" or (v.OnCanRun and v.OnCanRun(itemTable) == false)) then
			continue
		end

		actions[#actions + 1] = {k, v}
	end

	local drop = itemTable.functions and itemTable.functions.drop

	if (drop and (!drop.OnCanRun or drop.OnCanRun(itemTable) != false)) then
		actions[#actions + 1] = {"drop", drop}
	end

	itemTable.player = nil

	return actions
end

-- иконка для кнопки действия
local actionIcons = {
	drop = "drop",
	view = "view",
	equip = "equip",
	equipun = "unequip",
	unequip = "unequip",
	combine = "combine",
	use = "action"
}

local function GetActionIcon(key)
	return GetIcon(actionIcons[string.lower(key)] or "action")
end

local PANEL = {}

AccessorFunc(PANEL, "itemTable", "ItemTable")
AccessorFunc(PANEL, "inventoryID", "InventoryID")

function PANEL:Init()
	self:Droppable(RECEIVER_NAME)

	self.hover = 0
end

function PANEL:OnMousePressed(code)
	if (code == MOUSE_LEFT and self:IsDraggable()) then
		self:MouseCapture(true)
		self:DragMousePress(code)

		self.clickX, self.clickY = input.GetCursorPos()
	elseif (code == MOUSE_RIGHT and self.DoRightClick) then
		SelectItem(self.itemTable)
		self:DoRightClick()
	end
end

function PANEL:OnMouseReleased(code)
	local bDragging = dragndrop.IsDragging()

	-- move the item into the world if we're dropping on something that doesn't handle inventory item drops
	if (!dragndrop.m_ReceiverSlot or dragndrop.m_ReceiverSlot.Name != RECEIVER_NAME) then
		self:OnDrop(bDragging)
	end

	self:DragMouseRelease(code)
	self:SetZPos(99)
	self:MouseCapture(false)

	-- обычный клик без перетаскивания — выбрать предмет (досье справа)
	if (code == MOUSE_LEFT and !bDragging) then
		SelectItem(self.itemTable)
	end
end

function PANEL:DoRightClick()
	local itemTable = self.itemTable
	local inventory = self.inventoryID

	if (itemTable and inventory) then
		itemTable.player = LocalPlayer()

		local menu = DermaMenu()
		local override = hook.Run("CreateItemInteractionMenu", self, menu, itemTable)

		if (override == true) then
			if (menu.Remove) then
				menu:Remove()
			end

			return
		end

		for _, action in ipairs(GetItemActions(itemTable)) do
			local k, v = action[1], action[2]

			-- is Multi-Option Function
			if (v.isMulti) then
				local subMenu, subMenuOption = menu:AddSubMenu(L(v.name or k), function()
					RunItemFunction(itemTable, inventory, k, v)
				end)
				subMenuOption:SetImage(v.icon or "icon16/brick.png")

				if (v.multiOptions) then
					itemTable.player = LocalPlayer()
					local options = isfunction(v.multiOptions) and v.multiOptions(itemTable, LocalPlayer()) or v.multiOptions
					itemTable.player = nil

					for _, sub in pairs(options) do
						subMenu:AddOption(L(sub.name or "subOption"), function()
							RunItemFunction(itemTable, inventory, k, sub, sub.data)
						end)
					end
				end
			else
				menu:AddOption(L(v.name or k), function()
					RunItemFunction(itemTable, inventory, k, v)
				end):SetImage(v.icon or "icon16/brick.png")
			end
		end

		menu:Open()
		itemTable.player = nil
	end
end

function PANEL:OnDrop(bDragging, inventoryPanel, inventory, gridX, gridY)
	local item = self.itemTable

	if (!item or !bDragging) then
		return
	end

	if (!IsValid(inventoryPanel)) then
		local inventoryID = self.inventoryID

		if (inventoryID) then
			InventoryAction("drop", item.id, inventoryID, {})
		end
	elseif (inventoryPanel:IsAllEmpty(gridX, gridY, item.width, item.height, self)) then
		local oldX, oldY = self.gridX, self.gridY

		if (oldX != gridX or oldY != gridY or self.inventoryID != inventoryPanel.invID) then
			self:Move(gridX, gridY, inventoryPanel)
		end
	elseif (inventoryPanel.combineItem) then
		local combineItem = inventoryPanel.combineItem
		local inventoryID = combineItem.invID

		if (inventoryID) then
			combineItem.player = LocalPlayer()
				if (combineItem.functions.combine.sound) then
					surface.PlaySound(combineItem.functions.combine.sound)
				end

				InventoryAction("combine", combineItem.id, inventoryID, {item.id})
			combineItem.player = nil
		end
	end
end

function PANEL:Move(newX, newY, givenInventory, bNoSend)
	local iconSize = givenInventory.iconSize
	local oldX, oldY = self.gridX, self.gridY
	local oldParent = self:GetParent()

	if (givenInventory:OnTransfer(oldX, oldY, newX, newY, oldParent, bNoSend) == false) then
		return
	end

	local x = (newX - 1) * iconSize + 4
	local y = (newY - 1) * iconSize + givenInventory:GetPadding(2)

	self.gridX = newX
	self.gridY = newY

	self:SetParent(givenInventory)
	self:SetPos(x, y)

	if (self.slots) then
		for _, v in ipairs(self.slots) do
			if (IsValid(v) and v.item == self) then
				v.item = nil
			end
		end
	end

	self.slots = {}

	for currentX = 1, self.gridW do
		for currentY = 1, self.gridH do
			local slot = givenInventory.slots[self.gridX + currentX - 1][self.gridY + currentY - 1]

			slot.item = self
			self.slots[#self.slots + 1] = slot
		end
	end
end

-- название, обрезанное под ширину карточки (кэш по ширине)
function PANEL:GetShortName(width)
	local itemTable = self.itemTable
	local name = itemTable and GetItemName(itemTable):utf8upper() or ""

	if (self.shortNameWidth == width and self.shortNameSource == name) then
		return self.shortName
	end

	surface.SetFont("z19InvTiny")

	local result = name
	local maxWidth = width - 10

	if (surface.GetTextSize(result) > maxWidth) then
		local length = utf8.len(name) or #name

		while (length > 1) do
			length = length - 1
			result = name:utf8sub(1, length) .. "…"

			if (surface.GetTextSize(result) <= maxWidth) then
				break
			end
		end
	end

	self.shortNameWidth = width
	self.shortNameSource = name
	self.shortName = result

	return result
end

function PANEL:ExtraPaint(width, height)
end

function PANEL:Paint(width, height)
	local eui = ix.eui
	local itemTable = self.itemTable
	local color = GetCategoryColor(itemTable)

	-- карточка
	surface.SetDrawColor(24, 25, 29, 240)
	surface.DrawRect(1, 1, width - 2, height - 2)

	eui.DrawGradientV(1, height * 0.35, width - 2, height * 0.65 - 1, ColorAlpha(color, 26))

	-- метка категории: тонкая полоса слева и уголок
	surface.SetDrawColor(color.r, color.g, color.b, 210)
	surface.DrawRect(1, 1, 2, height - 2)

	local rarity = itemTable and (itemTable.rarity and eui.styles and eui.styles.resonance
		and eui.styles.resonance.rarity[itemTable.rarity] or itemTable.rarityColor)

	surface.SetDrawColor(rarity and ColorAlpha(rarity, 200) or Color(255, 255, 255, 18))
	surface.DrawOutlinedRect(1, 1, width - 2, height - 2)

	self:ExtraPaint(width, height)
end

function PANEL:PaintOver(width, height)
	local itemTable = self.itemTable
	local eui = ix.eui
	local accent = eui.colors.accent

	if (itemTable and itemTable.PaintOver) then
		itemTable.PaintOver(self, itemTable, width, height)
	end

	-- плашка с названием
	if (itemTable and height >= 44) then
		surface.SetFont("z19InvTiny")
		local _, textH = surface.GetTextSize("W")
		local stripH = textH + 4

		surface.SetDrawColor(11, 12, 14, 205)
		surface.DrawRect(3, height - stripH - 1, width - 4, stripH)

		draw.SimpleText(self:GetShortName(width), "z19InvTiny", 7, height - 1 - stripH * 0.5,
			Color(220, 220, 216, 230), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	-- маркер повёрнутого предмета (плагин itemrotate)
	if (itemTable and itemTable.GetData and itemTable:GetData("rotated", false)) then
		draw.SimpleText("↻", "z19InvMonoBold", width - 5, 3, ColorAlpha(accent, 230), TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
	end

	-- не подходит под фильтр — гасим
	if (!ItemMatchesFilter(itemTable)) then
		surface.SetDrawColor(11, 12, 14, 205)
		surface.DrawRect(0, 0, width, height)
		return
	end

	local bSelected = itemTable and ix.gui.invSelected == itemTable.id

	self.hover = math.Approach(self.hover, self.Hovered and 1 or 0, FrameTime() * 8)

	if (self.hover > 0) then
		-- бегущая линия сканера
		local scanY = 1 + (RealTime() * 0.8 % 1) * (height - 3)

		surface.SetDrawColor(accent.r, accent.g, accent.b, 26 * self.hover)
		surface.DrawRect(1, 1, width - 2, height - 2)

		eui.DrawGradientV(1, math.max(scanY - 18, 1), width - 2, math.min(18, scanY), ColorAlpha(accent, 50 * self.hover))

		surface.SetDrawColor(accent.r, accent.g, accent.b, 170 * self.hover)
		surface.DrawRect(1, scanY, width - 2, 1)
	end

	if (bSelected) then
		surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
		surface.DrawOutlinedRect(0, 0, width, height, 2)

		-- уголок «выбрано»
		draw.NoTexture()
		surface.DrawPoly({
			{x = width - 14, y = 0},
			{x = width, y = 0},
			{x = width, y = 14}
		})
	elseif (self.hover > 0) then
		eui.DrawCorners(1, 1, width - 2, height - 2, math.min(10, width * 0.2), ColorAlpha(accent, 255 * self.hover))
	end
end

vgui.Register("ixItemIcon", PANEL, "SpawnIcon")

-- ячейка сетки: слабая заливка и уголки, которые вместе с соседями складываются в перекрестья
local function PaintSlot(panel, width, height)
	local tick = math.max(3, math.floor(width * 0.07))

	surface.SetDrawColor(255, 255, 255, 5)
	surface.DrawRect(1, 1, width - 2, height - 2)

	surface.SetDrawColor(255, 255, 255, 46)
	surface.DrawRect(0, 0, tick, 1)
	surface.DrawRect(0, 0, 1, tick)
	surface.DrawRect(width - tick, 0, tick, 1)
	surface.DrawRect(width - 1, 0, 1, tick)
	surface.DrawRect(0, height - 1, tick, 1)
	surface.DrawRect(0, height - tick, 1, tick)
	surface.DrawRect(width - tick, height - 1, tick, 1)
	surface.DrawRect(width - 1, height - tick, 1, tick)
end

PANEL = {}
DEFINE_BASECLASS("DFrame")

AccessorFunc(PANEL, "iconSize", "IconSize", FORCE_NUMBER)
AccessorFunc(PANEL, "bHighlighted", "Highlighted", FORCE_BOOL)

function PANEL:Init()
	self:SetIconSize(64)
	self:ShowCloseButton(false)
	self:SetDraggable(true)
	self:SetSizable(true)
	self:SetTitle(L"inv")
	self:Receiver(RECEIVER_NAME, self.ReceiveDrop)

	self.btnMinim:SetVisible(false)
	self.btnMinim:SetMouseInputEnabled(false)
	self.btnMaxim:SetVisible(false)
	self.btnMaxim:SetMouseInputEnabled(false)

	self.btnClose.Paint = function(this, width, height)
		local danger = ix.eui.colors.danger
		local size = math.min(width, height) * 0.62

		if (this:IsHovered()) then
			surface.SetDrawColor(danger.r, danger.g, danger.b, 200)
			surface.DrawRect(2, 2, width - 4, height - 4)
		end

		surface.SetMaterial(GetIcon("unequip"))
		surface.SetDrawColor(255, 255, 255, this:IsHovered() and 255 or 160)
		surface.DrawTexturedRect(width * 0.5 - size * 0.5, height * 0.5 - size * 0.5, size, size)
	end

	self.lblTitle:SetFont("z19InvMonoBold")
	self.lblTitle:SetTextColor(ix.eui.colors.text)

	self.panels = {}
end

function PANEL:GetPadding(index)
	return select(index, self:GetDockPadding())
end

function PANEL:SetTitle(text)
	if (text == nil) then
		self.oldPadding = {self:GetDockPadding()}

		self.lblTitle:SetText("")
		self.lblTitle:SetVisible(false)

		self:DockPadding(5, 5, 5, 5)
	else
		if (self.oldPadding) then
			self:DockPadding(unpack(self.oldPadding))
			self.oldPadding = nil
		end

		BaseClass.SetTitle(self, tostring(text):utf8upper())
		self.lblTitle:SetVisible(true)
	end
end

function PANEL:PerformLayout(width, height)
	BaseClass.PerformLayout(self, width, height)

	-- заголовок левее — справа от янтарной метки
	if (self.lblTitle:IsVisible()) then
		self.lblTitle:SetPos(14, 2)
	end

	if (self.Sizing and self.gridW and self.gridH) then
		local newWidth = (width - 8) / self.gridW
		local newHeight = (height - self:GetPadding(2) + self:GetPadding(4)) / self.gridH

		self:SetIconSize((newWidth + newHeight) / 2)
		self:RebuildItems()
	end
end

function PANEL:Paint(width, height)
	local eui = ix.eui
	local accent = eui.colors.accent

	if (!self.bNoBackgroundBlur) then
		ix.util.DrawBlur(self, 6)
	end

	surface.SetDrawColor(eui.colors.panel.r, eui.colors.panel.g, eui.colors.panel.b, self.bMainGrid and 0 or 235)
	surface.DrawRect(0, 0, width, height)

	-- шапка контейнера (сумки, хранилища)
	if (self.lblTitle:IsVisible()) then
		local headerH = self:GetPadding(2) - 3

		surface.SetDrawColor(eui.colors.panelLight)
		surface.DrawRect(0, 0, width, headerH)

		surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
		surface.DrawRect(0, 0, 4, headerH)

		local hazardW = math.min(width * 0.2, 46)
		eui.DrawHazard(width - hazardW - headerH - 4, 4, hazardW, headerH - 8, 120)

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawRect(0, headerH, width, 1)
	end

	if (!self.bMainGrid) then
		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)
	end
end

function PANEL:FitParent(invWidth, invHeight)
	local parent = self:GetParent()

	if (!IsValid(parent)) then
		return
	end

	local width, height = parent:GetSize()
	local padding = 4
	local iconSize

	if (invWidth > invHeight) then
		iconSize = (width - padding * 2) / invWidth
	elseif (invHeight > invWidth) then
		iconSize = (height - padding * 2) / invHeight
	else
		-- we use height because the titlebar will make it more tall than it is wide
		iconSize = (height - padding * 2) / invHeight - 4
	end

	self:SetSize(iconSize * invWidth + padding * 2, iconSize * invHeight + padding * 2)
	self:SetIconSize(iconSize)
end

function PANEL:OnRemove()
	if (self.childPanels) then
		for _, v in ipairs(self.childPanels) do
			if (v != self) then
				v:Remove()
			end
		end
	end
end

function PANEL:ViewOnly()
	self.viewOnly = true

	for _, icon in pairs(self.panels) do
		icon.OnMousePressed = nil
		icon.OnMouseReleased = nil
		icon.doRightClick = nil
	end
end

function PANEL:SetInventory(inventory, bFitParent)
	if (inventory.slots) then
		local invWidth, invHeight = inventory:GetSize()
		self.invID = inventory:GetID()

		if (IsValid(ix.gui.inv1) and ix.gui.inv1.childPanels and inventory != LocalPlayer():GetCharacter():GetInventory()) then
			self:SetIconSize(ix.gui.inv1:GetIconSize())
			self:SetPaintedManually(true)
			self.bNoBackgroundBlur = true

			ix.gui.inv1.childPanels[#ix.gui.inv1.childPanels + 1] = self
		elseif (bFitParent) then
			self:FitParent(invWidth, invHeight)
		else
			self:SetSize(self.iconSize, self.iconSize)
		end

		self:SetGridSize(invWidth, invHeight)

		for x, items in pairs(inventory.slots) do
			for y, data in pairs(items) do
				if (!data.id) then continue end

				local item = ix.item.instances[data.id]

				if (item and !IsValid(self.panels[item.id])) then
					local icon = self:AddIcon(item:GetModel() or "models/props_junk/popcan01a.mdl",
						x, y, item.width, item.height, item:GetSkin())

					if (IsValid(icon)) then
						icon:SetHelixTooltip(function(tooltip)
							ix.hud.PopulateItemTooltip(tooltip, item)
						end)

						self.panels[item.id] = icon
					end
				end
			end
		end
	end
end

function PANEL:SetGridSize(w, h)
	local iconSize = self.iconSize
	local newWidth = w * iconSize + 8
	local newHeight = h * iconSize + self:GetPadding(2) + self:GetPadding(4)

	self.gridW = w
	self.gridH = h

	self:SetSize(newWidth, newHeight)
	self:SetMinWidth(newWidth)
	self:SetMinHeight(newHeight)
	self:BuildSlots()
end

function PANEL:BuildSlots()
	local iconSize = self.iconSize

	self.slots = self.slots or {}

	for _, v in ipairs(self.slots) do
		for _, v2 in ipairs(v) do
			v2:Remove()
		end
	end

	self.slots = {}

	for x = 1, self.gridW do
		self.slots[x] = {}

		for y = 1, self.gridH do
			local slot = self:Add("DPanel")
			slot:SetZPos(-999)
			slot.gridX = x
			slot.gridY = y
			slot:SetPos((x - 1) * iconSize + 4, (y - 1) * iconSize + self:GetPadding(2))
			slot:SetSize(iconSize, iconSize)
			slot.Paint = PaintSlot

			self.slots[x][y] = slot
		end
	end
end

function PANEL:RebuildItems()
	local iconSize = self.iconSize

	for x = 1, self.gridW do
		for y = 1, self.gridH do
			local slot = self.slots[x][y]

			slot:SetPos((x - 1) * iconSize + 4, (y - 1) * iconSize + self:GetPadding(2))
			slot:SetSize(iconSize, iconSize)
		end
	end

	for _, v in pairs(self.panels) do
		if (IsValid(v)) then
			v:SetPos(self.slots[v.gridX][v.gridY]:GetPos())
			v:SetSize(v.gridW * iconSize, v.gridH * iconSize)
		end
	end
end

function PANEL:PaintDragPreview(width, height, mouseX, mouseY, itemPanel)
	local iconSize = self.iconSize
	local item = itemPanel:GetItemTable()

	if (item) then
		local inventory = ix.item.inventories[self.invID]
		local dropX = math.ceil((mouseX - 4 - (itemPanel.gridW - 1) * 32) / iconSize)
		local dropY = math.ceil((mouseY - self:GetPadding(2) - (itemPanel.gridH - 1) * 32) / iconSize)

		local hoveredPanel = vgui.GetHoveredPanel()

		if (IsValid(hoveredPanel) and hoveredPanel != itemPanel and hoveredPanel.GetItemTable) then
			local hoveredItem = hoveredPanel:GetItemTable()

			if (hoveredItem) then
				local info = hoveredItem.functions.combine

				if (info and info.OnCanRun and info.OnCanRun(hoveredItem, {item.id}) != false) then
					local accent = ix.eui.colors.accent

					surface.SetDrawColor(accent.r, accent.g, accent.b, 40)
					surface.DrawRect(hoveredPanel.x, hoveredPanel.y, hoveredPanel:GetWide(), hoveredPanel:GetTall())

					surface.SetMaterial(GetIcon("combine"))
					surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
					surface.DrawTexturedRect(hoveredPanel.x + hoveredPanel:GetWide() * 0.5 - 12,
						hoveredPanel.y + hoveredPanel:GetTall() * 0.5 - 12, 24, 24)

					self.combineItem = hoveredItem

					return
				end
			end
		end

		self.combineItem = nil

		-- don't draw grid if we're dragging it out of bounds
		if (inventory) then
			local invWidth, invHeight = inventory:GetSize()

			if (dropX < 1 or dropY < 1 or
				dropX + itemPanel.gridW - 1 > invWidth or
				dropY + itemPanel.gridH - 1 > invHeight) then
				return
			end
		end

		local bEmpty = true

		for x = 0, itemPanel.gridW - 1 do
			for y = 0, itemPanel.gridH - 1 do
				local x2 = dropX + x
				local y2 = dropY + y

				bEmpty = self:IsEmpty(x2, y2, itemPanel)

				if (!bEmpty) then
					-- no need to iterate further since we know something is blocking the hovered grid cells, break through both loops
					goto finish
				end
			end
		end

		::finish::
		local color = bEmpty and Color(110, 200, 120) or ix.eui.colors.danger
		local previewX = (dropX - 1) * iconSize + 4
		local previewY = (dropY - 1) * iconSize + self:GetPadding(2)

		surface.SetDrawColor(color.r, color.g, color.b, 34)
		surface.DrawRect(previewX, previewY, itemPanel:GetWide(), itemPanel:GetTall())

		ix.eui.DrawCorners(previewX, previewY, itemPanel:GetWide(), itemPanel:GetTall(), 8, ColorAlpha(color, 230))
	end
end

-- буквы столбцов: A..Z, дальше AA, AB...
local function ColumnName(index)
	local name = ""

	while (index > 0) do
		local rest = (index - 1) % 26
		name = string.char(65 + rest) .. name
		index = math.floor((index - 1) / 26)
	end

	return name
end

function PANEL:PaintOver(width, height)
	local panel = self.previewPanel

	if (IsValid(panel)) then
		local itemPanel = (dragndrop.GetDroppable() or {})[1]

		if (IsValid(itemPanel)) then
			self:PaintDragPreview(width, height, self.previewX, self.previewY, itemPanel)
		end
	end

	self.previewPanel = nil

	-- координатная линейка вокруг основной сетки
	if (self.bMainGrid and self.gridW and self.gridH) then
		local iconSize = self.iconSize
		local top = self:GetPadding(2)
		local color = ColorAlpha(ix.eui.colors.textDim, 170)

		DisableClipping(true)
			for x = 1, self.gridW do
				draw.SimpleText(ColumnName(x), "z19InvTiny", 4 + (x - 0.5) * iconSize, top - 4, color,
					TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
			end

			for y = 1, self.gridH do
				draw.SimpleText(tostring(y), "z19InvTiny", 0, top + (y - 0.5) * iconSize, color,
					TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
		DisableClipping(false)

		ix.eui.DrawCorners(0, 0, width, height, 12, ColorAlpha(ix.eui.colors.accent, 150))
	end
end

function PANEL:IsEmpty(x, y, this)
	return (self.slots[x] and self.slots[x][y]) and (!IsValid(self.slots[x][y].item) or self.slots[x][y].item == this)
end

function PANEL:IsAllEmpty(x, y, width, height, this)
	for x2 = 0, width - 1 do
		for y2 = 0, height - 1 do
			if (!self:IsEmpty(x + x2, y + y2, this)) then
				return false
			end
		end
	end

	return true
end

function PANEL:OnTransfer(oldX, oldY, x, y, oldInventory, noSend)
	local inventories = ix.item.inventories
	local inventory = inventories[oldInventory.invID]
	local inventory2 = inventories[self.invID]
	local item

	if (inventory) then
		item = inventory:GetItemAt(oldX, oldY)

		if (!item) then
			return false
		end

		if (hook.Run("CanTransferItem", item, inventories[oldInventory.invID], inventories[self.invID]) == false) then
			return false, "notAllowed"
		end

		if (item.CanTransfer and
			item:CanTransfer(inventory, inventory != inventory2 and inventory2 or nil) == false) then
			return false
		end
	end

	if (!noSend) then
		net.Start("ixInventoryMove")
			net.WriteUInt(oldX, 6)
			net.WriteUInt(oldY, 6)
			net.WriteUInt(x, 6)
			net.WriteUInt(y, 6)
			net.WriteUInt(oldInventory.invID, 32)
			net.WriteUInt(self != oldInventory and self.invID or oldInventory.invID, 32)
		net.SendToServer()
	end

	if (inventory) then
		inventory.slots[oldX][oldY] = nil
	end

	if (item and inventory2) then
		inventory2.slots[x] = inventory2.slots[x] or {}
		inventory2.slots[x][y] = item
	end
end

function PANEL:AddIcon(model, x, y, w, h, skin)
	local iconSize = self.iconSize

	w = w or 1
	h = h or 1

	if (self.slots[x] and self.slots[x][y]) then
		local panel = self:Add("ixItemIcon")
		panel:SetSize(w * iconSize, h * iconSize)
		panel:SetZPos(999)
		panel:InvalidateLayout(true)
		panel:SetModel(model, skin)
		panel:SetPos(self.slots[x][y]:GetPos())
		panel.gridX = x
		panel.gridY = y
		panel.gridW = w
		panel.gridH = h

		local inventory = ix.item.inventories[self.invID]

		if (!inventory) then
			return
		end

		local itemTable = inventory:GetItemAt(panel.gridX, panel.gridY)

		panel:SetInventoryID(inventory:GetID())
		panel:SetItemTable(itemTable)

		if (self.panels[itemTable:GetID()]) then
			self.panels[itemTable:GetID()]:Remove()
		end

		if (itemTable.exRender) then
			panel.Icon:SetVisible(false)
			panel.ExtraPaint = function(this, panelX, panelY)
				local exIcon = ikon:GetIcon(itemTable.uniqueID)
				if (exIcon) then
					surface.SetMaterial(exIcon)
					surface.SetDrawColor(color_white)
					surface.DrawTexturedRect(0, 0, panelX, panelY)
				else
					ikon:renderIcon(
						itemTable.uniqueID,
						itemTable.width,
						itemTable.height,
						itemTable:GetModel(),
						itemTable.iconCam
					)
				end
			end
		else
			-- yeah..
			RenderNewIcon(panel, itemTable)
		end

		panel.slots = {}

		for i = 0, w - 1 do
			for i2 = 0, h - 1 do
				local slot = self.slots[x + i] and self.slots[x + i][y + i2]

				if (IsValid(slot)) then
					slot.item = panel
					panel.slots[#panel.slots + 1] = slot
				else
					for _, v in ipairs(panel.slots) do
						v.item = nil
					end

					panel:Remove()

					return
				end
			end
		end

		return panel
	end
end

function PANEL:ReceiveDrop(panels, bDropped, menuIndex, x, y)
	local panel = panels[1]

	if (!IsValid(panel)) then
		self.previewPanel = nil
		return
	end

	if (bDropped) then
		local inventory = ix.item.inventories[self.invID]

		if (inventory and panel.OnDrop) then
			local dropX = math.ceil((x - 4 - (panel.gridW - 1) * 32) / self.iconSize)
			local dropY = math.ceil((y - self:GetPadding(2) - (panel.gridH - 1) * 32) / self.iconSize)

			panel:OnDrop(true, self, inventory, dropX, dropY)
		end

		self.previewPanel = nil
	else
		self.previewPanel = panel
		self.previewX = x
		self.previewY = y
	end
end

vgui.Register("ixInventory", PANEL, "DFrame")

-- кнопка-метка фильтра категорий
local CHIP = {}

function CHIP:Init()
	self:SetText("")
	self:SetCursor("hand")
	self.label = ""
	self.hover = 0
end

function CHIP:Setup(label, category, color)
	self.label = label:utf8upper()
	self.category = category
	self.color = color

	surface.SetFont("z19InvMonoBold")
	local textW = surface.GetTextSize(self.label)

	self:SetWide(textW + (color and 26 or 18))
end

function CHIP:IsActive()
	return ix.gui.invFilter.category == self.category
end

function CHIP:OnCursorEntered()
	if (ix.z19) then
		ix.z19.PlayUI("hover")
	end
end

function CHIP:DoClick()
	ix.gui.invFilter.category = self.category

	if (ix.z19) then
		ix.z19.PlayUI("click")
	end
end

function CHIP:Paint(width, height)
	local eui = ix.eui
	local accent = eui.colors.accent
	local bActive = self:IsActive()

	self.hover = math.Approach(self.hover, self:IsHovered() and 1 or 0, FrameTime() * 8)

	if (bActive) then
		surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
		surface.DrawRect(0, 0, width, height)
	else
		surface.SetDrawColor(255, 255, 255, 8 + self.hover * 14)
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)
	end

	local x = 9

	if (self.color) then
		surface.SetDrawColor(bActive and Color(20, 20, 22) or self.color)
		surface.DrawRect(9, height * 0.5 - 3, 6, 6)
		x = 19
	end

	draw.SimpleText(self.label, "z19InvMonoBold", x, height * 0.5,
		bActive and Color(20, 20, 22) or ColorAlpha(eui.colors.text, 180 + self.hover * 75),
		TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
end

vgui.Register("z19InvChip", CHIP, "DButton")

-- склад: панель поиска и фильтров, «чертёж» с сеткой, шкала занятых ячеек
local STORAGE = {}

function STORAGE:Init()
	local eui = ix.eui
	local margin = ScreenScale(6)

	ix.gui.invFilter = {}
	ix.gui.invSelected = nil

	self.toolbar = self:Add("Panel")
	self.toolbar:Dock(TOP)
	self.toolbar:SetTall(ScreenScale(17))
	self.toolbar:DockPadding(margin, ScreenScale(3), margin, ScreenScale(3))

	-- поиск
	self.search = self.toolbar:Add("DTextEntry")
	self.search:Dock(RIGHT)
	self.search:SetWide(ScreenScale(90))
	self.search:SetFont("z19InvMono")
	self.search:SetUpdateOnType(true)
	self.search:SetPaintBackground(false)
	self.search:SetTextColor(eui.colors.text)
	self.search:SetCursorColor(eui.colors.accent)
	self.search:SetHighlightColor(ColorAlpha(eui.colors.accent, 120))
	self.search:SetTextInset(ScreenScale(11), 0)
	self.search.OnValueChange = function(this, value)
		value = string.Trim(value or "")
		ix.gui.invFilter.text = value != "" and value:utf8lower() or nil
	end
	self.search.Paint = function(this, width, height)
		local accent = eui.colors.accent
		local bFocus = this:HasFocus()

		surface.SetDrawColor(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, 220)
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(bFocus and ColorAlpha(accent, 200) or eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)

		local size = height * 0.5

		surface.SetMaterial(GetIcon("search"))
		surface.SetDrawColor(bFocus and accent or eui.colors.textDim)
		surface.DrawTexturedRect(ScreenScale(3), height * 0.5 - size * 0.5, size, size)

		if (this:GetValue() == "" and !bFocus) then
			draw.SimpleText("ПОИСК ПРЕДМЕТА...", "z19InvMono", ScreenScale(11), height * 0.5,
				ColorAlpha(eui.colors.textDim, 160), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end

		this:DrawTextEntryText(eui.colors.text, ColorAlpha(accent, 120), accent)
	end

	-- метки категорий
	self.chips = self:Add("Panel")
	self.chips:Dock(TOP)
	self.chips:SetTall(ScreenScale(10))
	self.chips:DockMargin(margin, ScreenScale(2), margin, 0)

	-- низ: шкала ячеек и подсказка
	self.footer = self:Add("Panel")
	self.footer:Dock(BOTTOM)
	self.footer:SetTall(ScreenScale(17))
	self.footer.Paint = function(this, width, height)
		self:PaintFooter(width, height)
	end

	-- место под сетку (с отступом под координатную линейку)
	self.canvas = self:Add("DTileLayout")
	self.canvas:SetBorder(0)
	self.canvas:SetSpaceX(ScreenScale(8))
	self.canvas:SetSpaceY(ScreenScale(8))
	self.canvas:Dock(FILL)
	self.canvas:DockMargin(margin + ScreenScale(8), ScreenScale(12), margin, ScreenScale(4))

	self.categoryKey = ""
	self.nextCategoryCheck = 0
end

function STORAGE:GetInventory()
	local character = LocalPlayer():GetCharacter()

	return character and character:GetInventory()
end

-- пересобрать метки категорий, если набор категорий в инвентаре изменился
function STORAGE:Think()
	if (self.nextCategoryCheck > RealTime()) then
		return
	end

	self.nextCategoryCheck = RealTime() + 0.5

	local inventory = self:GetInventory()

	if (!inventory) then
		return
	end

	local categories = {}

	for _, item in pairs(inventory:GetItems(true)) do
		categories[item.category or "misc"] = true
	end

	local list = table.GetKeys(categories)
	table.sort(list)

	local key = table.concat(list, "|")

	if (key == self.categoryKey) then
		return
	end

	self.categoryKey = key
	self.chips:Clear()

	if (ix.gui.invFilter.category and !categories[ix.gui.invFilter.category]) then
		ix.gui.invFilter.category = nil
	end

	local all = self.chips:Add("z19InvChip")
	all:Dock(LEFT)
	all:DockMargin(0, 0, 4, 0)
	all:Setup("ВСЕ", nil)

	for _, category in ipairs(list) do
		local chip = self.chips:Add("z19InvChip")
		chip:Dock(LEFT)
		chip:DockMargin(0, 0, 4, 0)
		chip:Setup(L(category), category, GetCategoryColor({category = category}))
	end
end

function STORAGE:Paint(width, height)
	local eui = ix.eui
	local accent = eui.colors.accent
	local toolbarH = self.toolbar:GetTall()

	surface.SetDrawColor(eui.colors.panel)
	surface.DrawRect(0, 0, width, height)

	-- «миллиметровка» чертежа
	local step = math.max(ScreenScale(8), 16)

	surface.SetDrawColor(255, 255, 255, 5)

	for x = step, width, step do
		surface.DrawRect(x, toolbarH, 1, height - toolbarH)
	end

	for y = toolbarH + step, height, step do
		surface.DrawRect(0, y, width, 1)
	end

	-- крупный номер зоны фоном
	draw.SimpleText("19", "eixGhostFont", width - ScreenScale(4), height - self.footer:GetTall(),
		Color(255, 255, 255, 6), TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)

	-- шапка
	surface.SetDrawColor(eui.colors.panelLight)
	surface.DrawRect(0, 0, width, toolbarH)

	surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
	surface.DrawRect(0, 0, 4, toolbarH)

	surface.SetMaterial(GetIcon("backpack"))
	surface.SetDrawColor(accent.r, accent.g, accent.b, 255)

	local iconSize = toolbarH * 0.5
	local textX = ScreenScale(6)

	surface.DrawTexturedRect(textX, toolbarH * 0.5 - iconSize * 0.5, iconSize, iconSize)
	textX = textX + iconSize + ScreenScale(4)

	draw.SimpleText("ЛИЧНЫЕ ВЕЩИ", "z19InvTitle", textX, toolbarH * 0.5, eui.colors.text,
		TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

	surface.SetFont("z19InvTitle")
	textX = textX + surface.GetTextSize("ЛИЧНЫЕ ВЕЩИ") + ScreenScale(6)

	local inventory = self:GetInventory()

	draw.SimpleText(string.format("КОНТЕЙНЕР №%05d  //  ОПИСЬ ИМУЩЕСТВА", inventory and inventory:GetID() or 0),
		"z19InvMono", textX, toolbarH * 0.5, ColorAlpha(eui.colors.textDim, 200), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

	surface.SetDrawColor(eui.colors.hairline)
	surface.DrawRect(0, toolbarH, width, 1)
	surface.DrawOutlinedRect(0, 0, width, height)
end

function STORAGE:PaintFooter(width, height)
	local eui = ix.eui
	local accent = eui.colors.accent
	local inventory = self:GetInventory()
	local margin = ScreenScale(6)

	surface.SetDrawColor(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, 160)
	surface.DrawRect(1, 0, width - 2, height - 1)

	surface.SetDrawColor(eui.colors.hairline)
	surface.DrawRect(0, 0, width, 1)

	if (!inventory) then
		return
	end

	local gridW, gridH = inventory:GetSize()
	local total = math.max(gridW * gridH, 1)
	local used = 0

	for _, item in pairs(inventory:GetItems(true)) do
		used = used + (item.width or 1) * (item.height or 1)
	end

	local fraction = math.min(used / total, 1)
	local color = fraction > 0.85 and eui.colors.danger or accent

	draw.SimpleText(string.format("ЗАНЯТО %d / %d", used, total), "z19InvMonoBold", margin, height * 0.32, color,
		TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

	draw.SimpleText("ЛКМ — ВЫБРАТЬ   ·   ПКМ — ДЕЙСТВИЯ   ·   ТАЩИТЬ ЗА ПРЕДЕЛЫ — ВЫБРОСИТЬ", "z19InvMono",
		width - margin, height * 0.32, ColorAlpha(eui.colors.textDim, 180), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)

	-- по сегменту на ячейку
	local barY = height * 0.62
	local barW = width - margin * 2
	local gap = total > 60 and 1 or 2
	local segment = (barW - gap * (total - 1)) / total

	for i = 1, total do
		local x = margin + (i - 1) * (segment + gap)

		if (i <= used) then
			surface.SetDrawColor(color.r, color.g, color.b, 230)
		else
			surface.SetDrawColor(255, 255, 255, 16)
		end

		surface.DrawRect(x, barY, math.max(segment, 1), 5)
	end
end

vgui.Register("z19InvStorage", STORAGE, "Panel")

hook.Add("CreateMenuButtons", "ixInventory", function(tabs)
	if (hook.Run("CanPlayerViewInventory") == false) then
		return
	end

	tabs["inv"] = {
		bDefault = true,
		Create = function(info, container)
			-- правая колонка: досье выбранного предмета
			local details = container:Add("z19ItemDetails")
			details:Dock(RIGHT)
			details:SetWide(math.max(container:GetWide() * 0.27, 320))
			details:DockMargin(ScreenScale(6), 0, 0, 0)

			local storage = container:Add("z19InvStorage")
			storage:Dock(FILL)

			local canvas = storage.canvas
			local canvasLayout = canvas.PerformLayout
			canvas.PerformLayout = nil -- we'll layout after we add the panels instead of each time one is added

			ix.gui.menuInventoryContainer = canvas

			local panel = canvas:Add("ixInventory")
			panel:SetPos(0, 0)
			panel:SetDraggable(false)
			panel:SetSizable(false)
			panel:SetTitle(nil)
			panel.bNoBackgroundBlur = true
			panel.bMainGrid = true
			panel.childPanels = {}

			local inventory = LocalPlayer():GetCharacter():GetInventory()

			-- размер ячейки: сетка занимает доступную высоту склада (и не больше ~2/3 ширины)
			do
				local gridW, gridH = 6, 5

				if (inventory) then
					gridW, gridH = inventory:GetSize()
				end

				local availableW = (container:GetWide() - details:GetWide() - ScreenScale(6)) * 0.62
				local availableH = container:GetTall() - ScreenScale(17) * 2 - ScreenScale(12) - ScreenScale(36)
				local size = math.min(availableW / math.max(gridW, 1), availableH / math.max(gridH, 1))

				panel:SetIconSize(math.floor(math.Clamp(size, 56, ScrH() * 0.11)))
			end

			if (inventory) then
				panel:SetInventory(inventory)
			end

			ix.gui.inv1 = panel

			if (ix.option.Get("openBags", true)) then
				for _, v in pairs(inventory:GetItems()) do
					if (!v.isBag) then
						continue
					end

					v.functions.View.OnClick(v)
				end
			end

			canvas.PerformLayout = canvasLayout
			canvas:Layout()
		end
	}
end)

hook.Add("PostRenderVGUI", "ixInvHelper", function()
	local pnl = ix.gui.inv1

	hook.Run("PostDrawInventory", pnl)
end)

-- кнопка действия предмета в досье
local ACTION = {}

function ACTION:Init()
	self:SetText("")
	self:SetCursor("hand")
	self:SetTall(ScreenScale(13))
	self.hover = 0
end

function ACTION:Setup(item, inventoryID, key, info)
	self.item = item
	self.inventoryID = inventoryID
	self.key = key
	self.info = info
	self.label = L(info.name or key):utf8upper()
	self.icon = GetActionIcon(key)
	self.bDanger = key == "drop"
end

function ACTION:OnCursorEntered()
	if (ix.z19) then
		ix.z19.PlayUI("hover")
	end
end

function ACTION:DoClick()
	local item, info = self.item, self.info

	if (ix.z19) then
		ix.z19.PlayUI("click")
	end

	-- действие с вариантами — выпадающий список
	if (info.isMulti and info.multiOptions) then
		item.player = LocalPlayer()
		local options = isfunction(info.multiOptions) and info.multiOptions(item, LocalPlayer()) or info.multiOptions
		item.player = nil

		local menu = DermaMenu()

		for _, sub in pairs(options) do
			menu:AddOption(L(sub.name or "subOption"), function()
				RunItemFunction(item, self.inventoryID, self.key, sub, sub.data)
			end)
		end

		menu:Open()
		return
	end

	RunItemFunction(item, self.inventoryID, self.key, info)

	-- список действий мог измениться (надел/снял)
	local details = self:GetParent():GetParent()

	timer.Simple(0.3, function()
		if (IsValid(details) and details.RebuildActions) then
			details:RebuildActions()
		end
	end)
end

function ACTION:Paint(width, height)
	local eui = ix.eui
	local color = self.bDanger and eui.colors.danger or eui.colors.accent

	self.hover = math.Approach(self.hover, (self:IsHovered() or self.Depressed) and 1 or 0, FrameTime() * 10)

	surface.SetDrawColor(255, 255, 255, 7)
	surface.DrawRect(0, 0, width, height)

	if (self.hover > 0) then
		surface.SetDrawColor(color.r, color.g, color.b, 40 * self.hover)
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(color.r, color.g, color.b, 255)
		surface.DrawRect(0, 0, width * self.hover, 1)
	end

	surface.SetDrawColor(color.r, color.g, color.b, 255)
	surface.DrawRect(0, 0, 3, height)

	surface.SetDrawColor(eui.colors.hairline)
	surface.DrawOutlinedRect(0, 0, width, height)

	local size = height * 0.5

	surface.SetMaterial(self.icon)
	surface.SetDrawColor(color.r, color.g, color.b, 255)
	surface.DrawTexturedRect(ScreenScale(5), height * 0.5 - size * 0.5, size, size)

	draw.SimpleText(self.label, "z19InvLabel", ScreenScale(5) + size + ScreenScale(4), height * 0.5,
		ColorAlpha(eui.colors.text, 200 + 55 * self.hover), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

	draw.SimpleText("›", "z19InvLabel", width - ScreenScale(5) + self.hover * 3, height * 0.5,
		ColorAlpha(color, 120 + 135 * self.hover), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
end

vgui.Register("z19ItemAction", ACTION, "DButton")

-- досье объекта: выбранный (или наведённый) предмет — модель в окне сканера, данные и действия
local DETAILS = {}

function DETAILS:Init()
	self.model = self:Add("DModelPanel")
	self.model:SetVisible(false)
	self.model:SetMouseInputEnabled(false)
	self.model:SetFOV(30)
	self.model.LayoutEntity = function(this, entity)
		entity:SetAngles(Angle(0, RealTime() * 30 % 360, 0))
	end

	self.description = self:Add("DLabel")
	self.description:SetFont("z19InvBody")
	self.description:SetTextColor(ix.eui.colors.textDim)
	self.description:SetWrap(true)
	self.description:SetContentAlignment(7)
	self.description:SetText("")

	self.actions = self:Add("Panel")
end

function DETAILS:GetLayout(width, height)
	local header = ScreenScale(17)
	local modelH = math.floor(height * 0.34)
	local infoY = header + modelH + ScreenScale(6)
	local footerH = ScreenScale(16)

	return header, modelH, infoY, footerH
end

function DETAILS:PerformLayout(width, height)
	local header, modelH, infoY, footerH = self:GetLayout(width, height)
	local margin = ScreenScale(6)
	local actionsH = self.actionCount and (self.actionCount * (ScreenScale(13) + 3)) or 0

	self.model:SetPos(1, header + 1)
	self.model:SetSize(width - 2, modelH - 2)

	local descriptionY = infoY + ScreenScale(30)
	local actionsY = height - footerH - margin - actionsH

	self.description:SetPos(margin, descriptionY)
	self.description:SetSize(width - margin * 2, math.max(actionsY - descriptionY - margin, 0))

	self.actions:SetPos(margin, actionsY)
	self.actions:SetSize(width - margin * 2, actionsH)
end

function DETAILS:SetItem(itemTable, bSelected)
	if (self.item == itemTable and self.bSelected == bSelected) then
		return
	end

	self.item = itemTable
	self.bSelected = bSelected
	self.scanStart = RealTime()

	if (!itemTable) then
		self.model:SetVisible(false)
		self.description:SetText("")
		self:RebuildActions()
		return
	end

	self.model:SetVisible(true)
	self.model:SetModel(itemTable:GetModel())

	if (IsValid(self.model.Entity) and itemTable.GetSkin) then
		self.model.Entity:SetSkin(itemTable:GetSkin() or 0)
	end

	-- камера: предмет целиком в кадре
	local entity = self.model.Entity

	if (IsValid(entity)) then
		local mins, maxs = entity:GetRenderBounds()
		local size = math.max(maxs.x - mins.x, maxs.y - mins.y, maxs.z - mins.z)
		local center = (mins + maxs) * 0.5

		self.model:SetLookAt(center)
		self.model:SetCamPos(center + Vector(1, 1, 0.6):GetNormalized() * size * 1.9)
	end

	local description = itemTable.GetDescription and itemTable:GetDescription() or itemTable.description or ""
	self.description:SetText(L(description))

	self:RebuildActions()
end

-- кнопки действий — только для выбранного предмета
function DETAILS:RebuildActions()
	self.actions:Clear()
	self.actionCount = 0

	local item = self.item

	if (item and self.bSelected and item.invID) then
		for _, action in ipairs(GetItemActions(item)) do
			local button = self.actions:Add("z19ItemAction")
			button:Dock(TOP)
			button:DockMargin(0, 0, 0, 3)
			button:Setup(item, item.invID, action[1], action[2])

			self.actionCount = self.actionCount + 1
		end
	end

	self:InvalidateLayout()
end

function DETAILS:Think()
	-- выбранный предмет пропал (выброшен, использован) — снять выбор
	local selectedID = ix.gui.invSelected
	local selected = selectedID and ix.item.instances[selectedID]

	if (selectedID and (!selected or !ix.item.inventories[selected.invID or 0])) then
		ix.gui.invSelected = nil
		selected = nil
	end

	if (selected) then
		self:SetItem(selected, true)
		return
	end

	-- ничего не выбрано — показываем предмет под курсором
	local hovered = vgui.GetHoveredPanel()

	if (IsValid(hovered) and hovered.itemTable and hovered.gridX) then
		self:SetItem(hovered.itemTable, false)
	elseif (self.bSelected) then
		self:SetItem(nil, false)
	end
end

function DETAILS:Paint(width, height)
	local eui = ix.eui
	local accent = eui.colors.accent
	local header, modelH, infoY, footerH = self:GetLayout(width, height)
	local margin = ScreenScale(6)
	local item = self.item

	surface.SetDrawColor(eui.colors.panel)
	surface.DrawRect(0, 0, width, height)

	-- шапка
	surface.SetDrawColor(eui.colors.panelLight)
	surface.DrawRect(0, 0, width, header)

	surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
	surface.DrawRect(0, 0, 4, header)

	draw.SimpleText("ДОСЬЕ ОБЪЕКТА", "z19InvTitle", margin, header * 0.5, eui.colors.text,
		TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

	draw.SimpleText(item and string.format("№%06d", item.id or 0) or "—", "z19InvMono", width - margin, header * 0.5,
		ColorAlpha(eui.colors.textDim, 200), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)

	-- окно сканера
	local modelY = header

	surface.SetDrawColor(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, 200)
	surface.DrawRect(1, modelY, width - 2, modelH)

	local color = item and GetCategoryColor(item) or accent

	eui.DrawGradientV(1, modelY + modelH * 0.4, width - 2, modelH * 0.6, ColorAlpha(color, 22))

	-- сетка сканера
	surface.SetDrawColor(255, 255, 255, 6)

	for x = margin, width - margin, ScreenScale(10) do
		surface.DrawRect(x, modelY + 4, 1, modelH - 8)
	end

	eui.DrawCorners(margin, modelY + margin, width - margin * 2, modelH - margin * 2, 12, ColorAlpha(accent, 140))

	if (item) then
		-- проход сканера при смене предмета
		local scan = math.Clamp((RealTime() - (self.scanStart or 0)) / 0.6, 0, 1)

		if (scan < 1) then
			local scanY = modelY + modelH * scan

			surface.SetDrawColor(accent.r, accent.g, accent.b, 200 * (1 - scan))
			surface.DrawRect(1, scanY, width - 2, 2)
		end

		draw.SimpleText(self.bSelected and "● ВЫБРАН" or "○ ПРОСМОТР", "z19InvTiny", margin + 4, modelY + margin + 4,
			ColorAlpha(self.bSelected and accent or eui.colors.textDim, 220), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	else
		surface.SetMaterial(GetIcon("box"))
		surface.SetDrawColor(255, 255, 255, 30)

		local size = modelH * 0.3
		surface.DrawTexturedRect(width * 0.5 - size * 0.5, modelY + modelH * 0.42 - size * 0.5, size, size)

		draw.SimpleText("ВЫБЕРИТЕ ПРЕДМЕТ", "z19InvMonoBold", width * 0.5, modelY + modelH * 0.72,
			ColorAlpha(eui.colors.textDim, 200), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	surface.SetDrawColor(eui.colors.hairline)
	surface.DrawRect(0, modelY + modelH, width, 1)

	-- название и метки
	if (item) then
		local name = GetItemName(item):utf8upper()

		draw.SimpleText(name, "z19InvName", margin, infoY, eui.colors.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

		local tagY = infoY + ScreenScale(14)
		local tagX = margin
		local tags = {
			{L(item.category or "misc"):utf8upper(), color},
			{string.format("%d×%d", item.width or 1, item.height or 1), eui.colors.textDim}
		}

		if (item.GetData and item:GetData("equip")) then
			tags[#tags + 1] = {"ЭКИПИРОВАН", Color(110, 200, 120)}
		end

		surface.SetFont("z19InvTiny")

		for _, tag in ipairs(tags) do
			local textW, textH = surface.GetTextSize(tag[1])
			local tagW, tagH = textW + 12, textH + 6

			surface.SetDrawColor(tag[2].r, tag[2].g, tag[2].b, 30)
			surface.DrawRect(tagX, tagY, tagW, tagH)

			surface.SetDrawColor(tag[2].r, tag[2].g, tag[2].b, 160)
			surface.DrawOutlinedRect(tagX, tagY, tagW, tagH)

			draw.SimpleText(tag[1], "z19InvTiny", tagX + 6, tagY + tagH * 0.5, tag[2], TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

			tagX = tagX + tagW + 4
		end

		if (!self.bSelected) then
			draw.SimpleText("ЛКМ ПО ПРЕДМЕТУ — ДЕЙСТВИЯ", "z19InvTiny", margin, height - footerH - margin,
				ColorAlpha(eui.colors.textDim, 150), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
		end
	end

	-- низ: баланс
	local footerY = height - footerH

	surface.SetDrawColor(eui.colors.bg.r, eui.colors.bg.g, eui.colors.bg.b, 160)
	surface.DrawRect(1, footerY, width - 2, footerH - 1)

	surface.SetDrawColor(eui.colors.hairline)
	surface.DrawRect(0, footerY, width, 1)

	local character = LocalPlayer():GetCharacter()

	if (character) then
		draw.SimpleText("БАЛАНС", "z19InvMono", margin, footerY + footerH * 0.5, eui.colors.textDim,
			TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(ix.currency.Get(character:GetMoney()), "z19InvLabel", width - margin, footerY + footerH * 0.5,
			accent, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	end

	surface.SetDrawColor(eui.colors.hairline)
	surface.DrawOutlinedRect(0, 0, width, height)
end

vgui.Register("z19ItemDetails", DETAILS, "Panel")
