
--[[
	Enhanced Helix — ui_derma
	Меню Зоны-19 (ixMenu, открывается по Q): слева вертикальная лента кнопок-иконок
	(подпись всплывает при наведении, секции — выезжающим списком справа от иконки),
	справа шапка раздела и контент. Логика вкладок, секций и анимаций — как в оригинале.
	Иконки — Tabler Icons (MIT), materials/scp_ui/menu/<вкладка>.png.
]]

local animationTime = 1
local matrixZScale = Vector(1, 1, 0.0001)

local iconMaterials = {}

local function GetTabIcon(name)
	name = tostring(name or "default")

	if (!iconMaterials[name]) then
		local material = Material("scp_ui/menu/" .. name .. ".png", "smooth mips")

		if (material:IsError()) then
			material = Material("scp_ui/menu/default.png", "smooth mips")
		end

		iconMaterials[name] = material
	end

	return iconMaterials[name]
end

-- кнопка-иконка ленты: внешний вид поверх ixMenuButton / ixMenuSelectionButton
-- (логика выбора и секций остаётся от них)
local function StyleRailButton(button, iconName, label)
	button:SetText("", true)
	button.railIcon = GetTabIcon(iconName)
	button.railLabel = label
	button.railHover = 0

	button.Paint = function(this, width, height)
		local accent = ix.eui.colors.accent

		-- подсветка включается сразу и не пропадает при нажатии
		if (this:IsHovered() or this.Depressed) then
			this.railHover = 1
		else
			this.railHover = math.Approach(this.railHover, 0, FrameTime() * 5)
		end

		local bSelected = (this.GetSelected and this:GetSelected())
			or (IsValid(this.sectionPanel) and this.sectionPanel:IsVisible())

		if (bSelected) then
			surface.SetDrawColor(accent.r, accent.g, accent.b, 28)
			surface.DrawRect(0, 0, width, height)

			surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
			surface.DrawRect(0, 0, 3, height)
		elseif (this.railHover > 0) then
			surface.SetDrawColor(255, 255, 255, 12 * this.railHover)
			surface.DrawRect(0, 0, width, height)
		end

		local size = math.floor(height * 0.46)
		local color = bSelected and accent or ix.eui.colors.text
		local alpha = bSelected and 255 or Lerp(this.railHover, 150, 255)

		surface.SetMaterial(this.railIcon)
		surface.SetDrawColor(color.r, color.g, color.b, alpha)
		surface.DrawTexturedRect(width * 0.5 - size * 0.5, height * 0.5 - size * 0.5, size, size)

		if (this.railHover > 0 and IsValid(ix.gui.menu)) then
			ix.gui.menu.hoveredRail = this
		end
	end

	button.OnCursorEntered = function(this)
		if (ix.z19) then
			ix.z19.PlayUI("hover")
		end
	end
end

DEFINE_BASECLASS("ixSubpanelParent")
local PANEL = {}

AccessorFunc(PANEL, "bCharacterOverview", "CharacterOverview", FORCE_BOOL)

function PANEL:Init()
	if (IsValid(ix.gui.menu)) then
		ix.gui.menu:Remove()
	end

	ix.gui.menu = self

	-- properties
	self.manualChildren = {}
	self.noAnchor = CurTime() + 0.4
	self.anchorMode = true
	self.rotationOffset = Angle(0, 180, 0)
	self.projectedTexturePosition = Vector(0, 0, 6)
	self.projectedTextureRotation = Angle(-45, 60, 0)

	self.bCharacterOverview = false
	self.bOverviewOut = false
	self.overviewFraction = 0

	self.currentAlpha = 0
	self.currentBlur = 0

	-- setup
	self:SetPadding(ScreenScale(16), true)
	self:SetSize(ScrW(), ScrH())
	self:SetPos(0, 0)

	-- лента иконок слева и шапка раздела справа
	self.railWidth = ScreenScale(26)
	self.headerHeight = ScreenScale(20)
	self.navHeight = self.headerHeight
	self.contentY = self:GetPadding() + self.headerHeight + 8
	self:SetLeftOffset(self.railWidth + 8)

	self.buttons = self:Add("Panel")
	self.buttons:SetPos(self:GetPadding(), self:GetPadding())
	self.buttons:SetSize(self.railWidth, self:GetTall() - self:GetPadding() * 2)
	self.buttons:SetPaintedManually(true)
	self.buttons.Paint = function(this, width, height)
		surface.SetDrawColor(ix.eui.colors.panel)
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(ix.eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)

		-- эмблема Фонда сверху ленты
		local logo = ix.z19 and ix.z19.GetMaterial("scp_intro/logo.png")

		if (logo and !logo:IsError()) then
			local size = width * 0.62

			surface.SetMaterial(logo)
			surface.SetDrawColor(255, 255, 255, 230)
			surface.DrawTexturedRect(width * 0.5 - size * 0.5, width * 0.19, size, size)
		end

		surface.SetDrawColor(ix.eui.colors.hairline)
		surface.DrawRect(6, width, width - 12, 1)
	end

	-- место под эмблему
	local logoSpace = self.buttons:Add("Panel")
	logoSpace:Dock(TOP)
	logoSpace:SetTall(self.railWidth + 4)

	local close = self.buttons:Add("ixMenuButton")
	close:Dock(BOTTOM)
	close:SetTall(self.railWidth)
	StyleRailButton(close, "close", L("return"))
	close.DoClick = function()
		self:Remove()
	end

	local characters = self.buttons:Add("ixMenuButton")
	characters:Dock(BOTTOM)
	characters:SetTall(self.railWidth)
	StyleRailButton(characters, "characters", L("characters"))
	characters.DoClick = function()
		self:Remove()
		vgui.Create("ixCharMenu")
	end

	-- @todo make a better way to avoid clicks in the padding PLEASE
	self.guard = self:Add("Panel")
	self.guard:SetPos(0, 0)
	self.guard:SetSize(self:GetPadding(), self:GetTall())

	-- tabs
	self.tabs = self.buttons:Add("Panel")
	self.tabs.buttons = {}
	self.tabs:Dock(FILL)
	self:PopulateTabs()

	self:MakePopup()
	self:OnOpened()
end

function PANEL:OnOpened()
	self:SetAlpha(0)

	self:CreateAnimation(animationTime, {
		target = {currentAlpha = 255},
		easing = "outQuint",

		Think = function(animation, panel)
			panel:SetAlpha(panel.currentAlpha)
		end
	})
end

function PANEL:GetActiveTab()
	return (self:GetActiveSubpanel() or {}).subpanelName
end

function PANEL:TransitionSubpanel(id)
	local lastSubpanel = self:GetActiveSubpanel()

	-- don't transition to the same panel
	if (IsValid(lastSubpanel) and lastSubpanel.subpanelID == id) then
		return
	end

	local subpanel = self:GetSubpanel(id)

	if (IsValid(subpanel)) then
		if (!subpanel.bPopulated) then
			-- we need to set the size of the subpanel if it's a section since it will be 0, 0
			if (subpanel.sectionParent) then
				subpanel:SetSize(self:GetStandardSubpanelSize())
				subpanel:SetPos(subpanel.x, self.contentY)
			end

			local info = subpanel.info
			subpanel.Paint = nil

			if (istable(info) and info.Create) then
				info:Create(subpanel)
			elseif (isfunction(info)) then
				info(subpanel)
			end

			hook.Run("MenuSubpanelCreated", subpanel.subpanelName, subpanel)
			subpanel.bPopulated = true
		end

		-- only play whoosh sound only when the menu was already open
		if (IsValid(lastSubpanel)) then
			if (ix.z19) then
				ix.z19.PlayUI("click")
			else
				LocalPlayer():EmitSound("Helix.Whoosh")
			end
		end

		self:SetActiveSubpanel(id)
	end

	subpanel = self:GetActiveSubpanel()

	local info = subpanel.info
	local bHideBackground = istable(info) and (info.bHideBackground != nil and info.bHideBackground or false) or false

	if (bHideBackground) then
		self:HideBackground()
	else
		self:ShowBackground()
	end

	-- call hooks if we've changed subpanel
	if (IsValid(lastSubpanel) and istable(lastSubpanel.info) and lastSubpanel.info.OnDeselected) then
		lastSubpanel.info:OnDeselected(lastSubpanel)
	end

	if (IsValid(subpanel) and istable(subpanel.info) and subpanel.info.OnSelected) then
		subpanel.info:OnSelected(subpanel)
	end

	ix.gui.lastMenuTab = id
end

function PANEL:SetCharacterOverview(bValue, length)
	bValue = tobool(bValue)
	length = length or animationTime

	if (bValue) then
		if (!IsValid(self.projectedTexture)) then
			self.projectedTexture = ProjectedTexture()
		end

		local faction = ix.faction.indices[LocalPlayer():Team()]
		local color = faction and faction.color or color_white

		self.projectedTexture:SetEnableShadows(false)
		self.projectedTexture:SetNearZ(12)
		self.projectedTexture:SetFarZ(64)
		self.projectedTexture:SetFOV(90)
		self.projectedTexture:SetColor(color)
		self.projectedTexture:SetTexture("effects/flashlight/soft")

		self:CreateAnimation(length, {
			index = 3,
			target = {overviewFraction = 1},
			easing = "outQuint",
			bIgnoreConfig = true
		})

		self.bOverviewOut = false
		self.bCharacterOverview = true
	else
		self:CreateAnimation(length, {
			index = 3,
			target = {overviewFraction = 0},
			easing = "outQuint",
			bIgnoreConfig = true,

			OnComplete = function(animation, panel)
				panel.bCharacterOverview = false

				if (IsValid(panel.projectedTexture)) then
					panel.projectedTexture:Remove()
				end
			end
		})

		self.bOverviewOut = true
	end
end

function PANEL:GetOverviewInfo(origin, angles, fov)
	local originAngles = Angle(0, angles.yaw, angles.roll)
	local target = LocalPlayer():GetObserverTarget()
	local fraction = self.overviewFraction
	local bDrawPlayer = ((fraction > 0.2) or (!self.bOverviewOut and (fraction > 0.2))) and !IsValid(target)
	local forward = originAngles:Forward() * 58 - originAngles:Right() * 16
	forward.z = 0

	local newOrigin

	if (IsValid(target)) then
		newOrigin = target:GetPos() + forward
	else
		newOrigin = origin - LocalPlayer():OBBCenter() * 0.6 + forward
	end

	local newAngles = originAngles + self.rotationOffset
	newAngles.pitch = 5
	newAngles.roll = 0

	return LerpVector(fraction, origin, newOrigin), LerpAngle(fraction, angles, newAngles), Lerp(fraction, fov, 90), bDrawPlayer
end

function PANEL:HideBackground()
	self:CreateAnimation(animationTime, {
		index = 2,
		target = {currentBlur = 0},
		easing = "outQuint"
	})
end

function PANEL:ShowBackground()
	self:CreateAnimation(animationTime, {
		index = 2,
		target = {currentBlur = 1},
		easing = "outQuint"
	})
end

function PANEL:GetStandardSubpanelSize()
	return ScrW() - self:GetPadding() * 2 - self.railWidth - 8, ScrH() - self:GetPadding() * 2 - self.headerHeight - 8
end

function PANEL:SetupTab(name, info, sectionParent)
	local bTable = istable(info)
	local buttonColor = ix.eui.colors.accent
	local bDefault = (bTable and info.bDefault) or false
	local qualifiedName = sectionParent and (sectionParent.name .. "/" .. name) or name

	-- setup subpanels without populating them so we can retain the order
	local subpanel = self:AddSubpanel(qualifiedName, true)
	local id = subpanel.subpanelID
	subpanel.info = info
	subpanel.sectionParent = sectionParent and qualifiedName
	subpanel:SetPaintedManually(true)
	subpanel:SetTitle(nil)

	if (sectionParent) then
		-- hide section subpanels if they haven't been populated to seeing more subpanels than necessary
		-- fly by as you navigate tabs in the menu
		subpanel:SetSize(0, 0)
		subpanel:SetPos(subpanel.x, self.contentY)
	else
		subpanel:SetSize(self:GetStandardSubpanelSize())
		subpanel:SetPos(subpanel.x, self.contentY)

		-- this is called while the subpanel has not been populated
		subpanel.Paint = function(panel, width, height)
			derma.SkinFunc("PaintPlaceholderPanel", panel, width, height)
		end
	end

	local button

	if (sectionParent) then
		button = sectionParent:AddSection(L(name))

		-- секции — выезжающий список справа от иконки вкладки
		local list = sectionParent:GetSectionPanel()

		if (IsValid(list) and !list.eixDropdown) then
			list.eixDropdown = true
			list:SetParent(self)
			list:SetPaintedManually(false)
			list:SetZPos(1000)

			local oldShow = list.Show

			list.Show = function(this)
				local screenX, screenY = sectionParent:LocalToScreen(0, 0)
				local localX, localY = self:ScreenToLocal(screenX, screenY)

				this:SetPos(localX + sectionParent:GetWide() + 6, localY)
				this:SetWide(ScreenScale(90))
				oldShow(this)
			end

			local oldListPaint = list.Paint

			list.Paint = function(this, width, height)
				ix.util.DrawBlur(this, 6)

				surface.SetDrawColor(ix.eui.colors.panel)
				surface.DrawRect(0, 0, width, height)

				surface.SetDrawColor(ix.eui.colors.accent)
				surface.DrawRect(0, 0, 2, height)

				surface.SetDrawColor(ix.eui.colors.hairline)
				surface.DrawOutlinedRect(0, 0, width, height)

				oldListPaint(this, width, height)
			end
		end

		name = qualifiedName
	else
		button = self.tabs:Add("ixMenuSelectionButton")
		button:Dock(TOP)
		button:SetTall(self.railWidth)
		button:SetButtonList(self.tabs.buttons)
		button:SetBackgroundColor(buttonColor)
		StyleRailButton(button, name, L(name))
	end

	button.name = name
	button.id = id
	button.OnSelected = function()
		self:TransitionSubpanel(id)
	end

	if (bTable and info.PopulateTabButton) then
		info:PopulateTabButton(button)
	end

	-- don't allow sections in sections
	if (sectionParent or !bTable or !info.Sections) then
		return bDefault, button, subpanel
	end

	-- create button sections
	for sectionName, sectionInfo in pairs(info.Sections) do
		self:SetupTab(sectionName, sectionInfo, button)
	end

	return bDefault, button, subpanel
end

function PANEL:PopulateTabs()
	local default
	local tabs = {}

	hook.Run("CreateMenuButtons", tabs)

	for name, info in SortedPairs(tabs) do
		local bDefault, button = self:SetupTab(name, info)

		if (bDefault) then
			default = button
		end
	end

	-- открыть конкретную вкладку (Q открывает меню сразу на инвентаре)
	local forced = ix.gui.menuOpenTab
	ix.gui.menuOpenTab = nil

	if (forced) then
		for i = 1, #self.tabs.buttons do
			if (self.tabs.buttons[i].name == forced) then
				default = self.tabs.buttons[i]
				break
			end
		end
	elseif (ix.gui.lastMenuTab) then
		for i = 1, #self.tabs.buttons do
			local button = self.tabs.buttons[i]

			if (button.id == ix.gui.lastMenuTab) then
				default = button
				break
			end
		end
	end

	if (!IsValid(default) and #self.tabs.buttons > 0) then
		default = self.tabs.buttons[1]
	end

	if (IsValid(default)) then
		default:SetSelected(true)
		self:SetActiveSubpanel(default.id, 0)
	end

	self.buttons:MoveToFront()
	self.guard:MoveToBefore(self.buttons)
end

function PANEL:AddManuallyPaintedChild(panel)
	panel:SetParent(self)
	panel:SetPaintedManually(panel)

	self.manualChildren[#self.manualChildren + 1] = panel
end

function PANEL:OnKeyCodePressed(key)
	self.noAnchor = CurTime() + 0.5

	-- повторное нажатие Q (или клавиши, назначенной на +menu) закрывает меню
	local binding = input.LookupBinding("+menu")
	local menuKey = binding and input.GetKeyCode(binding)

	if (key == KEY_Q or key == menuKey) then
		self:Remove()
	end
end

function PANEL:Think()
	if (IsValid(self.projectedTexture)) then
		local forward = LocalPlayer():GetForward()
		forward.z = 0

		local right = LocalPlayer():GetRight()
		right.z = 0

		self.projectedTexture:SetBrightness(self.overviewFraction * 4)
		self.projectedTexture:SetPos(LocalPlayer():GetPos() + right * 16 - forward * 8 + self.projectedTexturePosition)
		self.projectedTexture:SetAngles(forward:Angle() + self.projectedTextureRotation)
		self.projectedTexture:Update()
	end

	if (self.bClosing) then
		return
	end

	-- меню открыто, пока его не закроют (Q, кнопка ленты или меню игры)
	if (gui.IsGameUIVisible()) then
		self:Remove()
	end
end

function PANEL:Paint(width, height)
	derma.SkinFunc("PaintMenuBackground", self, width, height, self.currentBlur)

	-- шапка раздела: название вкладки, путь моно-шрифтом, полоса «опасность»
	do
		local padding = self:GetPadding()
		local frameAlpha = (self.currentAlpha or 255) / 255
		local headerX = padding + self.railWidth + 8
		local headerW = width - headerX - padding
		local accent = ix.eui.colors.accent
		local hazardW = ScreenScale(36)

		surface.SetDrawColor(ix.eui.colors.panel.r, ix.eui.colors.panel.g, ix.eui.colors.panel.b, 235 * frameAlpha)
		surface.DrawRect(headerX, padding, headerW, self.headerHeight)

		surface.SetDrawColor(accent.r, accent.g, accent.b, 255 * frameAlpha)
		surface.DrawRect(headerX, padding + self.headerHeight - 2, ScreenScale(30), 2)

		ix.eui.DrawHazard(headerX + headerW - hazardW, padding, hazardW, self.headerHeight, 230 * frameAlpha)

		local tab = self:GetActiveTab()

		if (tab) then
			local segments = string.Explode("/", tostring(tab))
			local path = {}

			for _, segment in ipairs(segments) do
				path[#path + 1] = L(segment):utf8upper()
			end

			draw.SimpleText(path[#path], "eixTitleFont", headerX + ScreenScale(6), padding + self.headerHeight * 0.5,
				ColorAlpha(ix.eui.colors.text, 255 * frameAlpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

			draw.SimpleText("ЗОНА-19  //  " .. table.concat(path, "  /  "), "eixMonoSmallFont",
				headerX + headerW - hazardW - ScreenScale(6), padding + self.headerHeight * 0.5,
				ColorAlpha(ix.eui.colors.textDim, 220 * frameAlpha), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
	end

	local bShouldScale = self.currentAlpha != 255

	if (bShouldScale) then
		local currentScale = Lerp(self.currentAlpha / 255, 0.9, 1)
		local matrix = Matrix()

		matrix:Scale(matrixZScale * currentScale)
		matrix:Translate(Vector(
			ScrW() * 0.5 - (ScrW() * currentScale * 0.5),
			ScrH() * 0.5 - (ScrH() * currentScale * 0.5),
			1
		))

		cam.PushModelMatrix(matrix)
	end

	BaseClass.Paint(self, width, height)
	self:PaintSubpanels(width, height)
	self.buttons:PaintManual()

	for i = 1, #self.manualChildren do
		self.manualChildren[i]:PaintManual()
	end

	if (IsValid(ix.gui.inv1) and ix.gui.inv1.childPanels) then
		for i = 1, #ix.gui.inv1.childPanels do
			local panel = ix.gui.inv1.childPanels[i]

			if (IsValid(panel)) then
				panel:PaintManual()
			end
		end
	end

	if (bShouldScale) then
		cam.PopModelMatrix()
	end
end

-- подпись кнопки ленты рисуется поверх всего, справа от иконки
function PANEL:PaintOver(width, height)
	local button = self.hoveredRail
	self.hoveredRail = nil

	if (!IsValid(button) or button.railHover <= 0 or !button.railLabel or button.railLabel == "") then
		return
	end

	local screenX, screenY = button:LocalToScreen(0, 0)
	local x, y = self:ScreenToLocal(screenX + button:GetWide() + 8, screenY)
	local text = tostring(button.railLabel):utf8upper()

	surface.SetFont("eixSubTitleFont")
	local textW, textH = surface.GetTextSize(text)
	local boxW, boxH = textW + 20, textH + 10
	local alpha = button.railHover * 255

	y = y + button:GetTall() * 0.5 - boxH * 0.5

	surface.SetDrawColor(ix.eui.colors.bg.r, ix.eui.colors.bg.g, ix.eui.colors.bg.b, alpha * 0.95)
	surface.DrawRect(x, y, boxW, boxH)

	surface.SetDrawColor(ix.eui.colors.accent.r, ix.eui.colors.accent.g, ix.eui.colors.accent.b, alpha)
	surface.DrawRect(x, y, 2, boxH)

	draw.SimpleText(text, "eixSubTitleFont", x + 10, y + boxH * 0.5, ColorAlpha(ix.eui.colors.text, alpha),
		TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
end

function PANEL:PerformLayout()
	self.guard:SetSize(self:GetPadding(), self:GetTall())
end

function PANEL:Remove()
	self.bClosing = true
	self:SetMouseInputEnabled(false)
	self:SetKeyboardInputEnabled(false)
	self:SetCharacterOverview(false, animationTime * 0.5)

	-- remove input from opened child panels since they grab focus
	if (IsValid(ix.gui.inv1) and ix.gui.inv1.childPanels) then
		for i = 1, #ix.gui.inv1.childPanels do
			local panel = ix.gui.inv1.childPanels[i]

			if (IsValid(panel)) then
				panel:SetMouseInputEnabled(false)
				panel:SetKeyboardInputEnabled(false)
			end
		end
	end

	CloseDermaMenus()
	gui.EnableScreenClicker(false)

	self:CreateAnimation(animationTime * 0.5, {
		index = 2,
		target = {currentBlur = 0},
		easing = "outQuint"
	})

	self:CreateAnimation(animationTime * 0.5, {
		target = {currentAlpha = 0},
		easing = "outQuint",

		-- we don't animate the blur because blurring doesn't draw things
		-- with amount < 1 very well, resulting in jarring transition
		Think = function(animation, panel)
			panel:SetAlpha(panel.currentAlpha)
		end,

		OnComplete = function(animation, panel)
			if (IsValid(panel.projectedTexture)) then
				panel.projectedTexture:Remove()
			end

			BaseClass.Remove(panel)
		end
	})
end

vgui.Register("ixMenu", PANEL, "ixSubpanelParent")

if (IsValid(ix.gui.menu)) then
	ix.gui.menu:Remove()
end

ix.gui.lastMenuTab = nil
