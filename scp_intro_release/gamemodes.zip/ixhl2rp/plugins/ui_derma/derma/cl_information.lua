
--[[
	Enhanced Helix — ui_derma
	Вкладка «Вы» (ixCharacterInfo) — личное дело сотрудника Зоны-19:
	- шапка досье: «фото» (живая модель персонажа крупным планом), имя, личный номер,
	  подразделение цветом фракции, дата и время комплекса, штамп допуска;
	- описание/приметы (клик — изменить описание);
	- сведения: подразделение, должность, баланс и строки других плагинов (хук CreateCharacterInfo);
	- характеристики посегментными шкалами с бонусами.
	Слева, как в Helix, камера показывает самого персонажа. Хуки CanCreateCharacterInfo,
	CreateCharacterInfo, UpdateCharacterInfo, CreateCharacterInfoCategory и
	UpdateCharacterInfoCategory работают как в оригинале.
]]

local function CreateFonts()
	local function font(name, face, size, weight, minimum)
		surface.CreateFont(name, {
			font = face,
			size = math.max(math.Round(ScreenScale(size)), minimum or 12),
			weight = weight,
			extended = true,
			antialias = true
		})
	end

	font("z19InfoName", "Zone19 Sans Bold", 15, 700, 30)
	font("z19InfoTitle", "Zone19 Sans Bold", 8.5, 700, 18)
	font("z19InfoValue", "Zone19 Sans Semi", 6.6, 600, 15)
	font("z19InfoBody", "IBM Plex Sans", 6.2, 400, 15)
	font("z19InfoStamp", "Zone19 Sans Black", 8, 900, 17)
	font("z19InfoMono", "JetBrains Mono", 4.7, 400, 11)
	font("z19InfoMonoBold", "JetBrains Mono", 4.9, 700, 12)
end

CreateFonts()
hook.Add("LoadFonts", "z19InformationFonts", CreateFonts)

local icons = {}

local function GetIcon(name)
	if (!icons[name]) then
		icons[name] = Material("scp_ui/info/" .. name .. ".png", "smooth mips")
	end

	return icons[name]
end

local function GetFactionColor()
	local faction = ix.faction.indices[LocalPlayer():Team()]

	return faction and faction.color or ix.eui.colors.accent
end

-- оформление строки ixListRow (свои и добавленные другими плагинами)
local function StyleRow(row)
	if (row.z19Styled) then
		return
	end

	row.z19Styled = true

	row.label:SetFont("z19InfoMonoBold")
	row.label:SetTextColor(ix.eui.colors.textDim)
	row.label:SetExpensiveShadow(0)
	row.label:SetContentAlignment(4)
	row.label:SetTextInset(ScreenScale(13), 0)
	row.label.Paint = nil

	row.text:SetFont("z19InfoValue")
	row.text:SetTextColor(ix.eui.colors.text)
	row.text:SetContentAlignment(6)
	row.text:SetTextInset(ScreenScale(5), 0)
	row.text.Paint = nil

	row:DockMargin(0, 0, 0, 3)
	row:SetMinimumWidth(ScreenScale(70))

	row.Paint = function(this, width, height)
		local eui = ix.eui
		local color = this.z19Color or eui.colors.accent

		surface.SetDrawColor(eui.colors.panel)
		surface.DrawRect(0, 0, width, height)

		surface.SetDrawColor(color.r, color.g, color.b, 255)
		surface.DrawRect(0, 0, 2, height)

		local size = height * 0.46

		surface.SetMaterial(GetIcon(this.z19Icon or "id"))
		surface.SetDrawColor(color.r, color.g, color.b, 220)
		surface.DrawTexturedRect(ScreenScale(4), height * 0.5 - size * 0.5, size, size)

		-- пунктир от подписи к значению
		local labelW = this.label:GetWide()

		surface.SetFont("z19InfoValue")
		local textW = surface.GetTextSize(this.text:GetText() or "")

		surface.SetDrawColor(255, 255, 255, 14)

		for x = labelW + 6, width - textW - ScreenScale(10), 6 do
			surface.DrawRect(x, height * 0.5 + 4, 2, 1)
		end

		surface.SetDrawColor(eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)
	end
end

-- заголовок раздела досье
local SECTION = {}

function SECTION:Init()
	self:Dock(TOP)
	self:SetTall(ScreenScale(13))
	self:DockMargin(0, ScreenScale(5), 0, ScreenScale(3))
	self.title = ""
end

function SECTION:SetTitle(title, code)
	self.title = title:utf8upper()
	self.code = code
end

function SECTION:Paint(width, height)
	local eui = ix.eui
	local accent = eui.colors.accent

	surface.SetFont("z19InfoTitle")
	local textW = surface.GetTextSize(self.title)

	draw.SimpleText(self.title, "z19InfoTitle", 0, height * 0.5, eui.colors.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

	surface.SetDrawColor(accent.r, accent.g, accent.b, 200)
	surface.DrawRect(textW + 8, height * 0.5, width - textW - 8, 1)

	if (self.code) then
		surface.SetFont("z19InfoMono")
		local codeW, codeH = surface.GetTextSize(self.code)

		surface.SetDrawColor(eui.colors.bg)
		surface.DrawRect(width - codeW - 10, height * 0.5 - codeH * 0.5 - 1, codeW + 10, codeH + 2)

		draw.SimpleText(self.code, "z19InfoMono", width, height * 0.5, ColorAlpha(accent, 220),
			TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	end
end

vgui.Register("z19InfoSection", SECTION, "Panel")

-- шапка досье: фото, имя, номер, подразделение, время, штамп
local HEADER = {}

function HEADER:Init()
	self:Dock(TOP)
	self:SetTall(ScreenScale(56))

	self.photo = self:Add("DModelPanel")
	self.photo:SetMouseInputEnabled(false)
	self.photo:SetFOV(24)
	self.photo.LayoutEntity = function(this, entity)
		entity:SetAngles(Angle(0, 0, 0))

		if (!this.bFramed) then
			this.bFramed = true

			entity:SetupBones()

			local bone = entity:LookupBone("ValveBiped.Bip01_Head1")
			local head = bone and entity:GetBonePosition(bone) or Vector(0, 0, 64)

			if (head == entity:GetPos()) then
				head = Vector(0, 0, 64)
			end

			this:SetLookAt(head + Vector(0, 0, -1))
			this:SetCamPos(head + Vector(34, 6, 1))
		end

		this:RunAnimation()
	end

	self.photo.PaintOver = function(this, width, height)
		local color = GetFactionColor()

		-- сканлайны и рамка фото
		surface.SetDrawColor(0, 0, 0, 40)

		for y = 0, height, 3 do
			surface.DrawRect(0, y, width, 1)
		end

		ix.eui.DrawGradientV(0, height * 0.6, width, height * 0.4, Color(color.r, color.g, color.b, 40))

		surface.SetDrawColor(color.r, color.g, color.b, 220)
		surface.DrawOutlinedRect(0, 0, width, height)

		ix.eui.DrawCorners(3, 3, width - 6, height - 6, 8, Color(255, 255, 255, 120))
	end
end

function HEADER:Setup(suppress)
	self.bShowTime = !suppress.time
	self.bShowName = !suppress.name
	self.format = ix.option.Get("24hourTime", false) and "%d.%m.%Y  %H:%M" or "%d.%m.%Y  %I:%M %p"
end

function HEADER:Update(character)
	local client = LocalPlayer()
	local faction = ix.faction.indices[character:GetFaction()]

	self.name = character:GetName()
	self.number = string.format("%05d", character:GetID() % 100000)
	self.faction = faction and L(faction.name):utf8upper() or "—"

	self.photo:SetModel(client:GetModel())
	self.photo.bFramed = false

	local entity = self.photo.Entity

	if (IsValid(entity)) then
		entity:SetSkin(client:GetSkin())

		for i = 0, client:GetNumBodyGroups() - 1 do
			entity:SetBodygroup(i, client:GetBodygroup(i))
		end

		local sequence = entity:LookupSequence("idle_all_01")

		if (sequence and sequence > 0) then
			entity:ResetSequence(sequence)
		end
	end
end

function HEADER:PerformLayout(width, height)
	local margin = ScreenScale(5)
	local size = height - margin * 2 - 4

	self.photo:SetPos(margin, margin + 4)
	self.photo:SetSize(size * 0.82, size)
end

function HEADER:Think()
	if (self.bShowTime and (self.nextTime or 0) < RealTime()) then
		self.time = ix.date.GetFormatted(self.format)
		self.nextTime = RealTime() + 0.5
	end
end

function HEADER:Paint(width, height)
	local eui = ix.eui
	local accent = eui.colors.accent
	local color = GetFactionColor()
	local margin = ScreenScale(5)

	surface.SetDrawColor(eui.colors.panel)
	surface.DrawRect(0, 0, width, height)

	-- эмблема Фонда водяным знаком
	local logo = ix.z19 and ix.z19.GetMaterial("scp_intro/logo.png")

	if (logo and !logo:IsError()) then
		local size = height * 1.25

		surface.SetMaterial(logo)
		surface.SetDrawColor(255, 255, 255, 7)
		surface.DrawTexturedRect(width - size * 0.75, height * 0.5 - size * 0.5, size, size)
	end

	surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
	surface.DrawRect(0, 0, width, 3)

	local hazardW = math.min(width * 0.22, ScreenScale(60))
	eui.DrawHazard(width - hazardW, 3, hazardW, ScreenScale(3), 220)

	local textX = margin + self.photo:GetWide() + ScreenScale(7)
	local y = margin + ScreenScale(4)

	draw.SimpleText("ЛИЧНОЕ ДЕЛО СОТРУДНИКА  //  ФОНД SCP", "z19InfoMono", textX, y,
		ColorAlpha(eui.colors.textDim, 220), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

	if (self.bShowName) then
		draw.SimpleText(self.name or "", "z19InfoName", textX - 2, y + ScreenScale(6), eui.colors.text,
			TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
	end

	local lineY = y + ScreenScale(25)

	draw.SimpleText("№ " .. (self.number or "00000"), "z19InfoMonoBold", textX, lineY, accent,
		TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

	surface.SetFont("z19InfoMonoBold")
	local numberW = surface.GetTextSize("№ " .. (self.number or "00000"))

	surface.SetDrawColor(color.r, color.g, color.b, 255)
	surface.DrawRect(textX + numberW + 10, lineY + 2, 6, 6)

	draw.SimpleText(self.faction or "", "z19InfoMonoBold", textX + numberW + 22, lineY, color,
		TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

	if (self.bShowTime and self.time) then
		surface.SetMaterial(GetIcon("clock"))
		surface.SetDrawColor(eui.colors.textDim)

		local iconSize = ScreenScale(5)
		local timeY = height - margin - iconSize

		surface.DrawTexturedRect(textX, timeY, iconSize, iconSize)

		draw.SimpleText("ЗОНА-19  ·  " .. self.time, "z19InfoMono", textX + iconSize + 6, timeY + iconSize * 0.5,
			eui.colors.textDim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	-- штамп допуска
	local stamp = "ДОПУЩЕН"

	surface.SetFont("z19InfoStamp")
	local stampW, stampH = surface.GetTextSize(stamp)
	local boxW, boxH = stampW + ScreenScale(8), stampH + ScreenScale(2)
	local boxX, boxY = width - margin - boxW, height - margin - boxH

	surface.SetDrawColor(color.r, color.g, color.b, 170)
	surface.DrawOutlinedRect(boxX, boxY, boxW, boxH, 2)
	surface.DrawOutlinedRect(boxX + 4, boxY + 4, boxW - 8, boxH - 8, 1)

	draw.SimpleText(stamp, "z19InfoStamp", boxX + boxW * 0.5, boxY + boxH * 0.5, ColorAlpha(color, 200),
		TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

	surface.SetDrawColor(eui.colors.hairline)
	surface.DrawOutlinedRect(0, 0, width, height)
end

vgui.Register("z19InfoHeader", HEADER, "Panel")

-- описание (приметы): клик — изменить
local DESCRIPTION = {}

function DESCRIPTION:Init()
	self:Dock(TOP)
	self:SetCursor("hand")
	self:SetMouseInputEnabled(true)
	self:SetTall(ScreenScale(30))

	self.text = self:Add("DLabel")
	self.text:SetFont("z19InfoBody")
	self.text:SetTextColor(ix.eui.colors.text)
	self.text:SetWrap(true)
	self.text:SetContentAlignment(7)
	self.text:SetMouseInputEnabled(false)
	self.text:SetText("")

	self.hover = 0
end

function DESCRIPTION:SetText(text)
	self.text:SetText(text or "")
	self:InvalidateLayout()
end

function DESCRIPTION:PerformLayout(width, height)
	local margin = ScreenScale(5)
	local top = ScreenScale(12)

	self.text:SetPos(margin, top)
	self.text:SetWide(width - margin * 2)
	self.text:SizeToContentsY()

	local newHeight = top + self.text:GetTall() + margin

	if (newHeight != height) then
		self:SetTall(newHeight)
	end
end

function DESCRIPTION:OnCursorEntered()
	if (ix.z19) then
		ix.z19.PlayUI("hover")
	end
end

function DESCRIPTION:OnMousePressed(code)
	if (code == MOUSE_LEFT) then
		if (ix.z19) then
			ix.z19.PlayUI("click")
		end

		ix.command.Send("CharDesc")

		if (IsValid(ix.gui.menu)) then
			ix.gui.menu:Remove()
		end
	end
end

function DESCRIPTION:Paint(width, height)
	local eui = ix.eui
	local accent = eui.colors.accent
	local margin = ScreenScale(5)

	self.hover = math.Approach(self.hover, self:IsHovered() and 1 or 0, FrameTime() * 8)

	surface.SetDrawColor(eui.colors.panel)
	surface.DrawRect(0, 0, width, height)

	surface.SetDrawColor(accent.r, accent.g, accent.b, 14 * self.hover)
	surface.DrawRect(0, 0, width, height)

	surface.SetDrawColor(accent.r, accent.g, accent.b, 120 + 135 * self.hover)
	surface.DrawRect(0, 0, 2, height)

	draw.SimpleText("ОПИСАНИЕ  //  ПРИМЕТЫ", "z19InfoMonoBold", margin, ScreenScale(6), eui.colors.textDim,
		TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

	-- «изменить» справа
	local size = ScreenScale(5)
	local label = "ИЗМЕНИТЬ"

	surface.SetFont("z19InfoMono")
	local labelW = surface.GetTextSize(label)

	draw.SimpleText(label, "z19InfoMono", width - margin, ScreenScale(6), ColorAlpha(accent, 120 + 135 * self.hover),
		TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)

	surface.SetMaterial(GetIcon("edit"))
	surface.SetDrawColor(accent.r, accent.g, accent.b, 120 + 135 * self.hover)
	surface.DrawTexturedRect(width - margin - labelW - size - 6, ScreenScale(6) - size * 0.5, size, size)

	surface.SetDrawColor(eui.colors.hairline)
	surface.DrawOutlinedRect(0, 0, width, height)
end

vgui.Register("z19InfoDescription", DESCRIPTION, "Panel")

-- характеристика: название, значение, посегментная шкала (бонусы — светлее)
local ATTRIBUTE = {}

function ATTRIBUTE:Init()
	self:Dock(TOP)
	self:DockMargin(0, 0, 0, 3)
	self:SetTall(ScreenScale(15))

	self.value = 0
	self.boost = 0
	self.max = 100
	self.shown = 0
end

function ATTRIBUTE:Setup(name, value, boost, maximum)
	self.name = L(name):utf8upper()
	self.value = value
	self.boost = boost or 0
	self.max = math.max(maximum, 1)
end

function ATTRIBUTE:Paint(width, height)
	local eui = ix.eui
	local accent = eui.colors.accent
	local margin = ScreenScale(5)

	-- шкала заполняется при открытии вкладки
	self.shown = Lerp(FrameTime() * 6, self.shown, self.value)

	surface.SetDrawColor(eui.colors.panel)
	surface.DrawRect(0, 0, width, height)

	draw.SimpleText(self.name, "z19InfoMonoBold", margin, height * 0.32, eui.colors.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

	local valueText = string.format("%.1f / %.0f", self.value, self.max)

	if (self.boost != 0) then
		valueText = string.format("%s  (%+.1f)", valueText, self.boost)
	end

	draw.SimpleText(valueText, "z19InfoMono", width - margin, height * 0.32, eui.colors.textDim,
		TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)

	local segments = 24
	local gap = 2
	local barX, barY = margin, height * 0.62
	local barW, barH = width - margin * 2, math.max(height * 0.2, 4)
	local segmentW = (barW - gap * (segments - 1)) / segments
	local base = math.Clamp((self.shown - self.boost) / self.max, 0, 1) * segments
	local total = math.Clamp(self.shown / self.max, 0, 1) * segments

	for i = 1, segments do
		local x = barX + (i - 1) * (segmentW + gap)

		if (i <= base + 0.001) then
			surface.SetDrawColor(accent.r, accent.g, accent.b, 235)
		elseif (i <= total + 0.001) then
			surface.SetDrawColor(255, 236, 170, 200)
		else
			surface.SetDrawColor(255, 255, 255, 14)
		end

		surface.DrawRect(x, barY, segmentW, barH)
	end

	surface.SetDrawColor(eui.colors.hairline)
	surface.DrawOutlinedRect(0, 0, width, height)
end

vgui.Register("z19InfoAttribute", ATTRIBUTE, "Panel")

local PANEL = {}

function PANEL:Init()
	local parent = self:GetParent()

	self:SetSize(math.max(parent:GetWide() * 0.4, ScreenScale(190)), parent:GetTall())
	self:Dock(RIGHT)
	self:DockMargin(0, 0, 0, 0)

	self.VBar:SetWide(ScreenScale(2))
	self.VBar:SetHideButtons(true)
	self.VBar.Paint = function(this, width, height)
		surface.SetDrawColor(255, 255, 255, 8)
		surface.DrawRect(0, 0, width, height)
	end

	self:GetCanvas():DockPadding(0, 0, ScreenScale(3), ScreenScale(6))

	-- entry setup
	local suppress = {}
	hook.Run("CanCreateCharacterInfo", suppress)

	self.suppress = suppress

	self.header = self:Add("z19InfoHeader")
	self.header:Setup(suppress)

	if (!suppress.description) then
		self.description = self:Add("z19InfoDescription")
		self.description:DockMargin(0, ScreenScale(4), 0, 0)
	end

	if (!suppress.characterInfo) then
		local section = self:Add("z19InfoSection")
		section:SetTitle("Сведения", "ФОРМА 19-К")

		self.characterInfo = self:Add("Panel")
		self.characterInfo.list = {}
		self.characterInfo:Dock(TOP) -- no dock margin because this is handled by ixListRow
		self.characterInfo.SizeToContents = function(this)
			local height = 0

			for _, v in ipairs(this:GetChildren()) do
				if (IsValid(v) and v:IsVisible()) then
					if (v.label and v.text) then
						StyleRow(v)
					end

					local _, top, _, bottom = v:GetDockMargin()
					height = height + v:GetTall() + top + bottom
				end
			end

			this:SetTall(height)
		end

		if (!suppress.faction) then
			self.faction = self.characterInfo:Add("ixListRow")
			self.faction:SetList(self.characterInfo.list)
			self.faction:Dock(TOP)
			self.faction.z19Icon = "faction"
		end

		if (!suppress.class) then
			self.class = self.characterInfo:Add("ixListRow")
			self.class:SetList(self.characterInfo.list)
			self.class:Dock(TOP)
			self.class.z19Icon = "class"
		end

		if (!suppress.money) then
			self.money = self.characterInfo:Add("ixListRow")
			self.money:SetList(self.characterInfo.list)
			self.money:Dock(TOP)
			self.money.z19Icon = "money"
			self.money:SizeToContents()
		end

		hook.Run("CreateCharacterInfo", self.characterInfo)
		self.characterInfo:SizeToContents()
	end

	-- no need to update since we aren't showing the attributes panel
	if (!suppress.attributes) then
		local character = LocalPlayer().GetCharacter and LocalPlayer():GetCharacter()

		if (character and !table.IsEmpty(ix.attributes.list)) then
			local section = self:Add("z19InfoSection")
			section:SetTitle(L("attributes"), "ОЦЕНКА ПРИГОДНОСТИ")

			self.attributes = self:Add("Panel")
			self.attributes:Dock(TOP)

			local boost = character:GetBoosts()
			local height = 0

			for k, v in SortedPairsByMemberValue(ix.attributes.list, "name") do
				local attributeBoost = 0

				if (boost[k]) then
					for _, bValue in pairs(boost[k]) do
						attributeBoost = attributeBoost + bValue
					end
				end

				local row = self.attributes:Add("z19InfoAttribute")
				row:Setup(v.name, character:GetAttribute(k, 0), attributeBoost,
					v.maxValue or ix.config.Get("maxAttributes", 100))

				height = height + row:GetTall() + 3
			end

			self.attributes:SetTall(height)
		end
	end

	hook.Run("CreateCharacterInfoCategory", self)
end

function PANEL:Update(character)
	if (!character) then
		return
	end

	local faction = ix.faction.indices[character:GetFaction()]
	local class = ix.class.list[character:GetClass()]
	local factionColor = faction and faction.color or ix.eui.colors.accent

	self.header:Update(character)

	if (self.description) then
		self.description:SetText(character:GetDescription())
	end

	if (self.faction) then
		self.faction.z19Color = factionColor
		self.faction:SetLabelText(L("faction"):utf8upper())
		self.faction:SetText(L(faction.name))
		self.faction:SizeToContents()
	end

	if (self.class) then
		-- don't show class label if the class is the same name as the faction
		if (class and class.name != faction.name) then
			self.class:SetLabelText(L("class"):utf8upper())
			self.class:SetText(L(class.name))
			self.class:SizeToContents()
		else
			self.class:SetVisible(false)
		end
	end

	if (self.money) then
		self.money:SetLabelText(L("money"):utf8upper())
		self.money:SetText(ix.currency.Get(character:GetMoney()))
		self.money:SizeToContents()
	end

	if (self.characterInfo) then
		hook.Run("UpdateCharacterInfo", self.characterInfo, character)

		-- подписи строк других плагинов — тоже капсом
		for _, row in ipairs(self.characterInfo.list) do
			if (IsValid(row) and row.label) then
				row.label:SetText(row.label:GetText():utf8upper())
				row.label:SizeToContents()
				row:UpdateLabelWidths()
			end
		end

		self.characterInfo:SizeToContents()
	end

	hook.Run("UpdateCharacterInfoCategory", self, character)
end

function PANEL:OnSubpanelRightClick()
	properties.OpenEntityMenu(LocalPlayer())
end

vgui.Register("ixCharacterInfo", PANEL, "DScrollPanel")

hook.Add("CreateMenuButtons", "ixCharInfo", function(tabs)
	tabs["you"] = {
		bHideBackground = true,
		buttonColor = team.GetColor(LocalPlayer():Team()),
		Create = function(info, container)
			container.infoPanel = container:Add("ixCharacterInfo")

			container.OnMouseReleased = function(this, key)
				if (key == MOUSE_RIGHT) then
					this.infoPanel:OnSubpanelRightClick()
				end
			end
		end,
		OnSelected = function(info, container)
			container.infoPanel:Update(LocalPlayer():GetCharacter())
			ix.gui.menu:SetCharacterOverview(true)
		end,
		OnDeselected = function(info, container)
			ix.gui.menu:SetCharacterOverview(false)
		end
	}
end)
