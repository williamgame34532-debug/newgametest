
--[[
	Enhanced Helix — ui_derma
	Ре-регистрация ixTextEntry: тёмное поле ввода вместо белёсой заливки —
	глубокий фон, волосяная рамка, акцентная нижняя линия при фокусе,
	мягкий подсвет при наведении. Используется именем/описанием при создании
	персонажа, настройками, поиском и т.д.
]]

DEFINE_BASECLASS("DTextEntry")
local PANEL = {}

AccessorFunc(PANEL, "backgroundColor", "BackgroundColor")

function PANEL:Init()
	self:SetPaintBackground(false)
	self:SetTextColor(ix.eui.colors.text)
	self:SetCursorColor(ix.eui.colors.text)
	self:SetHighlightColor(ColorAlpha(ix.eui.GetAccent(), 90))

	self.backgroundColor = ix.eui.colors.panelLight
end

function PANEL:SetFont(font)
	surface.SetFont(font)
	local _, height = surface.GetTextSize("W@")

	self:SetTall(height + 8)
	BaseClass.SetFont(self, font)
end

function PANEL:Paint(width, height)
	local background = self.backgroundColor or ix.eui.colors.panelLight

	surface.SetDrawColor(background.r, background.g, background.b, self:IsHovered() and 255 or 220)
	surface.DrawRect(0, 0, width, height)

	surface.SetDrawColor(ix.eui.colors.hairline)
	surface.DrawOutlinedRect(0, 0, width, height)

	if (self:HasFocus()) then
		local accent = ix.eui.GetAccent()

		surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
		surface.DrawRect(0, height - 2, width, 2)
	else
		surface.SetDrawColor(ix.eui.colors.hairlineBright.r, ix.eui.colors.hairlineBright.g,
			ix.eui.colors.hairlineBright.b, 45)
		surface.DrawRect(0, height - 1, width, 1)
	end

	BaseClass.Paint(self, width, height)
end

vgui.Register("ixTextEntry", PANEL, "DTextEntry")
