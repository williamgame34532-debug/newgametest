
--[[
	Enhanced Helix — ui_derma
	Экран загрузки персонажей, компоновка Half-Life: Singularity:
	центрированный заголовок «ВЫБЕРИТЕ ПЕРСОНАЖА», ряд крупных карточек
	с 3D-моделями (имя + фракция в нижней плашке, оранжевая рамка выбора),
	снизу по центру кнопки «Начать игру / Удалить персонажа / Вернуться».
	Сетевые сообщения и цепочка удаления — как в оригинале.
]]

local errorModel = "models/error.mdl"
local scrollerLayout = vgui.GetControlTable("DHorizontalScroller").PerformLayout

-- карточка персонажа
local PANEL = {}

AccessorFunc(PANEL, "selected", "Selected", FORCE_BOOL)

function PANEL:Init()
	self:SetCursor("hand")
	self:SetMouseInputEnabled(true)

	self.model = self:Add("ixModelPanel")
	self.model:Dock(FILL)
	self.model:DockMargin(2, 2, 2, ScreenScale(24))
	self.model:SetModel(errorModel)
	self.model:SetFOV(38)
	self.model:SetMouseInputEnabled(false)
	self.model.PaintModel = self.model.Paint

	self.selected = false
end

function PANEL:SetCharacter(character)
	self.character = character

	self.model:SetModel(character:GetModel())

	local entity = self.model.Entity

	if (IsValid(entity)) then
		entity:SetSkin(character:GetData("skin", 0))

		local bodygroups = character:GetData("groups", nil)

		if (istable(bodygroups)) then
			for k, v in pairs(bodygroups) do
				entity:SetBodygroup(k, v)
			end
		end
	end

	local faction = ix.faction.indices[character:GetFaction()]

	self.name = character:GetName()
	self.factionName = faction and L(faction.name):utf8upper() or ""
	self.factionColor = faction and faction.color or color_white
end

function PANEL:GetLoadPanel()
	local scroller = self:GetParent():GetParent()
	return scroller.loadPanel
end

function PANEL:OnMousePressed(code)
	if (code != MOUSE_LEFT) then
		return
	end

	LocalPlayer():EmitSound("Helix.Press")
	self:GetLoadPanel():SelectCard(self)
end

function PANEL:OnMouseDoublePressed(code)
	if (code != MOUSE_LEFT) then
		return
	end

	local loadPanel = self:GetLoadPanel()

	loadPanel:SelectCard(self)
	loadPanel:ChooseCurrent()
end

function PANEL:Paint(width, height)
	local singularity = ix.eui.styles.singularity

	-- подложка карточки
	surface.SetDrawColor(ix.eui.colors.bg.r, ix.eui.colors.bg.g, ix.eui.colors.bg.b, 200)
	surface.DrawRect(0, 0, width, height)

	ix.eui.DrawScanlines(0, 0, width, height, 6, 4)

	-- нижняя информационная плашка
	local stripHeight = ScreenScale(24)

	surface.SetDrawColor(ix.eui.colors.panelLight.r, ix.eui.colors.panelLight.g, ix.eui.colors.panelLight.b, 235)
	surface.DrawRect(0, height - stripHeight, width, stripHeight)

	local factionColor = self.factionColor or color_white

	surface.SetDrawColor(factionColor.r, factionColor.g, factionColor.b, 230)
	surface.DrawRect(0, height - stripHeight, width, 2)

	draw.SimpleText(self.name or "", "eixCardFont", width * 0.5, height - stripHeight * 0.62,
		ix.eui.colors.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

	draw.SimpleText(self.factionName or "", "eixMonoSmallFont", width * 0.5, height - stripHeight * 0.22,
		ColorAlpha(ix.eui.colors.textDim, 220), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

	-- рамка: оранжевая у выбранной, тонкая у остальных
	if (self.selected) then
		local accent = singularity.accent

		surface.SetDrawColor(accent.r, accent.g, accent.b, 18)
		surface.DrawRect(0, 0, width, height - stripHeight)

		surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
		surface.DrawOutlinedRect(0, 0, width, height)
		surface.DrawOutlinedRect(1, 1, width - 2, height - 2)

		ix.eui.DrawCorners(-3, -3, width + 6, height + 6, 14, ColorAlpha(accent, 220), 2)
	elseif (self:IsHovered()) then
		surface.SetDrawColor(ix.eui.colors.hairlineBright)
		surface.DrawOutlinedRect(0, 0, width, height)
	else
		surface.SetDrawColor(ix.eui.colors.hairline)
		surface.DrawOutlinedRect(0, 0, width, height)
	end
end

vgui.Register("eixCharCard", PANEL, "Panel")

-- character load panel
PANEL = {}

AccessorFunc(PANEL, "animationTime", "AnimationTime", FORCE_NUMBER)
AccessorFunc(PANEL, "backgroundFraction", "BackgroundFraction", FORCE_NUMBER)

function PANEL:Init()
	local parent = self:GetParent()
	local modelFOV = (ScrW() > ScrH() * 1.8) and 102 or 78

	self.animationTime = 1
	self.backgroundFraction = 1

	self.cardWidth = math.max(ScrH() * 0.26, 300)
	self.cardHeight = math.max(ScrH() * 0.46, 420)

	-- main panel
	self.panel = self:AddSubpanel("main")
	self.panel:SetTitle(nil)
	self.panel.loadPanel = self
	self.panel.OnSetActive = function()
		self:CreateAnimation(self.animationTime, {
			index = 2,
			target = {backgroundFraction = 1},
			easing = "outQuint",
		})
	end

	-- центрированный заголовок (singularity)
	local header = self.panel:Add("DLabel")
	header:SetFont("eixSubTitleFont")
	header:SetTextColor(ix.eui.colors.text)
	header:SetText(L("loadTitle"):utf8upper())
	header:Dock(TOP)
	header:DockMargin(0, ScreenScale(8), 0, 0)
	header:SetContentAlignment(5)
	header:SetTall(ScreenScale(14))

	local headerLine = self.panel:Add("Panel")
	headerLine:Dock(TOP)
	headerLine:SetTall(ScreenScale(6))
	headerLine.Paint = function(this, width, height)
		local accent = ix.eui.styles.singularity.accent

		surface.SetDrawColor(accent.r, accent.g, accent.b, 200)
		surface.DrawRect(width * 0.5 - 32, height - 2, 64, 2)
	end

	-- нижние кнопки по центру
	local buttonRow = self.panel:Add("Panel")
	buttonRow:Dock(BOTTOM)
	buttonRow:SetTall(ScreenScale(18))

	local continueButton = buttonRow:Add("ixMenuButton")
	continueButton:SetText("choose")
	continueButton:SetTextColor(ix.eui.styles.singularity.accent)
	continueButton:SizeToContents()
	continueButton.DoClick = function()
		self:ChooseCurrent()
	end

	local deleteButton = buttonRow:Add("ixMenuButton")
	deleteButton:SetText("delete")
	deleteButton:SizeToContents()
	deleteButton:SetTextColor(derma.GetColor("Error", deleteButton))
	deleteButton.DoClick = function()
		if (self.character) then
			self:SetActiveSubpanel("delete")
		end
	end

	local back = buttonRow:Add("ixMenuButton")
	back:SetText("return")
	back:SizeToContents()
	back.DoClick = function()
		self:SlideDown()
		parent.mainPanel:Undim()
	end

	buttonRow.buttons = {continueButton, deleteButton, back}
	buttonRow.PerformLayout = function(this, width, height)
		local totalWidth = 0

		for _, v in ipairs(this.buttons) do
			totalWidth = totalWidth + v:GetWide()
		end

		local gap = ScreenScale(8)
		totalWidth = totalWidth + gap * (#this.buttons - 1)

		local x = width * 0.5 - totalWidth * 0.5

		for _, v in ipairs(this.buttons) do
			v:SetPos(x, height * 0.5 - v:GetTall() * 0.5)
			x = x + v:GetWide() + gap
		end
	end

	-- ряд карточек
	self.cards = self.panel:Add("DHorizontalScroller")
	self.cards.loadPanel = self
	self.cards:Dock(FILL)
	self.cards:DockMargin(0, ScreenScale(6), 0, ScreenScale(6))
	self.cards:SetOverlap(-ScreenScale(10))
	self.cards.PerformLayout = function(this, width, height)
		scrollerLayout(this, width, height)

		-- вертикальное центрирование и высота карточек
		for _, v in ipairs(this.Panels) do
			if (IsValid(v)) then
				v:SetTall(math.min(self.cardHeight, height))
				v:SetPos(v.x, height * 0.5 - v:GetTall() * 0.5)
			end
		end

		-- центрируем ряд, если карточки не заполняют всю ширину
		local totalWidth = 0

		for _, v in ipairs(this.Panels) do
			if (IsValid(v)) then
				totalWidth = totalWidth + v:GetWide() - this:GetOverlap()
			end
		end

		if (totalWidth < width) then
			this.pnlCanvas:SetPos(width * 0.5 - totalWidth * 0.5, this.pnlCanvas.y)
		end
	end

	-- character deletion panel (логика оригинала)
	self.delete = self:AddSubpanel("delete")
	self.delete:SetTitle(nil)
	self.delete.OnSetActive = function()
		self.deleteModel:SetModel(self.character:GetModel())
		self:CreateAnimation(self.animationTime, {
			index = 2,
			target = {backgroundFraction = 0},
			easing = "outQuint"
		})
	end

	local deleteInfo = self.delete:Add("Panel")
	deleteInfo:SetSize(parent:GetWide() * 0.5, parent:GetTall())
	deleteInfo:Dock(LEFT)

	local deleteReturn = deleteInfo:Add("ixMenuButton")
	deleteReturn:Dock(BOTTOM)
	deleteReturn:SetText("no")
	deleteReturn:SizeToContents()
	deleteReturn.DoClick = function()
		self:SetActiveSubpanel("main")
	end

	local deleteConfirm = self.delete:Add("ixMenuButton")
	deleteConfirm:Dock(BOTTOM)
	deleteConfirm:SetText("yes")
	deleteConfirm:SetContentAlignment(6)
	deleteConfirm:SizeToContents()
	deleteConfirm:SetTextColor(derma.GetColor("Error", deleteConfirm))
	deleteConfirm.DoClick = function()
		local id = self.character:GetID()

		parent:ShowNotice(1, L("deleteComplete", self.character:GetName()))
		self:Populate(id)
		self:SetActiveSubpanel("main")

		net.Start("ixCharacterDelete")
			net.WriteUInt(id, 32)
		net.SendToServer()
	end

	self.deleteModel = deleteInfo:Add("ixModelPanel")
	self.deleteModel:Dock(FILL)
	self.deleteModel:SetModel(errorModel)
	self.deleteModel:SetFOV(modelFOV)
	self.deleteModel.PaintModel = self.deleteModel.Paint

	local deleteNag = self.delete:Add("Panel")
	deleteNag:SetTall(parent:GetTall() * 0.5)
	deleteNag:Dock(BOTTOM)

	local deleteTitle = deleteNag:Add("DLabel")
	deleteTitle:SetFont("eixTitleFont")
	deleteTitle:SetText(L("areYouSure"):utf8upper())
	deleteTitle:SetTextColor(ix.eui.colors.danger)
	deleteTitle:SizeToContents()
	deleteTitle:Dock(TOP)

	local deleteText = deleteNag:Add("DLabel")
	deleteText:SetFont("ixMenuButtonFont")
	deleteText:SetText(L("deleteConfirm"))
	deleteText:SetTextColor(ix.eui.colors.textDim)
	deleteText:SetContentAlignment(7)
	deleteText:Dock(FILL)

	-- finalize setup
	self:SetActiveSubpanel("main", 0)
end

function PANEL:SelectCard(card)
	for _, v in ipairs(self.cards.Panels) do
		if (IsValid(v)) then
			v:SetSelected(v == card)
		end
	end

	self.character = card.character
end

function PANEL:ChooseCurrent()
	if (!self.character) then
		return
	end

	self:SlideDown(self.animationTime, function()
		net.Start("ixCharacterChoose")
			net.WriteUInt(self.character:GetID(), 32)
		net.SendToServer()
	end, true)
end

function PANEL:OnCharacterDeleted(character)
	if (self.bActive and #ix.characters == 0) then
		self:SlideDown()
	end
end

function PANEL:Populate(ignoreID)
	-- убираем старые карточки
	for _, v in ipairs(self.cards.Panels) do
		if (IsValid(v)) then
			v:Remove()
		end
	end

	self.cards.Panels = {}
	self.character = nil

	local localCharacter = LocalPlayer().GetCharacter and LocalPlayer():GetCharacter()
	local selectedCard

	for i = 1, #ix.characters do
		local id = ix.characters[i]
		local character = ix.char.loaded[id]

		if (character and character:GetID() != ignoreID) then
			local card = vgui.Create("eixCharCard")
			card:SetWide(self.cardWidth)
			card:SetCharacter(character)

			self.cards:AddPanel(card)

			if (localCharacter and character:GetID() == localCharacter:GetID()) then
				selectedCard = card
			end
		end
	end

	if (!selectedCard and #self.cards.Panels > 0) then
		selectedCard = self.cards.Panels[#self.cards.Panels]
	end

	if (IsValid(selectedCard)) then
		self:SelectCard(selectedCard)
	end

	self.cards:InvalidateLayout(true)
end

function PANEL:OnSlideUp()
	self.bActive = true
	self:Populate()
end

function PANEL:OnSlideDown()
	self.bActive = false
end

function PANEL:Paint(width, height)
	derma.SkinFunc("PaintCharacterLoadBackground", self, width, height)
end

vgui.Register("ixCharMenuLoad", PANEL, "ixCharMenuPanel")
