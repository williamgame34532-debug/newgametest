
--[[
	Enhanced Helix — ui_derma
	Загрузка бойца (ixCharMenuLoad): белый фон с «обратным дождём», по центру — модель
	с камерой, приближенной по пояс; сверху имя и описание; по краям стрелки для смены
	бойца (также ← / → на клавиатуре); снизу кнопки «Выбрать» и «Удалить» (с подтверждением).
	Сетевые сообщения выбора и удаления — как в оригинале.
]]

local z19 = ix.z19
local errorModel = "models/error.mdl"

-- стрелка у края экрана
local ARROW = {}

AccessorFunc(ARROW, "direction", "Direction", FORCE_NUMBER)

function ARROW:Init()
	self:SetText("")
	self:SetCursor("hand")

	self.direction = 1
	self.hover = 0
end

function ARROW:OnCursorEntered()
	if (!self:GetDisabled()) then
		LocalPlayer():EmitSound("Helix.Rollover")
	end
end

function ARROW:OnMousePressed(code)
	if (self:GetDisabled()) then
		return
	end

	LocalPlayer():EmitSound("Helix.Press")
	baseclass.Get("DButton").OnMousePressed(self, code)
end

function ARROW:Paint(width, height)
	local disabled = self:GetDisabled()

	self.hover = math.Approach(self.hover, (self:IsHovered() and !disabled) and 1 or 0, FrameTime() * 6)

	local alpha = disabled and 40 or (150 + self.hover * 105)
	local size = height * (0.34 + self.hover * 0.04)
	local cx = width * 0.5 + self.direction * self.hover * ScreenScale(3)
	local cy = height * 0.5

	-- шеврон из двух толстых линий
	local thickness = math.max(3, ScreenScale(1.6))
	local half = size * 0.5

	surface.SetDrawColor(z19.colors.ink.r, z19.colors.ink.g, z19.colors.ink.b, alpha)
	draw.NoTexture()

	for i = 0, thickness - 1 do
		local offset = i - thickness * 0.5
		local tipX = cx + self.direction * half * 0.5 + offset * self.direction

		surface.DrawLine(cx - self.direction * half * 0.5 + offset * self.direction, cy - half, tipX, cy)
		surface.DrawLine(tipX, cy, cx - self.direction * half * 0.5 + offset * self.direction, cy + half)
	end
end

vgui.Register("z19ArrowButton", ARROW, "DButton")

-- экран загрузки
local PANEL = {}

AccessorFunc(PANEL, "animationTime", "AnimationTime", FORCE_NUMBER)
AccessorFunc(PANEL, "backgroundFraction", "BackgroundFraction", FORCE_NUMBER)

function PANEL:Init()
	local parent = self:GetParent()
	local width, height = parent:GetSize()
	local padding = ScreenScale(22)

	self.animationTime = 1
	self.backgroundFraction = 1
	self.characters = {}
	self.index = 1
	self.switch = 1
	self.switchDirection = 1
	self.confirm = 0

	-- назад
	self.backButton = vgui.Create("z19TextButton", self)
	self.backButton:SetLabel("‹  НАЗАД")
	self.backButton:SizeToLabel()
	self.backButton:SetPos(padding, padding)
	self.backButton.DoClick = function()
		parent:ReturnToMain("play")
	end

	-- модель (камера приближена по пояс)
	self.modelX = width * 0.2
	self.model = vgui.Create("ixModelPanel", self)
	self.model:SetPos(self.modelX, height * 0.2)
	self.model:SetSize(width * 0.6, height * 0.8)
	self.model:SetModel(errorModel)
	self.model:SetFOV(30)
	self.model:SetMouseInputEnabled(false)
	self.model.PaintModel = self.model.Paint

	-- описание под именем (с переносом строк)
	self.description = vgui.Create("DLabel", self)
	self.description:SetFont("z19Body")
	self.description:SetTextColor(z19.colors.inkSoft)
	self.description:SetWrap(true)
	self.description:SetContentAlignment(8)
	self.description:SetSize(width * 0.46, ScreenScale(26))
	self.description:SetPos(width * 0.27, padding + ScreenScale(46))
	self.description:SetText("")

	-- стрелки
	local arrowSize = ScreenScale(40)

	self.leftArrow = vgui.Create("z19ArrowButton", self)
	self.leftArrow:SetDirection(-1)
	self.leftArrow:SetSize(arrowSize, arrowSize * 1.6)
	self.leftArrow:SetPos(padding, height * 0.5 - arrowSize * 0.8)
	self.leftArrow.DoClick = function()
		self:Step(-1)
	end

	self.rightArrow = vgui.Create("z19ArrowButton", self)
	self.rightArrow:SetDirection(1)
	self.rightArrow:SetSize(arrowSize, arrowSize * 1.6)
	self.rightArrow:SetPos(width - padding - arrowSize, height * 0.5 - arrowSize * 0.8)
	self.rightArrow.DoClick = function()
		self:Step(1)
	end

	-- кнопки снизу
	local buttonW, buttonH = width * 0.17, ScreenScale(30)
	local gap = ScreenScale(8)

	self.chooseButton = vgui.Create("z19MaterialButton", self)
	self.chooseButton:SetLabel("ВЫБРАТЬ")
	self.chooseButton:SetSublabel("НАЧАТЬ СЛУЖБУ")
	self.chooseButton:SetSize(buttonW, buttonH)
	self.chooseButton:SetPos(width * 0.5 - buttonW - gap * 0.5, height - padding - buttonH)
	self.chooseButton.DoClick = function()
		self:ChooseCurrent()
	end

	self.deleteButton = vgui.Create("z19TextButton", self)
	self.deleteButton:SetLabel("УДАЛИТЬ")
	self.deleteButton:SetLabelFont("z19Button")
	self.deleteButton:SetColor(z19.colors.danger)
	self.deleteButton:SetOutlined(true)
	self.deleteButton:SetSize(buttonW * 0.75, buttonH)
	self.deleteButton:SetPos(width * 0.5 + gap * 0.5, height - padding - buttonH)
	self.deleteButton.DoClick = function()
		if (self.character) then
			self:ShowConfirm(true)
		end
	end

	-- подтверждение удаления
	self.confirmPanel = vgui.Create("EditablePanel", self)
	self.confirmPanel:SetSize(width, height)
	self.confirmPanel:SetVisible(false)
	self.confirmPanel.Paint = function(this, panelWidth, panelHeight)
		local alpha = self.confirm

		surface.SetDrawColor(246, 246, 244, 215 * alpha)
		surface.DrawRect(0, 0, panelWidth, panelHeight)

		local boxW, boxH = panelWidth * 0.36, panelHeight * 0.26
		local boxX, boxY = panelWidth * 0.5 - boxW * 0.5, panelHeight * 0.5 - boxH * 0.5

		z19.DrawShadow(boxX, boxY, boxW, boxH, alpha)

		surface.SetDrawColor(255, 255, 255, 255 * alpha)
		surface.DrawRect(boxX, boxY, boxW, boxH)

		surface.SetDrawColor(z19.colors.danger.r, z19.colors.danger.g, z19.colors.danger.b, 255 * alpha)
		surface.DrawRect(boxX, boxY, boxW, 4)

		draw.SimpleText("УДАЛИТЬ БОЙЦА?", "z19CardTitleSmall", panelWidth * 0.5, boxY + boxH * 0.22,
			ColorAlpha(z19.colors.ink, 255 * alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(self.character and self.character:GetName() or "", "z19Body", panelWidth * 0.5,
			boxY + boxH * 0.42, ColorAlpha(z19.colors.inkSoft, 255 * alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(L("deleteConfirm"), "z19BodySmall", panelWidth * 0.5, boxY + boxH * 0.56,
			ColorAlpha(z19.colors.inkDim, 255 * alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	local confirmButtonW, confirmButtonH = width * 0.1, ScreenScale(16)

	local yes = self.confirmPanel:Add("z19TextButton")
	yes:SetLabel("ДА, УДАЛИТЬ")
	yes:SetColor(z19.colors.danger)
	yes:SetOutlined(true)
	yes:SetSize(confirmButtonW, confirmButtonH)
	yes:SetPos(width * 0.5 - confirmButtonW - gap * 0.5, height * 0.5 + height * 0.13 - confirmButtonH - ScreenScale(6))
	yes.DoClick = function()
		self:DeleteCurrent()
	end

	local no = self.confirmPanel:Add("z19TextButton")
	no:SetLabel("НЕТ")
	no:SetOutlined(true)
	no:SetSize(confirmButtonW, confirmButtonH)
	no:SetPos(width * 0.5 + gap * 0.5, yes.y)
	no.DoClick = function()
		self:ShowConfirm(false)
	end
end

function PANEL:ShowConfirm(bShow)
	if (bShow) then
		self.confirmPanel:SetVisible(true)
		self.confirmPanel:MoveToFront()
	end

	self:CreateAnimation(0.25, {
		index = 3,
		target = {confirm = bShow and 1 or 0},
		easing = "outQuad",

		OnComplete = function(animation, panel)
			if (!bShow) then
				panel.confirmPanel:SetVisible(false)
			end
		end
	})
end

function PANEL:DeleteCurrent()
	if (!self.character) then
		return
	end

	local parent = self:GetParent()
	local id = self.character:GetID()

	parent:ShowNotice(1, L("deleteComplete", self.character:GetName()))
	self:ShowConfirm(false)
	self:Populate(id)

	net.Start("ixCharacterDelete")
		net.WriteUInt(id, 32)
	net.SendToServer()
end

function PANEL:Step(direction)
	local count = #self.characters

	if (count < 2) then
		return
	end

	local newIndex = self.index + direction

	if (newIndex < 1) then
		newIndex = count
	elseif (newIndex > count) then
		newIndex = 1
	end

	self.switchDirection = direction
	self:SelectIndex(newIndex, true)
end

function PANEL:SelectIndex(index, bAnimate)
	local character = self.characters[index]

	if (!character) then
		return
	end

	self.index = index
	self.character = character

	self.model:SetModel(character:GetModel())

	local entity = self.model.Entity

	if (IsValid(entity)) then
		entity:SetSkin(character:GetData("skin", 0))

		local bodygroups = character:GetData("groups", nil)

		if (istable(bodygroups)) then
			for k, v in pairs(bodygroups) do
				entity:SetBodygroup(k, v)
			end
		end
	end

	-- камера по пояс
	z19.FrameModel(self.model, 0.72, 0.62)

	local faction = ix.faction.indices[character:GetFaction()]

	self.name = character:GetName()
	self.factionName = faction and L(faction.name):utf8upper() or ""
	self.description:SetText(character:GetDescription() or "")

	local bMany = #self.characters > 1
	self.leftArrow:SetDisabled(!bMany)
	self.rightArrow:SetDisabled(!bMany)

	if (bAnimate) then
		self.switch = 0

		self:CreateAnimation(0.45, {
			index = 4,
			target = {switch = 1},
			easing = "outCubic"
		})
	else
		self.switch = 1
	end
end

function PANEL:ChooseCurrent()
	if (!self.character or self.bChoosing) then
		return
	end

	local id = self.character:GetID()
	local parent = self:GetParent()

	self.bChoosing = true
	self:SetMouseInputEnabled(false)

	-- затемнение, затем запрос на сервер; меню закроется по CharacterLoaded
	parent:Transition(function()
		self.bChoosing = false

		net.Start("ixCharacterChoose")
			net.WriteUInt(id, 32)
		net.SendToServer()
	end)
end

function PANEL:OnCharacterDeleted(character)
	if (self:IsVisible() and #ix.characters > 0) then
		self:Populate()
	end
end

function PANEL:Populate(ignoreID)
	self.characters = {}
	self.character = nil

	local localCharacter = LocalPlayer().GetCharacter and LocalPlayer():GetCharacter()
	local selected

	for i = 1, #ix.characters do
		local character = ix.char.loaded[ix.characters[i]]

		if (character and character:GetID() != ignoreID) then
			self.characters[#self.characters + 1] = character

			if (localCharacter and character:GetID() == localCharacter:GetID()) then
				selected = #self.characters
			end
		end
	end

	if (#self.characters == 0) then
		self.name = ""
		self.factionName = ""
		self.description:SetText("")
		self.model:SetModel(errorModel)

		self.chooseButton:SetDisabled(true)
		self.deleteButton:SetDisabled(true)
		self.leftArrow:SetDisabled(true)
		self.rightArrow:SetDisabled(true)

		return
	end

	self.chooseButton:SetDisabled(false)
	self.deleteButton:SetDisabled(false)

	self:SelectIndex(selected or #self.characters)
end

function PANEL:OnSlideUp()
	self.bActive = true
	self.bChoosing = false
	self.confirm = 0
	self.confirmPanel:SetVisible(false)
	self:SetMouseInputEnabled(true)
	self:Populate()
	self:RequestFocus()
end

function PANEL:OnSlideDown()
	self.bActive = false
end

function PANEL:OnKeyCodePressed(key)
	if (self.confirm > 0) then
		if (key == KEY_ESCAPE) then
			self:ShowConfirm(false)
		end

		return
	end

	if (key == KEY_LEFT or key == KEY_A) then
		self:Step(-1)
	elseif (key == KEY_RIGHT or key == KEY_D) then
		self:Step(1)
	elseif (key == KEY_ENTER) then
		self:ChooseCurrent()
	end
end

function PANEL:Think()
	-- анимация смены бойца: модель выезжает со стороны стрелки и проявляется
	local offset = (1 - self.switch) * ScreenScale(30) * self.switchDirection

	self.model:SetPos(self.modelX + offset, self.model.y)
	self.model:SetAlpha(255 * self.switch)
	self.description:SetAlpha(255 * self.switch)
end

function PANEL:Paint(width, height)
	z19.PaintWhiteBackground(self, width, height)

	local padding = ScreenScale(22)
	local alpha = 255 * self.switch

	-- водяной знак эмблемы за моделью
	local logo = z19.GetMaterial("scp_intro/logo.png")

	if (!logo:IsError()) then
		local size = height * 0.7

		surface.SetMaterial(logo)
		surface.SetDrawColor(255, 255, 255, 12)
		surface.DrawTexturedRect(width * 0.5 - size * 0.5, height * 0.58 - size * 0.5, size, size)
	end

	-- имя, фракция и счётчик
	draw.SimpleText(self.name or "", "z19Huge", width * 0.5, padding - ScreenScale(4),
		ColorAlpha(z19.colors.ink, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

	local infoY = padding + ScreenScale(30)
	local count = #self.characters

	if (count > 0) then
		local info = string.format("%s   ·   %02d / %02d", self.factionName or "", self.index, count)

		z19.DrawSpaced(info, "z19Mono", width * 0.5, infoY, 3, ColorAlpha(z19.colors.inkSoft, alpha), TEXT_ALIGN_CENTER)

		surface.SetDrawColor(z19.colors.accent.r, z19.colors.accent.g, z19.colors.accent.b, alpha)
		surface.DrawRect(width * 0.5 - ScreenScale(13), infoY + ScreenScale(10), ScreenScale(26), 3)
	end

	-- подсказка
	draw.SimpleText("←  →   СМЕНИТЬ БОЙЦА", "z19Mono", width - padding, height - padding,
		z19.colors.inkDim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)
end

vgui.Register("ixCharMenuLoad", PANEL, "ixCharMenuPanel")
