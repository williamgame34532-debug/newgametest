
--[[
	Enhanced Helix — ui_derma
	Главное меню персонажей «Зона-19» в духе Star Wars Battlefront:
	на фоне — рисованный кадр комплекса, слева колонка карточек с артами
	(«Играть», «Сообщество», «Отключиться»), карточка под курсором подрастает.
	«Играть» уводит колонку и выводит по центру две карточки: «Создать бойца»
	и «Загрузить бойца». Переходы между экранами — через затемнение и появление.
	Сетевая логика и API контейнера (Close, ShowNotice, OnCharacterDeleted…) — как в оригинале.
]]

local z19 = ix.z19
local audioFadeInTime = 2
local animationTime = 0.5
local transitionTime = 0.35
local matrixZScale = Vector(1, 1, 0.0001)

local ART = "scp_menu/"

-- базовая панель экранов меню (создание, загрузка) — API оригинала
DEFINE_BASECLASS("ixSubpanelParent")
local PANEL = {}

function PANEL:Init()
	self:SetSize(self:GetParent():GetSize())
	self:SetPos(0, 0)

	self.childPanels = {}
	self.subpanels = {}
	self.activeSubpanel = ""

	self.currentDimAmount = 0
	self.currentY = 0
	self.currentScale = 1
	self.currentAlpha = 255
	self.targetDimAmount = 255
	self.targetScale = 0.9
end

function PANEL:Dim(length, callback)
	length = length or animationTime
	self.currentDimAmount = 0

	self:CreateAnimation(length, {
		target = {
			currentDimAmount = self.targetDimAmount,
			currentScale = self.targetScale
		},
		easing = "outCubic",
		OnComplete = callback
	})

	self:OnDim()
end

function PANEL:Undim(length, callback)
	length = length or animationTime
	self.currentDimAmount = self.targetDimAmount

	self:CreateAnimation(length, {
		target = {
			currentDimAmount = 0,
			currentScale = 1
		},
		easing = "outCubic",
		OnComplete = callback
	})

	self:OnUndim()
end

function PANEL:OnDim()
end

function PANEL:OnUndim()
end

function PANEL:Paint(width, height)
	local amount = self.currentDimAmount
	local bShouldScale = self.currentScale != 1
	local matrix

	if (bShouldScale) then
		matrix = Matrix()
		matrix:Scale(matrixZScale * self.currentScale)
		matrix:Translate(Vector(
			ScrW() * 0.5 - (ScrW() * self.currentScale * 0.5),
			ScrH() * 0.5 - (ScrH() * self.currentScale * 0.5),
			1
		))

		cam.PushModelMatrix(matrix)
		self.currentMatrix = matrix
	end

	BaseClass.Paint(self, width, height)

	if (bShouldScale) then
		cam.PopModelMatrix()
		self.currentMatrix = nil
	end

	if (amount > 0) then
		surface.SetDrawColor(0, 0, 0, amount)
		surface.DrawRect(0, 0, width, height)
	end
end

vgui.Register("ixCharMenuPanel", PANEL, "ixSubpanelParent")

-- список кнопок оригинала (оставлен для совместимости с плагинами)
PANEL = {}

function PANEL:Init()
	local parent = self:GetParent()
	self:SetSize(parent:GetWide() * 0.25, parent:GetTall())

	self:GetVBar():SetWide(0)
	self:GetVBar():SetVisible(false)
end

function PANEL:Add(name)
	local panel = vgui.Create(name, self)
	panel:Dock(TOP)

	return panel
end

function PANEL:SizeToContents()
	self:GetCanvas():InvalidateLayout(true)

	if (self:GetTall() > self:GetCanvas():GetTall()) then
		self:GetCanvas():Dock(BOTTOM)
	else
		self:GetCanvas():Dock(NODOCK)
	end
end

vgui.Register("ixCharMenuButtonList", PANEL, "DScrollPanel")

-- карточка меню: белая шапка с заголовком, арт снизу, при наведении подрастает
PANEL = {}

AccessorFunc(PANEL, "title", "Title", FORCE_STRING)
AccessorFunc(PANEL, "subtitle", "Subtitle", FORCE_STRING)
AccessorFunc(PANEL, "bLarge", "Large", FORCE_BOOL)

function PANEL:Init()
	self:SetText("")
	self:SetCursor("hand")

	self.title = ""
	self.subtitle = ""
	self.hover = 0
	self.visibility = 1
	self.bLarge = false
end

function PANEL:SetArt(name)
	self.art = z19.GetMaterial(ART .. name)
end

function PANEL:SetBadge(text)
	self.badge = text
end

function PANEL:SetVisibility(fraction)
	self.visibility = fraction
	self:SetAlpha(fraction * 255)
	self:SetMouseInputEnabled(fraction > 0.95)
	self:SetVisible(fraction > 0)
end

function PANEL:OnCursorEntered()
	if (!self:GetDisabled()) then
		LocalPlayer():EmitSound("Helix.Rollover")
	end
end

function PANEL:OnMousePressed(code)
	if (self:GetDisabled() or code != MOUSE_LEFT) then
		return
	end

	LocalPlayer():EmitSound("Helix.Press")
	baseclass.Get("DButton").OnMousePressed(self, code)
end

function PANEL:GetGrowInset()
	return ScreenScale(5)
end

function PANEL:Paint(width, height)
	local disabled = self:GetDisabled()

	self.hover = math.Approach(self.hover, (self:IsHovered() and !disabled) and 1 or 0, FrameTime() * 5)

	local ease = self.hover * self.hover * (3 - 2 * self.hover)
	local inset = self:GetGrowInset() * (1 - ease)
	local x, y = inset, inset
	local cardW, cardH = width - inset * 2, height - inset * 2

	z19.DrawShadow(x, y, cardW, cardH, 0.8 + ease)

	-- шапка
	local headerH = self.bLarge and ScreenScale(30) or ScreenScale(22)

	surface.SetDrawColor(z19.colors.white)
	surface.DrawRect(x, y, cardW, headerH)

	local textX = x + ScreenScale(8)
	local titleFont = self.bLarge and "z19CardTitle" or "z19CardTitleSmall"

	-- длинный заголовок не должен вылезать за карточку
	if (self.bLarge) then
		for _, candidate in ipairs({"z19CardTitle", "z19CardTitleMid", "z19CardTitleSmall"}) do
			titleFont = candidate
			surface.SetFont(candidate)

			if (surface.GetTextSize(self.title) <= cardW - ScreenScale(16)) then
				break
			end
		end
	end

	surface.SetFont(titleFont)
	local _, titleH = surface.GetTextSize(self.title)

	surface.SetFont("z19CardSub")
	local _, subH = surface.GetTextSize(self.subtitle)

	local textY = y + headerH * 0.5 - (titleH + subH) * 0.5 + 2

	draw.SimpleText(self.title, titleFont, textX, textY, disabled and z19.colors.inkDim or z19.colors.ink)
	draw.SimpleText(self.subtitle, "z19CardSub", textX + 2, textY + titleH - 4, z19.colors.inkSoft)

	-- арт
	local artY = y + headerH
	local artH = cardH - headerH

	surface.SetDrawColor(30, 32, 36, 255)
	surface.DrawRect(x, artY, cardW, artH)

	z19.DrawCover(self.art, x, artY, cardW, artH, 1.02 + ease * 0.06, 255)

	if (disabled) then
		surface.SetDrawColor(236, 236, 233, 190)
		surface.DrawRect(x, artY, cardW, artH)
	end

	-- плашка-бейдж в углу арта (как BONUS SCORE)
	if (self.badge) then
		surface.SetFont("z19CardSub")
		local badgeW, badgeH = surface.GetTextSize(self.badge)
		badgeW, badgeH = badgeW + ScreenScale(8), badgeH + ScreenScale(3)

		local badgeX = x + cardW - badgeW - ScreenScale(6)
		local badgeY = y + cardH - badgeH - ScreenScale(6)

		draw.RoundedBox(badgeH * 0.5, badgeX, badgeY, badgeW, badgeH, z19.colors.accent)
		draw.SimpleText(self.badge, "z19CardSub", badgeX + badgeW * 0.5, badgeY + badgeH * 0.5,
			z19.colors.ink, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	-- рамка выделения
	if (ease > 0) then
		surface.SetDrawColor(z19.colors.accent.r, z19.colors.accent.g, z19.colors.accent.b, 255 * ease)
		surface.DrawOutlinedRect(x - 3, y - 3, cardW + 6, cardH + 6, 3)
	end
end

vgui.Register("z19MenuCard", PANEL, "DButton")

-- главный экран
PANEL = {}

AccessorFunc(PANEL, "bUsingCharacter", "UsingCharacter", FORCE_BOOL)

function PANEL:Init()
	local parent = self:GetParent()

	self.bUsingCharacter = LocalPlayer().GetCharacter and LocalPlayer():GetCharacter()
	self.mode = "main"
	self.playFraction = 0

	-- «Играть»
	self.playCard = vgui.Create("z19MenuCard", self)
	self.playCard:SetTitle("ИГРАТЬ")
	self.playCard:SetSubtitle("СОЗДАТЬ ИЛИ ЗАГРУЗИТЬ БОЙЦА")
	self.playCard:SetArt("panel_play.jpg")
	self.playCard:SetLarge(true)
	self.playCard.DoClick = function()
		self:SetMode("play")
	end

	-- «Сообщество»
	self.communityCard = vgui.Create("z19MenuCard", self)
	self.communityCard:SetTitle("СООБЩЕСТВО")
	self.communityCard:SetSubtitle("САЙТ, ДИСКОРД И НОВОСТИ СЕРВЕРА")
	self.communityCard:SetArt("panel_community.jpg")
	self.communityCard.DoClick = function()
		local url = ix.config.Get("communityURL", "")

		if (url != "") then
			gui.OpenURL(url)
		else
			parent:ShowNotice(3, "Ссылка на сообщество не задана (конфиг communityURL).")
		end
	end

	-- «Отключиться» / «Вернуться»
	self.returnButton = vgui.Create("z19MenuCard", self)
	self.returnButton:SetArt("panel_disconnect.jpg")
	self.returnButton.DoClick = function()
		if (self.bUsingCharacter) then
			parent:Close()
		else
			RunConsoleCommand("disconnect")
		end
	end
	self:UpdateReturnButton()

	-- экран «Играть»: две карточки по центру
	self.createCard = vgui.Create("z19MenuCard", self)
	self.createCard:SetTitle("СОЗДАТЬ БОЙЦА")
	self.createCard:SetSubtitle("НОВЫЙ СОТРУДНИК ФОНДА")
	self.createCard:SetArt("panel_create.jpg")
	self.createCard:SetLarge(true)
	self.createCard.DoClick = function()
		parent:OpenCreate()
	end

	self.loadButton = vgui.Create("z19MenuCard", self)
	self.loadButton:SetTitle("ЗАГРУЗИТЬ БОЙЦА")
	self.loadButton:SetSubtitle("ПРОДОЛЖИТЬ СЛУЖБУ")
	self.loadButton:SetArt("panel_load.jpg")
	self.loadButton:SetLarge(true)
	self.loadButton.DoClick = function()
		parent:OpenLoad()
	end

	self.backButton = vgui.Create("z19TextButton", self)
	self.backButton:SetLabel("‹  НАЗАД")
	self.backButton:SetColor(z19.colors.white)
	self.backButton:SizeToLabel()
	self.backButton.DoClick = function()
		self:SetMode("main")
	end

	self:UpdateLoadButton()
	self:ApplyFractions()
end

function PANEL:UpdateLoadButton()
	local count = #ix.characters

	self.loadButton:SetDisabled(count == 0)
	self.loadButton:SetBadge(count > 0 and ("БОЙЦОВ: " .. count) or "НЕТ БОЙЦОВ")
end

function PANEL:UpdateReturnButton(bValue)
	if (bValue != nil) then
		self.bUsingCharacter = bValue
	end

	if (self.bUsingCharacter) then
		self.returnButton:SetTitle("ВЕРНУТЬСЯ")
		self.returnButton:SetSubtitle("К ТЕКУЩЕМУ БОЙЦУ")
	else
		self.returnButton:SetTitle("ОТКЛЮЧИТЬСЯ")
		self.returnButton:SetSubtitle("ПОКИНУТЬ СЕРВЕР")
	end
end

-- "main" — колонка слева, "play" — две карточки по центру
function PANEL:SetMode(mode, bInstant)
	if (self.mode == mode and !bInstant) then
		return
	end

	self.mode = mode

	local target = mode == "play" and 1 or 0

	if (bInstant) then
		self.playFraction = target
		self:ApplyFractions()
		return
	end

	self:CreateAnimation(0.9, {
		index = 30,
		target = {playFraction = target},
		easing = "linear",

		Think = function(animation, panel)
			panel:ApplyFractions()
		end,

		OnComplete = function(animation, panel)
			panel:ApplyFractions()
		end
	})
end

local function Smooth(x)
	x = math.Clamp(x, 0, 1)
	return x * x * (3 - 2 * x)
end

-- раскладка с учётом анимации перехода
function PANEL:ApplyFractions()
	local width, height = self:GetSize()

	if (width <= 0) then
		width, height = ScrW(), ScrH()
	end

	local t = self.playFraction
	local padding = ScreenScale(22)
	local gap = ScreenScale(5)

	-- левая колонка уезжает влево с задержкой между карточками
	local columnX = padding
	local columnW = width * 0.34
	local top = height * 0.2
	local heights = {height * 0.36, height * 0.16, height * 0.16}
	local cards = {self.playCard, self.communityCard, self.returnButton}
	local y = top

	for i, card in ipairs(cards) do
		local local01 = Smooth((t * 1.8) - (i - 1) * 0.15)
		local visibility = 1 - local01

		card:SetPos(columnX - local01 * columnW * 0.5, y)
		card:SetSize(columnW, heights[i])
		card:SetVisibility(visibility)

		y = y + heights[i] + gap
	end

	-- центральные карточки появляются после ухода колонки
	local cardW = width * 0.27
	local cardH = height * 0.52
	local centerY = height * 0.22
	local centerCards = {self.createCard, self.loadButton}
	local totalW = cardW * 2 + padding

	for i, card in ipairs(centerCards) do
		local appear = Smooth((t - 0.45 - (i - 1) * 0.08) / 0.47)

		card:SetSize(cardW, cardH)
		card:SetPos(width * 0.5 - totalW * 0.5 + (i - 1) * (cardW + padding), centerY + (1 - appear) * ScreenScale(18))
		card:SetVisibility(appear)
	end

	local backAppear = Smooth((t - 0.7) / 0.3)

	self.backButton:SetPos(width * 0.5 - self.backButton:GetWide() * 0.5, centerY + cardH + padding * 0.8)
	self.backButton:SetAlpha(backAppear * 255)
	self.backButton:SetVisible(backAppear > 0)
	self.backButton:SetMouseInputEnabled(backAppear > 0.95)
end

function PANEL:PerformLayout(width, height)
	self:ApplyFractions()
end

function PANEL:Paint(width, height)
	local padding = ScreenScale(22)
	local t = self.playFraction

	-- логотип и название сервера
	local logo = z19.GetMaterial("scp_intro/logo.png")
	local logoSize = ScreenScale(22)
	local headerY = padding

	if (!logo:IsError()) then
		surface.SetMaterial(logo)
		surface.SetDrawColor(255, 255, 255, 255)
		surface.DrawTexturedRect(padding, headerY, logoSize, logoSize)
	end

	local schemaName = (L2("schemaName") or Schema.name or "ЗОНА-19")

	draw.SimpleText("ЗОНА-19", "z19Title", padding + logoSize + ScreenScale(6) + 2, headerY - ScreenScale(2) + 2,
		Color(0, 0, 0, 120))
	draw.SimpleText("ЗОНА-19", "z19Title", padding + logoSize + ScreenScale(6), headerY - ScreenScale(2),
		z19.colors.white)
	draw.SimpleText(string.utf8upper(schemaName), "z19Mono", padding + logoSize + ScreenScale(7),
		headerY + logoSize - ScreenScale(4), ColorAlpha(z19.colors.white, 180))

	-- вкладки как в Battlefront: активная — в жёлтой плашке
	local tabs = {{"ГЛАВНАЯ", 1 - Smooth(t * 2)}, {"ИГРАТЬ", Smooth(t * 2 - 0.5)}}
	local tabX = width * 0.5 - ScreenScale(70)

	surface.SetFont("z19Tab")

	for _, tab in ipairs(tabs) do
		local text, active = tab[1], tab[2]
		local tabW, tabH = surface.GetTextSize(text)
		local boxPad = ScreenScale(3)

		if (active > 0.01) then
			surface.SetDrawColor(z19.colors.accent.r, z19.colors.accent.g, z19.colors.accent.b, 255 * active)
			surface.DrawRect(tabX - boxPad, headerY + ScreenScale(3) - boxPad * 0.5, tabW + boxPad * 2, tabH + boxPad)
		end

		local textColor = Color(Lerp(active, 246, 18), Lerp(active, 246, 18), Lerp(active, 244, 20), 255)

		draw.SimpleText(text, "z19Tab", tabX, headerY + ScreenScale(3), textColor)
		tabX = tabX + tabW + ScreenScale(18)
	end

	-- подсказка управления (справа снизу, над версией)
	local hintY = height - padding - ScreenScale(6)

	surface.SetFont("z19ButtonSmall")
	local hintW = surface.GetTextSize("ВЫБРАТЬ")
	local hintX = width - padding - hintW - ScreenScale(12)

	draw.RoundedBox(ScreenScale(4), hintX, hintY - ScreenScale(4), ScreenScale(8), ScreenScale(8),
		ColorAlpha(z19.colors.white, 230))
	draw.SimpleText("ЛКМ", "z19Mono", hintX + ScreenScale(4), hintY, z19.colors.ink, TEXT_ALIGN_CENTER,
		TEXT_ALIGN_CENTER)
	draw.SimpleText("ВЫБРАТЬ", "z19ButtonSmall", hintX + ScreenScale(12), hintY, z19.colors.white,
		TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

	draw.SimpleText("ENHANCED HELIX // " .. tostring(GAMEMODE.Version or ""), "z19Mono", width - 6, height - 4,
		ColorAlpha(z19.colors.white, 90), TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)
end

function PANEL:OnDim()
	self:SetMouseInputEnabled(false)
	self:SetKeyboardInputEnabled(false)
end

function PANEL:OnUndim()
	self:SetVisible(true)
	self:SetMouseInputEnabled(true)
	self:SetKeyboardInputEnabled(true)

	-- персонажа могли удалить — обновляем кнопки
	self.bUsingCharacter = LocalPlayer().GetCharacter and LocalPlayer():GetCharacter()
	self:UpdateReturnButton()
	self:UpdateLoadButton()
end

-- совместимость: в оригинале главный экран затемнялся под открытыми панелями
function PANEL:Dim()
	self:OnDim()
end

function PANEL:Undim()
	self:OnUndim()
end

function PANEL:OnClose()
	for _, v in pairs(self:GetChildren()) do
		if (IsValid(v)) then
			v:SetVisible(false)
		end
	end
end

vgui.Register("ixCharMenuMain", PANEL, "EditablePanel")

-- контейнер меню
PANEL = {}

function PANEL:Init()
	if (IsValid(ix.gui.loading)) then
		ix.gui.loading:Remove()
	end

	if (IsValid(ix.gui.characterMenu)) then
		if (IsValid(ix.gui.characterMenu.channel)) then
			ix.gui.characterMenu.channel:Stop()
		end

		ix.gui.characterMenu:Remove()
	end

	self:SetSize(ScrW(), ScrH())
	self:SetPos(0, 0)

	self.fade = 0
	self.backgroundTime = 0

	-- главный экран
	self.mainPanel = self:Add("ixCharMenuMain")
	self.mainPanel:SetSize(ScrW(), ScrH())
	self.mainPanel:SetPos(0, 0)

	-- создание персонажа
	self.newCharacterPanel = self:Add("ixCharMenuNew")
	self.newCharacterPanel:SlideDown(0)
	self.newCharacterPanel:SetVisible(false)

	-- загрузка персонажа
	self.loadCharacterPanel = self:Add("ixCharMenuLoad")
	self.loadCharacterPanel:SlideDown(0)
	self.loadCharacterPanel:SetVisible(false)

	-- уведомления
	self.notice = self:Add("ixNoticeBar")

	self:MakePopup()
	self.currentAlpha = 255
	self.volume = 0

	ix.gui.characterMenu = self

	if (!IsValid(ix.gui.intro)) then
		self:PlayMusic()
	end

	hook.Run("OnCharacterMenuCreated", self)
end

-- затемнение -> callback -> появление
function PANEL:Transition(callback)
	if (self.bTransitioning) then
		return
	end

	self.bTransitioning = true
	self:SetMouseInputEnabled(false)

	self:CreateAnimation(transitionTime, {
		index = 50,
		target = {fade = 1},
		easing = "inQuad",

		OnComplete = function(animation, panel)
			if (callback) then
				callback()
			end

			panel:CreateAnimation(transitionTime * 1.3, {
				index = 50,
				target = {fade = 0},
				easing = "outQuad",

				OnComplete = function(_, this)
					this.bTransitioning = false

					if (!this.bClosing) then
						this:SetMouseInputEnabled(true)
					end
				end
			})
		end
	})
end

function PANEL:OpenCreate()
	local maximum = hook.Run("GetMaxPlayerCharacter", LocalPlayer()) or ix.config.Get("maxCharacters", 5)

	if (#ix.characters >= maximum) then
		self:ShowNotice(3, L("maxCharacters"))
		return
	end

	self:Transition(function()
		self.mainPanel:OnDim()
		self.mainPanel:SetVisible(false)
		self.newCharacterPanel:SlideUp(0)
	end)
end

function PANEL:OpenLoad()
	if (#ix.characters == 0) then
		return
	end

	self:Transition(function()
		self.mainPanel:OnDim()
		self.mainPanel:SetVisible(false)
		self.loadCharacterPanel:SlideUp(0)
	end)
end

-- вернуться с экрана создания/загрузки (по умолчанию — на экран «Играть»)
function PANEL:ReturnToMain(mode, bInstant)
	local function show()
		if (self.newCharacterPanel:IsVisible()) then
			self.newCharacterPanel:SlideDown(0)
			self.newCharacterPanel:SetVisible(false)
		end

		if (self.loadCharacterPanel:IsVisible()) then
			self.loadCharacterPanel:SlideDown(0)
			self.loadCharacterPanel:SetVisible(false)
		end

		self.mainPanel:SetMode(mode or "play", true)
		self.mainPanel:OnUndim()
	end

	if (bInstant) then
		show()
	else
		self:Transition(show)
	end
end

function PANEL:PlayMusic()
	local path = "sound/" .. ix.config.Get("music")
	local url = path:match("http[s]?://.+")
	local play = url and sound.PlayURL or sound.PlayFile
	path = url and url or path

	play(path, "noplay", function(channel, error, message)
		if (!IsValid(self) or !IsValid(channel)) then
			return
		end

		channel:SetVolume(self.volume or 0)
		channel:Play()

		self.channel = channel

		self:CreateAnimation(audioFadeInTime, {
			index = 10,
			target = {volume = 1},

			Think = function(animation, panel)
				if (IsValid(panel.channel)) then
					panel.channel:SetVolume(self.volume * 0.5)
				end
			end
		})
	end)
end

function PANEL:ShowNotice(type, text)
	self.notice:SetType(type)
	self.notice:SetText(text)
	self.notice:Show()
end

function PANEL:HideNotice()
	if (IsValid(self.notice) and !self.notice:GetHidden()) then
		self.notice:Slide("up", 0.5, true)
	end
end

function PANEL:OnCharacterDeleted(character)
	self.mainPanel:UpdateLoadButton()

	if (#ix.characters == 0 and self.loadCharacterPanel:IsVisible()) then
		self:ReturnToMain("play")
	end

	self.loadCharacterPanel:OnCharacterDeleted(character)
end

function PANEL:OnCharacterLoadFailed(error)
	self.loadCharacterPanel:SetMouseInputEnabled(true)

	if (!self.loadCharacterPanel:IsVisible()) then
		self:OpenLoad()
	end

	self:ShowNotice(3, error)
end

function PANEL:IsClosing()
	return self.bClosing
end

function PANEL:Close(bFromMenu)
	self.bClosing = true
	self.bFromMenu = bFromMenu

	local fadeOutTime = animationTime * 8

	self:CreateAnimation(fadeOutTime, {
		index = 1,
		target = {currentAlpha = 0},

		Think = function(animation, panel)
			panel:SetAlpha(panel.currentAlpha)
		end,

		OnComplete = function(animation, panel)
			panel:Remove()
		end
	})

	self:CreateAnimation(fadeOutTime - 0.1, {
		index = 10,
		target = {volume = 0},

		Think = function(animation, panel)
			if (IsValid(panel.channel)) then
				panel.channel:SetVolume(self.volume * 0.5)
			end
		end,

		OnComplete = function(animation, panel)
			if (IsValid(panel.channel)) then
				panel.channel:Stop()
				panel.channel = nil
			end
		end
	})

	if (bFromMenu) then
		for _, v in pairs(self:GetChildren()) do
			if (IsValid(v)) then
				v:SetVisible(false)
			end
		end
	else
		self.mainPanel.currentAlpha = 255

		self.mainPanel:CreateAnimation(animationTime * 2, {
			target = {currentAlpha = 0},
			easing = "outQuint",

			Think = function(animation, panel)
				panel:SetAlpha(panel.currentAlpha)
			end,

			OnComplete = function(animation, panel)
				panel:SetVisible(false)
			end
		})
	end

	self:SetMouseInputEnabled(false)
	self:SetKeyboardInputEnabled(false)
	gui.EnableScreenClicker(false)
end

function PANEL:Paint(width, height)
	-- рисованный кадр Зоны-19 с медленным «дыханием» камеры
	self.backgroundTime = self.backgroundTime + FrameTime()

	local drift = math.sin(self.backgroundTime * 0.05)

	surface.SetDrawColor(14, 16, 20, 255)
	surface.DrawRect(0, 0, width, height)

	z19.DrawCover(z19.GetMaterial(ART .. "menu_bg.jpg"), 0, 0, width, height, 1.06 + drift * 0.02, 255, drift * 0.6, 0)

	-- затемнение слева под карточками и снизу
	surface.SetMaterial(z19.gradientLeft)
	surface.SetDrawColor(0, 0, 0, 150)
	surface.DrawTexturedRect(0, 0, width * 0.55, height)

	surface.SetMaterial(z19.gradientBottom)
	surface.SetDrawColor(0, 0, 0, 110)
	surface.DrawTexturedRect(0, height * 0.7, width, height * 0.3)
end

function PANEL:PaintOver(width, height)
	if (self.bClosing and self.bFromMenu) then
		surface.SetDrawColor(color_black)
		surface.DrawRect(0, 0, width, height)
	end

	if (self.fade > 0) then
		surface.SetDrawColor(0, 0, 0, self.fade * 255)
		surface.DrawRect(0, 0, width, height)
	end
end

function PANEL:OnRemove()
	if (IsValid(self.channel)) then
		self.channel:Stop()
		self.channel = nil
	end
end

vgui.Register("ixCharMenu", PANEL, "EditablePanel")

if (IsValid(ix.gui.characterMenu)) then
	ix.gui.characterMenu:Remove()

	--TODO: REMOVE ME
	ix.gui.characterMenu = vgui.Create("ixCharMenu")
end
