
--[[
	Enhanced Helix — ui_derma
	Рестайл бизнеса (рынок): карточки товаров в духе рынка resonance —
	тёмные плашки с волосяной рамкой, красный ховер с угловыми засечками,
	рамка редкости (ITEM.rarity / ITEM.rarityColor). Окно оформления заказа
	наследует тему через PaintFrame. Патчатся только методы отрисовки.
]]

local businessItem = vgui.GetControlTable("ixBusinessItem")

if (businessItem) then
	function businessItem:Paint(width, height)
		local accent = ix.eui.styles.resonance.accent
		local itemTable = self.itemTable
		local rarity = itemTable and (itemTable.rarity and ix.eui.styles.resonance.rarity[itemTable.rarity]
			or itemTable.rarityColor)

		surface.SetDrawColor(ix.eui.colors.panelLight.r, ix.eui.colors.panelLight.g,
			ix.eui.colors.panelLight.b, self:IsHovered() and 255 or 210)
		surface.DrawRect(0, 0, width, height)

		if (self:IsHovered()) then
			surface.SetDrawColor(accent.r, accent.g, accent.b, 18)
			surface.DrawRect(0, 0, width, height)

			surface.SetDrawColor(accent.r, accent.g, accent.b, 220)
			surface.DrawOutlinedRect(0, 0, width, height)

			ix.eui.DrawCorners(0, 0, width, height, 6, ColorAlpha(accent, 255))
		elseif (rarity) then
			surface.SetDrawColor(rarity.r, rarity.g, rarity.b, 190)
			surface.DrawOutlinedRect(0, 0, width, height)

			ix.eui.DrawCornerTriangle(0, 0, 12, ColorAlpha(rarity, 255))
		else
			surface.SetDrawColor(ix.eui.colors.hairline)
			surface.DrawOutlinedRect(0, 0, width, height)
		end

		surface.SetDrawColor(ix.eui.colors.hairline.r, ix.eui.colors.hairline.g,
			ix.eui.colors.hairline.b, 25)
		surface.DrawRect(0, height - 1, width, 1)
	end
end
