local PLUGIN = PLUGIN

PLUGIN.name = "Item Rotation"
PLUGIN.author = "Enhanced Helix"
PLUGIN.description = "Поворот прямоугольных предметов в сеточном инвентаре (ПКМ → «Повернуть»). Габариты хранятся на инстансе предмета, состояние — в data.rotated (переживает рестарт)."

--[[
	Как это работает: инстансы предметов в Helix — таблицы с метатаблицей на
	определение предмета, поэтому rawset(width/height) на инстансе меняет
	габариты только этого предмета. Вся логика ядра (CanItemFit, Move,
	Transfer, отрисовка) читает item.width/height с инстанса и автоматически
	видит повёрнутые габариты. Персистентность: data.rotated + починка
	occupancy после загрузки персонажа.
]]

-- привести физические габариты инстанса в соответствие с data.rotated
function PLUGIN.SyncItemSize(item)
	if (!item) then
		return
	end

	local stock = ix.item.list[item.uniqueID]

	if (!stock or stock.width == stock.height) then
		return
	end

	local bRotated = tobool(item.data and item.data.rotated)

	if (bRotated) then
		rawset(item, "width", stock.height)
		rawset(item, "height", stock.width)
	else
		rawset(item, "width", nil)
		rawset(item, "height", nil)
	end
end

-- пересобрать occupancy-сетку инвентаря из фактических позиций/габаритов предметов
function PLUGIN.RepairInventory(inventory)
	if (!inventory or !inventory.slots) then
		return
	end

	local items = {}

	for _, items2 in pairs(inventory.slots) do
		for _, item in pairs(items2) do
			if (istable(item) and item.gridX and !items[item]) then
				items[item] = true
			end
		end
	end

	local slots = {}

	for item in pairs(items) do
		PLUGIN.SyncItemSize(item)

		for x = item.gridX, item.gridX + (item.width or 1) - 1 do
			slots[x] = slots[x] or {}

			for y = item.gridY, item.gridY + (item.height or 1) - 1 do
				slots[x][y] = item
			end
		end
	end

	inventory.slots = slots
end

if (SERVER) then
	util.AddNetworkString("eixItemRotate")
	util.AddNetworkString("eixItemRotated")

	net.Receive("eixItemRotate", function(length, client)
		local itemID = net.ReadUInt(32)
		local item = ix.item.instances[itemID]
		local character = client:GetCharacter()

		if (!item or !character or !item.invID) then
			return
		end

		local inventory = ix.item.inventories[item.invID]

		if (!inventory) then
			return
		end

		-- те же проверки доступа, что и у перемещения предметов
		if (!((inventory.owner and inventory.owner == character:GetID()) or inventory:OnCheckAccess(client))) then
			return
		end

		local stock = ix.item.list[item.uniqueID]

		if (!stock or stock.width == stock.height) then
			return
		end

		local x, y = item.gridX, item.gridY

		if (!x or !y) then
			return
		end

		local oldW, oldH = item.width, item.height
		local newW, newH = oldH, oldW

		-- влезает ли повёрнутый предмет на своём месте (свои клетки игнорируются)
		if (x + newW - 1 > inventory.w or y + newH - 1 > inventory.h
			or !inventory:CanItemFit(x, y, newW, newH, item)) then
			client:Notify("Здесь предмет не повернуть — не хватает места.")
			return
		end

		-- освобождаем старые клетки
		for x2 = x, x + oldW - 1 do
			if (inventory.slots[x2]) then
				for y2 = y, y + oldH - 1 do
					if (inventory.slots[x2][y2] == item) then
						inventory.slots[x2][y2] = nil
					end
				end
			end
		end

		-- переключаем состояние (SetData сам сохранит в БД и разошлёт data владельцу)
		item:SetData("rotated", !item:GetData("rotated", false))
		PLUGIN.SyncItemSize(item)

		-- занимаем новые клетки
		for x2 = x, x + item.width - 1 do
			inventory.slots[x2] = inventory.slots[x2] or {}

			for y2 = y, y + item.height - 1 do
				inventory.slots[x2][y2] = item
			end
		end

		-- сообщаем всем наблюдателям инвентаря — пусть перестроят иконку
		local receivers = inventory:GetReceivers()

		if (istable(receivers) and #receivers > 0) then
			net.Start("eixItemRotated")
				net.WriteUInt(item.invID, 32)
				net.WriteUInt(itemID, 32)
				net.WriteBool(item:GetData("rotated", false))
			net.Send(receivers)
		end
	end)

	-- персистентность: после загрузки персонажа чиним occupancy повёрнутых предметов,
	-- т.к. восстановление из БД размечало сетку по неповёрнутым габаритам
	function PLUGIN:PlayerLoadedCharacter(client, character, oldCharacter)
		timer.Simple(1, function()
			if (!IsValid(client) or !character) then
				return
			end

			local inventory = character:GetInventory()

			if (inventory) then
				local bHasRotated = false

				for _, v in pairs(inventory:GetItems()) do
					if (v:GetData("rotated", false)) then
						bHasRotated = true
						break
					end
				end

				if (bHasRotated) then
					PLUGIN.RepairInventory(inventory)
					inventory:Sync(client)
				end
			end
		end)
	end
else
	-- пункт контекстного меню (hook.Add — надёжнее диспатча плагин-хуков)
	hook.Add("CreateItemInteractionMenu", "eixItemRotate", function(icon, menu, itemTable)
		if (PLUGIN.AddRotateOption) then
			PLUGIN:AddRotateOption(icon, menu, itemTable)
		end
	end)

	function PLUGIN:AddRotateOption(icon, menu, itemTable)
		local stock = ix.item.list[itemTable.uniqueID]

		if (!stock or stock.width == stock.height or !itemTable.invID) then
			return
		end

		menu:AddOption("Повернуть", function()
			net.Start("eixItemRotate")
				net.WriteUInt(itemTable:GetID(), 32)
			net.SendToServer()
		end):SetImage("icon16/arrow_rotate_clockwise.png")
	end

	-- сервер повернул предмет — обновляем локальный инстанс и перестраиваем иконку
	net.Receive("eixItemRotated", function()
		local invID = net.ReadUInt(32)
		local itemID = net.ReadUInt(32)
		local bRotated = net.ReadBool()
		local item = ix.item.instances[itemID]

		if (!item) then
			return
		end

		-- у сторонних наблюдателей data по сети не приходит — выставляем сами
		item.data = item.data or {}
		item.data.rotated = bRotated

		PLUGIN.SyncItemSize(item)

		local character = LocalPlayer():GetCharacter()
		local panelID = (character and invID == character:GetInventory():GetID()) and 1 or invID
		local panel = ix.gui["inv" .. panelID]

		if (!IsValid(panel) or !panel.panels) then
			return
		end

		local icon = panel.panels[itemID]

		if (!IsValid(icon)) then
			return
		end

		local gridX, gridY = icon.gridX, icon.gridY

		-- освобождаем ссылки слотов на старую иконку
		if (icon.slots) then
			for _, slot in ipairs(icon.slots) do
				if (IsValid(slot) and slot.item == icon) then
					slot.item = nil
				end
			end
		end

		icon:Remove()

		local newIcon = panel:AddIcon(item:GetModel() or "models/props_junk/popcan01a.mdl",
			gridX, gridY, item.width, item.height, item:GetSkin())

		if (IsValid(newIcon)) then
			newIcon:SetHelixTooltip(function(tooltip)
				ix.hud.PopulateItemTooltip(tooltip, item)
			end)

			newIcon.itemID = itemID
			panel.panels[itemID] = newIcon
		end
	end)
end
