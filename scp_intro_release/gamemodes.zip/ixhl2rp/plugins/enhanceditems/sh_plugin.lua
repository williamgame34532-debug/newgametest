local PLUGIN = PLUGIN

PLUGIN.name = "Enhanced Items"
PLUGIN.author = "Enhanced Helix"
PLUGIN.description = "Кастомные предметы Enhanced Helix (перенесены из корня plugins/ и items/base/)."
