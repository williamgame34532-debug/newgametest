ITEM.name = "Бочка с отходами"
ITEM.model = "models/hlvr/combine_hazardprops/combinehazardprops_barrel_lock.mdl"
ITEM.description = "Обычная бочка с отходами."
ITEM.category = "Misc"
ITEM.price = 1
ITEM.width = 1
ITEM.height = 1
ITEM.noBusiness = false
