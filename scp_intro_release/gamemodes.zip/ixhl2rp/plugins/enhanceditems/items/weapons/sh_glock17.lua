ITEM.name = "Glock 17"
-- ВНИМАНИЕ: замените на реальную world-модель из аддона TFA NMRiH,
-- в исходнике вместо пути к модели стоял класс оружия.
ITEM.model = "models/weapons/w_pistol.mdl"
ITEM.description = "Пистолет Glock 17."
ITEM.category = "Weapons"
ITEM.price = 1
ITEM.width = 1
ITEM.height = 1
ITEM.noBusiness = false
ITEM.class = "tfa_nmrih_g17"
ITEM.weaponCategory = "sidearm"
