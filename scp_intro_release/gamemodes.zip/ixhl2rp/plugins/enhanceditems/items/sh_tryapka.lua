ITEM.name = "Тряпка"
ITEM.model = "models/hlvr/combine_hazardprops/combinehazardprops_clothe.mdl"
ITEM.description = "Обычная тряпка альянса."
ITEM.category = "Misc"
ITEM.price = 1
ITEM.width = 1
ITEM.height = 1
ITEM.noBusiness = false
