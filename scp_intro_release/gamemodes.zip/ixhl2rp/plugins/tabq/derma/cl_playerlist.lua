
--[[
	TAB-Q — список персонала Зоны-19.
	Панель выезжает слева (не на весь экран), пока зажат TAB: шапка с эмблемой и счётчиком,
	игроки сгруппированы по фракциям, в строке — аватар Steam, имя, описание, ник Steam и пинг.
	Клик мышью показывает курсор, ПКМ по строке — меню игрока (как в табло Helix).
]]

-- плагин грузится раньше ui_derma (по алфавиту), поэтому тему берём при обращении, а не при загрузке
local eui = setmetatable({}, {__index = function(_, key)
	return ix.eui and ix.eui[key]
end})

-- строка игрока
local ROW = {}

function ROW:Init()
	self:SetTall(ScreenScale(19))
	self:SetCursor("hand")
	self.hover = 0

	self.avatar = self:Add("AvatarImage")
	self.avatar:SetMouseInputEnabled(false)
end

function ROW:SetPlayer(client)
	self.player = client
	self.avatar:SetPlayer(client, 64)
	self:Update()
end

function ROW:Update()
	local client = self.player

	if (!IsValid(client)) then
		return
	end

	local character = client:GetCharacter()

	self.name = client:GetName()
	self.description = hook.Run("GetCharacterDescription", client)
		or (character and character:GetDescription()) or ""
	self.steamName = client:SteamName()
	self.ping = client:Ping()

	-- длинное описание — в одну строку с многоточием
	self.description = self.description:gsub("[\r\n]+", " ")
end

function ROW:PerformLayout(width, height)
	local size = height - 8
	self.avatar:SetSize(size, size)
	self.avatar:SetPos(6, 4)
end

local function Ellipsize(text, font, maxWidth)
	surface.SetFont(font)

	if (surface.GetTextSize(text) <= maxWidth) then
		return text
	end

	local length = text:utf8len()

	while (length > 1) do
		length = length - 1

		local cut = text:utf8sub(1, length) .. "…"

		if (surface.GetTextSize(cut) <= maxWidth) then
			return cut
		end
	end

	return "…"
end

function ROW:Paint(width, height)
	if (self:IsHovered()) then
		self.hover = 1
	else
		self.hover = math.Approach(self.hover, 0, FrameTime() * 5)
	end

	surface.SetDrawColor(255, 255, 255, 6 + self.hover * 12)
	surface.DrawRect(0, 0, width, height)

	if (self.hover > 0) then
		local accent = eui.colors.accent

		surface.SetDrawColor(accent.r, accent.g, accent.b, 255 * self.hover)
		surface.DrawRect(0, 0, 2, height)
	end

	-- рамка аватара
	local size = height - 8

	surface.SetDrawColor(eui.colors.hairline)
	surface.DrawOutlinedRect(5, 3, size + 2, size + 2)

	local textX = size + 16
	local pingW = ScreenScale(18)
	local textW = width - textX - pingW - 8

	draw.SimpleText(Ellipsize(self.name or "", "z19TabName", textW), "z19TabName", textX, height * 0.3,
		eui.colors.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

	draw.SimpleText(Ellipsize(self.description or "", "z19TabDesc", textW), "z19TabDesc", textX, height * 0.72,
		eui.colors.textDim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

	-- пинг и ник Steam справа
	local ping = self.ping or 0
	local pingColor = ping < 80 and Color(90, 190, 110) or (ping < 160 and eui.colors.accent or eui.colors.danger)

	draw.SimpleText(ping .. " мс", "z19TabMono", width - 8, height * 0.3, pingColor, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	draw.SimpleText(Ellipsize(self.steamName or "", "z19TabMono", pingW + 20), "z19TabMono", width - 8, height * 0.72,
		ColorAlpha(eui.colors.textDim, 150), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
end

function ROW:OnMousePressed(code)
	local client = self.player

	if (!IsValid(client)) then
		return
	end

	if (code == MOUSE_RIGHT) then
		local menu = DermaMenu()

		menu:AddOption(L("copySteamID"), function()
			SetClipboardText(client:IsBot() and client:EntIndex() or client:SteamID())
		end):SetImage("icon16/page_copy.png")

		menu:AddOption("Открыть профиль Steam", function()
			client:ShowProfile()
		end):SetImage("icon16/user.png")

		hook.Run("PopulateScoreboardPlayerMenu", client, menu)
		menu:Open()
	end
end

vgui.Register("z19PlayerRow", ROW, "Panel")

-- заголовок группы (фракция)
local HEADER = {}

function HEADER:Init()
	self:SetTall(ScreenScale(11))
	self.text = ""
	self.count = 0
	self.color = color_white
end

function HEADER:Paint(width, height)
	local color = self.color

	surface.SetDrawColor(color.r, color.g, color.b, 40)
	surface.DrawRect(0, 0, width, height)

	surface.SetDrawColor(color.r, color.g, color.b, 255)
	surface.DrawRect(0, 0, 3, height)

	draw.SimpleText(self.text, "z19TabGroup", 10, height * 0.5, eui.colors.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	draw.SimpleText(string.format("%02d", self.count), "z19TabMono", width - 8, height * 0.5,
		ColorAlpha(eui.colors.text, 160), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
end

vgui.Register("z19PlayerGroup", HEADER, "Panel")

-- сама панель
local PANEL = {}

local function CreateFonts()
	surface.CreateFont("z19TabTitle", {font = "Zone19 Sans Bold", size = math.max(ScreenScale(11), 24), weight = 700, extended = true})
	surface.CreateFont("z19TabGroup", {font = "Zone19 Sans Semi", size = math.max(ScreenScale(5.6), 14), weight = 600, extended = true})
	surface.CreateFont("z19TabName", {font = "Zone19 Sans Semi", size = math.max(ScreenScale(6.4), 16), weight = 600, extended = true})
	surface.CreateFont("z19TabDesc", {font = "Zone19 Sans Book", size = math.max(ScreenScale(5.2), 13), weight = 400, extended = true})
	surface.CreateFont("z19TabMono", {font = "JetBrains Mono", size = math.max(ScreenScale(4.6), 12), weight = 400, extended = true})
end

CreateFonts()
hook.Add("LoadFonts", "z19PlayerListFonts", CreateFonts)

function PANEL:Init()
	local margin = ScreenScale(10)

	self.panelWidth = math.Clamp(ScrW() * 0.3, 420, 680)
	self.margin = margin
	self.fraction = 0
	self.rows = {}
	self.nextUpdate = 0

	self:SetSize(self.panelWidth, ScrH() - margin * 2)
	self:SetPos(-self.panelWidth, margin)

	self.headerHeight = ScreenScale(34)

	self.scroll = self:Add("DScrollPanel")
	self.scroll:Dock(FILL)
	self.scroll:DockMargin(8, self.headerHeight + 8, 8, 8)
	self.scroll:GetVBar():SetWide(4)

	self:Populate()
	self:Open()
end

function PANEL:Open()
	self.bClosing = false
	self:SetVisible(true)
	self:Populate()

	self:CreateAnimation(0.35, {
		index = 1,
		target = {fraction = 1},
		easing = "outQuint",

		Think = function(animation, panel)
			panel:ApplyFraction()
		end
	})
end

function PANEL:Close()
	if (self.bClosing) then
		return
	end

	self.bClosing = true
	self:DisableCursor()
	CloseDermaMenus()

	self:CreateAnimation(0.25, {
		index = 1,
		target = {fraction = 0},
		easing = "inQuad",

		Think = function(animation, panel)
			panel:ApplyFraction()
		end,

		OnComplete = function(animation, panel)
			panel:SetVisible(false)
		end
	})
end

function PANEL:ApplyFraction()
	self:SetPos(Lerp(self.fraction, -self.panelWidth - 10, self.margin), self.margin)
	self:SetAlpha(255 * self.fraction)
end

function PANEL:EnableCursor()
	if (!self.bCursor) then
		self.bCursor = true
		self:MakePopup()
		self:SetKeyboardInputEnabled(false)
	end
end

function PANEL:DisableCursor()
	if (self.bCursor) then
		self.bCursor = false
		self:SetMouseInputEnabled(false)
		gui.EnableScreenClicker(false)
	end
end

-- пересобрать список: группы по фракциям, внутри — по имени
function PANEL:Populate()
	self.scroll:Clear()
	self.rows = {}

	local groups = {}

	for _, client in ipairs(player.GetAll()) do
		if (!client:GetCharacter() or hook.Run("ShouldShowPlayerOnScoreboard", client) == false) then
			continue
		end

		local teamIndex = client:Team()

		groups[teamIndex] = groups[teamIndex] or {}
		groups[teamIndex][#groups[teamIndex] + 1] = client
	end

	local order = 0

	for teamIndex, clients in SortedPairs(groups) do
		local faction = ix.faction.indices[teamIndex]

		table.sort(clients, function(a, b)
			return a:GetName() < b:GetName()
		end)

		local header = self.scroll:Add("z19PlayerGroup")
		header:Dock(TOP)
		header:DockMargin(0, order > 0 and 8 or 0, 0, 2)
		header:SetZPos(order)
		header.text = faction and L(faction.name):utf8upper() or team.GetName(teamIndex):utf8upper()
		header.color = faction and faction.color or team.GetColor(teamIndex)
		header.count = #clients
		order = order + 1

		for _, client in ipairs(clients) do
			local row = self.scroll:Add("z19PlayerRow")
			row:Dock(TOP)
			row:DockMargin(0, 0, 0, 2)
			row:SetZPos(order)
			row:SetPlayer(client)
			order = order + 1

			self.rows[client] = row
		end
	end

	self.playerCount = player.GetCount()
end

function PANEL:Think()
	if (self.bClosing or CurTime() < self.nextUpdate) then
		return
	end

	self.nextUpdate = CurTime() + 0.5

	-- состав изменился — пересобираем, иначе только обновляем строки
	local bRebuild = player.GetCount() != self.playerCount

	for client, row in pairs(self.rows) do
		if (!IsValid(client) or !IsValid(row) or !client:GetCharacter()) then
			bRebuild = true
			break
		end

		row:Update()
	end

	if (bRebuild) then
		self:Populate()
	end
end

function PANEL:Paint(width, height)
	ix.util.DrawBlur(self, 6)

	surface.SetDrawColor(eui.colors.panel)
	surface.DrawRect(0, 0, width, height)

	surface.SetDrawColor(eui.colors.hairline)
	surface.DrawOutlinedRect(0, 0, width, height)

	-- шапка
	local header = self.headerHeight
	local accent = eui.colors.accent

	surface.SetDrawColor(eui.colors.panelLight)
	surface.DrawRect(0, 0, width, header)

	eui.DrawHazard(0, header - 6, width, 6, 255)

	local logo = ix.z19 and ix.z19.GetMaterial("scp_intro/logo.png")
	local logoSize = header * 0.56

	if (logo and !logo:IsError()) then
		surface.SetMaterial(logo)
		surface.SetDrawColor(255, 255, 255, 240)
		surface.DrawTexturedRect(12, (header - 6) * 0.5 - logoSize * 0.5, logoSize, logoSize)
	end

	local textX = 12 + logoSize + 12

	draw.SimpleText("ПЕРСОНАЛ ЗОНЫ-19", "z19TabTitle", textX, (header - 6) * 0.38, eui.colors.text,
		TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

	draw.SimpleText(string.format("НА СВЯЗИ: %d / %d   ·   %s", player.GetCount(), game.MaxPlayers(), game.GetMap()),
		"z19TabMono", textX, (header - 6) * 0.74, eui.colors.textDim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

	surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
	surface.DrawRect(0, 0, 3, header - 6)

	-- подсказка снизу
	if (!self.bCursor) then
		draw.SimpleText("ЛКМ — КУРСОР   ·   ПКМ ПО ИГРОКУ — МЕНЮ", "z19TabMono", width * 0.5, height - 4,
			ColorAlpha(eui.colors.textDim, 120), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
	end
end

function PANEL:OnRemove()
	gui.EnableScreenClicker(false)
end

vgui.Register("z19PlayerList", PANEL, "EditablePanel")

if (IsValid(ix.gui.playerList)) then
	ix.gui.playerList:Remove()
end
