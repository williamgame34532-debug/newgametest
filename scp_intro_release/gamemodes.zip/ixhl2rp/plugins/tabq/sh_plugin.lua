
local PLUGIN = PLUGIN

PLUGIN.name = "TAB-Q"
PLUGIN.author = "Enhanced Helix"
PLUGIN.description = "TAB (зажать) — список персонала слева: аватар Steam, имя, описание, пинг. " ..
	"Q (нажать) — меню с инвентарём, Q (удерживать) — обычное Q-меню песочницы."

-- сколько держать Q, чтобы открылось обычное Q-меню вместо инвентаря
PLUGIN.holdTime = 0.35

ix.util.Include("cl_hooks.lua")
