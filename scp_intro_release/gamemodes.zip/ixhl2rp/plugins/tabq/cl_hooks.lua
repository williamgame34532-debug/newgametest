
local PLUGIN = PLUGIN

-- TAB: вместо меню Helix — боковая панель персонала (пока клавиша зажата)
function PLUGIN:ScoreboardShow()
	if (!LocalPlayer():GetCharacter()) then
		return true
	end

	if (IsValid(ix.gui.playerList)) then
		ix.gui.playerList:Open()
	else
		ix.gui.playerList = vgui.Create("z19PlayerList")
	end

	return true
end

function PLUGIN:ScoreboardHide()
	if (IsValid(ix.gui.playerList)) then
		ix.gui.playerList:Close()
	end

	return true
end

-- курсор в списке появляется по клику мыши, пока TAB зажат (как в стандартном табло)
function PLUGIN:PlayerBindPress(client, bind, bPressed)
	if (bPressed and IsValid(ix.gui.playerList) and !ix.gui.playerList.bClosing
		and (bind:find("+attack", 1, true) or bind:find("+attack2", 1, true))) then
		ix.gui.playerList:EnableCursor()
		return true
	end
end

-- Q: короткое нажатие — меню с инвентарём, удержание — обычное Q-меню
function PLUGIN:OnSpawnMenuOpen()
	if (!LocalPlayer():GetCharacter()) then
		return
	end

	self.qPressTime = RealTime()
	self.bQHeld = true
	self.bSpawnMenuOpened = false

	return false
end

function PLUGIN:OnSpawnMenuClose()
	if (!self.bQHeld) then
		return
	end

	self.bQHeld = false

	if (self.bSpawnMenuOpened) then
		self.bSpawnMenuOpened = false
		GAMEMODE:OnSpawnMenuClose()
	elseif (IsValid(ix.gui.menu) and !ix.gui.menu.bClosing) then
		ix.gui.menu:Remove()
	elseif (LocalPlayer():GetCharacter()) then
		ix.gui.menuOpenTab = "inv"
		vgui.Create("ixMenu")
	end

	return false
end

function PLUGIN:Think()
	if (self.bQHeld and !self.bSpawnMenuOpened and RealTime() - (self.qPressTime or 0) >= self.holdTime) then
		self.bSpawnMenuOpened = true
		GAMEMODE:OnSpawnMenuOpen()
	end
end
